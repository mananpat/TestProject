/**
 * 
 */
package com.citi.ef.jaxb.test;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import com.citi.ef.util.dataview.config.ViewConfig;



/**
 * @author mp14693
 *
 * File To Xml - unMarshaller example
 */
@RunWith(JUnit4.class)
public class FileToXmlTest {	
	@Test
	public void testSODPositionUnMarshller() throws Exception {
		/*File file = new File("C://MananPatel/DataViewGeneratorUtil/trunk/src/test/resources/SODPositionFile.xml");
		JAXBContext jaxbContext;
		try {
			jaxbContext = JAXBContext.newInstance(Positions.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			Posit sodPositionList = (Positions) jaxbUnmarshaller.unmarshal(file);
			System.out.println(sodPositionList);
		} catch (JAXBException e) {			
			e.printStackTrace();
		}*/
	}
	
	@Test
	public void testMananViewUnMarshller() throws Exception {
		//File file = new File("C://MananPatel/DataViewGeneratorUtil/trunk/src/test/resources/MananSODPositionView.xml");
		File file = new File("../test/resources/MananSODPositionView.xml");
		JAXBContext jaxbContext;
		try {
			jaxbContext = JAXBContext.newInstance(com.citi.ef.util.dataview.config.ViewConfig.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			ViewConfig mananView = (ViewConfig) jaxbUnmarshaller.unmarshal(file);			
			System.out.println(mananView.toString());
		} catch (JAXBException e) {			
			e.printStackTrace();
		}
	}	
	
}
