/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.tableview;


/**
 * Unit test for simple App.
 *
 * @author ms889296
 */
public class AppTest
{
    /**
     * Rigourous Test :-)
     */
	public static void main(String[] args) 
    {
    	/*Object[] inputData = new Object[2];
    	inputData[0] = "\"IBM\", \"International Bus Machine\", \"US\", \"EQ\", new Integer(1000)";
    	inputData[1] = "\"MSFT\", \"Microsoft\", \"US\", \"EQ\", new Integer(1000) ";
    	
    	for(int i =0; i<inputData.length; i++){
    		System.out.println(inputData[0]);
    	}
    	
    	Object[][] data = new Object[][] {inputData};
    	*/
    	Object[][] data = new Object[][] {
				{"ZOne", "1", "A1", new Integer(0) },
				{"DTwo", "2", "A2", new Integer(-1) },
				{"AThree", "3", "A1", new Integer(1) },
		};
    	
    	for(int i =0; i<data.length; i++){
    		System.out.println(data[0]);
    	}
    	
    	/*Object[][] data = new Object[][] {
		{"IBM", "International Bus Machine", "US", "EQ", new Integer(1000) },
		{"MSFT", "Microsoft", "US", "EQ", new Integer(500) },
		{"BP", "British Patrol", "UK", "CSH", new Integer(300) },
		{"IBM", "International Bus Machine", "JP", "EQ", new Integer(200) },
		{"FB", "Facegook", "US", "EQ", new Integer(800) },
		};
	*/
    }
}
