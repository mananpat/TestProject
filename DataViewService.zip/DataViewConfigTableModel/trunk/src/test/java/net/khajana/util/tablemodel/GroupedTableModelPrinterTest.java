/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */

package net.khajana.util.tablemodel;

import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import net.khajana.util.tablemodel.aggrigated.Aggrigator;
import net.khajana.util.tablemodel.impl.aggrigator.IntegerSum;
import net.khajana.util.tablemodel.impl.sorted.SortedTableModelImpl;
import net.khajana.util.tablemodel.sorted.SortedTableModel;
import net.khajana.util.treetablemodel.grouped.AggrigatedGroupedTableModel;
import net.khajana.util.treetablemodel.grouped.GroupedTableModel;
import net.khajana.util.treetablemodel.grouped.GroupedTableModelPrinter;
import net.khajana.util.treetablemodel.impl.grouped.GroupedTableModelImpl;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

/**
 *
 * @author ms889296
 */
@RunWith(JUnit4.class)
public class GroupedTableModelPrinterTest {

//	@Test
	public void testPrintTableModel() {


		GroupedTableModelPrinter printer = new GroupedTableModelPrinter();

		Object[][] data = new Object[][] {
				{"ZOne", "1", "A1", new Integer(0) },
				{"DTwo", "2", "A2", new Integer(-1) },
				{"AThree", "3", "A1", new Integer(1) },
		};

		String[] columnNames = new String[] {
				"Column 1",
				"Column 2",
				"Column 3",
				"Column 4",
		};
		TableModel tableModel = new DefaultTableModel(data, columnNames);
		SortedTableModel sortedTableModel = new SortedTableModelImpl(tableModel);
		sortedTableModel.addSortColumn(2);
		sortedTableModel.sort();

		GroupedTableModel groupedTableModel = new GroupedTableModelImpl(sortedTableModel, sortedTableModel);
		groupedTableModel.addGroupColumn(2);
		groupedTableModel.group();

		printer.print(groupedTableModel, true, false, false);
	}

	@Test
	public void testAggregatedPrintTableModel() {


		GroupedTableModelPrinter printer = new GroupedTableModelPrinter();

		/*Object[][] data = new Object[][] {
				{"ZOne", "1", "ACCT1", new Integer(100), "SEC1" },
				{"DTwo", "2", "ACCT2", new Integer(-300), "SEC1" },
				{"AThree", "3", "ACCT1", new Integer(1200), "SEC2" },
				{"XThree", "4", "ACCT2", new Integer(500), "SEC2" },
				{"Three", "5", "ACCT1", new Integer(100), "SEC1" },

		};

		String[] columnNames = new String[] {
				"Column 1",
				"Column 2",
				"Column 3",
				"Column 4",
				"Column 5",
		};*/
		
		Object[][] data = new Object[][] {
				{"111", "EQ", new Long(1000), "LONG"},
				{"222", "EQ", new Long(500), "LONG"},
				{"333", "CASH",new Long(-300), "SHORT"},
				{"444", "CASH",new Long(200), "LONG"},
				{"555", "EQ", new Long(-800), "SHORT"},

		};

		String[] columnNames = new String[] {
				"FII",
				"ASSETTYPE",
				"QUANTITY",
				"SIDE",				
		};
		
		TableModel tableModel = new DefaultTableModel(data, columnNames);
		SortedTableModel sortedTableModel = new SortedTableModelImpl(tableModel);
		sortedTableModel.addSortColumn(1);
		sortedTableModel.addSortColumn(0);
		sortedTableModel.sort();
				
		TableModelPrinter printer2 = new TableModelPrinter();
		printer2.print(sortedTableModel, "Sorted Table Model", true, true, false);

		GroupedTableModel groupedTableModel = new GroupedTableModelImpl(sortedTableModel, sortedTableModel);
		groupedTableModel.addGroupColumn(1);
		//groupedTableModel.addGroupColumn(3);

		AggrigatedGroupedTableModel aggrigatedGroupedTableModel = (AggrigatedGroupedTableModel) groupedTableModel;
		Aggrigator aggrigator = new IntegerSum();

		aggrigatedGroupedTableModel.setAggrigationCategoryOrder(new String[] {"sum"});
		aggrigatedGroupedTableModel.addAggrigator(2, 0, aggrigator);
		//aggrigatedGroupedTableModel.addAggrigator(2, 1, aggrigator);
		//aggrigatedGroupedTableModel.addAggrigator(2, -1, aggrigator);
		/*aggrigatedGroupedTableModel.addAggrigator(2, 1, aggrigator);
		aggrigatedGroupedTableModel.addAggrigator(2, -1, aggrigator);*/
		//((GroupedTableModelImpl)groupedTableModel).setGrandTotal(true);

		groupedTableModel.group();
		System.out.println(">>>  Aggregated ");
		printer.print(groupedTableModel, true, true, false);
		System.out.println("<<<  Aggregated ");

	}
}
