package net.khajana.processor.impl;

import java.io.File;

import javax.swing.table.TableModel;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import net.khajana.processor.TableModelProcessor;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import com.citi.ef.util.dataview.config.ReportConfig;
import com.citi.ef.util.dataview.config.ViewConfig;

@RunWith(JUnit4.class)
public class TestTableModelProcessorImpl {

	private static final String QUOTE = "\"";
	
	@Test
	public void testMananSODViewUnMarshller() throws Exception {
		//Load the test Data from flat/xml file
		File file = new File("C://MananPatel/DataViewGeneratorUtil/trunk/src/test/resources/SODPositionFile.xml");
		
		JAXBContext jaxbContext;	
		
		ReportConfig report = null;
		file = new File("C://MananPatel/DataViewGeneratorUtil/trunk/src/test/resources/SODPositionReport.xml");
		
		try {
			jaxbContext = JAXBContext.newInstance(ReportConfig.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			report = (ReportConfig) jaxbUnmarshaller.unmarshal(file);
			System.out.println(report);
			
			Marshaller marshaller = jaxbContext.createMarshaller();
	        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
	        marshaller.marshal(report, System.out);	        
		} catch (JAXBException e) {			
			e.printStackTrace();
		}
		
		ViewConfig viewConfig = null;
		file = new File("C://MananPatel/DataViewGeneratorUtil/trunk/src/test/resources/MananSODPositionView.xml");		
		try {
			jaxbContext = JAXBContext.newInstance(ViewConfig.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			viewConfig = (ViewConfig) jaxbUnmarshaller.unmarshal(file);
			System.out.println(viewConfig);
			
			Marshaller marshaller = jaxbContext.createMarshaller();
	        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
	        marshaller.marshal(viewConfig, System.out);	  
	        
		} catch (JAXBException e) {			
			e.printStackTrace();
		}
						
		//get ALL columns from Reports config
		//String[] reportColumns = getReportDisplayColumns(report);				
		
		FileReader fileReader = new FileReader();
		String fileName = "C://MananPatel/DataViewGeneratorUtil/trunk/src/test/resources/data.csv";
		TableModel tableModel = fileReader.readData(fileName);
				
		TableModelProcessor viewProcessor = new TableModelProcessorImpl();
		Object object = viewProcessor.process(tableModel, viewConfig, null);
		
		
		
	}
	
	/*
	 * 
	 */
	/*private String[] getReportDisplayColumns(Report report){
		List<String> columnsList = new ArrayList<String>();
		if(report != null) {
			List<Column> columns = report.getColumns().getColumn();			
			for(Column column : columns){
				columnsList.add("products$"+column.getColumnId());
			}
			
		}
		return columnsList.toArray(new String[columnsList.size()]);
	}	*/
}

