/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */
package net.khajana.util.tableview.impl;

import java.util.ArrayList;
import java.util.Map;

import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import net.khajana.util.tablemodel.TableModelPrinter;
import net.khajana.util.tablemodel.enums.SortOrder;
import net.khajana.util.tablemodel.impl.aggrigator.IntegerSum;
import net.khajana.util.tableview.AggrigateColumn;
import net.khajana.util.tableview.ConfigException;
import net.khajana.util.tableview.GroupColumn;
import net.khajana.util.tableview.SortColumn;
import net.khajana.util.tableview.TableViewConfig;
import net.khajana.util.tableview.TableViewResults;
import net.khajana.util.tableview.ViewColumn;
import net.khajana.util.treetablemodel.grouped.GroupedTableModel;
import net.khajana.util.treetablemodel.grouped.GroupedTableModelPrinter;
import net.khajana.util.treetablemodel.impl.paginated.PaginatedGroupedTableModelImpl;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

/**
*
* @author ms889296
*/
@RunWith(JUnit4.class)
public class DefaultTableViewProducerTest {


	@Test
	public void testView() throws ConfigException {
		TableModel dataTableModel = getDataTableModel();
		
		TableViewConfig tableViewConfig = getTableViewConfig();
        Map<String, SortOrder> overrideSort = null;
        Map<String, String> filterStrings = null;

        DefaultTableViewProducer producer = new DefaultTableViewProducer();
        TableViewResults tableViewResults = producer.processView(dataTableModel, tableViewConfig, overrideSort, filterStrings);
        
        //To print raw data model
       // TableModelPrinter printer = new TableModelPrinter();
       // printer.print(tableViewResults, "Original Table Model", true, true, true);
             
        /* to print raw data model.
        TableModel tableModel = tableViewResults.getNonNullTableModel();
        TableModelPrinter tableModelPrinter = new TableModelPrinter();
        System.out.println("TableModel ................................");
        tableModelPrinter.print(tableModel, true, true);
        System.out.println("\n\n\n\n");
		*/

        // To Print the grouped and aggregated model. This model would be used for csv extract for full xml.
        GroupedTableModel groupedTableModel = tableViewResults.getGroupedTableModel();
        GroupedTableModelPrinter groupedTableModelPrinter = new GroupedTableModelPrinter();
        System.out.println("Grouped TableModel ................................");
        groupedTableModelPrinter.print(groupedTableModel, true, false, false);
        System.out.println("\n\n\n\n");

        // Paginated Model, This model would be used for UI rendering response.
        PaginatedGroupedTableModelImpl paginatedGroupedTableModelImpl = new PaginatedGroupedTableModelImpl(groupedTableModel);
        paginatedGroupedTableModelImpl.setRowsPerPage(2);
        paginatedGroupedTableModelImpl.paginate();

       /* System.out.println("Paginated TableModel ................................");
        for (int pageNo = 0; pageNo < paginatedGroupedTableModelImpl.getPageCount(); pageNo++) {
            GroupedTableModel page = paginatedGroupedTableModelImpl.getPage(pageNo);
            System.out.println("\n\nPage # " + pageNo);
            groupedTableModelPrinter.print(page, true, false, false);
		}*/

	}

	private TableViewConfig getTableViewConfig() {
		
		DefaultTableViewConfig tableViewConfig = new DefaultTableViewConfig();

		String viewName = "TestView1";
		tableViewConfig.setName(viewName);

		ArrayList<ViewColumn> displayColumns = new ArrayList<ViewColumn>();
		displayColumns.add(new DefaultViewColumn("ticker", "products"));
		displayColumns.add(new DefaultViewColumn("desc", "products"));
		displayColumns.add(new DefaultViewColumn("settleCountry", "products"));
		displayColumns.add(new DefaultViewColumn("assetType", "products"));
		displayColumns.add(new DefaultViewColumn("sharesIssued", "products"));
		tableViewConfig.setDisplayColumns(displayColumns);

		ArrayList<GroupColumn> groupByColumns = new ArrayList<GroupColumn>();
		groupByColumns.add(new DefaultGroupColumn("assetType", "products", SortOrder.DESC));
		groupByColumns.add(new DefaultGroupColumn("ticker", "products", SortOrder.DESC));
		groupByColumns.add(new DefaultGroupColumn("settleCountry", "products", SortOrder.ASC));
		tableViewConfig.setGroupByColumns(groupByColumns);

		ArrayList<SortColumn> sortByColumns = new ArrayList<SortColumn>();
		sortByColumns.add(new DefaultSortColumn("desc", "products", SortOrder.ASC));
		tableViewConfig.setSortByColumns(sortByColumns);

		/*ArrayList<AggrigateColumn> aggrigateColumns = new ArrayList<AggrigateColumn>();
		aggrigateColumns.add(new DefaultAggrigateColumn("sharesIssued", "products", new IntegerSum() , "ticker"));
		aggrigateColumns.add(new DefaultAggrigateColumn("sharesIssued", "products", new IntegerSum() , "assetType"));
		aggrigateColumns.add(new DefaultAggrigateColumn("sharesIssued", "products", new IntegerSum()));
		tableViewConfig.setAggrigateColumns(aggrigateColumns);

		ArrayList<String> aggrigateCategoryOrder = new ArrayList<String>();
		aggrigateCategoryOrder.add("sum");
		tableViewConfig.setAggrigateCategoryOrder(aggrigateCategoryOrder);*/

		return tableViewConfig;
	}
	
	private TableModel getDataTableModel() {
		Object[][] data = new Object[][] {
				{"IBM", "International Bus Machine", "US", "EQ", new Integer(1000) },
				{"MSFT", "Microsoft", "US", "EQ", new Integer(500) },
				{"BP", "British Patrol", "UK", "CSH", new Integer(300) },
				{"IBM", "International Bus Machine", "JP", "EQ", new Integer(200) },
				{"FB", "Facegook", "US", "EQ", new Integer(800) },
		};

		String[] columnNames = new String[] {
				"products$ticker",
				"products$desc",
				"products$settleCountry",
				"products$assetType",
				"products$sharesIssued",
		};
		TableModel tableModel = new DefaultTableModel(data, columnNames);
		return tableModel;
	}
}
