/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */

package net.khajana.util.tablemodel;

import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import net.khajana.util.tablemodel.aggrigated.AggrigatedTableModel;
import net.khajana.util.tablemodel.aggrigated.AggrigationException;
import net.khajana.util.tablemodel.aggrigated.Aggrigator;
import net.khajana.util.tablemodel.impl.aggrigated.AggrigatedTableModelImpl;
import net.khajana.util.tablemodel.impl.aggrigator.Count;
import net.khajana.util.tablemodel.impl.aggrigator.IntegerSum;
import net.khajana.util.tablemodel.impl.sorted.SortedTableModelImpl;
import net.khajana.util.tablemodel.sorted.SortedTableModel;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

/**
 *
 * @author ms889296
 */
@RunWith(JUnit4.class)
public class TableModelPrinterTest {

	@Test
	public void testPrintTableModel() throws AggrigationException {


		TableModelPrinter printer = new TableModelPrinter();

		Object[][] data = new Object[][] {
				{"ZOne", "1", "A1", new Integer(0) },
				{"DTwo", "2", "A2", new Integer(-2) },
				{"AThree", "3", "A3", new Integer(1) },
		};

		String[] columnNames = new String[] {
				"Column 1",
				"Column 2",
				"Column 3",
				"Column 4",
		};

		TableModel tableModel = new DefaultTableModel(data, columnNames);
		printer.print(tableModel, "Original Table Model", true, true, true);


		SortedTableModel sortedTableModel = new SortedTableModelImpl(tableModel);
		sortedTableModel.addSortColumn(0);
		sortedTableModel.sort();
		printer.print(sortedTableModel, "Sorted Table Model", true, true, true);


		AggrigatedTableModel aggrigatedTableModel = new AggrigatedTableModelImpl(sortedTableModel, sortedTableModel);

		Aggrigator aggrigator = new IntegerSum();		
		aggrigatedTableModel.addAggrigator(3,  aggrigator); 
		Aggrigator countAgg = new Count();
		aggrigatedTableModel.addAggrigator(3, countAgg);

		aggrigatedTableModel.aggrigate();
		System.out.println("Aggregated Value is " + aggrigatedTableModel.getAggrigatedValue(3, aggrigator) + "   count is " + aggrigatedTableModel.getAggrigatedValue(3, countAgg));
		
		printer.print(aggrigatedTableModel, "aggrigatedTableModel Table Model", true, true, true);

	}

}
