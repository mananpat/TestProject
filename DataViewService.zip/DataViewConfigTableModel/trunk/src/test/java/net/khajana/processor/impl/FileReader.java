/**
 * 
 */
package net.khajana.processor.impl;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import net.khajana.util.tablemodel.TableModelPrinter;
import net.khajana.util.tablemodel.aggrigated.Aggrigator;
import net.khajana.util.tablemodel.impl.aggrigator.IntegerSum;
import net.khajana.util.tablemodel.impl.sorted.SortedTableModelImpl;
import net.khajana.util.tablemodel.sorted.SortedTableModel;
import net.khajana.util.treetablemodel.grouped.AggrigatedGroupedTableModel;
import net.khajana.util.treetablemodel.grouped.GroupedTableModel;
import net.khajana.util.treetablemodel.grouped.GroupedTableModelPrinter;
import net.khajana.util.treetablemodel.impl.grouped.GroupedTableModelImpl;

import org.apache.log4j.Logger;

/**
 * @author mp14693
 *
 */
public class FileReader {
	
	final static Logger log = Logger.getLogger(FileReader.class);
	
	public TableModel readData(String fileName) {
		
		log.info("Starting FileReadProcessor..");		
				
		List<String[]> dataRows = new ArrayList<String[]>();
		String[] headers = null;
		
		try
		{
		  // Open the file that is the first 
			  // command line parameter
			  FileInputStream fstream = new FileInputStream(fileName);
			  // Get the object of DataInputStream
			  DataInputStream in = new DataInputStream(fstream);
			  BufferedReader br = new BufferedReader(new InputStreamReader(in));
			  String strLine;	  
			  
			  int count = 0;
			  while ((strLine = br.readLine()) != null)   {
				 String[] readTokens = null;
				  System.out.println (strLine);
				  readTokens = strLine.split(",");				  
				  if(count==0){					  
					  headers=readTokens; 
				  }
				  else {
					  dataRows.add(readTokens);
				  }
				  
				  count++;
			  }			  
			  //Close the input stream
			  in.close();
		}catch (Exception e){//Catch exception if any
			  System.err.println("Error: " + e.getMessage());
		}		
		
		Object[][] dataRowsArray = new Object[dataRows.size()][headers.length];
		int index = 0;
		for (String[] row : dataRows) {
	        System.out.println("Row = " + Arrays.toString(row));
	        
	        Object[] tempArray = new Object[4];
	        tempArray[0] = row[0];
	        tempArray[1] = row[1];
	        tempArray[2] = new Integer(Integer.parseInt(row[2]));
	        tempArray[3] = row[3];
	        
	        dataRowsArray[index] = tempArray;
	        index++;
	    } 
						
		log.info("FileReadProcessor Completed sucessfully..");
				
		TableModel tableModel = new DefaultTableModel(dataRowsArray, headers);
		TableModelPrinter printer = new TableModelPrinter();
		printer.print(tableModel, true,  false);
		
		return tableModel;
	}	
	
	public static void main(String args[]){
		String fileName = "C://MananPatel/DataViewGeneratorUtil/trunk/src/test/resources/data.csv";
		FileReader reader = new FileReader();
		TableModel tableModel = reader.readData(fileName);
		
				 
		SortedTableModel sortedTableModel = new SortedTableModelImpl(tableModel);
		sortedTableModel.addSortColumn(1);
		sortedTableModel.addSortColumn(0);
		sortedTableModel.sort();
				
		TableModelPrinter printer2 = new TableModelPrinter();
		printer2.print(sortedTableModel, "Sorted Table Model", true, true, false);

		GroupedTableModel groupedTableModel = new GroupedTableModelImpl(sortedTableModel, sortedTableModel);
		groupedTableModel.addGroupColumn(1);
		//groupedTableModel.addGroupColumn(3);

		AggrigatedGroupedTableModel aggrigatedGroupedTableModel = (AggrigatedGroupedTableModel) groupedTableModel;
		Aggrigator aggrigator = new IntegerSum();

		aggrigatedGroupedTableModel.setAggrigationCategoryOrder(new String[] {"sum"});
		aggrigatedGroupedTableModel.addAggrigator(2, 0, aggrigator);
		//aggrigatedGroupedTableModel.addAggrigator(2, 1, aggrigator);
		//aggrigatedGroupedTableModel.addAggrigator(2, -1, aggrigator);
		/*aggrigatedGroupedTableModel.addAggrigator(2, 1, aggrigator);
		aggrigatedGroupedTableModel.addAggrigator(2, -1, aggrigator);*/
		//((GroupedTableModelImpl)groupedTableModel).setGrandTotal(true);

		GroupedTableModelPrinter printer = new GroupedTableModelPrinter();
		groupedTableModel.group();
		System.out.println("\n\n ");
		System.out.println("Printing Final Data \n");
		System.out.println(">>>  Aggregated ");
		printer.print(groupedTableModel, true, true, false);
		System.out.println("<<<  Aggregated ");

		
	}
}

