/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.tablemodel.impl;

import javax.swing.table.TableModel;

import net.khajana.util.tablemodel.DecoratedTableModel;

/**
 *
 * @author ms889296
 */
public class DeligatedTableModel extends DecoratedTableModel {

	int firstRowIndex;
	int lastRowIndex;
	
	private static final long serialVersionUID = 1L;

	public DeligatedTableModel(TableModel tableModel, int firstRowIndex, int lastRowIndex) {
		super(tableModel, false);
		super.setIndices(initIndexes(firstRowIndex, lastRowIndex));
		this.firstRowIndex = firstRowIndex;
		this.lastRowIndex = lastRowIndex;
	}

	public int getFirstRowIndex() {
		return firstRowIndex;
	}

	public int getLastRowIndex() {
		return lastRowIndex;
	}

	private int[] initIndexes(int firstRowIndex, int lastRowIndex) {
		int[] indices = new int[lastRowIndex - firstRowIndex + 1];
		for(int i = 0, j = firstRowIndex, k = lastRowIndex + 1; j < k; j++) {
			indices[i++] = j;
		}
		return indices;
	}
}
