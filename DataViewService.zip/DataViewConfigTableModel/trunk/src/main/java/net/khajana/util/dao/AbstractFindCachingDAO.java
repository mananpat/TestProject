/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.dao;

import net.khajana.util.cache.Cache;
import net.khajana.util.cache.CacheException;

/**
 *
 * @author ms889296
 */
public abstract class AbstractFindCachingDAO <PARAM, VAL,CK> implements IFindCachingDAO<PARAM,VAL,CK> {

    private Cache cache;

    public abstract void init() throws Exception;

    public void setCache(Cache cache) {
        this.cache = cache;
    }

    public Cache getCache() {
        return cache;
    }

    
    public VAL find(PARAM param) throws CacheException {
        VAL results = findFromCache(param);
        if (null == results) {
            // TODO block other threads of the same request.
            results = findFromDataSource(param);
            cache(param, results);
        }

        return results;
	}

    
    public void cache(PARAM param, VAL value) throws CacheException {
        CK cacheKey = getCacheKeyFactory().getCacheKey(param);
		cache.put(cacheKey, value);
    }

    
    public void removeFromCache(PARAM param) throws CacheException {
        CK cacheKey = getCacheKeyFactory().getCacheKey(param);
		cache.remove(cacheKey);
    }

    
    public VAL findFromCache(PARAM param) {
        CK cacheKey = getCacheKeyFactory().getCacheKey(param);
        VAL cached = (VAL)cache.get(cacheKey);
        return cached;
    }
}
