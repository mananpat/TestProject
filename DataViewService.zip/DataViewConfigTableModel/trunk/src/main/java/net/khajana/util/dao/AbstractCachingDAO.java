/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.dao;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import net.khajana.util.cache.Cache;
import net.khajana.util.cache.CacheException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author ms889296
 */
public abstract class AbstractCachingDAO <PARAM,VAL,CK,BT> implements IFindSelectCachingDAO<PARAM,VAL,CK,BT> {

    private Cache cache;

    private Logger logger = LoggerFactory.getLogger(AbstractCachingDAO.class);

    public abstract void init() throws Exception;

    public void setCache(Cache cache) {
        this.cache = cache;
    }

    public Cache getCache() {
        return cache;
    }

 
    public VAL find(PARAM param) throws CacheException {
    	VAL results = findFromCache(param);
        if (null == results) {
            // TODO block other threads of the same request.
            results = findFromDataSource(param);
            cache(param, results);
        }

        return results;
	}

    
    public void cache(PARAM param, VAL value) throws CacheException {
        CK cacheKey = getCacheKeyFactory().getCacheKey(param);
		cache.put(cacheKey, value);
    }

    
    public void removeFromCache(PARAM param) throws CacheException {
        CK cacheKey = getCacheKeyFactory().getCacheKey(param);
		cache.remove(cacheKey);
    }

    
    public VAL findFromCache(PARAM param) {
        CK cacheKey = getCacheKeyFactory().getCacheKey(param);
        VAL cached = (VAL)cache.get(cacheKey);
        return cached;
    }

    
    public Map<PARAM,VAL> select(Set<PARAM> paramList) throws CacheException {
        Map<PARAM,VAL> results = new HashMap<PARAM, VAL>();

        Map<BT, Set<PARAM>> itemsByCategory = groupBySearchType(paramList);

        for (BT category : itemsByCategory.keySet()) {
            Set<PARAM> items = itemsByCategory.get(category);

            Map<PARAM, VAL> cachedValues = selectFromCache(items);

            cachedValues = (cachedValues==null) ? new HashMap<PARAM, VAL>() : cachedValues;
            if (logger.isDebugEnabled()) {
                logger.debug(String.format("Found %s items in cache out of total lookup of %s", cachedValues.size(), items.size()));
            }

            if (null != cachedValues && cachedValues.size() > 0) {
                results.putAll(cachedValues);
            }

            Set<PARAM> notInCache = CollectionUtils.findMissing(items, cachedValues);
            if (notInCache != null && notInCache.size() > 0) {
                // TODO block other threads of the same request.
                Map<PARAM, VAL> dsValues = selectFromDataSource(notInCache);
                cache(dsValues);
                if (null != dsValues && dsValues.size() > 0) {
                    results.putAll(dsValues);
                }
            }
        }

        return results;
	}

    
    public void cache(Map<PARAM, VAL> values) throws CacheException {
       for (PARAM param : values.keySet()) {  // TODO ENTRY SET
			cache.put(getCacheKeyFactory().getCacheKey(param), values.get(param));
        }
    }

    
    public void removeFromCache(Set<PARAM> params) throws CacheException {
        Set<CK> keys = new HashSet<CK>();
        for (PARAM param : params) {
            keys.add(getCacheKeyFactory().getCacheKey(param));
        }
        CK[] keysR = (CK[]) keys.toArray(new Object[keys.size()]);
		cache.remove((Object[])keysR);
    }

    
    public Map<PARAM, VAL> selectFromCache(Set<PARAM> params) {
        Map<CK,PARAM> strToObjKey = new HashMap<CK,PARAM>();
        for (PARAM param : params) {
            strToObjKey.put(getCacheKeyFactory().getCacheKey(param), param);
        }

        CK[] keys = (CK[]) strToObjKey.keySet().toArray(new Object[strToObjKey.size()]);
        Map<CK, VAL> values = (Map<CK, VAL>) cache.get(keys);

        if(values == null || strToObjKey == null) // Null pointer check
            return null;

        Map<PARAM, VAL> mapped = CollectionUtils.mapToOther(strToObjKey, values);
        return mapped;
    }

}
