/**
 * 
 */
package net.khajana.processor.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.swing.table.TableModel;

import net.khajana.processor.TableModelProcessor;
import net.khajana.util.tablemodel.TableModelPrinter;
import net.khajana.util.tablemodel.enums.SortOrder;
import net.khajana.util.tableview.GroupColumn;
import net.khajana.util.tableview.TableViewConfig;
import net.khajana.util.tableview.TableViewResults;
import net.khajana.util.tableview.ViewColumn;
import net.khajana.util.tableview.impl.DefaultGroupColumn;
import net.khajana.util.tableview.impl.DefaultTableViewConfig;
import net.khajana.util.tableview.impl.DefaultTableViewProducer;
import net.khajana.util.tableview.impl.DefaultViewColumn;

import org.apache.log4j.Logger;

import com.citi.ef.util.dataview.config.ColumnClause;
import com.citi.ef.util.dataview.config.ViewConfig;


/**
 * @author mp14693
 *
 */
public class TableModelProcessorImpl extends BaseViewProcessor implements TableModelProcessor {

	final static Logger log = Logger.getLogger(TableModelProcessorImpl.class);
	
	/*
	 * 
	 * (non-Javadoc)
	 * @see net.khajana.ViewProcessor#processViewForData(java.lang.Object[], java.lang.Object[][], com.citi.ef.util.dataview.domain.View, net.khajana.impl.ViewProcessorOutputEnum)
	 */
	public Object process(TableModel dataTableModel, ViewConfig viewConfigTemplate, ViewProcessorOutputEnum outputFormat) throws Exception {
		
		TableViewConfig viewConfig = getTableViewConfig(viewConfigTemplate);		
		
		Map<String, SortOrder> overrideSort = null;
        Map<String, String> filterStrings = null;
        
        DefaultTableViewProducer producer = new DefaultTableViewProducer();
        TableViewResults tableViewResults = producer.processView(dataTableModel, viewConfig, overrideSort, filterStrings);
        
        /*GroupedTableModel groupedTableModel= tableViewResults.getGroupedTableModel();
        GroupedTableModelPrinter printer = new GroupedTableModelPrinter();
        System.out.println(">>>  Aggregated ");
		printer.print(groupedTableModel, true, true, false);
		System.out.println("<<<  Aggregated ");*/
		
        TableModel tableModel = tableViewResults.getNonNullTableModel();
        TableModelPrinter tableModelPrinter = new TableModelPrinter();
        System.out.println("TableModel ................................");
        tableModelPrinter.print(tableModel, "Original Table Model", true, true, true);
        
        
        System.out.println("\n\n\n\n");
        
		return tableViewResults;		
	}
	
	
	/**
	 * Parse VieWconfig and prepare TableViewConfig with various decorators
	 * 
	 * @param viewConfigTemplate
	 * @return TableViewConfig
	 */
	private TableViewConfig getTableViewConfig(ViewConfig viewConfigTemplate) {	
		DefaultTableViewConfig tableViewConfig = new DefaultTableViewConfig();		
		tableViewConfig.setName(viewConfigTemplate.getName());

		List<com.citi.ef.util.dataview.config.DisplayColumn> configDisplayColumns = viewConfigTemplate.getDisplayColumn();		
		ArrayList<ViewColumn> viewColumns = new ArrayList<ViewColumn>();		
		
		if(configDisplayColumns != null && !configDisplayColumns.isEmpty() && configDisplayColumns.size() != 0 ){
			for(com.citi.ef.util.dataview.config.DisplayColumn displayColumn : configDisplayColumns){
				viewColumns.add(new DefaultViewColumn(displayColumn.getColumnId(), "products"));
			}
		}	
		
		tableViewConfig.setDisplayColumns(viewColumns);
		
		
		//grouped column config
		List<ColumnClause> configGroupedColumns = viewConfigTemplate.getGroupedByColumn();
		ArrayList<GroupColumn> groupByColumns = new ArrayList<GroupColumn>();
		if(configGroupedColumns != null && !configGroupedColumns.isEmpty() && configGroupedColumns.size() > 0 ){
			for(ColumnClause groupColumnClause : configGroupedColumns){					
				groupByColumns.add(new DefaultGroupColumn(groupColumnClause.getColumnId(), "products" , SortOrder.valueOf(groupColumnClause.getColumnOrder().value())));
			}
			tableViewConfig.setGroupByColumns(groupByColumns);
		}
				
		
		//sortedBy column config
		/*List<ColumnClause> configSortedColumns = viewConfigTemplate.getSortedByColumns();
		ArrayList<SortColumn> sortedByColumns = new ArrayList<SortColumn>();
		if(configSortedColumns != null && !configSortedColumns.isEmpty() && configSortedColumns.size() > 0 ){
			for(ColumnClause sortByColumn : configSortedColumns){					
				sortedByColumns.add(new DefaultGroupColumn(sortByColumn.getColumnId(), "products" , SortOrder.valueOf(sortByColumn.getColumnOrder().value())));
			}
			tableViewConfig.setSortByColumns(sortedByColumns);
		}*/
		
				
		/*Aggrigator aggrigator = new IntegerSum();
		List<ViewConfig.AggregatedByColumns.Column> configAggregatedColumns = viewConfigTemplate.getAggregatedByColumns().getColumn();
		ArrayList<AggrigateColumn> aggregatedColumns = new ArrayList<AggrigateColumn>();
		if(configAggregatedColumns != null && !configAggregatedColumns.isEmpty() && configAggregatedColumns.size() != 0 ){
		for(ViewConfig.AggregatedByColumns.Column configAggregatedColumn : configAggregatedColumns){					
				aggregatedColumns.add(new DefaultAggrigateColumn(configAggregatedColumn.getColumnId(), "products", aggrigator, "ASSETTYPE"));
			}
		}
		
		List<String> aggrigateCategoryOrder = new ArrayList<String>();
		aggrigateCategoryOrder.add("sum");		
		tableViewConfig.setAggrigateCategoryOrder(aggrigateCategoryOrder);
		tableViewConfig.setAggrigateColumns(aggregatedColumns);
		*/
		
		
/*		
		groupByColumns.add(new DefaultGroupColumn("assetType", "products", SortOrder.DESC));
		groupByColumns.add(new DefaultGroupColumn("ticker", "products", SortOrder.DESC));
		groupByColumns.add(new DefaultGroupColumn("settleCountry", "products", SortOrder.ASC));
*/		
		
		/*viewColumns.add(new DefaultViewColumn("ticker", "products"));
		viewColumns.add(new DefaultViewColumn("desc", "products"));
		viewColumns.add(new DefaultViewColumn("settleCountry", "products"));
		viewColumns.add(new DefaultViewColumn("assetType", "products"));
		viewColumns.add(new DefaultViewColumn("sharesIssued", "products"));*/
		

		/*ArrayList<GroupColumn> groupByColumns = new ArrayList<GroupColumn>();
		groupByColumns.add(new DefaultGroupColumn("assetType", "products", SortOrder.DESC));
		groupByColumns.add(new DefaultGroupColumn("ticker", "products", SortOrder.DESC));
		groupByColumns.add(new DefaultGroupColumn("settleCountry", "products", SortOrder.ASC));
		tableViewConfig.setGroupByColumns(groupByColumns);

		ArrayList<SortColumn> sortByColumns = new ArrayList<SortColumn>();
		sortByColumns.add(new DefaultSortColumn("desc", "products", SortOrder.ASC));
		tableViewConfig.setSortByColumns(sortByColumns);*/


		return tableViewConfig;
	}	
}
