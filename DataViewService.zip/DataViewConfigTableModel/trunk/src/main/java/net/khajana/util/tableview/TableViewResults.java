/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.tableview;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.table.TableModel;

import net.khajana.util.treetablemodel.grouped.GroupedTableModel;

/**
 *
 * @author ms889296
 */
public class TableViewResults {

    private static List<TableModelHeirchy> heircheyList = new ArrayList<TableModelHeirchy>();
    private String tableLogicalName;
    private Map<TableModelHeirchy, TableModel> tableModels = new HashMap<TableModelHeirchy, TableModel>();
    private GroupedTableModel groupedTableModel;
    private Collection<String> dataSetColumns;

    static {
        heircheyList.addAll(Arrays.asList(TableModelHeirchy.values()));
    }

    public String getTableLogicalName() {
        return tableLogicalName;
    }

    public void setTableLogicalName(String tableLogicalName) {
        this.tableLogicalName = tableLogicalName;
    }

    public TableModel getTableModel(TableModelHeirchy tableModelHeirchy) {
        return tableModels.get(tableModelHeirchy);
    }

    public TableModel getNonNullTableModel() {
        return getNonNullTableModel(TableModelHeirchy.values()[TableModelHeirchy.values().length - 1]);
    }

    public TableModel getNonNullTableModel(TableModelHeirchy tableModelHeirchy) {
        int idx = heircheyList.indexOf(tableModelHeirchy);
        for (int i = idx; i > -1; i--) {
            TableModelHeirchy th = heircheyList.get(i);
            TableModel model = tableModels.get(th);
            if (null != model) {
                return model;
            }
        }
        return null;
    }

    public void addTableModel(TableModel tableModel, TableModelHeirchy tableModelHirchy) {
        tableModels.put(tableModelHirchy, tableModel);
    }

    public GroupedTableModel getGroupedTableModel() {
        return groupedTableModel;
    }

    public void setGroupedTableModel(GroupedTableModel groupedTableModel) {
        this.groupedTableModel = groupedTableModel;
    }

    public void setDataSetColumns(Collection<String> dataSetColumns) {
        this.dataSetColumns = dataSetColumns;
    }

    public Collection<String> getDataSetColumns() {
        return dataSetColumns;
    }

    public boolean isColumnInDataSet(String logicalName) {
        return dataSetColumns.contains(logicalName);
    }

    public int getDataSetColumnCount() {
        return dataSetColumns.size();
    }
}
