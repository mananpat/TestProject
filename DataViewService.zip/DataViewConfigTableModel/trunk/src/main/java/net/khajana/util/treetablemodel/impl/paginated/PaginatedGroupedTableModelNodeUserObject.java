/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.treetablemodel.impl.paginated;

/**
 *
 * @author ms889296
 */
public class PaginatedGroupedTableModelNodeUserObject implements Cloneable, java.io.Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private boolean continuedFromPreviousPage;
	private boolean continuedOnNextPage;
	
	public boolean isContinuedFromPreviousPage() {
		return continuedFromPreviousPage;
	}
	public void setContinuedFromPreviousPage(boolean continuedFromPreviousPage) {
		this.continuedFromPreviousPage = continuedFromPreviousPage;
	}
	public boolean isContinuedOnNextPage() {
		return continuedOnNextPage;
	}
	public void setContinuedOnNextPage(boolean continuedOnNextPage) {
		this.continuedOnNextPage = continuedOnNextPage;
	}
	
	/// @Override
	public Object clone() {
		
		try {
			PaginatedGroupedTableModelNodeUserObject newObj = (PaginatedGroupedTableModelNodeUserObject)super.clone();
		
			newObj.continuedFromPreviousPage = continuedFromPreviousPage;
			newObj.continuedOnNextPage = continuedOnNextPage;
			return newObj;
		} catch (CloneNotSupportedException e) {
		    // Won't happen because we implement Cloneable
		    throw new Error(e.toString());
		}
	}
	
//	@Override
//	public String toString() {
//		return ToStringBuilder.reflectionToString(this);
//	}
}
