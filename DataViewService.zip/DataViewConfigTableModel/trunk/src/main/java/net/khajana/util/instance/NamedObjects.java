/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.instance;


import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Collection of Named Objects.  Class can be subclassed to provide an application
 * specific context without the need to implement any additional methods.
 *
 * @author ms889296
 *
 */
public class NamedObjects<T extends NamedObject> implements Iterable<T> {

	private Map<String, T> keyedObjects = new HashMap<String, T>();

	/**
	 *
	 */
	public NamedObjects() {
		super();
	}

	public Iterator<T> iterator() {
		return keyedObjects.values().iterator();
	}

	public void add(T property) {
		keyedObjects.put(property.getName(), property);
	}

	public T get(String propertyName) {
		return keyedObjects.get(propertyName);
	}

	public void remove(String propertyName) {
		keyedObjects.remove(propertyName);
	}

	public int size() {
		return keyedObjects.size();
	}

	/*
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
	*/
}
