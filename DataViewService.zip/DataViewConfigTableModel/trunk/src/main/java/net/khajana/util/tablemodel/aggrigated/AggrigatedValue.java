/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.tablemodel.aggrigated;

/**
 *
 * @author ms889296
 */
public class AggrigatedValue {

	Aggrigator aggrigator;
	Object value;
	
	public AggrigatedValue(Aggrigator aggrigator) {
		this.aggrigator = aggrigator;	
	}

	/**
	 * @return  Returns the aggrigator.
	 */
	public Aggrigator getAggrigator() {
		return aggrigator;
	}

	/**
	 * @param aggrigator  The aggrigator to set.
	 */
	public void setAggrigator(Aggrigator aggrigator) {
		this.aggrigator = aggrigator;
	}

	/**
	 * @return  Returns the value.
	 */
	public Object getValue() {
		return value;
	}

	/**
	 * @param value  The value to set.
	 */
	public void setValue(Object value) {
		this.value = value;
	}

	public boolean equals(Object obj) {
		if (null == obj) {
			return false;
		}
		
		if (obj instanceof AggrigatedValue) {
			return ((AggrigatedValue)obj).aggrigator == this.aggrigator;
		} else if (obj instanceof Aggrigator) {
			return ((Aggrigator)obj) == this.aggrigator;
		}
		return false;
		
	}
}