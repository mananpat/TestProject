/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.tablemodel.impl.filtered;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.TableModel;

import net.khajana.util.tablemodel.DecoratedTableModel;
import net.khajana.util.tablemodel.filtered.ColumnFilteredTableModel;

/**
 *
 * @author ms889296
 */
public abstract class AbstractColumnFilteredTableModel extends DecoratedTableModel implements ColumnFilteredTableModel {

	private List<Integer> visibleColumns = new ArrayList<Integer>();
	
	public AbstractColumnFilteredTableModel(TableModel tableModel) {
		super(tableModel);
	}

	protected abstract List<Integer> filterIt();

	public void filter() {
		List<Integer> acceptColumns = filterIt();
		int[] indices = new int[acceptColumns.size()];
		for (int i = 0; i < indices.length; i++) {
			indices[i] = acceptColumns.get(i);
		}
		super.setColumnIndices(indices);
	}	

	public Integer[] getColumns() {
		return visibleColumns.toArray(new Integer[visibleColumns.size()]);
	}

	public void addColumn(int columnIndex) {
		visibleColumns.add(columnIndex);
	}

	public void addColumns(int[] columnIndexes) {
		for (int columnIndex : columnIndexes) {
			visibleColumns.add(columnIndex);
		}
	}

	public void removeColumn(int columnIndex) {
		visibleColumns.remove(new Integer(columnIndex));

	}

	public void removeAllColumns() {
		visibleColumns.clear();
	}

	@Override
    public String getColumnName(int column) {
		return super.getColumnName(visibleColumns.get(column));
	}
	@Override
	public Class<?> getColumnClass(int columnIndex) {
		return super.getColumnClass(visibleColumns.get(columnIndex));
	}

}
