/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.tableview;

/**
 *
 * @author ms889296
 */
public enum TableModelHeirchy {
	DATA,  	   // The original data model
	FILTERED, // The unwanted rows have been filtered out.
	SORTED,  // Columns for grouping and sorting have been sorted here
	LOGICAL_COLUMN_FILTERED,  // This includes the grouped and display columns.  Grouped columns first.
	//AGGRIGATED_LOGICAL_COLUMN_FILTERED, // model returns aggrigated values, the grouped columns first.
	COLUMN_FILTERED, // This has only the display columns
	//AGGRIGATED_COLUMN_FILTERED, // model returns aggrigated values, the underlying tablemodel may or may not include grouped columns.
}
