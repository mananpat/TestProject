/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.treetablemodel.impl.paginated;

import net.khajana.util.treetablemodel.PaginatedTreeTableModel;

/**
 *
 * @author ms889296
 */
public abstract class AbstractPaginatedTreeTableModel<T> implements PaginatedTreeTableModel<T> {

	private int rowsPerPage = 25;
	
	/**
	 * The page number for each row index. eg. <br> a[0] = 0  = row 0, page 0, <br>  a[1] = 0 = row 1, page 0, <br> a[2] = 1 = row 2, page 1. <br> as it can be seen, everything is 0, based, so page 0 really means page 1 of a document, and row 0 is really the 1st row of the document.
	 */
	private int[] indicesPageNumber;

	private T[] treeTableModels;
	
	public int getRowsPerPage() {
		return rowsPerPage;
	}

	public void setRowsPerPage(int rowsPerPage) {
		this.rowsPerPage = rowsPerPage;
	}

	public T getPage(int pageNumber) {
		return treeTableModels[pageNumber];
	}

	public int getPageCount() {
		return treeTableModels.length;
	}

	public int getPageNumber(int rowIndex) {
		return indicesPageNumber[rowIndex];
	}

	public void paginate() {
		paginateIt();
	}
	
	protected void init(int[] indicesPageNumber, T[] treeTableModels) {
		this.indicesPageNumber = indicesPageNumber;
		this.treeTableModels = treeTableModels;
	}

	protected abstract void paginateIt();
}
