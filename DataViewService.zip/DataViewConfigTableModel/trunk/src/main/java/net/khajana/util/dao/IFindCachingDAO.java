/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.dao;

import net.khajana.util.cache.CacheException;
import net.khajana.util.cache.CacheKeyFactory;

/**
 *
 * @author ms889296
 */
public interface IFindCachingDAO <PARAM,VAL,CK> {

    public VAL find(PARAM param) throws CacheException;

    public VAL findFromCache(PARAM param);
    public VAL findFromDataSource(PARAM param);

    public CacheKeyFactory<PARAM,CK> getCacheKeyFactory();
    public void cache(PARAM param, VAL value) throws CacheException;
    public void removeFromCache(PARAM param) throws CacheException;

}
