/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.crud;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

/**
 * Use this interface to define all dao objects that are used for crud purpose.
 *
 * @author ms889296
 */
public interface ICrudDAO<ENTITY,ID,C extends Serializable> {

    ENTITY findById(Class<ENTITY> clazz, ID id);
    List<ENTITY> findAll(Class<ENTITY> entityClass);

    /**
     * The contents of the returned ENTITY are not guranteed to be complete, as they depend on the
     * underlying persistence layer.  For example, Hibernate returns a fully populated object,
     * whereas JDO returns only the ID that was generated.
     * @param entity
     * @return ENTITY whose contents depending on the underlying persistence layer.
     */
    ENTITY saveOrUpdate(ENTITY entity);

    /**
     * The contents of the returned ENTITY are not guranteed to be complete, as they depend on the
     * underlying persistence layer.  For example, Hibernate returns a fully populated object,
     * whereas JDO returns only the ID that was generated.
     * @param entity
     * @return ENTITY whose contents depending on the underlying persistence layer.
     */
    Collection<ENTITY> saveOrUpdateAll(Collection<ENTITY> entityList);

    void delete(ENTITY entity);
    int  deleteAll(Class<ENTITY> entity);

    public List<ENTITY> findByCriteria(C criteria);
    public List<ENTITY> findByCriteria(C criteria, int firstResult, int maxResults);
}
