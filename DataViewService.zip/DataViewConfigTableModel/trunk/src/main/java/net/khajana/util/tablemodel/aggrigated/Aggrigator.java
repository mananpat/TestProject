/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.tablemodel.aggrigated;

import javax.swing.table.TableModel;

/**
 *
 * @author ms889296
 */
public interface Aggrigator {

	public String getCategory();

	/**
	 * @param dataTableModel will contain the rows in the same order as the result model, except that it will contain all possible columns.
	 * @param viewModel will only contains the actual columns that are in the result table.
	 */
	public Object aggrigate(TableModel dataTableModel, TableModel viewModel, int dataColumnIndex, int viewColumnIndex) throws AggrigationException;
	public Object aggrigate(TableModel dataTableModel, TableModel viewModel, int dataColumnIndex, int viewColumnIndex, int firstRow, int lastRow) throws AggrigationException;
	public Object aggrigate(TableModel dataTableModel, TableModel viewModel, int dataColumnIndex, int viewColumnIndex, int[] rowIndexes) throws AggrigationException;

}
