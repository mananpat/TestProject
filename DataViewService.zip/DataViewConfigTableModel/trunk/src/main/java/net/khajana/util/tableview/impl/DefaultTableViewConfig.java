/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.tableview.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.khajana.util.instance.NamedObject;
import net.khajana.util.tablemodel.enums.VariableSeperator;
import net.khajana.util.tableview.AggrigateColumn;
import net.khajana.util.tableview.FilterColumn;
import net.khajana.util.tableview.GroupColumn;
import net.khajana.util.tableview.SortColumn;
import net.khajana.util.tableview.TableViewConfig;
import net.khajana.util.tableview.ViewColumn;

import org.apache.commons.lang.StringUtils;

/**
 *
 * @author ms889296
 */
public class DefaultTableViewConfig implements TableViewConfig, NamedObject {

	private String name;

	private List<FilterColumn> filterByColumns;
	private List<GroupColumn> groupByColumns;
	private List<SortColumn> sortByColumns;
	private List<ViewColumn> displayColumns;
	private List<AggrigateColumn> aggrigateColumns;
	private List<String> aggrigateCategoryOrder;

	public List<String> getAggrigateCategoryOrder() {
		return aggrigateCategoryOrder;
	}
	public void setAggrigateCategoryOrder(List<String> aggrigateCategoryOrder) {
		this.aggrigateCategoryOrder = aggrigateCategoryOrder;
	}
	public List<AggrigateColumn> getAggrigateColumns() {
		return aggrigateColumns;
	}
	public void setAggrigateColumns(List<AggrigateColumn> aggrigateColumns) {
		this.aggrigateColumns = aggrigateColumns;
	}
	public List<ViewColumn> getDisplayColumns() {
		return displayColumns;
	}
	public void setDisplayColumns(List<ViewColumn> displayColumns) {
		this.displayColumns = displayColumns;
	}
	public List<FilterColumn> getFilterByColumns() {
		return filterByColumns;
	}
	public void setFilterByColumns(List<FilterColumn> filterByColumns) {
		this.filterByColumns = filterByColumns;
	}

	
	public int getGroupByColumnCount() {
		List<GroupColumn> gc = getGroupByColumns();
		if (gc == null) {
			return 0;
		}
		return gc.size();
	}
	public List<GroupColumn> getGroupByColumns() {
		return groupByColumns;
	}
	public void setGroupByColumns(List<GroupColumn> groupByColumns) {
		this.groupByColumns = groupByColumns;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<SortColumn> getSortByColumns() {
		return sortByColumns;
	}
	public void setSortByColumns(List<SortColumn> sortByColumns) {
		this.sortByColumns = sortByColumns;
	}

	// Utility Methods

	public int getDisplayColumnCount() {
		return displayColumns.size();
	}

	public ViewColumn getDisplayColumn(int columnIndex) {
		return displayColumns.get(columnIndex);
	}

	public ViewColumn getDisplayColumn(String columnLogicalName) {
		String[] tokens = split(columnLogicalName);
		if (null == tokens) {
			return null;
		}

//		System.out.println(columnLogicalName + " TOKENS ARE");
//		for (int i = 0; i < tokens.length; i++) {
//			System.out.println(i + " token " + tokens[i]);
//		}
		for (ViewColumn viewColumn : displayColumns) {
			if (viewColumn.getDataSourceName().equals(tokens[0]) &&
					viewColumn.getName().equals(tokens[1])) {
				return viewColumn;
			}
		}
		return null;
	}
	public ViewColumn getGroupedByColumn(int groupIndex) {
		return groupByColumns.get(groupIndex);
	}
	public ViewColumn getGroupedByColumn(String columnLogicalName) {
		String[] tokens = split(columnLogicalName);
		if (null == tokens) {
			return null;
		}

		for (ViewColumn viewColumn : displayColumns) {
			if (viewColumn.getDataSourceName().equals(tokens[0]) &&
					viewColumn.getName().equals(tokens[1])) {
				return viewColumn;
			}
		}
		return null;
	}

	public List<ViewColumn> getGroupByColumnsAsViewColumns() {
		if (null == groupByColumns) {
			return null;
		}
		List<ViewColumn> vc = new ArrayList<ViewColumn>();
		for (int i = 0, j = groupByColumns.size(); i < j; i++) {
			vc.add(getGroupedByColumn(i));
		}
		return vc;
	}

	public Map<String,SortColumn> getSortByColumnsMap() {
		Map<String,SortColumn> map = new HashMap<String,SortColumn>();
		if (null != sortByColumns) {
			for (SortColumn sc : sortByColumns) {
				map.put(sc.getName(), sc);
			}
		}
		return map;
	}
	
	public boolean isColumnAggrigated(String columnLogicalName, String groupedColumnName, String category) {
		List<AggrigateColumn> aggCols = getAggrigateColumns();
		if (null == aggCols || aggCols.size() == 0) {
			return false;
		}

		for (AggrigateColumn aggrigateColumn : aggCols) {
			boolean groupEquals = aggrigateColumn.getAggrigatedGroupLogicalName() == groupedColumnName ||
			  (null != groupedColumnName && null != aggrigateColumn.getAggrigatedGroupLogicalName() && aggrigateColumn.getAggrigatedGroupLogicalName().equals(groupedColumnName));

			if (aggrigateColumn.getLogicalName().equals(columnLogicalName)
				&& aggrigateColumn.getAggrigator().getCategory().equals(category)
				&& groupEquals) {
				return true;
			}
		}
		return false;
	}

	private String[] split(String columnLogicalName) {
		final String LOGICAL_COLUMN_NAME_SEPERATOR = VariableSeperator.MULTI_VALUE;

		int idx = columnLogicalName.indexOf(LOGICAL_COLUMN_NAME_SEPERATOR);
		if (idx < 0) {
			return null;
		}

//		System.out.println("using split with " + LOGICAL_COLUMN_NAME_SEPERATOR);

		String tokens[] = StringUtils.split(columnLogicalName, LOGICAL_COLUMN_NAME_SEPERATOR);
		return tokens;
	}
}
