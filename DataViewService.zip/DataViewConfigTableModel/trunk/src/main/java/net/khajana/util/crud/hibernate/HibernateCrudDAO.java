/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.crud.hibernate;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;


import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.springframework.orm.hibernate3.HibernateTemplate;

import net.khajana.util.crud.ICrudDAO;
import net.khajana.util.crud.shared.IEntity;


/**
 *
 * @author ms889296
 *
 */
public class HibernateCrudDAO<ENTITY extends IEntity<ID>, ID extends Serializable, C extends DetachedCriteria> implements ICrudDAO<ENTITY, ID, C> {

    protected HibernateTemplate template = null;

    public void setSessionFactory(SessionFactory sessionFactory) {
        template = new HibernateTemplate(sessionFactory);
    }

	
    public ENTITY findById(Class<ENTITY> clazz, ID id) {
        return (ENTITY) template.get(clazz, id);
    }

    
    public List<ENTITY> findAll(Class<ENTITY> entityList) {
        return template.loadAll(entityList);
    }

    
    public List<ENTITY> findByCriteria(C criteria) {
        return template.findByCriteria(criteria);
    }

    
    public List<ENTITY> findByCriteria(C criteria, int firstResult, int maxResults) {
        return template.findByCriteria(criteria, firstResult, maxResults);
    }

    
    public ENTITY saveOrUpdate(ENTITY entity) {
        template.saveOrUpdate(entity);
        return entity;
    }

    
    public Collection<ENTITY> saveOrUpdateAll(Collection<ENTITY> entityList) {
        template.saveOrUpdateAll(entityList);
        return entityList;
    }

    
    public void delete(ENTITY entity) {
        template.delete(entity);
    }

    
    public int deleteAll(Class<ENTITY> domain) {
        List<ENTITY> list = this.findAll(domain);
        if (list == null) {
            return 0;
        }
        template.deleteAll(list);
        return list.size();
    }
}
