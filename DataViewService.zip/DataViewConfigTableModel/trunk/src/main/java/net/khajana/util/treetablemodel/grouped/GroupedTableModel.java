/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.treetablemodel.grouped;

import javax.swing.table.TableModel;
import javax.swing.tree.DefaultMutableTreeNode;

import net.khajana.util.treetablemodel.TreeTableModel;

/**
 *
 * @author ms889296
 */
public interface GroupedTableModel extends TreeTableModel {

	public void group();

	public int[] getGroupColumns();
	public int getGroupColumnIndex(int groupLevel);
	public String getGroupColumnName(int groupLevel);
	
	public Object getGroupingValue(int rowIndex, int columnIndex);
	public TableModel getAsTableModel(DefaultMutableTreeNode node);	
	
	public void addGroupColumn(int columnIndex);
	public void removeGroupColumn(int columnIndex);
	
	public void removeAllGroupColumns();
}
