/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.treetablemodel.impl;

import java.util.Enumeration;
import java.util.Map;

import javax.swing.table.TableModel;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreeNode;

import net.khajana.util.tablemodel.aggrigated.AggrigationException;
import net.khajana.util.tablemodel.aggrigated.Aggrigator;

/**
 *
 * @author ms889296
 */
public class AggrigatedRowNode implements MutableTreeNode {

	private TreeNode parent;

	private TableModel viewTableModel;
	private TableModel dataTableModel;
	private Map<String, Integer> dataModelNameIndexMap;

	private Aggrigator[] aggrigators;
	private Object userObject;
	
	public AggrigatedRowNode() {
		// for serialization
	}
	public AggrigatedRowNode(MutableTreeNode parent, TableModel dataTableModel, Map<String, Integer> dataModelNameIndexMap, TableModel viewTableModel, Aggrigator[] aggrigators, Object userObject) {
		this.parent = parent;
		this.viewTableModel = viewTableModel;
		this.dataTableModel = dataTableModel;
		this.dataModelNameIndexMap = dataModelNameIndexMap;
		this.aggrigators = aggrigators;
		this.userObject = userObject;
	}
	
	public String getCategory() {
		for (int i = 0; i < aggrigators.length; i++) {
			if (aggrigators[i] != null) {
				return aggrigators[i].getCategory();
			}
		}
		return null;
	}
	
	public Object getAggrigatedValueAt(int columnIndex) throws AggrigationException {
		String columnName = viewTableModel.getColumnName(columnIndex);
		int dataColumnIndex = dataModelNameIndexMap.get(columnName);
		
		return aggrigators[columnIndex].aggrigate(dataTableModel, viewTableModel, dataColumnIndex, columnIndex);
	}

	public boolean isAggrigated(int columnIndex) {
		return aggrigators[columnIndex] != null;
	}
	
	public TableModel getViewTableModel() {
		return viewTableModel;
	}

	public void setViewTableModel(TableModel viewTableModel) {
		this.viewTableModel = viewTableModel;
	}

	public Aggrigator getAggrigator(int columnIndex) {
		return aggrigators[columnIndex];
	}
	
	/* (non-Javadoc)
	 * @see javax.swing.tree.TreeNode#children()
	 */
	public Enumeration children() {
		return null;
	}

	/* (non-Javadoc)
	 * @see javax.swing.tree.TreeNode#getAllowsChildren()
	 */
	public boolean getAllowsChildren() {
		return false;
	}

	/* (non-Javadoc)
	 * @see javax.swing.tree.TreeNode#getChildAt(int)
	 */
	public TreeNode getChildAt(int childIndex) {
		return null;
	}

	/* (non-Javadoc)
	 * @see javax.swing.tree.TreeNode#getChildCount()
	 */
	public int getChildCount() {
		return 0;
	}

	/* (non-Javadoc)
	 * @see javax.swing.tree.TreeNode#getIndex(javax.swing.tree.TreeNode)
	 */
	public int getIndex(TreeNode node) {
		return -1;
	}

	/* (non-Javadoc)
	 * @see javax.swing.tree.TreeNode#getParent()
	 */
	/**
	 * @return  Returns the parent.
	 */
	public TreeNode getParent() {
		return parent;
	}
	
	/* (non-Javadoc)
	 * @see javax.swing.tree.TreeNode#isLeaf()
	 */
	public boolean isLeaf() {
		return true;
	}

	/* (non-Javadoc)
	 * @see javax.swing.tree.MutableTreeNode#insert(javax.swing.tree.MutableTreeNode, int)
	 */
	public void insert(MutableTreeNode child, int index) {
		// NO-OP
	}

	/* (non-Javadoc)
	 * @see javax.swing.tree.MutableTreeNode#remove(int)
	 */
	public void remove(int index) {
		// NO-OP
	}

	/* (non-Javadoc)
	 * @see javax.swing.tree.MutableTreeNode#remove(javax.swing.tree.MutableTreeNode)
	 */
	public void remove(MutableTreeNode node) {
		// NO-OP
	}

	/* (non-Javadoc)
	 * @see javax.swing.tree.MutableTreeNode#removeFromParent()
	 */
	public void removeFromParent() {
		// NO-OP
	}

	/* (non-Javadoc)
	 * @see javax.swing.tree.MutableTreeNode#setParent(javax.swing.tree.MutableTreeNode)
	 */
	public void setParent(MutableTreeNode parent) {
		this.parent = parent;
	}

	/* (non-Javadoc)
	 * @see javax.swing.tree.MutableTreeNode#setUserObject(java.lang.Object)
	 */
	/**
	 * @param userObject  The userObject to set.
	 */
	public void setUserObject(Object object) {
		this.userObject = object;
	}
	
	/**
	 * @return  Returns the userObject.
	 */
	public Object getUserObject() {
		return userObject;
	}

}
