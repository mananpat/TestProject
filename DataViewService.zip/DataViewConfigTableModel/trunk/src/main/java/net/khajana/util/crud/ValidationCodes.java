/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.crud;

/**
 *
 * @author ms889296
 */
public enum ValidationCodes {

    DATE_FORMAT_ERROR("invalid.date","%s date format is invalid (Valid Fmt: YYYY-MM-dd)"),
    NULL_INPUT("null.parameter","%s Input object can not be null"),
    REQUIRED_FIELD("required.field","%s Field must have a value"),
    MIN_1("constraint.min1","At least one %s must be in the list"),
    DUPLICATE_NOT_ALLOWED("constraint.duplicatNotAllowed","Duplicate %s values are not allowed"),
    VERSION_STALE("data.version.stale","Attempting to modify or delete a %s record that has been modified by another user."),
    OBJECT_ALREADY_DELETED("data.deleted","Failed to update - The %s object has been already removed by another User");

    private String code;
    private String deaultMessage;

    private ValidationCodes(String code, String deaultMessage) {
        this.code = code;
        this.deaultMessage = deaultMessage;
    }

    public String getCode() {
        return code;
    }
    public String getDeaultMessage() {
        return deaultMessage;
    }
}
