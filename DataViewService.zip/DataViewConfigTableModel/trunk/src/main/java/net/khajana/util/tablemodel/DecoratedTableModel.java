/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */

package net.khajana.util.tablemodel;

import javax.swing.event.TableModelEvent;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableModel;

/**
 *
 * @author ms889296
 */
public class DecoratedTableModel extends AbstractTableModel {

	private TableModel tableModel;
	private int [] indices;
	private int [] columnIndices;

	private static final long serialVersionUID = 1L;

	public DecoratedTableModel(TableModel tableModel) {
		super();
		this.tableModel = tableModel;
		this.indices = generateIndices(tableModel);
		this.columnIndices = generateColumnIndices(tableModel);
	}

	/**
	 * Allows for the table to be created without the internal indices
	 * from being created.  This is a performance benifit when a 'deligated'
	 * model is used that modified the indices.  Use this with caution, as
	 * if the indices are not initilized then other calls with lead to errors.
	 * @param tableModel
	 * @param createIndices false value will ignore the indeces creation.
	 */
	public DecoratedTableModel(TableModel tableModel, boolean createIndices) {
		super();
		this.tableModel = tableModel;
		if (createIndices) {
			this.indices = generateIndices(tableModel);
		}
		this.columnIndices = generateColumnIndices(tableModel);
	}

	/**
	 * @param indices  The indices to set.
	 */
	protected void setIndices(int[] indices) {
		this.indices = indices;

		TableModelEvent e = new TableModelEvent(this);
		fireTableChanged(e);
	}
	/**
	 * @return  Returns the indices.
	 */
	protected int[] getIndices() {
		return indices;
	}

	/**
	 * @param columnIndices  The columnIndices to set.
	 */
	protected void setColumnIndices(int[] indices) {
		this.columnIndices = indices;

		TableModelEvent e = new TableModelEvent(this);
		fireTableChanged(e);
	}
	/**
	 * @return  Returns the columnIndices.
	 */
	protected int[] getColumnIndices() {
		return columnIndices;
	}

	public int getRowCount() {
		return indices.length;
	}

	// TODO columns should also be decorated
	public int getColumnCount() {
		return columnIndices.length;
	}

	public Object getValueAt(int rowIndex, int columnIndex) {
		// wierd junit error so removed
//		assert(rowIndex==-1);
//		assert(columnIndex==-1);
		if (rowIndex < 0 || columnIndex < 0 || tableModel.getRowCount() == 0) {
			System.out.println("problem");
		}
		return tableModel.getValueAt(indices[rowIndex], columnIndices[columnIndex]);
	}
	@Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
		return tableModel.isCellEditable(indices[rowIndex], columnIndex);
	}
	@Override
	public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
		tableModel.setValueAt(aValue, indices[rowIndex], columnIndex);
	}

	@Override
    public String getColumnName(int column) {
		return tableModel.getColumnName(column);
	}
	@Override
	public Class<?> getColumnClass(int columnIndex) {
		return tableModel.getColumnClass(columnIndex);
	}

	// TODO override all methods of abstract table model to correctly proxy.

	public TableModel getModel() {
		return tableModel;
	}
	public int getRealRow(int mappedIndex) {
		return indices[mappedIndex];
	}
	public int getMappedRow(int realRowIndex) {
		for (int i = 0; i < indices.length; i++) {
			if (indices[i] == realRowIndex) {
				return i;
			}
		}
		return -1;
	}

	protected Object getAbsoluteRowIndexedValueAt(int rowIndex, int columnIndex) {
		return tableModel.getValueAt(rowIndex, columnIndices[columnIndex]);
	}

	private int[] generateIndices(TableModel model) {
		int [] indices = new int[model.getRowCount()];
		for(int i = 0, j=indices.length; i < j; i++) {
			indices[i] = i;
		}
		return indices;
	}

	private int[] generateColumnIndices(TableModel model) {
		int [] indices = new int[model.getColumnCount()];
		for(int i = 0, j=indices.length; i < j; i++) {
			indices[i] = i;
		}
		return indices;
	}

}
