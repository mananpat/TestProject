/**
 * 
 */
package net.khajana.processor.impl;

/**
 * @author mp14693
 *
 */
public enum ViewProcessorOutputEnum {
	RESULT_VIEW_OBJECT,
	XML_STRING,
	CSV_COMMA_DELIMINATED,
	CSV_TAB_DELIMINATED,
}
