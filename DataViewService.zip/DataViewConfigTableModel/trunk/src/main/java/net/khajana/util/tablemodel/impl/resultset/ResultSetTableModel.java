/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.tablemodel.impl.resultset;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.table.AbstractTableModel;

import net.khajana.util.tablemodel.enums.VariableSeperator;

/**
 *
 * @author ms889296
 */
public class ResultSetTableModel extends AbstractTableModel {

	private Object[][] data;
	private Class[] classes;

	private String dataSourceName = "";
	private String[] columnNames;

	private Map<String, Integer> nameIndex = new HashMap<String, Integer>();

	private static final long serialVersionUID = 1L;

	public ResultSetTableModel() {
		super();
	}

	/**
	 * Initilize the model with all columns and rows from the resultset.
	 * @param resultSet
	 * @throws SQLException
	 */
	public ResultSetTableModel(ResultSet resultSet, String dataSourceName) throws SQLException {
		super();
		init(resultSet, dataSourceName);
	}

	/**
	 * Initilize the resultset with the columns at the specified column indexes and
	 * in the specified order
	 * @param resultSet the resultset to read from
	 * @param resultSetColumnIndexes the columns to extract and dthe order to extract in.
	 * @throws SQLException
	 */
	public ResultSetTableModel(ResultSet resultSet, int[] resultSetColumnIndexes, String dataSourceName) throws SQLException {
		super();
		init(resultSet, dataSourceName, resultSetColumnIndexes);
	}

	/**
	 * Initilize the resuletset with the specified columns in the specified order.
	 * @param resultSet the resultset to read from
	 * @param resultSetColumnNames the columns to extract and dthe order to extract in.
	 * @throws SQLException
	 */
	public ResultSetTableModel(ResultSet resultSet, String dataSourceName, String[] resultSetColumnNames) throws SQLException {
		super();
		init(resultSet, dataSourceName, resultSetColumnNames);
	}

	/**
	 * Initilize the resultset with th especiifed columns and map column names of
	 * these model using the columnNames parameter.
	 * @param resultSet the resultset to read from
	 * @param resultSetColumnIndexes the columns to extract and dthe order to extract in.
	 * @param columnNames this models column names
	 * @throws SQLException
	 */
	public ResultSetTableModel(ResultSet resultSet, int[] resultSetColumnIndexes, String dataSourceName, String[] columnNames) throws SQLException {
		super();
		init(resultSet, dataSourceName, resultSetColumnIndexes);
		if (this.columnNames.length != columnNames.length) {
			throw new SQLException("Number of specified column names does not equal the number of columns extracted.");
		}
		this.columnNames = columnNames;
		this.dataSourceName = dataSourceName;
	}

	/**
	 * Initilize the resultset with th especiifed columns and map column names of
	 * these model using the columnNames parameter.
	 * @param resultSet the resultset to read from
	 * @param resultSetColumnNames the columns to extract and dthe order to extract in.
	 * @param columnNames this models column names
	 * @throws SQLException
	 */
	public ResultSetTableModel(ResultSet resultSet, String[] resultSetColumnNames, String dataSourceName, String[] columnNames) throws SQLException {
		super();
		init(resultSet, dataSourceName, resultSetColumnNames);
		if (this.columnNames.length != columnNames.length) {
			throw new SQLException("Number of specified column names does not equal the number of columns extracted.");
		}
		this.columnNames = columnNames;
		this.dataSourceName = dataSourceName;
	}

	public int getRowCount() {
		return data.length;
	}

	public int getColumnCount() {
		return classes.length;
	}

	public Object getValueAt(int rowIndex, int columnIndex) {
		return data[rowIndex][columnIndex];
	}

	@Override
	public String getColumnName(int column) {

		// TODO store the column names with this dataSource prepended.  avoid constant new object creations
		return dataSourceName + VariableSeperator.MULTI_VALUE + columnNames[column];
	}

	@Override
	public int findColumn(String columnName) {
		// dont append datasourceName. thus allows for search by both long and short name.
		return nameIndex.get(columnName);
	}

	@Override
	public Class<?> getColumnClass(int columnIndex) {
		return classes[columnIndex];
	}

	public String getDataSourceName() {
		return dataSourceName;
	}

	public void init(ResultSet rs, String dataSourceName) throws SQLException {
		ResultSetMetaData rsmd = rs.getMetaData();
		int columnCount = rsmd.getColumnCount();

		int[] columnIndexes = new int[columnCount];
		for (int i = 0; i < columnIndexes.length; i++) {
			columnIndexes[i] = i;
		}

		init(rs, dataSourceName, columnIndexes);
	}

	public void init(ResultSet rs, String dataSourceName, String[] columnToImport) throws SQLException {
		ResultSetMetaData rsmd = rs.getMetaData();
		int columnCount = rsmd.getColumnCount();


		Map<String,Integer> srcIndexMap = new HashMap<String,Integer>();
		for (int i = 0; i < columnCount; i++) {
			String cname = rsmd.getColumnName(i+1);
			srcIndexMap.put(cname, new Integer(i));
		}


		int destColumnCount = columnToImport.length;
		int[] columnIndexes = new int[destColumnCount];
		for (int i = 0; i < destColumnCount; i++) {
			Integer idx = srcIndexMap.get(columnToImport[i]);
			if (null == idx) {
				columnIndexes[i] = -1;
			} else {
				columnIndexes[i] = i;
			}
		}

		init(rs, dataSourceName, columnIndexes);
	}

	public void init(ResultSet rs, String dataSourceName, int[] columnIndexes) throws SQLException {
		int columnCount= columnIndexes.length;

		ResultSetMetaData rsmd = rs.getMetaData();

		classes = new Class[columnCount];
		columnNames = new String[columnCount];
		for (int i = 0; i < classes.length; i++) {
			try {
			classes[i] = this.getClass().getClassLoader().loadClass(rsmd.getColumnClassName(columnIndexes[i]+1));
			columnNames[i] = rsmd.getColumnName(columnIndexes[i]+1);

			// search by both long and sort names.
			nameIndex.put(columnNames[i], new Integer(i));
			nameIndex.put(dataSourceName + "." + columnNames[i], new Integer(i));

			} catch (ClassNotFoundException e) {
				// Not possible to happen
			}
		}

		List<Object[]> rows = new ArrayList<Object[]>();
		while (rs.next()) {
			Object[] row = new Object[columnCount];
			for (int i = 0; i < columnCount; i++) {
				row[i] = rs.getObject(columnIndexes[i]+1);
			}
			rows.add(row);
		}
		data = (Object[][]) rows.toArray(new Object[rows.size()][]);
	}

}
