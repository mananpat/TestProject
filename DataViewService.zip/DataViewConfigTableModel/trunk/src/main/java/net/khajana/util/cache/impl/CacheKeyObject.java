/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

 package net.khajana.util.cache.impl;

import java.io.Serializable;
import java.util.Date;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;

public class CacheKeyObject implements Serializable{
		private String key;
		private int hashCode;
		
		public CacheKeyObject() {
			// used only for serialization
		}
		public CacheKeyObject(String name, Map<String,Object> keyMap) {
			StringBuffer sb = new StringBuffer();
			
			if (null != name) {
				sb.append(name).append(";");
			}
			
			if (null != keyMap && keyMap.size() > 0) {
				SortedSet<String> sortedKeys = new TreeSet<String>(keyMap.keySet());
				for (String key : sortedKeys) {
					Object value = keyMap.get(key);
					
					if (sb.length() > 0) {
						sb.append(";");
					}
					
					String skey = key + "=";
	
					if (value == null) {
						skey += "null";
					} else if (value.getClass().isArray()) {
						skey += toString((Object[])value);
					} else if (value instanceof Date){
						skey += ((Date)value).getTime();
					} else {
						// TODO float might need to be better handled.
						skey += value;
					}
					sb.append(skey);
				}
			}
			
			this.key = sb.toString();
			this.hashCode = this.key.hashCode();
		}
		
		public CacheKeyObject(Map<String,Object> keyMap) {
			this(null, keyMap);
		}
		
		@Override
		public String toString() {
			return key;
		}
		@Override
		public int hashCode() {
			return hashCode;
		}
		@Override
		public boolean equals(Object obj) {
			if(obj == null) {
				return false;
			}
			if (!(obj instanceof CacheKeyObject)) {
				return false;
			}
			
			CacheKeyObject rh  = (CacheKeyObject) obj;
			if (this.key == rh.key) {
				return true;
			}
			if (this.key == null || rh.key == null) {
				return false;
			}
			return this.key.equals(rh.key);
		}
		
		private String toString(Object[] keys) {
			SortedSet<String> sortedKeys = new TreeSet<String>();
			for (Object okey : keys) {
				String skey = null;
				if (okey == null) {
					skey = "null";
				} else if (okey instanceof Date){
					skey += ((Date)okey).getTime();
				} else {
					skey = okey.toString();
				}
				sortedKeys.add(skey);
			}
			
			StringBuffer key = new StringBuffer();
			for (String string : sortedKeys) {
				if (key.length() > 0) {
					key.append(",");
				}
				key.append(string);
			}
			return key.toString();
		}		
}
