/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.dao;

import java.util.Map;
import java.util.Set;

import net.khajana.util.cache.CacheException;
import net.khajana.util.cache.CacheKeyFactory;

/**
 *
 * @author ms889296
 */
public interface ISelectCachingDAO <PARAM,VAL,CK,BT> {
    public Map<PARAM,VAL> select(Set<PARAM> param) throws CacheException;
    public Map<BT, Set<PARAM>> groupBySearchType(Set<PARAM> param);

    public Map<PARAM,VAL> selectFromDataSource(Set<PARAM> param);

    public CacheKeyFactory<PARAM,CK> getCacheKeyFactory();
    public Map<PARAM,VAL> selectFromCache(Set<PARAM> params);
    public void cache(Map<PARAM,VAL> values) throws CacheException;
    public void removeFromCache(Set<PARAM> params) throws CacheException;
}
