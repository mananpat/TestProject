/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.treetablemodel.impl;

import java.util.Enumeration;
import java.util.Vector;

import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreeNode;

/**
 *
 * @author ms889296
 */
public class AggrigatedTreeNode implements MutableTreeNode {

	private MutableTreeNode parent;
	private Object userObject;
	private Vector<AggrigatedRowNode> children = new Vector<AggrigatedRowNode>();
	
	public AggrigatedTreeNode() {
		super();
	}
	
	public AggrigatedTreeNode(AggrigatedTreeNode src) {
		super();
		parent = null;
		userObject = src.userObject;
		this.children.addAll(src.children);
	}
	
	public TreeNode getChildAt(int childIndex) {
		return children.get(childIndex);
	}

	public int getChildCount() {
		return children.size();
	}

	public TreeNode getParent() {
		return parent;
	}

	public int getIndex(TreeNode node) {
		if (node instanceof AggrigatedRowNode) {
			return children.indexOf(node);
		}
		return -1;
	}

	public boolean getAllowsChildren() {
		return true;
	}

	public boolean isLeaf() {
		return false;
	}

	public Enumeration children() {
		return children.elements();
	}

	/* (non-Javadoc)
	 * @see javax.swing.tree.MutableTreeNode#insert(javax.swing.tree.MutableTreeNode, int)
	 */
	public void insert(MutableTreeNode child, int index) {
		children.insertElementAt((AggrigatedRowNode)child, index);
	}

	/* (non-Javadoc)
	 * @see javax.swing.tree.MutableTreeNode#remove(int)
	 */
	public void remove(int index) {
		// NO-OP
	}

	/* (non-Javadoc)
	 * @see javax.swing.tree.MutableTreeNode#remove(javax.swing.tree.MutableTreeNode)
	 */
	public void remove(MutableTreeNode node) {
		// NO-OP
	}

	/* (non-Javadoc)
	 * @see javax.swing.tree.MutableTreeNode#removeFromParent()
	 */
	public void removeFromParent() {
		// NO-OP
	}

	/* (non-Javadoc)
	 * @see javax.swing.tree.MutableTreeNode#setParent(javax.swing.tree.MutableTreeNode)
	 */
	/**
	 * @param parent  The parent to set.
	 */
	public void setParent(MutableTreeNode parent) {
		this.parent = parent;
	}

	/* (non-Javadoc)
	 * @see javax.swing.tree.MutableTreeNode#setUserObject(java.lang.Object)
	 */
	/**
	 * @param userObject  The userObject to set.
	 */
	public void setUserObject(Object object) {
		this.userObject = object;
	}
	
	/**
	 * @return  Returns the userObject.
	 */
	public Object getUserObject() {
		return userObject;
	}
}
