/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

 package net.khajana.util.cache;

import java.util.Map;

/**
 * Cache Interface
 *
 * @author ms889296
 */
public interface Cache<K, V> {

    public V get(K key);

    public Map<K,V> get(K[] keys);

    public void put(K key, V value) throws CacheException;

    public void remove(K key) throws CacheException;

    public void remove(K[] keys) throws CacheException;

    public boolean hasKey(K key);
}
