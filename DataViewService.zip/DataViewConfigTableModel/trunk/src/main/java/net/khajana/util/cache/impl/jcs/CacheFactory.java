/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.cache.impl.jcs;

import org.apache.jcs.JCS;
import org.apache.jcs.access.exception.CacheException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This cache factor class is hard coded to use JCS cache. If needed,
 * this class can be made into an abstract factory that can be used
 * to subclass for specific cache implementation.
 *
 * @author ms889296
 *
 */
public class CacheFactory {

	final Logger logger = LoggerFactory.getLogger("cache" + "." + CacheFactory.class.getName());

	private static CacheFactory cacheFactory = new CacheFactory();
	private static String cacheConfigFileName;
	
	public static CacheFactory getCacheFactory() {
		return cacheFactory;
	}

	public static String getCacheConfigFileName() {
		return cacheConfigFileName;
	}
	public static void setCacheConfigFileName(String cacheConfigFileName) {
		CacheFactory.cacheConfigFileName = cacheConfigFileName;
	}


	public static CacheFactory initilizeCache(String cacheConfigFileName) {
		setCacheConfigFileName(cacheConfigFileName);
		
		if (null != cacheConfigFileName) {
			//logger.info("Using cache config file with name {}", cacheConfigFileName);			
			JCS.setConfigFilename(cacheConfigFileName);
		}
		return getCacheFactory();
	}
	
	public JCSCache getCache(String cacheName) throws net.khajana.util.cache.CacheException {
		 try {
			JCS cache = JCS.getInstance(cacheName);
			 if (null == cache) {
				logger.error("getDataSourceResults.JCS.getInstance ... cache not found: {}", cacheName);
				return null;
			 }
			 return new JCSCache(cache);  // TODO need to keep a pool of Cache objects to avoid new everytime.
		} catch (CacheException e) {
			// TODO Auto-generated catch block
			throw new net.khajana.util.cache.CacheException(e);
		}
	}
}
