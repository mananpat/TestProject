/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.tablemodel.impl.aggrigated;

import java.util.List;
import java.util.Map;

import javax.swing.table.TableModel;

import net.khajana.util.tablemodel.TableModelUtils;
import net.khajana.util.tablemodel.aggrigated.AggrigatedValue;
import net.khajana.util.tablemodel.aggrigated.AggrigationException;
import net.khajana.util.tablemodel.aggrigated.Aggrigator;

/**
 *
 * @author ms889296
 */
public class AggrigatedTableModelImpl extends AbstractAggrigatedTableModel {

	private static final long serialVersionUID = 1L;
	
	public AggrigatedTableModelImpl(TableModel tableModel, TableModel dataTableModel) {
		super(tableModel, dataTableModel);
	}

	@Override
	protected void aggrigateIt(TableModel dataTableModel, Map<Integer, List<AggrigatedValue>> aggrigators) throws AggrigationException {
		// TODO should aggrigation stop when one fails, or continue and just mark the bad ones.
		
		TableModel viewModel = this;
		Map<String, Integer> dataModelNameIndexMap = TableModelUtils.generateColumnNameIndexMap(dataTableModel);

		for (Integer viewColumnIndex : aggrigators.keySet()) {
			List<AggrigatedValue> aggVals = aggrigators.get(viewColumnIndex);
			for (AggrigatedValue aggVal : aggVals) {
				Aggrigator aggrigator = aggVal.getAggrigator();				
				String columnName = this.getColumnName(viewColumnIndex);
				int dataColumnIndex = dataModelNameIndexMap.get(columnName);
				Object value = aggrigator.aggrigate(dataTableModel, viewModel, dataColumnIndex, viewColumnIndex);
				aggVal.setValue(value);
			}
		}		
	}
}

