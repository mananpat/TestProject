/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.tablemodel.sorted;

import java.util.Comparator;

import javax.swing.table.TableModel;

import net.khajana.util.tablemodel.enums.HiLow;
import net.khajana.util.tablemodel.enums.SortOrder;

/**
 *
 * @author ms889296
 */
public interface SortedTableModel extends TableModel {

	public void sort();

	public int[] getSortColumns();
	public SortOrder getSortOrder(int columnIndex);
	public HiLow getColumnHiLow(int columnIndex);
	public Comparator getComparator(int columnIndex);

	/**
	 * Adds the column to the list of the columns.  There is no effect, if the column
	 * was already added to be sorted.
	 * @param columnIndex - the column to add to the list of columns to sort.
	 */
	public void addSortColumn(int columnIndex);
	public void setSortOrder(int columnIndex, SortOrder sortOrder);
	public void setSortComparator(int columnIndex, Comparator comparator);
	public void setSortNullHiLow(int columnIndex, HiLow hiLow);

	public void removeSortColumn(int columnIndex);
	public void removeAllSortColumns();
}
