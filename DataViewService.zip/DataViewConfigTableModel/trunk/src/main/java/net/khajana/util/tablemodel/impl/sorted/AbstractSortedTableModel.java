/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.tablemodel.impl.sorted;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import javax.swing.table.TableModel;

import net.khajana.util.tablemodel.DecoratedTableModel;
import net.khajana.util.tablemodel.enums.HiLow;
import net.khajana.util.tablemodel.enums.SortOrder;
import net.khajana.util.tablemodel.sorted.SortedTableModel;

/**
 *
 * Table model that sorts a given table model.
 *
 * @author ms889296
 */
public abstract class AbstractSortedTableModel extends DecoratedTableModel implements
		SortedTableModel {

	private List<SortColumn> sortColumns = new ArrayList<SortColumn>();

	/*
	 * Use this to avoid unncessary comparasions in the get methods.
	 */
	private SortColumn nullSortColumn = new SortColumn(-1);

	protected abstract void sortIt(int[] indeces);

	/**
	 *
	 */
	public AbstractSortedTableModel(TableModel tableModel) {
		super(tableModel);
	}

	public void addSortColumn(int columnIndex) {
		if (sortColumnIndex(columnIndex) == -1) {
			SortColumn sortColumn = new SortColumn(columnIndex);
			sortColumns.add(sortColumn);
			sortColumn.sortOrder = SortOrder.ASC;
		}
	}

	public void setSortComparator(int columnIndex, Comparator comparator) {
		SortColumn sortColumn = sortColumn(columnIndex);
		if (null != sortColumn) {
			sortColumn.comparator = comparator;
		}
	}

	public void setSortNullHiLow(int columnIndex, HiLow hiLow) {
		SortColumn sortColumn = sortColumn(columnIndex);
		if (null != sortColumn) {
			sortColumn.nullHiLow = hiLow;
		}
	}

	public void setSortOrder(int columnIndex, SortOrder sortOrder) {
		SortColumn sortColumn = sortColumn(columnIndex);
		if (null != sortColumn) {
			sortColumn.sortOrder = sortOrder;
		}
	}

	public void removeAllSortColumns() {
		sortColumns.clear();
	}
	public void removeSortColumn(int columnIndex) {
		int index = sortColumnIndex(columnIndex);
		if (index != -1) {
			sortColumns.remove(index);
		}
	}

	public HiLow getColumnHiLow(int columnIndex) {
		SortColumn sortColumn = sortColumnRead(columnIndex);
		return sortColumn.nullHiLow;
	}

	public Comparator getComparator(int columnIndex) {
		SortColumn sortColumn = sortColumnRead(columnIndex);
		return sortColumn.comparator;
	}

	public SortOrder getSortOrder(int columnIndex) {
		SortColumn sortColumn = sortColumnRead(columnIndex);
		return sortColumn.sortOrder;
	}

	public int[] getSortColumns() {
		int [] columnIndexes = new int[sortColumns.size()];
		for (int i = 0, j = sortColumns.size(); i < j; i++) {
			columnIndexes[i] = sortColumns.get(i).columnIndex;
		}
		return columnIndexes;
	}

	public void sort() {
		// TableModel model = super.getModel();
		int[] indices = super.getIndices();

		sortIt(indices);

		super.setIndices(indices);
	}

	private int sortColumnIndex(int columnIndex) {
		for (int i = 0; i < sortColumns.size(); i++) {
			if (sortColumns.get(i).columnIndex == columnIndex) {
				return i;
			}
		}
		return -1;
	}

	private SortColumn sortColumn(int columnIndex) {
		int index = sortColumnIndex(columnIndex);
		if (index > -1) {
			return sortColumns.get(index);
		}
		return null;
	}

	private SortColumn sortColumnRead(int columnIndex) {
		int index = sortColumnIndex(columnIndex);
		if (index > -1) {
			return sortColumns.get(index);
		}
		return nullSortColumn;
	}

	/**
	 * @author ms889296
	 */
	public static class SortColumn {
		int columnIndex;
		SortOrder sortOrder;
		HiLow nullHiLow;
		Comparator comparator;

		public SortColumn() {
			// Used for Serialization
		}
		public SortColumn(int columnIndex) {
			this.columnIndex = columnIndex;
		}
	}
}
