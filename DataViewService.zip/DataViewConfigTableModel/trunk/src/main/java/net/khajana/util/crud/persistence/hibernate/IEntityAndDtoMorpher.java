/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.crud.persistence.hibernate;

import java.util.Collection;

/**
 *
 * @author ms889296
 */
public interface IEntityAndDtoMorpher<ENTITY, DTO> {
    /**
     * Create a entity object and populate it from the values of the dto.
     * @param dto
     * @param existingEntity if true then the id values should be retained, else
     * its an intial all thus ids should be null.
     * @return
     */
    public ENTITY toEntity(DTO dto, ENTITY entity, boolean existingEntity);
    public DTO toDto(ENTITY entity);
    public Collection<DTO> toDto(Collection<ENTITY> entity);
}
