/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.treetablemodel;

import javax.swing.tree.TreeModel;
import javax.swing.tree.TreeNode;

/**
 *
 * @author ms889296
 */
public interface TreeTableModel extends TreeModel {

    /**
     * Returns the number of available columns.
     */
	public int getColumnCount();

    /**
     * Returns the name for column number <code>column</code>.
     */
	public String getColumnName(int columnIndex);

    /**
     * Returns the type for column number <code>column</code>.
     */
	public Class<?> getColumnClass(int columnIndex);

    /**
     * Returns the value to be displayed for node <code>node</code>, 
     * at column number <code>column</code>.
     */
    public Object getValueAt(TreeNode node, int column);

    /**
     * Indicates whether the the value for node <code>node</code>, 
     * at column number <code>column</code> is editable.
     */
    public boolean isCellEditable(TreeNode node, int column);
	
    /**
     * Sets the value for node <code>node</code>, 
     * at column number <code>column</code>.
     */
    public void setValueAt(Object aValue, TreeNode node, int column);
}
