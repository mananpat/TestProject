/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.cache.impl.jcs;

import java.util.HashMap;
import java.util.Map;

import net.khajana.util.cache.Cache;

import org.apache.jcs.JCS;
import org.apache.jcs.access.exception.CacheException;

/**
 * This cache class is hard coded to use JCS cache. If needed,
 * this class can be made into an interface with an implementation
 * that can be used to subclass for specific cache implementation.
 *
 * @author ms889296
 */
public class JCSCache<K, V> implements Cache<K,V> {

    private JCS cache;
//	private boolean retryOnFailure = false;
//	private int maxRetry = 3;

    public JCSCache(JCS cache) {
        this.cache = cache;
    }

    public V get(K key) {
        return (V) cache.get(key);
    }

    public void put(K key, V value) throws net.khajana.util.cache.CacheException {
        try {
            cache.put(key, value);
        } catch (CacheException e) {
            // TODO Auto-generated catch block
            throw new net.khajana.util.cache.CacheException(e);
        }
    }

    public void remove(K key) throws net.khajana.util.cache.CacheException {
        try {
            cache.remove(key);
        } catch (CacheException e) {
            // TODO Auto-generated catch block
            throw new net.khajana.util.cache.CacheException(e);
        }
    }

    public boolean hasKey(K key) {
    	return (cache.getCacheElement(key) != null);
    }

    
    public Map<K, V> get(K[] keys) {
    	Map<K,V> ret = new HashMap<K,V>();
    	for (K k : keys) {
			V val = (V) cache.get(k);
			ret.put(k, val);
		}
    	return ret;
    }

	
	public void remove(K[] keys) throws net.khajana.util.cache.CacheException {
		for (K k : keys) {
			try {
				cache.remove(k);
			} catch (CacheException e) {
	            // TODO Auto-generated catch block
	            throw new net.khajana.util.cache.CacheException(e);
			}
		}
	}

	/* recursion and exception issue; cleanup before enabling.
    private void remove_i(K key, boolean retryOnFailure, int attempt) throws net.khajana.util.cache.CacheException {
        try {
            cache.remove(key);
        } catch (CacheException e) {
        	if (retryOnFailure && attempt < maxRetry) {
        		remove_i(key, false, ++attempt);
        		return;
        	}
            // TODO Auto-generated catch block
        	if (attempt == 0) {
        		throw new net.khajana.util.cache.CacheException(e);
        	}
        }
    }
    */


}
