/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.treetablemodel.impl.grouped;

import java.awt.Point;
import java.util.Map;

import javax.swing.table.TableModel;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeNode;

import net.khajana.util.tablemodel.impl.DeligatedTableModel;
import net.khajana.util.treetablemodel.impl.TableModelRowNode;

/**
 *
 * @author ms889296
 */
public class DefaultGroupedTableModel extends AbstractGroupedTableModel {

	/**
	 * Used for serialization - do not use for normal usage. 
	 */
	public DefaultGroupedTableModel() {
	}
	public DefaultGroupedTableModel(Object root, TableModel tableModel) {
		super(root, tableModel);
	}

	public DefaultGroupedTableModel(Object root, TableModel groupingTableModel, TableModel valueTableModel) {
		super(root, groupingTableModel, valueTableModel);
	}

	public TableModel getAsTableModel(DefaultMutableTreeNode node) {
		Map<String,Object> userObject = (Map<String,Object>)node.getUserObject();
		Point point = (Point)userObject.get(Point.class.getName());
		TableModel groupTable = new DeligatedTableModel(getModel(), point.x, point.y);
		
		return groupTable;
	}

	public void group() {
	}

	public Object getValueAt(TreeNode nodeObj, int column) {
		// let an exception be thrown for a class cast to avoid unnecessary 
		// performance hits by instanceof.
		
			return ((TableModelRowNode)nodeObj).getValueAt(column);
	}

	public Object getChild(Object parent, int index) {
		DefaultMutableTreeNode node = (DefaultMutableTreeNode)parent;
		return node.getChildAt(index);
	}

	public int getChildCount(Object parent) {
		DefaultMutableTreeNode node = (DefaultMutableTreeNode)parent;
		return node.getChildCount();
	}

}
