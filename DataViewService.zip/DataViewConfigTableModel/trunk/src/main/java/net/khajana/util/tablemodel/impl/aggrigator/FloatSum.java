/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.tablemodel.impl.aggrigator;

import javax.swing.table.TableModel;

import net.khajana.util.tablemodel.aggrigated.AggrigationException;
import net.khajana.util.tablemodel.aggrigated.Aggrigator;

/**
 *
 * @author ms889296
 */
public class FloatSum extends AbstractNamedAggrigator implements Aggrigator {

	{
		super.setCategory("sum");
	}

	public FloatSum() {
		super();
	}

	public Object aggrigate(TableModel dataTableModel, TableModel viewModel, int dataColumnIndex, int viewColumnIndex) throws AggrigationException {
		float sum = 0;
		for (int i = 0, j = viewModel.getRowCount(); i < j; i++) {
			Object o = viewModel.getValueAt(i, viewColumnIndex);
			if (o == null) {
				continue;
			}
			float floatVal = ((Number)o).floatValue();
			sum += floatVal;
		}
		return new Float(sum);
	}

	public Object aggrigate(TableModel dataTableModel, TableModel viewModel, int dataColumnIndex, int viewColumnIndex, int firstRow, int lastRow) throws AggrigationException {
		float sum = 0;
		for (int i = firstRow, j = lastRow+1; i < j; i++) {
			Object o = viewModel.getValueAt(i, viewColumnIndex);
			if (o == null) {
				continue;
			}
			float floatVal = ((Number)o).floatValue();
			sum += floatVal;
		}
		return new Float(sum);
	}
	
	public Object aggrigate(TableModel dataTableModel, TableModel viewModel, int dataColumnIndex, int viewColumnIndex, int[] rowIndexes) throws AggrigationException {
		float sum = 0;
		for (int i = 0, j = rowIndexes.length; i < j; i++) {
			Object o = viewModel.getValueAt(rowIndexes[i], viewColumnIndex);
			if (o == null) {
				continue;
			}
			float floatVal = ((Number)o).floatValue();
			sum += floatVal;
		}
		return new Float(sum);
	}
}
