/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.crud.persistence;

/**
 *
 * @author ms889296
 */
public class DeleteDTO<ID>
{
    private ID id;

    /**
     * Optional parameter.  If not specified, then the latest version will be removed.
     * For UI usage of this service, it is recommended to pass a version # of the object presented to the user to ensure
     * that they are not deleting an object that someone may  have modified.
     */
    private long version=-1;

    private String userName;
    private String userComment;

    public DeleteDTO() {
    }

    public DeleteDTO(ID id, String userName, String userComment, long version) {
        this.id = id;
        this.userName = userName;
        this.userComment = userComment;
        this.version = version;
    }

    public long getVersion() {
        return version;
    }

    public void setVersion(long version) {
        this.version = version;
    }


    public ID getId() {
        return id;
    }

    public void setId(ID id) {
        this.id = id;
    }

    public String getUserComment() {
        return userComment;
    }

    public void setUserComment(String userComment) {
        this.userComment = userComment;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
}
