/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.tablemodel;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.swing.table.TableModel;

import net.khajana.util.tablemodel.enums.VariableSeperator;

import org.apache.commons.beanutils.BeanUtils;

/**
 *
 * @author ms889296
 */
public class TableModelUtils {

	public static Object[][] getValues(TableModel tableModel, int col1, int col2) {
		Object[][] values = new Object[tableModel.getRowCount()][2];
		for (int i = 0, j = values.length; i < j; i++) {
			values[i][0] = tableModel.getValueAt(i, col1);
			values[i][1] = tableModel.getValueAt(i, col2);
		}
		return values;
	}

	/**
	 * returns the distinct values based on distinct key column.  The key datatype will be converted to String using toString method.
	 * @param tableModel
	 * @param keyColumnIndex
	 * @param valueColumnIndex
	 * @return
	 */
	public static Object[] getDistinctValues(TableModel tableModel, int columnIndex) {
		Set<Object> distinct = new HashSet<Object>();

		for (int i = 0, j=tableModel.getRowCount(); i < j; i++) {
			Object k = tableModel.getValueAt(i, columnIndex);
			if (!distinct.contains(k)) {
				distinct.add(k);
			}
		}
		Object[] kv = distinct.toArray(new Object[distinct.size()]);
		return kv;
	}

	/**
	 * returns the distinct values based on distinct key column.  The key datatype will be converted to String using toString method.
	 * @param tableModel
	 * @param keyColumnIndex
	 * @param valueColumnIndex
	 * @return
	 */
	public static Object[][] getDistinctValues(TableModel tableModel, int keyColumnIndex, int valueColumnIndex) {
		Set<Object> distinct = new HashSet<Object>();
		List<Object[]> kvs = new ArrayList<Object[]>();

		for (int i = 0, j=tableModel.getRowCount(); i < j; i++) {
			Object k = tableModel.getValueAt(i, keyColumnIndex);
			if (!distinct.contains(k)) {
				distinct.add(k);
				Object v = tableModel.getValueAt(i, valueColumnIndex);
				kvs.add(new Object[] {k,v});
			}
		}
		Object[][] kv = kvs.toArray(new Object[kvs.size()][]);
		return kv;
	}

	public static Map<String, Integer> generateColumnNameIndexMap(TableModel tableModel) {
		Map<String, Integer> nameIndexMap = new HashMap<String, Integer>();
		for(int i = 0; i < tableModel.getColumnCount(); i++) {
			String name = tableModel.getColumnName(i);
			nameIndexMap.put(name, new Integer(i));
		}
		return nameIndexMap;
	}

	public static Map<Integer, String> generateColumnIndexNameMap(TableModel tableModel) {
		Map<Integer, String> indexNameMap = new HashMap<Integer, String>();
		for(int i = 0; i < tableModel.getColumnCount(); i++) {
			String name = tableModel.getColumnName(i);
			indexNameMap.put(new Integer(i), name);
		}
		return indexNameMap;
	}

	public static int[] getColumnIndexes(TableModel tableModel, List<String> columnNames) {
		int[] indexes = new int[columnNames.size()];
		Map<String, Integer> nameIndexMap = generateColumnNameIndexMap(tableModel);
		int i = 0;
		for (String columnName : columnNames) {
			Integer idx= nameIndexMap.get(columnName);
			if (null == idx) {
				indexes[i] = -1;
			} else {
				indexes[i] = idx;
			}
			i++;
		}
		return indexes;
	}

	public static int getColumnIndexe(TableModel tableModel, String columnName) {
		Map<String, Integer> nameIndexMap = generateColumnNameIndexMap(tableModel);
		System.out.println("index map is " + nameIndexMap);
		Integer idx= nameIndexMap.get(columnName);
		if (null == idx) {
			return -1;
		} else {
			return idx;
		}
	}

	public static Map<String,Object> getValues(TableModel tableModel, int rowIndex) {
		Map<String,Object> values = new HashMap<String,Object>();
		for (int i = 0, j = tableModel.getColumnCount(); i < j; i++) {
			Object value = tableModel.getValueAt(rowIndex, i);
			String columnName = tableModel.getColumnName(i);
			columnName = removeDataSourceNameFromColumnName(columnName);
			values.put(columnName, value);
		}
		return values;
	}

	public static void setValues(TableModel tableModel, int rowIndex, Object bean) throws IllegalAccessException, InvocationTargetException {
		Map<String,Object> values = getValues(tableModel, rowIndex);
		BeanUtils.populate(bean, values);
	}

	public static String removeDataSourceNameFromColumnName(String columnName) {
		int index = columnName.indexOf(VariableSeperator.MULTI_VALUE) ;
		if (index != -1) {
			return columnName.substring(index+1);
		}
		return columnName;
	}
}
