/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */

package net.khajana.util.tableview.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.table.TableModel;

import net.khajana.util.filter.TableValueFilter;
import net.khajana.util.filter.impl.RegularExpressionTableValueFilter;
import net.khajana.util.tablemodel.TableModelPrinter;
import net.khajana.util.tablemodel.TableModelUtils;
import net.khajana.util.tablemodel.aggrigated.Aggrigator;
import net.khajana.util.tablemodel.enums.SortOrder;
import net.khajana.util.tablemodel.filtered.ColumnFilteredTableModel;
import net.khajana.util.tablemodel.filtered.FilteredTableModel;
import net.khajana.util.tablemodel.impl.filtered.ColumnFilteredTableModelImpl;
import net.khajana.util.tablemodel.impl.filtered.FilteredTableModelImpl;
import net.khajana.util.tablemodel.impl.sorted.SortedTableModelImpl;
import net.khajana.util.tablemodel.sorted.SortedTableModel;
import net.khajana.util.tableview.AggrigateColumn;
import net.khajana.util.tableview.ConfigException;
import net.khajana.util.tableview.FilterColumn;
import net.khajana.util.tableview.GroupColumn;
import net.khajana.util.tableview.SortColumn;
import net.khajana.util.tableview.TableModelHeirchy;
import net.khajana.util.tableview.TableViewConfig;
import net.khajana.util.tableview.TableViewProducer;
import net.khajana.util.tableview.TableViewResults;
import net.khajana.util.tableview.ViewColumn;
import net.khajana.util.treetablemodel.grouped.AggrigatedGroupedTableModel;
import net.khajana.util.treetablemodel.grouped.GroupedTableModelPrinter;
import net.khajana.util.treetablemodel.impl.grouped.GroupedTableModelImpl;

/**
 *
 * @author ms889296
 */
public class DefaultTableViewProducer implements TableViewProducer {

    
    public TableViewResults processView(TableModel tableModel,
                                        TableViewConfig tableViewConfig,
                                        Map<String, SortOrder> overrideSort,
                                        Map<String, String> filterStrings)
                                throws ConfigException {

    	// TODO the following should be in a new ExpandableCollapsableTableModel
    	// TODO for the above to happen, each node must have a state collapsed which would be triggered and then used by the paginated model
    	// TODO collapsed, or expended to level.
    	// TODO path to expand/collapse
    	// TODO input a previous session that is expended/collapsed to permit individual nodes to be expended/collapsed.
    	// TODO when collapsed the totals could be on the collapsed row, but when expended the values can be on the bottom.

        TableModel model = tableModel;
        
        TableModelPrinter printer = new TableModelPrinter();
        printer.print(tableModel, "Original Table Model", true, true, true);
        
        Map<String, Integer> nameIndexMap = TableModelUtils.generateColumnNameIndexMap(tableModel);
        TableViewResults tableViewResults = new TableViewResults();

        tableViewResults.setTableLogicalName(tableViewConfig.getName());
        tableViewResults.addTableModel(tableModel, TableModelHeirchy.DATA);

        //		TableModel model = tableModel;
//		GroupedTableModel groupedTableModel = null;
//
//		TableViewConfigHelper tableViewConfigHelper = new TableViewConfigHelper(view);
//
//		List<AggrigatedColumn> aggrigatedColumns = tableViewConfigHelper.getAggrigatedColumns();
//		List<String> aggrigatedCategories = tableViewConfigHelper.getAggrigatedCategories();
//
//		String viewTitle = view.getTitle();
//		tableViewResults.setViewTitle(viewTitle);
//		tableViewResults.setTableViewConfig(tableViewConfigHelper);

        // TODO filtered table model

        {
            // This block is a way to localize the variable declarations;
            List<FilterColumn> filterByColumns = tableViewConfig.getFilterByColumns();
            if (null != filterByColumns && filterByColumns.size() != 0) {
                FilteredTableModel filteredTableModel = getFilteredTableModel(tableModel, filterByColumns, filterStrings, nameIndexMap);
                tableViewResults.addTableModel(filteredTableModel, TableModelHeirchy.FILTERED);
                model = filteredTableModel; // TODO some hierchy lookup below?
            } else if (null != filterStrings && filterStrings.size() > 0) {
                FilteredTableModel filteredTableModel = getFilteredTableModel(tableModel, filterByColumns, filterStrings, nameIndexMap);
                tableViewResults.addTableModel(filteredTableModel, TableModelHeirchy.FILTERED);
                model = filteredTableModel; // TODO some hierchy lookup below?
            }
        }


        {
            // This block is a way to localize the variable declarations;
            List<GroupColumn> groupByColumns = tableViewConfig.getGroupByColumns();
            List<SortColumn> sortByColumns = tableViewConfig.getSortByColumns();
            if ((null != groupByColumns && groupByColumns.size() != 0) || (null != sortByColumns && sortByColumns.size() != 0) || (null != overrideSort && overrideSort.size() != 0)) {
                model = getSortedTableModel(model, groupByColumns, sortByColumns, overrideSort, nameIndexMap);
                tableViewResults.addTableModel(model, TableModelHeirchy.SORTED);
            }
        }

        // getLogicalDisplayNames
        {
            // This block is a way to localize the variable declarations;
            List<ViewColumn> displayColumns = tableViewConfig.getDisplayColumns();
            List<GroupColumn> groupByColumns = tableViewConfig.getGroupByColumns();
            TableModel logicalColumnFilteredTableModel = getColumnFilteredTableModel(model, groupByColumns, displayColumns, nameIndexMap);
            tableViewResults.addTableModel(logicalColumnFilteredTableModel, TableModelHeirchy.LOGICAL_COLUMN_FILTERED);
        }

        {
            // This block is a way to localize the variable declarations;
            List<ViewColumn> displayColumns = tableViewConfig.getDisplayColumns();
            if (null != displayColumns && displayColumns.size() != 0) {
                TableModel columnFilteredTableModel = getColumnFilteredTableModel(model, displayColumns, nameIndexMap);
                tableViewResults.addTableModel(columnFilteredTableModel, TableModelHeirchy.COLUMN_FILTERED);

                Collection<String> dataSetColumns = new ArrayList<String>();
                for (int i = 0, j = columnFilteredTableModel.getColumnCount(); i < j; i++) {
                    dataSetColumns.add(columnFilteredTableModel.getColumnName(i));
                }
                tableViewResults.setDataSetColumns(dataSetColumns);
            }
        }

//	this adds aggrigation tablemodel... since we are using the aggrigatedgroupmodel, we don't really need this, unless we want to use
        // for csv, excel and xml
//		{
//			// This block is a way to localize the variable declarations;
//			List<AggrigateColumn> aggrigateColumns = tableViewConfig.getAggrigateColumns();
//
//			if (null != aggrigateColumns && aggrigateColumns.size() > 0) {
//				// get the most 'highest' table model
//				TableModel viewTableModel = tableViewResults.getNonNullTableModel();
//				// get the column name map for the 'highest' table model
//				Map<String, Integer> viewTableModelNameIndexMap = TableModelUtils.generateColumnNameIndexMap(viewTableModel);
//
//				try {
//					TableModel aggrigatedTableModel = getAggrigatedTableModel(viewTableModel, tableModel, aggrigateColumns, viewTableModelNameIndexMap);
//					tableViewResults.addTableModel(aggrigatedTableModel, TableModelHeirchy.AGGRIGATED_COLUMN_FILTERED);
//
//					// we don't need both so why do both?
//					//Map<String, Integer> columnFilteredNameIndexMap = TableModelUtils.generateColumnNameIndexMap(logicalColumnFilteredTableModel);
//					//aggrigatedTableModel = getAggrigatedTableModel(logicalColumnFilteredTableModel, tableModel, aggrigateColumns, columnFilteredNameIndexMap);
//					//tableViewResults.addTableModel(aggrigatedTableModel, TableModelHeirchy.AGGRIGATED_LOGICAL_COLUMN_FILTERED);
//
//				} catch (AggrigationException e) {
//					throw new ConfigException(e); // TODO send out more like a processing exception
//				}
//			}
//
//		}

        /*
        if (null != groupedColumns && groupedColumns.size() != 0) {
        treeTableModel = getGroupedTableModel(model, columnFilteredTableModel, groupedColumns);
        }
         */

        {

            TableModel groupingTableModel = tableViewResults.getTableModel(TableModelHeirchy.LOGICAL_COLUMN_FILTERED);
            TableModel valueTableModel = tableViewResults.getTableModel(TableModelHeirchy.COLUMN_FILTERED);
            List<GroupColumn> groupedColumns = tableViewConfig.getGroupByColumns();
            List<AggrigateColumn> aggrigateColumns = tableViewConfig.getAggrigateColumns();
            List<String> aggrigateCategoryOrder = tableViewConfig.getAggrigateCategoryOrder();

            boolean aggrigationAtStart = false; // TODO need to get from view config.
//             aggrigationAtStart = true; // TODO need to get from view config.

            TableModelPrinter printer2 = new TableModelPrinter();
            printer2.print(groupingTableModel, "Original Table Model", true, true, true);
            
            AggrigatedGroupedTableModel aggrigatedGroupedTableModel = getAggrigatedGroupedTableModel(groupingTableModel, valueTableModel,
                    groupedColumns, aggrigateColumns, aggrigateCategoryOrder, aggrigationAtStart);

            tableViewResults.setGroupedTableModel(aggrigatedGroupedTableModel);

            // System.out.println("groupedTableModel is >>>>>>>>>>>>    "  + aggrigatedGroupedTableModel);
            //GroupedTableModelPrinter gtmp = new GroupedTableModelPrinter();
            //gtmp.print(aggrigatedGroupedTableModel, false, true);
        }

        return tableViewResults;
    }

    private FilteredTableModel getFilteredTableModel(TableModel model, List<FilterColumn> filterByColumns, Map<String, String> filterStrings, Map<String, Integer> nameIndexMap) throws ConfigException {
        FilteredTableModel filteredTableModel = new FilteredTableModelImpl(model);

        if (null != filterByColumns) {
            for (FilterColumn column : filterByColumns) {
                //String dataSourceName = column.getDataSourceName();
                //String columnLogicalName = column.getName();
                Map<String, List<Object>> filterValues = column.getFilterValues();

                String dsColumnName = column.getLogicalName();
                Integer columnIndex = nameIndexMap.get(dsColumnName);
                if (columnIndex == null) {
                    // TODO log warning message
                    System.out.println("specified filter column not in table model [" + dsColumnName + "]");
                    continue;
                }

                TableValueFilter tableValueFilter = column.getTableValueFilter();

                if (filterStrings != null && filterStrings.containsKey(dsColumnName)) {
                    continue;
                }

                filteredTableModel.addFilter(tableValueFilter, columnIndex, filterValues);
            }
        }

        if (null != filterStrings) {
            for (String logicalColumnName : filterStrings.keySet()) {
                Integer columnIndex = nameIndexMap.get(logicalColumnName);
                if (columnIndex == null) {
                    continue;
                }
                TableValueFilter tableValueFilter = new RegularExpressionTableValueFilter();

                Map<String, List<Object>> filterValues = new HashMap<String, List<Object>>();
                List<Object> valuesList = new ArrayList<Object>();

                String filterString = filterStrings.get(logicalColumnName);
                valuesList.add(filterString);

                filterValues.put("value", valuesList);
                filteredTableModel.addFilter(tableValueFilter, columnIndex, filterValues);
            }
        }

        filteredTableModel.filter();

        return filteredTableModel;
    }

    private TableModel getSortedTableModel(TableModel model, List<GroupColumn> groupByColumns, List<SortColumn> sortByColumns, Map<String, SortOrder> overrideSort, Map<String, Integer> nameIndexMap) {
        SortedTableModel sortedTableModel = new SortedTableModelImpl(model);

        // TODO should we keep track of the columns added, thus we dont add the same column twice
        if (null != groupByColumns) {
            for (SortColumn column : groupByColumns) {
                //String dataSourceName = column.getDataSourceName();
                //String name = column.getName();
                SortOrder sortOrder = column.getSortOrder();
                // TODO -- will have to see if the column exists or not first.
                String dsColumnName = column.getLogicalName();
                Integer columnIndex = nameIndexMap.get(dsColumnName);
                if (columnIndex == null) {
                    // TODO log warning message
                    System.out.println("specified group column not in table model [" + dsColumnName + "]");
                    continue;
                }

                sortedTableModel.addSortColumn(columnIndex);
                sortedTableModel.setSortOrder(columnIndex, sortOrder);
            }
        }

        if (null != sortByColumns && (overrideSort == null || overrideSort.size() == 0)) {
            for (SortColumn column : sortByColumns) {
                //String dataSourceName = column.getDataSourceName();
                //String name = column.getName();
                SortOrder sortOrder = column.getSortOrder();
                String dsColumnName = column.getLogicalName();
                ;
                Integer columnIndex = nameIndexMap.get(dsColumnName);
                if (columnIndex == null) {
                    // TODO log warning message
                    System.out.println("specified sort column not in table model [" + dsColumnName + "]");
                    continue;
                }
                // TODO -- will have to see if the column exists or not first.
                sortedTableModel.addSortColumn(columnIndex);
                sortedTableModel.setSortOrder(columnIndex, sortOrder);
            }
        } else if (overrideSort != null && overrideSort.size() > 0) {
            for (String dsColumnName : overrideSort.keySet()) {
                SortOrder sortOrder = overrideSort.get(dsColumnName);
                Integer columnIndex = nameIndexMap.get(dsColumnName);
                if (columnIndex == null) {
                    // TODO log warning message
                    System.out.println("specified sort column not in table model [" + dsColumnName + "]");
                    continue;
                }
                // TODO -- will have to see if the column exists or not first.
                sortedTableModel.addSortColumn(columnIndex);
                sortedTableModel.setSortOrder(columnIndex, sortOrder);
            }
        }

        sortedTableModel.sort();

        return sortedTableModel;
    }

    private TableModel getColumnFilteredTableModel(TableModel model, List<GroupColumn> groupByColumns, List<ViewColumn> displayColumns, Map<String, Integer> nameIndexMap) {
        ColumnFilteredTableModel colFilteredModel = new ColumnFilteredTableModelImpl(model);
        if (null != groupByColumns && groupByColumns.size() > 0) {
            for (GroupColumn column : groupByColumns) {
                String dsColumnName = column.getLogicalName();
                Integer columnIndex = nameIndexMap.get(dsColumnName);
                if (columnIndex == null) {
                    // TODO log warning message
                    System.out.println("specified columnfilter column not in table model [" + dsColumnName + "]");
                    continue;
                }
                // TODO -- will have to see if the column exists or not first.
                colFilteredModel.addColumn(columnIndex);
            }
        }

        for (ViewColumn column : displayColumns) {
            String dsColumnName = column.getLogicalName();
            Integer columnIndex = nameIndexMap.get(dsColumnName);
            if (columnIndex == null) {
                // TODO log warning message
                System.out.println("specified columnfilter column not in table model(2) [" + dsColumnName + "]");
                continue;
            }
            // TODO -- will have to see if the column exists or not first.
            colFilteredModel.addColumn(columnIndex);
        }
        colFilteredModel.filter();
        return colFilteredModel;
    }

    private TableModel getColumnFilteredTableModel(TableModel model, List<ViewColumn> displayColumns, Map<String, Integer> nameIndexMap) {
        ColumnFilteredTableModel colFilteredModel = new ColumnFilteredTableModelImpl(model);
        ;
        for (ViewColumn column : displayColumns) {

            String dsColumnName = column.getLogicalName();
            Integer columnIndex = nameIndexMap.get(dsColumnName);
            if (columnIndex == null) {
                // TODO log warning message
                System.out.println("specified columnfilter column not in table model(3) [" + dsColumnName + "]");
                continue;
            }
            // TODO -- will have to see if the column exists or not first.
            colFilteredModel.addColumn(columnIndex);
        }
        colFilteredModel.filter();
        return colFilteredModel;
    }

//	private TableModel getAggrigatedTableModel(TableModel model, TableModel dataTableModel, List<AggrigateColumn> aggrigateColumns, Map<String, Integer> nameIndexMap) throws ConfigException, AggrigationException  {
//		AggrigatedTableModel aggrigatedTableModel = new AggrigatedTableModelImpl(model, dataTableModel);
//		for (AggrigateColumn column : aggrigateColumns) {
//			String name = column.getLogicalName();
//			Aggrigator aggrigator = column.getAggrigator();
//			int columnIndex = nameIndexMap.get(name);
//			// TODO -- will have to see if the column exists or not first.
//
//			aggrigatedTableModel.addAggrigator(columnIndex, aggrigator);
//		}
//		aggrigatedTableModel.aggrigate();
//
//		return aggrigatedTableModel;
//	}
    /**
     * Retuns a aggrigated grouped table model.
     * @param groupingTableModel - Model that includes the grouped columns
     * @param valueTableModel - Model that matches the gruping, except that only contains the columns that are to be included in result
     * @param groupedColumns - the actual columns that the group is to be done and the order
     * @param nameIndexMap
     * @param aggrigateColumns
     * @param aggrigateCategoryOrder
     * @return
     * @throws ConfigException
     */
    private AggrigatedGroupedTableModel getAggrigatedGroupedTableModel(TableModel groupingTableModel, TableModel valueTableModel,
            List<GroupColumn> groupedColumns,
            List<AggrigateColumn> aggrigateColumns, List<String> aggrigateCategoryOrder, boolean aggrigationAtStart) throws ConfigException {
        GroupedTableModelImpl groupedTableModel = new GroupedTableModelImpl(groupingTableModel, valueTableModel);
        groupedTableModel.setAggrigationAtStart(aggrigationAtStart);
        
        List<String> groupLevels = new ArrayList<String>();


        if (null != groupedColumns) {
            Map<String, Integer> groupingTableModelNameIndexMap = TableModelUtils.generateColumnNameIndexMap(groupingTableModel);

            for (SortColumn column : groupedColumns) {
                String dsColumnName = column.getLogicalName();
                Integer columnIndex = groupingTableModelNameIndexMap.get(dsColumnName);
                if (columnIndex == null) {
                    // TODO log warning message
                    System.out.println("specified aggrigated goup column not in table model [" + dsColumnName + "]");
                    continue;
                }

                groupLevels.add(column.getName());  // TODO -- should this name include datasource name
                // TODO -- will have to see if the column exists or not first.
                groupedTableModel.addGroupColumn(columnIndex);
            }
        }

        Map<String, Integer> valueTableModelNameIndexMap = TableModelUtils.generateColumnNameIndexMap(valueTableModel);
        AggrigatedGroupedTableModel aggrigatedGroupedTableModel = (AggrigatedGroupedTableModel) groupedTableModel;

        if (null != aggrigateColumns) {
            for (AggrigateColumn column : aggrigateColumns) {
                //String dataSourceName = column.getDataSourceName();
                //String name = column.getName();
                Aggrigator aggrigator = column.getAggrigator();
                String dsColumnName = column.getLogicalName();
                Integer columnIndex = valueTableModelNameIndexMap.get(dsColumnName);
                if (columnIndex == null) {
                    // TODO log warning message
                    System.out.println("specified aggrigated goup column not in table model(2) [" + dsColumnName + "]");
                    continue;
                }
                String groupLogicalName = column.getAggrigatedGroupLogicalName();

                int groupIndex = groupLevels.indexOf(groupLogicalName);
                // TODO -- will have to see if the column exists or not first.

                aggrigatedGroupedTableModel.addAggrigator(columnIndex, groupIndex, aggrigator);
               // aggrigatedGroupedTableModel.addAggrigator(1, 0, aggrigator);
            }

            // why set the aggrigation category order, when we are not aggrigating.
            if (null != aggrigateCategoryOrder && aggrigateCategoryOrder.size() > 0) {
                String[] aggCategories = aggrigateCategoryOrder.toArray(new String[aggrigateCategoryOrder.size()]);
                aggrigatedGroupedTableModel.setAggrigationCategoryOrder(aggCategories);
            }
        }

        groupedTableModel.setGrandTotal(true);
        
        groupedTableModel.group();

        /*GroupedTableModelPrinter printer = new GroupedTableModelPrinter();
        printer.print(groupedTableModel, true, false, false);*/
        
        return aggrigatedGroupedTableModel;
    }
//	private List<SortedColumn> createSortList(List<SortedColumn> groupedColumns, List<SortedColumn> sortedColumnsFromView, List<SortedColumn> sortedColumnsInteractive) {
//		List<SortedColumn> sortColumns = sortColumns = new ArrayList<SortedColumn>();;
//		Set<String> sortColumnsSet = new HashSet<String>();
//
//		if (null != groupedColumns) {
//			mergeSortColumns(groupedColumns, sortColumnsSet, sortColumns);
//		}
//
//		if (null != sortedColumnsInteractive && sortedColumnsInteractive.size() > 0) {
//			mergeSortColumns(sortedColumnsInteractive, sortColumnsSet, sortColumns);
//		} else if (null != sortedColumnsFromView) {
//			mergeSortColumns(sortedColumnsFromView, sortColumnsSet, sortColumns);
//		}
//
//		return sortColumns;
//	}
//	private void mergeSortColumns(List<SortedColumn> srcSortedColumns, Set<String> sortColumnsSet, List<SortedColumn> sortColumns) {
//		for (SortedColumn sorted : srcSortedColumns) {
//			if (!sortColumnsSet.contains(sorted.getLogicalName())) {
//				sortColumnsSet.add(sorted.getLogicalName());
//				sortColumns.add(sorted);
//			}
//		}
//	}
}
