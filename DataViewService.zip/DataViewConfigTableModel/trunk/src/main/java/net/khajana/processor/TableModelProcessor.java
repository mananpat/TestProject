/**
 * 
 */
package net.khajana.processor;


import javax.swing.table.TableModel;

import net.khajana.processor.impl.ViewProcessorOutputEnum;

import com.citi.ef.util.dataview.config.ViewConfig;


/**
 * @author mp14693
 *
 */
public interface TableModelProcessor {
	
	public Object process(TableModel tableModel, ViewConfig viewConfig, ViewProcessorOutputEnum outputFormat) throws Exception;
	
}
