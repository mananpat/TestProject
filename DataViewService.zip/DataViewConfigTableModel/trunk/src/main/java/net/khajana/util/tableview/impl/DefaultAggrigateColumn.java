/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.tableview.impl;

import net.khajana.util.tablemodel.aggrigated.Aggrigator;
import net.khajana.util.tableview.AggrigateColumn;

/**
 *
 * @author ms889296
 */
public class DefaultAggrigateColumn extends DefaultViewColumn implements AggrigateColumn {

	private Aggrigator aggrigator;
	private String aggrigatedGroupLogicalName;
	
	public DefaultAggrigateColumn() {
	}
	public DefaultAggrigateColumn(String name, String dataSourceName) {
		super(name, dataSourceName);
	}
	public DefaultAggrigateColumn(String name, String dataSourceName, Aggrigator aggrigator) {
		super(name, dataSourceName);
		this.aggrigator = aggrigator;
	}
	public DefaultAggrigateColumn(String name, String dataSourceName, Aggrigator aggrigator, String aggrigatedGroupLogicalName) {
		this(name, dataSourceName, aggrigator);
		this.aggrigatedGroupLogicalName = aggrigatedGroupLogicalName;
	}
	
	public String getAggrigatedGroupLogicalName() {
		return aggrigatedGroupLogicalName;
	}

	public void setAggrigatedGroupLogicalName(String aggrigatedGroupLogicalName) {
		this.aggrigatedGroupLogicalName = aggrigatedGroupLogicalName;
	}

	public Aggrigator getAggrigator() {
		return aggrigator;
	}

	public void setAggrigator(Aggrigator aggrigator) {
		this.aggrigator = aggrigator;
	}

}
