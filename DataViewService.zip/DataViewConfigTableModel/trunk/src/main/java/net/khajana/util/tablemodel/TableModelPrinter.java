/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */

package net.khajana.util.tablemodel;

import javax.swing.table.TableModel;

/**
 *
 * @author ms889296
 */
public class TableModelPrinter {

	private String indent = "";
	public TableModelPrinter() {
		super();
	}
	public TableModelPrinter(String indent) {
		this.indent = indent;
	}

	public void print(TableModel model, String message, boolean printColumnAttributes, boolean printDataRowWrapper, boolean printWrapper) {
		if (printWrapper) {
			System.out.println("START " + message);
		}

		print(model, printColumnAttributes, printDataRowWrapper);

		if (printWrapper) {
			System.out.println("END " + message);
		}
	}

	public void print(TableModel model, boolean printColumnAttributes, boolean printDataRowWrapper) {
		if (printColumnAttributes) {
			printColumnAttributes(model);
		}
		printRows(model, printDataRowWrapper);
	}

	protected void printColumnAttributes(TableModel model) {
		System.out.println("--- column names ---");
		for (int i = 0; i < model.getColumnCount(); i++) {
			System.out.println(i + "---" + model.getColumnName(i) + "  " + model.getColumnClass(i));
		}
	}

	protected void printRows(TableModel model, boolean printDataRowWrapper) {
		if (printDataRowWrapper)
			System.out.println("=== data === ");
		for(int i = 0; i < model.getRowCount(); i++) {
			for (int j = 0; j < model.getColumnCount(); j++) {
				if (j > 0) {
					System.out.print(",");
				} else if (j == 0) {
					System.out.print(indent);
				}
				System.out.print("\"" + model.getValueAt(i,j) + "\"");
			}
			System.out.println("");
		}
	}
}
