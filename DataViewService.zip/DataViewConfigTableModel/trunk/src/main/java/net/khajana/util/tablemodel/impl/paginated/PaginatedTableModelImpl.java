/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.tablemodel.impl.paginated;

import java.util.ArrayList;
import java.util.List;

import javax.swing.table.TableModel;

/**
 *
 * @author ms889296
 */
public class PaginatedTableModelImpl extends AbstractPaginatedTableModel {

	private static final long serialVersionUID = 1L;

	public PaginatedTableModelImpl(TableModel tableModel) {
		super(tableModel);
		init();
	}

	protected void paginateIt() {
		init();
	}

	private void init() {
		int rowsPerPage = getRowsPerPage();
		int rowCount = getRowCount();
		
		int [] indicesPageNumber = new int[rowCount];
		List<Integer> firstRowOfPageList = new ArrayList<Integer>();
		for (int i = 0, j = 0, p = 0; i < rowCount; i++, j++) {
			indicesPageNumber[i] = p;
			if (j == 0) {
				firstRowOfPageList.add(i);
			}
			if (j+1 == rowsPerPage) { // we could do >= , but more efficeint to just to equals
				// since the loop control will increment by one, we need to set this to -1, else we will miss 0
				j = -1;  
				p++;
			}
		}
		int[] firstRowOfPage = new int[firstRowOfPageList.size()];
		for (int i = 0; i < firstRowOfPage.length; i++) {
			firstRowOfPage[i] = firstRowOfPageList.get(i);
		}
		int lastRowOfLastPage = rowCount - 1;
		
		init(indicesPageNumber, firstRowOfPage, lastRowOfLastPage);
	}	
}
