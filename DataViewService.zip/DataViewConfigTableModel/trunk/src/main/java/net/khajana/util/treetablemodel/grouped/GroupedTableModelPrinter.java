/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */

package net.khajana.util.treetablemodel.grouped;

import java.awt.Point;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.swing.table.TableModel;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeNode;

import net.khajana.util.tablemodel.TableModelPrinter;
import net.khajana.util.tablemodel.aggrigated.AggrigationException;
import net.khajana.util.treetablemodel.impl.AggrigatedRowNode;
import net.khajana.util.treetablemodel.impl.AggrigatedTreeNode;
import net.khajana.util.treetablemodel.impl.TableModelRowNode;
import net.khajana.util.treetablemodel.impl.TableModelTreeNode;

/**
 *
 * @author ms889296
 */
public class GroupedTableModelPrinter {

	private boolean printDataRowsAsTable;
	private boolean printTraversedDataRows;
	private boolean printDebugInfo;

	public GroupedTableModelPrinter() {
		super();
	}
	public GroupedTableModelPrinter(boolean printDebugInfo) {
		this.printDebugInfo = printDebugInfo;
	}

	public void print(GroupedTableModel model, boolean printDataRowsAsTable, boolean printTraversedDataRows, boolean printColumnAttributes) {
		this.printDataRowsAsTable = printDataRowsAsTable;
		this.printTraversedDataRows = printTraversedDataRows;

		if (printColumnAttributes) {
			printColumnAttributes(model);
		}

		printRows(model);
	}

	protected void printColumnAttributes(GroupedTableModel model) {
		if (printDebugInfo)
			System.out.println("--- column names ---");
		for (int i = 0; i < model.getColumnCount(); i++) {
			System.out.println(i + "---" + model.getColumnName(i) + "  " + model.getColumnClass(i));
		}
	}

	protected void printRows(GroupedTableModel model) {
		TreeNode root = (TreeNode)model.getRoot();
		System.out.println("root is " + root);

		List<Object> groupValues = new ArrayList<Object>();
		printRows(model, root, groupValues, "");
	}

	protected void printRows(GroupedTableModel model, TreeNode nodeObject, List<Object> groupValues, String indent) {
		if (null != nodeObject) {
			TreeNode node = (TreeNode) nodeObject;
			for(int i = 0; i < node.getChildCount(); i++) {
				TreeNode cnode = node.getChildAt(i);
				if (null != cnode) {
					if (cnode instanceof TableModelRowNode) {
						for(int j = 0; j < model.getColumnCount(); j++) {
							if (j == 0) {
								System.out.print(indent);
							System.out.print (groupValues + ">>>");
							}
							if (j > 0) {
								System.out.print(",");
							}
							Object value = model.getValueAt(cnode, j);
							System.out.print(value);
						}
						System.out.println("");
					} else if (cnode instanceof TableModelTreeNode) {
						// uncomment the following if all rows need to be traveresed.

						if (printTraversedDataRows) {
							printRows(model, cnode, groupValues, indent + "    ");
						}

						if (printDataRowsAsTable) {
							TableModel tmodel = ((TableModelTreeNode)cnode).getTableModel();
							TableModelPrinter tmp = new TableModelPrinter(indent);
							tmp.print(tmodel, "Table Model from TableModelTreeNode " + groupValues, false ,false, false);
						}
					} else if (cnode instanceof DefaultMutableTreeNode) {

						DefaultMutableTreeNode tnode = (DefaultMutableTreeNode)cnode;
						int groupLevel = 0;
						if (null != tnode.getPath()) {
							groupLevel = tnode.getPath().length - 2; //-1 for root node and -1 for self as 0 based
						}

						Map<String,Object> userObject = (Map<String,Object>)((DefaultMutableTreeNode)cnode).getUserObject();
						Point point = (Point)userObject.get(Point.class.getName());

						int rowToQuery = point.x;

						if (model.getGroupColumns() != null && model.getGroupColumns().length > 0) {
							int columnToQuery = model.getGroupColumnIndex(groupLevel);
							Object groupValue = model.getGroupingValue(rowToQuery, columnToQuery);
							groupValues.add(groupValue);
							System.out.println("GroupValues " + groupValues);
						}

						printRows(model, cnode, groupValues, indent + "    ");

						if (model.getGroupColumns() != null && model.getGroupColumns().length > 0) {
							groupValues.remove(groupValues.size() -1);
						}
					} else if (cnode instanceof AggrigatedTreeNode) {
						System.out.print(indent);
						System.out.println("AggrigatedTreeNode " + groupValues);
						printRows(model, cnode, groupValues, indent + "    ");
					} else if (cnode instanceof AggrigatedRowNode) {
						for(int j = 0; j < model.getColumnCount(); j++) {
							if (j == 0) {
								System.out.print(indent);
							System.out.print (groupValues + " aggrigated >>>");
							}
							if (j > 0) {
								System.out.print(",");
							}
							AggrigatedRowNode agrn = (AggrigatedRowNode) cnode;
							Object value;
							try {
								if (agrn.isAggrigated(j)) {
									value = agrn.getAggrigatedValueAt(j);
									System.out.print(value);
								} else {
									System.out.print("not-agg");
								}
							} catch (AggrigationException e) {
								e.printStackTrace();
							}
						}
						System.out.println("");
					}
				}
			}
		}
	}

}
