/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.tablemodel.impl.filtered;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.swing.table.TableModel;

import net.khajana.util.filter.TableValueFilter;

/**
 *
 * @author ms889296
 */
public class FilteredTableModelImpl extends AbstractFilteredTableModel {

	private static final long serialVersionUID = 1L;

	public FilteredTableModelImpl(TableModel tableModel) {
		super(tableModel);
	}

	public List<Integer> filterIt() {
		TableModel model = getModel();
		Integer[] columnsToFilter = getFilterColumns();
		boolean accept = true;
		List<Integer> acceptRows = new ArrayList<Integer>();
		for (int i = 0; i < model.getRowCount(); i++) {
			accept = true;
			for (int j = 0; j < columnsToFilter.length; j++) {
				TableValueFilter[] cfilters = getFilters(columnsToFilter[j]);
				Map[] values = getFilterValues(columnsToFilter[j]);
				boolean a = accept(cfilters, values, model, i, columnsToFilter[j]);
				accept = accept && a;
				if (!accept) {
					break;
				}
			}
			if (accept) {
				acceptRows.add(i);
			}
		}
		return acceptRows;
	}

	private boolean accept(TableValueFilter[] cfilters, Map[] values, TableModel model, int rowIndex, int columnIndex) {
		boolean accept = true;
		for (int i = 0; i < cfilters.length; i++) {
			boolean a = cfilters[i].accept(values[i], model, rowIndex, columnIndex);
			accept = accept && a;
			if (!accept) {
				break;
			}
		}
		return accept;
	}
}
