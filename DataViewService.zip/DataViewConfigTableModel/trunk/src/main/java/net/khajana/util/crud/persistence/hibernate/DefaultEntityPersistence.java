/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.crud.persistence.hibernate;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;


import org.hibernate.criterion.DetachedCriteria;
import org.springframework.validation.BeanPropertyBindingResult;

import net.khajana.util.crud.ICrudDAO;
import net.khajana.util.crud.ValidationCodes;
import net.khajana.util.crud.ValidationException;
import net.khajana.util.crud.hibernate.AbstractUUIDEntity;
import net.khajana.util.crud.persistence.DeleteDTO;
import net.khajana.util.crud.persistence.IEntityPersistence;
import net.khajana.util.crud.shared.IEntity;


/**
 *
 * @author ms889296
 */
public class DefaultEntityPersistence<ENTITY extends IEntity<ID>,ID extends Serializable, DTO> implements IEntityPersistence<ID,DTO,DetachedCriteria> {

    private IDTOValidator<DTO> validator;
    private Class<ENTITY> entityClass;
    private IEntityAndDtoMorpher<ENTITY, DTO> morpher;
    private IEntityDuplicateCheck<ENTITY> dupChecker;
    private IEntityAuditor<ENTITY> auditor;
    private ICrudDAO<ENTITY, ID, DetachedCriteria> crudDAO;
    private ICrudDAO<AbstractUUIDEntity, ID, DetachedCriteria> auditorDAO;

    public void setValidator(IDTOValidator<DTO> validator) {
        this.validator = validator;
    }
    public IDTOValidator<DTO> getValidator() {
        return validator;
    }

    public IEntityAndDtoMorpher<ENTITY, DTO> getMorpher() {
        return morpher;
    }
    public void setMorpher(IEntityAndDtoMorpher<ENTITY, DTO> morpher) {
        this.morpher = morpher;
    }

    public IEntityDuplicateCheck<ENTITY> getDupChecker() {
        return dupChecker;
    }
    public void setDupChecker(IEntityDuplicateCheck<ENTITY> dupChecker) {
        this.dupChecker = dupChecker;
    }

    public ICrudDAO<ENTITY, ID, DetachedCriteria> getCrudDAO() {
        return crudDAO;
    }

    public void setCrudDAO(ICrudDAO<ENTITY, ID, DetachedCriteria> crudDAO) {
        this.crudDAO = crudDAO;
    }

    public ICrudDAO<AbstractUUIDEntity, ID, DetachedCriteria> getAuditorDAO() {
        return auditorDAO;
    }

    public void setAuditorDAO(ICrudDAO<AbstractUUIDEntity, ID, DetachedCriteria> auditorDAO) {
        this.auditorDAO = auditorDAO;
    }

    public Class<ENTITY> getEntityClass() {
        return entityClass;
    }
    public void setEntityClass(Class<ENTITY> entityClass) {
        this.entityClass = entityClass;
    }

    public IEntityAuditor<ENTITY> getAuditor() {
        return auditor;
    }

    public void setAuditor(IEntityAuditor<ENTITY> auditor) {
        this.auditor = auditor;
    }


    public DTO get(ID id) {
        // TODO should id be checked for null here?
        ENTITY entity = crudDAO.findById(entityClass, id);
        if (null == entity) {
            return null;
        }
        return morpher.toDto(entity);
    }

    public ENTITY getEntity(ID id) {
        // TODO should id be checked for null here?
        ENTITY entity = crudDAO.findById(entityClass, id);
        return entity;
    }

    
    public Collection<DTO> get() {
        Collection<ENTITY> entityList = crudDAO.findAll(entityClass);
        return toDTO(entityList);
    }

    public DTO add(DTO dto) throws ValidationException {
        validator.addValidator(dto);
        ENTITY entity = null;
        entity = morpher.toEntity(dto, entity, false);

        checkForDuplicate(entity, false);

        crudDAO.saveOrUpdate(entity);

        audit("INSERT", entity);

        return morpher.toDto(entity);
    }

    
    public DTO update(DTO dto) throws ValidationException {
        validator.updateValidator(dto);

        ENTITY entity = morpher.toEntity(dto, null, true);

        ENTITY existingEntity = crudDAO.findById(entityClass, entity.getEntityId());
        if (null == existingEntity) {
            // the object is already deleted throw exception
            BeanPropertyBindingResult errors = new BeanPropertyBindingResult(entity, entityClass.getName());
            errors.reject(entityClass.getName(), String.format(ValidationCodes.OBJECT_ALREADY_DELETED.getDeaultMessage(), entityClass.getName()));
            throw new ValidationException(errors.getGlobalErrors(), errors.getFieldErrors());
        }

        // populate the object from the server avoid loosing any chages.? version should take care of this.
        entity = morpher.toEntity(dto, existingEntity, true);

        checkForDuplicate(entity, true);

        crudDAO.saveOrUpdate(entity);

        audit("UPDATE", entity);

        return morpher.toDto(entity);
    }

    
    public void delete(DeleteDTO<ID> deleteDto) throws ValidationException {
        validator.deleteValidator(deleteDto);

        if (deleteDto.getVersion() == -1) {
            ENTITY entity = crudDAO.findById(entityClass, deleteDto.getId());
            if (null != entity) {
                crudDAO.delete(entity);

                audit("DELETE", entity);
            }
            return;
        }

        ENTITY entity = crudDAO.findById(entityClass, deleteDto.getId());
        if (null == entity) {
            return;
        }
        checkForEntityVersion(entity, entity.getEntityVersion(), deleteDto.getVersion());

        crudDAO.delete(entity);

        audit("DELETE", entity);
    }

    
    public Collection<DTO> findByCriteria(DetachedCriteria criteria) {
        Collection<ENTITY> entityList = crudDAO.findByCriteria(criteria);
        return toDTO(entityList);
    }

    private void checkForEntityVersion(ENTITY entity, long v1, long v2) throws ValidationException {
        if (v1 != v2) {
            BeanPropertyBindingResult errors = new BeanPropertyBindingResult(entity, entity.getClass().getName());
            errors.reject(entity.getClass().getName(), String.format(ValidationCodes.VERSION_STALE.getDeaultMessage(), entity.getClass().getName()));
            throw new ValidationException(errors.getGlobalErrors(), errors.getFieldErrors());
        }
    }

    private Collection<DTO> toDTO(Collection<ENTITY> entityList) {
        if (null == entityList) {
            return null;
        }
        return morpher.toDto(entityList);
    }

    private void throwDuplicateCheck(ENTITY entity) throws ValidationException {
        BeanPropertyBindingResult errors = new BeanPropertyBindingResult(entity, entityClass.getName());
        errors.reject(entityClass.getName(), String.format(ValidationCodes.DUPLICATE_NOT_ALLOWED.getDeaultMessage(), entityClass.getName()));
        throw new ValidationException(errors.getGlobalErrors(), errors.getFieldErrors());
    }

    private void checkForDuplicate(ENTITY entity, boolean onUpdate) throws ValidationException {
        DetachedCriteria dupCheckCriteria = dupChecker.getDuplicateSearchCriteria(entity, onUpdate);
        List<ENTITY> existing = crudDAO.findByCriteria(dupCheckCriteria);
        if (existing != null && existing.size() > 0) {
            throwDuplicateCheck(entity);  // TODO ENTITy or DTO for the error message?
        }
    }

    private void audit(String action, ENTITY entity) {
        try {
            auditorDAO.saveOrUpdate(auditor.audit(action, entity));
        } catch (Exception ex) {
            ex.printStackTrace();
            // DO not cause an exception due to audit issue.
            // TODO logger
        }
    }
}
