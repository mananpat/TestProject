/**
 * 
 */
package net.khajana.processor.impl;

import java.util.ArrayList;

import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import net.khajana.util.tablemodel.enums.SortOrder;
import net.khajana.util.tableview.GroupColumn;
import net.khajana.util.tableview.SortColumn;
import net.khajana.util.tableview.TableViewConfig;
import net.khajana.util.tableview.ViewColumn;
import net.khajana.util.tableview.impl.DefaultGroupColumn;
import net.khajana.util.tableview.impl.DefaultSortColumn;
import net.khajana.util.tableview.impl.DefaultTableViewConfig;
import net.khajana.util.tableview.impl.DefaultViewColumn;

import org.apache.log4j.Logger;

/**
 * @author mp14693
 *
 */
public abstract class BaseViewProcessor {

	final static Logger log = Logger.getLogger(BaseViewProcessor.class);

	//TableModel dataTableModel;
	//TableViewConfig tableViewConfig;
	
	public TableModel getDataTableModel(String[] inputDataColumns, Object[] inputData) {		
		Object[][] data = new Object[][]{inputData};		 	
		TableModel tableModel = new DefaultTableModel(data, inputDataColumns);
		return tableModel;
		
		/*Object[][] data = new Object[][] {
				{"IBM", "International Bus Machine", "US", "EQ", new Integer(1000) },
				{"MSFT", "Microsoft", "US", "EQ", new Integer(500) },
				{"BP", "British Patrol", "UK", "CSH", new Integer(300) },
				{"IBM", "International Bus Machine", "JP", "EQ", new Integer(200) },
				{"FB", "Facegook", "US", "EQ", new Integer(800) },
		};

		String[] columnNames = new String[] {
				"products$ticker",
				"products$desc",
				"products$settleCountry",
				"products$assetType",
				"products$sharesIssued",
		};
		TableModel tableModel = new DefaultTableModel(data, columnNames);
		return tableModel;
		*/
	}
	
	
}
