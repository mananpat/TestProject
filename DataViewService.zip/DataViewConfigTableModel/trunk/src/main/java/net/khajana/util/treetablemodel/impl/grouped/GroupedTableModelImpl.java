/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */

package net.khajana.util.treetablemodel.impl.grouped;

import java.awt.Point;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.table.TableModel;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreeNode;

import net.khajana.util.tablemodel.TableModelUtils;
import net.khajana.util.tablemodel.aggrigated.Aggrigator;
import net.khajana.util.tablemodel.impl.DeligatedTableModel;
import net.khajana.util.treetablemodel.impl.AggrigatedRowNode;
import net.khajana.util.treetablemodel.impl.AggrigatedTreeNode;
import net.khajana.util.treetablemodel.impl.TableModelRowNode;
import net.khajana.util.treetablemodel.impl.TableModelTreeNode;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/*
DefaultMutableTreeNode(point) // each GroupNode is this - with point indicating the range of values.
	// Rows:  valueModel is the main table (not a subset) and x and y are the range for this table.
	TableModel childTable = new DeligatedTableModel(valueModel, point.x, point.y);
		// This translates to rows:  based on (y - x)
	MutableTreeNode childNode = new TableModelTreeNode(childTable);
				return new TableModelRowNode(TableModelTreeNode.this, tableModel, cindex++);
*/

/**
 *
 * @author ms889296
 */
public class GroupedTableModelImpl extends AbstractGroupedTableModel {

	final Logger logger = LoggerFactory.getLogger(GroupedTableModelImpl.class);

	public GroupedTableModelImpl() {
		// for serialization
	}
	public GroupedTableModelImpl(TableModel groupingTableModel, TableModel valueTableModel) {
		super(new DefaultMutableTreeNode(), groupingTableModel, valueTableModel);
	}

	public TableModel getAsTableModel(DefaultMutableTreeNode node) {
		Map<String,Object> userObject = (Map<String,Object>)node.getUserObject();
		Point point = (Point)userObject.get(Point.class.getName());
		TableModel groupTable = new DeligatedTableModel(getModel(), point.x, point.y);

		return groupTable;
	}


	public Object getValueAt(TreeNode nodeObj, int column) {
		// let an exception be thrown for a class cast to avoid unnecessary
		// performance hits by instanceof.

			return ((TableModelRowNode)nodeObj).getValueAt(column);
	}

	public Object getChild(Object parent, int index) {
		DefaultMutableTreeNode node = (DefaultMutableTreeNode)parent;
		return node.getChildAt(index);
	}

	public int getChildCount(Object parent) {
		DefaultMutableTreeNode node = (DefaultMutableTreeNode)parent;
		return node.getChildCount();
	}

	boolean aggrigationAtStart = false;
	boolean grandTotal = true;



	public boolean isAggrigationAtStart() {
		return aggrigationAtStart;
	}
	public void setAggrigationAtStart(boolean aggrigationAtStart) {
		this.aggrigationAtStart = aggrigationAtStart;
	}
	public boolean isGrandTotal() {
		return grandTotal;
	}
	public void setGrandTotal(boolean grandTotal) {
		this.grandTotal = grandTotal;
	}


	public void group() {
		DefaultMutableTreeNode root = (DefaultMutableTreeNode)getRoot();

		// clear out in case of re-grouping.
		root.removeAllChildren();

		TableModel groupingModel = getGroupingModel();
		Map<String, Integer> dataModelNameIndexMap = TableModelUtils.generateColumnNameIndexMap(groupingModel);

		TableModel valueModel = getModel();

		int[] groupedColumns = getGroupColumns();
		List<Integer> groupedColumnIndexes = new ArrayList<Integer>();
		for (int i = 0; i < groupedColumns.length; i++) {
			groupedColumnIndexes.add(groupedColumns[i]);
		}

		if (grandTotal && aggrigationAtStart) {
			/* start aggrigation */
			int groupLevel = -1; // grand total
			AggrigatedTreeNode aggrigatedTreeNode = getAggrigatedTreeNode(groupLevel, groupingModel, dataModelNameIndexMap, new DeligatedTableModel(valueModel, 0, valueModel.getRowCount()-1), null); // TODO i don't know if table models are correct

			if (null != aggrigatedTreeNode && aggrigatedTreeNode.getChildCount() > 0) {
				root.add(aggrigatedTreeNode);
			}
			/* end aggrigation */
		}


		if (valueModel.getRowCount() > 0) {
			groupIt(groupingModel, dataModelNameIndexMap, valueModel, root, 0, valueModel.getRowCount() - 1, groupedColumnIndexes, 0);
		}

		if (grandTotal && !aggrigationAtStart) {
			/* start aggrigation */
			int groupLevel = -1; // grand total
			AggrigatedTreeNode aggrigatedTreeNode = getAggrigatedTreeNode(groupLevel, groupingModel, dataModelNameIndexMap, new DeligatedTableModel(valueModel, 0, valueModel.getRowCount()-1), null); // TODO i don't know if table models are correct

			if (null != aggrigatedTreeNode && aggrigatedTreeNode.getChildCount() > 0) {
				root.add(aggrigatedTreeNode);
			}
			/* end aggrigation */
		}

	}

	private void groupIt(TableModel groupingModel, Map<String, Integer> dataModelNameIndexMap, TableModel valueModel, DefaultMutableTreeNode node,
						 int startIndex, int endIndex, List<Integer> groupedColumnIndexes, int currentGroupLevel) {
		Point[] points = null;
		if (groupedColumnIndexes == null || groupedColumnIndexes.size() == 0 || valueModel.getRowCount() == 0) {
			 points = new Point[] {new Point(startIndex, endIndex)};
		} else {
			// always get the first item in the list, as recursively the first item is always removed.
			int columnIndex = groupedColumnIndexes.get(0);
			points = getGroupRanges(groupingModel, startIndex, endIndex, columnIndex);
		}

		if (null != points) {
			for (int i = 0; i < points.length; i++) {
				Point point = points[i];

				// i think this is the start of the group.
				Map<String,Object> userObject = new HashMap<String,Object>();
				userObject.put(Point.class.getName(), point);

				DefaultMutableTreeNode child = new DefaultMutableTreeNode(userObject);
				node.add(child);

				if (aggrigationAtStart) {
					/* start aggrigation */
					int groupLevel = currentGroupLevel; // groupedColumnIndexes.size();
					AggrigatedTreeNode aggrigatedTreeNode = getAggrigatedTreeNode(groupLevel, groupingModel, dataModelNameIndexMap, new DeligatedTableModel(valueModel, point.x, point.y), point); // TODO i don't know if table models are correct

					if (null != aggrigatedTreeNode && aggrigatedTreeNode.getChildCount() > 0) {
						child.add(aggrigatedTreeNode);
					}
					/* end aggrigation */
				}

				if (groupedColumnIndexes.size() < 2) { // O or 1, no group or 1 level of group.?? comment is incorrect
					TableModel childTable = new DeligatedTableModel(valueModel, point.x, point.y);

					MutableTreeNode childNode = new TableModelTreeNode(childTable);
					child.add(childNode);
				} else {
					// remove the first item in the list as it has been processed

					if (groupedColumnIndexes.size() > 0) {
						Integer columnIndex = groupedColumnIndexes.remove(0);
						groupIt(groupingModel, dataModelNameIndexMap, valueModel, child, point.x, point.y, groupedColumnIndexes, currentGroupLevel + 1);
						groupedColumnIndexes.add(0, columnIndex);
					}
				}

				if (!aggrigationAtStart) {
					/* start aggrigation */
					int groupLevel = currentGroupLevel; // groupedColumnIndexes.size();
					AggrigatedTreeNode aggrigatedTreeNode = getAggrigatedTreeNode(groupLevel, groupingModel, dataModelNameIndexMap, new DeligatedTableModel(valueModel, point.x, point.y), point); // TODO i don't know if table models are correct

					if (null != aggrigatedTreeNode && aggrigatedTreeNode.getChildCount() > 0) {
						child.add(aggrigatedTreeNode);
					}
					/* end aggrigation */
				}
			}
		}
	}

	/**
	 * Returns the start and end indexes of rows who's value in the provided colum are equal.
	 * This allows for grouping.
	 * @param tableModel The model to scan
	 * @param startIndex for row index
	 * @param endIndex last row index
	 * @param columnIndex column to compare
	 * @return array of points  point.x is the first row, point.y is the last row with the same value as the first row.
	 */

	private Point[] getGroupRanges(TableModel tableModel, int startIndex, int endIndex, int columnIndex) {
		List<Point> points = new ArrayList<Point>();

		if (startIndex == endIndex) {
			Point p = new Point(startIndex, endIndex);
			points.add(p);
		} else {
			Object pv = tableModel.getValueAt(startIndex, columnIndex);
			Object cv = null;

			for (int i = startIndex + 1, j = endIndex + 1, xs = startIndex; i < j; i++) {
				cv = tableModel.getValueAt(i, columnIndex);
				if (pv == cv && i != endIndex) {
					// same refrence, or both null.
					continue;
				}

				if (pv == null || cv == null || !pv.equals(cv)) {
					// not equals., one of the two is null, or equals returned false. or last element
					// change in group.
					Point p = new Point(xs, i - 1);
					points.add(p);
					xs = i;
					pv = cv;
				}

				// last node needs to be processed.
				if (i == endIndex) {
					Point p = new Point(xs, i);
					points.add(p);
					xs = i;
					pv = cv;
				}
			}
		}

		// do we really need to convert to array if we are using it internaly?
		return points.toArray(new Point[points.size()]);
	}

	private AggrigatedTreeNode getAggrigatedTreeNode(int groupLevel, TableModel dataTableModel, Map<String, Integer> dataModelNameIndexMap, TableModel tableModel, Point point) {
		String[] aggrigationCategoryOrder = getAggrigationCategoryOrder();

		if (null == aggrigationCategoryOrder || aggrigationCategoryOrder.length == 0) {
			logger.debug("aggrigationCategoryOrder is null or empty, thus not aggrigating this view");
			return null;
		}

		AggrigatedTreeNode agrrigatedRow = new AggrigatedTreeNode();
		int columnCount = getColumnCount();

		for (int catgIdx = 0; catgIdx < aggrigationCategoryOrder.length; catgIdx++) {
			Aggrigator[] categoryAggrigators = new Aggrigator[columnCount];
			boolean categoryHasAggrigator = false;
			for (int col = 0; col < columnCount; col++) {
				Aggrigator aggrigator = getAggrigators(col, groupLevel, aggrigationCategoryOrder[catgIdx]);
				if (aggrigator != null) {
					categoryAggrigators[col] = aggrigator;
					categoryHasAggrigator = true;
				}
			}
			if (categoryHasAggrigator) {
				Map<String,Object> userObject = new HashMap<String,Object>();
				userObject.put(Point.class.getName(), point);

				AggrigatedRowNode arn = new AggrigatedRowNode(agrrigatedRow, dataTableModel, dataModelNameIndexMap, tableModel, categoryAggrigators, userObject);
				agrrigatedRow.insert(arn, agrrigatedRow.getChildCount());
			}
		}

		if (agrrigatedRow.getChildCount() > 0) {
			return agrrigatedRow;
		}

		return null;
	}
/*

for groupIndex get aggrigators
  create an aggrigaton row
    for each aggrigated column, add aggrigation node



 */
}
