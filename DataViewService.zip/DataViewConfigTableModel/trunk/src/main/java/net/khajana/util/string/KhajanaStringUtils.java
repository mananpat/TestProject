/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.string;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang.StringUtils;

/**
*
* @author ms889296
*/
public class KhajanaStringUtils {

    public static String[] join(String[] a1, String[] a2) {
        List<String> joined = new ArrayList<String>();
        joined.addAll(Arrays.asList(a1));
        joined.addAll(Arrays.asList(a2));
        return joined.toArray(new String[joined.size()]);
    }

    public static String[] split(String value, String seperator) {
        return StringUtils.splitByWholeSeparator(value, seperator);
    }

    public static String[] split(String value, char seperator) {
        return StringUtils.split(value, seperator);
    }

    public static String[] splitFirst(String value, char seperator) {
        int idx = value.indexOf(seperator);
        if (idx < 1) {
            return new String[]{value};
        }
        String[] s2 = new String[2];
        s2[0] = value.substring(0, idx);
        s2[1] = value.substring(idx + 1);
        return s2;
    }
}
