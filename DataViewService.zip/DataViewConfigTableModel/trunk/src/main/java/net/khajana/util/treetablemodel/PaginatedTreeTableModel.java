/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.treetablemodel;

/**
 *
 * @author ms889296
 */
public interface PaginatedTreeTableModel<T> /* extends TreeTableModel, */  {

	public void paginate();
	
	public int getRowsPerPage();
	public void setRowsPerPage(int rowsPerPage);
	
	public int getPageCount();
	public T getPage(int pageNumber);
	
	public int getPageNumber(int rowIndex);
}
