/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.tablemodel.impl.aggrigated;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.swing.table.TableModel;

import net.khajana.util.tablemodel.DecoratedTableModel;
import net.khajana.util.tablemodel.aggrigated.AggrigatedTableModel;
import net.khajana.util.tablemodel.aggrigated.AggrigatedValue;
import net.khajana.util.tablemodel.aggrigated.AggrigationException;
import net.khajana.util.tablemodel.aggrigated.Aggrigator;

/**
 *
 * @author ms889296
 */
public abstract class AbstractAggrigatedTableModel extends DecoratedTableModel implements AggrigatedTableModel {

	private Map<Integer, List<AggrigatedValue>> aggrigators = new HashMap<Integer, List<AggrigatedValue>>();
	private TableModel dataTableModel;

	public AbstractAggrigatedTableModel(TableModel tableModel, TableModel dataTableModel) {
		super(tableModel);
		this.dataTableModel = dataTableModel;
	}

	protected abstract void aggrigateIt(TableModel dataTableModel, Map<Integer, List<AggrigatedValue>> aggrigators) throws AggrigationException;

	public void aggrigate() throws AggrigationException {
		aggrigateIt(dataTableModel, aggrigators);

	}

	public boolean isAggrigatedAs(int columnIndex, String aggrigatorName) {
		List<AggrigatedValue> aggVals = aggrigators.get(columnIndex);
		if (null == aggVals || aggVals.size() == 0) {
			return false;
		}

		/*  TODO removed b/c NamedObject interface has been removed
		for (AggrigatedValue value : aggVals) {
			if (value.getAggrigator().getName().equals(aggrigatorName)) {
				return true;
			}
		}
		 */

		return false;
	}

	public int[] getAggrigatedColumns() {
		Integer[] cidxes = aggrigators.keySet().toArray(new Integer[aggrigators.size()]);
		int[] idxes = new int[cidxes.length];

		for (int i = 0; i < cidxes.length; i++) {
			Integer integer = cidxes[i];
			idxes[i] = integer.intValue();
		}
		return idxes;
	}

	public Aggrigator getAggrigator(int columnIndex, String logicalName) {
		List<AggrigatedValue> aggVals = aggrigators.get(columnIndex);
		if (null == aggVals) {
			return null;
		}

		/* TODO removed b/c NamedObject interface has been removed
		for (int i = 0; i < aggVals.size(); i++) {
			if (aggVals.get(i).getAggrigator().getName().equals(logicalName)) {
				return aggVals.get(i).getAggrigator();
			}
		}
		*/

		return null;
	}

	public Aggrigator getAggrigatorByCategory(int columnIndex, String category) {
		List<AggrigatedValue> aggVals = aggrigators.get(columnIndex);
		if (null == aggVals) {
			return null;
		}

		for (int i = 0; i < aggVals.size(); i++) {
			if (aggVals.get(i).getAggrigator().getCategory().equals(category)) {
				return aggVals.get(i).getAggrigator();
			}
		}

		return null;
	}

	public Aggrigator[] getAggrigators(int columnIndex) {
		List<AggrigatedValue> aggVals = aggrigators.get(columnIndex);
		if (null == aggVals) {
			return null;
		}

		Aggrigator[] aggs = new Aggrigator[aggVals.size()];
		for (int i = 0; i < aggs.length; i++) {
			aggs[i] = aggVals.get(i).getAggrigator();
		}

		return aggs;
	}

	public Aggrigator[] getAggrigators() {
		Set<AggrigatedValue> aggVals = new HashSet<AggrigatedValue>();

		for (List<AggrigatedValue> caggs : aggrigators.values()) {
			aggVals.addAll(caggs);
//			System.out.println("agg vals now has " + aggVals);
		}
		Aggrigator[] aggs = new Aggrigator[aggVals.size()];
		int idx = 0;
		for (AggrigatedValue aggVal : aggVals) {
			aggs[idx++] = aggVal.getAggrigator();
		}

		return aggs;
	}

	public void addAggrigator(int columnIndex, Aggrigator aggrigator) {
		List<AggrigatedValue> aggs = aggrigators.get(columnIndex);
		if (null == aggs) {
			aggs = new ArrayList<AggrigatedValue>();
			aggrigators.put(columnIndex, aggs);
		}
		if (!aggs.contains(aggrigator)) {
			AggrigatedValue aggValue = new AggrigatedValue(aggrigator);
			aggs.add(aggValue);
		}
	}

	public void removeAggrigator(int columnIndex, Aggrigator aggrigator) {
		List<AggrigatedValue> aggs = aggrigators.get(columnIndex);
		if (null != aggs) {
			aggs.remove(aggrigator);
			if (aggs.size() == 0) {
				aggrigators.remove(columnIndex);
			}
		}
	}

	public void removeAllAggrigators(int columnIndex) {
		aggrigators.remove(columnIndex);
	}

	public void removeAllAggrigators() {
		aggrigators.clear();
	}

	public Object getAggrigatedValue(int columnIndex, String aggrigatorLogicalName) {
		/* TODO removed b/c NamedObject interface has been removed
		Aggrigator[] aggrigators = getAggrigators(columnIndex);
		for (int i = 0; i < aggrigators.length; i++) {
			if (aggrigators[i].getName().equals(aggrigatorLogicalName)) {
				return getAggrigatedValue(columnIndex, aggrigators[i]);
			}
		}
		*/
		return null;
	}
	public Object getAggrigatedValue(int columnIndex, Aggrigator aggrigator) {
		List<AggrigatedValue> aggVals = aggrigators.get(columnIndex);
		if (null == aggVals) {
			throw new ArrayIndexOutOfBoundsException("Column Not aggrigated " + columnIndex);
		}
//		System.out.println("AGGRIGATORS " + aggrigators);
//		System.out.println("aggrigator " + aggrigator);
		for (AggrigatedValue aggValue : aggVals) {
			if (aggValue.equals(aggrigator)) {
				return aggValue.getValue();
			}
		}
		// aggVals.get(aggVals.indexOf(aggrigator));
		// return aggVal.getValue();
		return null;
	}
}
