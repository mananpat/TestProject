/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.filter.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.swing.table.TableModel;

import org.apache.commons.beanutils.ConversionException;
import org.apache.commons.beanutils.ConvertUtils;

import net.khajana.util.filter.TableValueFilter;

/**
 *
 * @author ms889296
 */
public class RegularExpressionTableValueFilter implements TableValueFilter{

	public RegularExpressionTableValueFilter() {
		super();
	}
	
	public boolean accept(Map<String,List<Object>> values, TableModel tableModel, int rowIndex, int colIndex) {
		/*
		Object value = values.get("value").get(0);

		// TODO this method needs to be Implemented
		Object v = tableModel.getValueAt(rowIndex, colIndex);
		if (v.equals(value)) {
			return true;
		}
		return false;
*/		
		Object value = values.get("value").get(0);

		Object convertedValue = value;
		Class clazz = tableModel.getColumnClass(colIndex);
		List<Object> convertedValueList = values.get("value_" + clazz.getName());
		if (null == convertedValueList) {
			if (null != value && value instanceof String) {
				try {
					String sval = (String)value;
					sval = sval.trim();
					convertedValue = ConvertUtils.convert(sval, clazz);
					convertedValueList = new ArrayList<Object>();
					convertedValueList.add(convertedValue);
					values.put("value_" + clazz.getName(), convertedValueList);
				} catch (ConversionException e) {
					// silantly ignore as we could not convert.
					// TODO might want to set a could not convert to type 
					// exceptioon in values thus do not try to convert for each row.
					e.printStackTrace();  // TODO log to log system
				}
			}
		} else {
			convertedValue = convertedValueList.get(0);
		}
		
		Object v = tableModel.getValueAt(rowIndex, colIndex);
		if (convertedValue == v) {
			return true;
		}
		if (convertedValue == null || v == null) {
			return false;
		}
		int c = ((Comparable)convertedValue).compareTo(v);
		return (c == 0);
	}
}
