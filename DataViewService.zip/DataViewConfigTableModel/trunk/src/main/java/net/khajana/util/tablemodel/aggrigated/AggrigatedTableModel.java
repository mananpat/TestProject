/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.tablemodel.aggrigated;

import javax.swing.table.TableModel;

/**
 *
 * @author ms889296
 */
public interface AggrigatedTableModel extends TableModel {
	public void aggrigate() throws AggrigationException;

	public int[] getAggrigatedColumns();
	
	public Aggrigator getAggrigatorByCategory(int columnIndex, String category);
	
	public Aggrigator getAggrigator(int columnIndex, String logicalName);	
	public Aggrigator[] getAggrigators(int columnIndex);	
	public Aggrigator[] getAggrigators();

	public boolean isAggrigatedAs(int columnIndex, String aggrigatorName);

	public void addAggrigator(int columnIndex, Aggrigator aggrigator);
	public void removeAggrigator(int columnIndex, Aggrigator aggrigator);
	public void removeAllAggrigators(int columnIndex);
	public void removeAllAggrigators();
	
	public Object getAggrigatedValue(int columnIndex, Aggrigator aggrigator);	
	public Object getAggrigatedValue(int columnIndex, String aggrigatorLogicalName);	
}
