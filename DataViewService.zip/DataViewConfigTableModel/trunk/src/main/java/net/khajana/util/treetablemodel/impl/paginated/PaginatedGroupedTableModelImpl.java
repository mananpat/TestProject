/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */

package net.khajana.util.treetablemodel.impl.paginated;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.table.TableModel;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreeNode;

import net.khajana.util.tablemodel.impl.DeligatedTableModel;
import net.khajana.util.treetablemodel.grouped.GroupedTableModel;
import net.khajana.util.treetablemodel.grouped.GroupedTableModelPrinter;
import net.khajana.util.treetablemodel.impl.AggrigatedTreeNode;
import net.khajana.util.treetablemodel.impl.TableModelTreeNode;
import net.khajana.util.treetablemodel.impl.grouped.AbstractGroupedTableModel;
import net.khajana.util.treetablemodel.impl.grouped.DefaultGroupedTableModel;

/**
 *
 * @author ms889296
 */
public class PaginatedGroupedTableModelImpl extends AbstractPaginatedTreeTableModel<GroupedTableModel> {

	private GroupedTableModel groupedTableModel;

	public PaginatedGroupedTableModelImpl(GroupedTableModel groupedTableModel) {
		this.groupedTableModel = groupedTableModel;
	}

	@Override
	protected void paginateIt() {
		/** Each element in the list is for a given page **/
		List<GroupedTableModel> paginatedGroupedTableModels = new ArrayList<GroupedTableModel>();
		List<Integer> indicesPageNumbers = new ArrayList<Integer>();

		AbstractGroupedTableModel srcAbstractGroupedTableModel = (AbstractGroupedTableModel)groupedTableModel;

		TreeNode srcRootNode = (TreeNode)groupedTableModel.getRoot();
		DefaultMutableTreeNode destRootNode = (DefaultMutableTreeNode) ((DefaultMutableTreeNode)groupedTableModel.getRoot()).clone();

		int treeDepth = groupedTableModel.getGroupColumns().length + 1;
		if (groupedTableModel.getGroupColumns().length == 0) {
			treeDepth++;
		}

		TreeNode[] destNodeObjects = new TreeNode[treeDepth];
		destNodeObjects[0] = destRootNode;
		DefaultGroupedTableModel dgtm = new DefaultGroupedTableModel(destRootNode, srcAbstractGroupedTableModel.getGroupingModel(), srcAbstractGroupedTableModel.getModel());
		setGroupedColumns(srcAbstractGroupedTableModel, dgtm);

//		System.out.println("adding paginated model " + paginatedGroupedTableModels.size());
		paginatedGroupedTableModels.add(dgtm);

		int [] groupStartedOnPage = new int[treeDepth];
		int [] groupRowsOnPage = new int[treeDepth];
		int [] groupNodesRemain = new int[treeDepth];

		int[] pageRowCount = new int[] {0};
		for(int i = 0; i < srcRootNode.getChildCount(); i++) {
			TreeNode childNode = srcRootNode.getChildAt(i);

			try {
				paginate(srcAbstractGroupedTableModel, childNode, paginatedGroupedTableModels, destNodeObjects, 0, pageRowCount, indicesPageNumbers, groupStartedOnPage, groupRowsOnPage, groupNodesRemain);
			} catch (CloneNotSupportedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		// paginate((AbstractGroupedTableModel)groupedTableModel, srcRootNode, paginatedGroupedTableModels, destNodeObject, 0);

		// List<TreeNode> treeNodes = new ArrayList<TreeNode>();

//		printIt(paginatedGroupedTableModels);

		// iterate thorugh tree;

		int[] indicesPageNumberInts = new int[indicesPageNumbers.size()];
		for (int i = 0; i < indicesPageNumberInts.length; i++) {
			indicesPageNumberInts[i] = indicesPageNumbers.get(i);
		}

		System.out.println("          number of pages = number of models    " + paginatedGroupedTableModels.size());
		init(indicesPageNumberInts, (GroupedTableModel[])paginatedGroupedTableModels.toArray(new GroupedTableModel[paginatedGroupedTableModels.size()]));
	}

	private void setGroupedColumns(AbstractGroupedTableModel sourceGroupedTableModel, AbstractGroupedTableModel destGroupedTableModel) {
		int[] groupedColumns = sourceGroupedTableModel.getGroupColumns();
		if (null != groupedColumns) {
			for (int i = 0; i < groupedColumns.length; i++) {
				destGroupedTableModel.addGroupColumn(groupedColumns[i]);
			}
		}
	}

	private void printIt(List<GroupedTableModel> paginatedGroupedTableModels) {
		System.out.println("printing ");

		System.out.println("");
		System.out.println("PAGINATED MODEL STARTED");
		System.out.println("");

		GroupedTableModelPrinter printer = new GroupedTableModelPrinter();
		for (int i = 0; i < paginatedGroupedTableModels.size(); i++) {
			System.out.println("");
			System.out.println("");
			System.out.println("");
			System.out.println("Page Number " + (i + 1));
			GroupedTableModel agtm = paginatedGroupedTableModels.get(i);
			printer.print(agtm, true, true, true);

			if (i == 0) {
				break;
			}
		}
		System.out.println("");
		System.out.println("PAGINATED MODEL FINISHED");
		System.out.println("");
	}

	protected void paginate(AbstractGroupedTableModel sourceGroupedTableModel, TreeNode srcNodeObject,
							List<GroupedTableModel> paginatedGroupedTableModels, TreeNode[] destNodeObjects, int groupLevel, int[] pageRowCount,
							List<Integer> indicesPageNumbers, int[] groupStartedOnPage, int[] groupRowsOnPage, int[] groupNodesRemain) throws CloneNotSupportedException {

		if (null != srcNodeObject) {
			if (srcNodeObject instanceof DefaultMutableTreeNode) {
				// if userObject is null then its the root.
				// else if userObject is point then its the GroupNode.
				DefaultMutableTreeNode destNode  = (DefaultMutableTreeNode)destNodeObjects[groupLevel];

				DefaultMutableTreeNode newChildNode = (DefaultMutableTreeNode) ((DefaultMutableTreeNode)srcNodeObject).clone();

				{ // fix up block due to showllow clone problem.
					Map<String,Object> userObject = (Map<String,Object>)((DefaultMutableTreeNode)newChildNode).getUserObject();
					if (null != userObject) {
						Map<String,Object> newUserObject =( HashMap<String,Object>)((HashMap<String,Object>)userObject).clone();
						newChildNode.setUserObject(newUserObject);
					}
				}

				PaginatedGroupedTableModelNodeUserObject paginatedGroupedTableModelNodeUserObject = new PaginatedGroupedTableModelNodeUserObject();
				paginatedGroupedTableModelNodeUserObject.setContinuedFromPreviousPage(false);
				paginatedGroupedTableModelNodeUserObject.setContinuedOnNextPage(false);
				Map<String,Object> userObject = (Map<String,Object>)newChildNode.getUserObject();
				if (null == userObject) {
					userObject = new HashMap<String,Object>();
					newChildNode.setUserObject(userObject);
				}
				userObject.put(PaginatedGroupedTableModelNodeUserObject.class.getName(), paginatedGroupedTableModelNodeUserObject);

				destNode.add(newChildNode);

				destNodeObjects[groupLevel+1] = newChildNode;

				groupRowsOnPage[groupLevel + 1] = 0;

				for(int i = 0, j = srcNodeObject.getChildCount(); i < j; i++) {
					TreeNode childNode = srcNodeObject.getChildAt(i);

					groupStartedOnPage[groupLevel] = paginatedGroupedTableModels.size() - 1;
					groupNodesRemain[groupLevel+1] = j - i;
					paginate(sourceGroupedTableModel, childNode, paginatedGroupedTableModels, destNodeObjects, groupLevel+1, pageRowCount, indicesPageNumbers, groupStartedOnPage, groupRowsOnPage, groupNodesRemain);
				}

			} else if (srcNodeObject instanceof AggrigatedTreeNode) {

				DefaultMutableTreeNode destNode  = (DefaultMutableTreeNode)destNodeObjects[groupLevel];

				AggrigatedTreeNode newChildNode = new AggrigatedTreeNode((AggrigatedTreeNode)srcNodeObject);

				destNode.add(newChildNode);

				//destNodeObjects[groupLevel+1] = newChildNode;

			} else if (srcNodeObject instanceof TableModelTreeNode) {
				// This is the inner most group.  The children of this node
				// are the table rows.

				int rowsNeededForGroupHeader = 1;

				int rowsPerPage = getRowsPerPage();
				int rowsToUse = rowsPerPage - pageRowCount[0];

				groupStartedOnPage[groupLevel] = paginatedGroupedTableModels.size() - 1;
				groupRowsOnPage[groupLevel] = 0;

				if (rowsToUse <=0) {  // instead of 0 we do 1, as we need to consider the group header as well.

					int currentPageIndex = paginatedGroupedTableModels.size() - 1;
					ClonedGroupTableModel clonedGroupTableModel= createNewGroupedTableModel((TableModelTreeNode)srcNodeObject, destNodeObjects, sourceGroupedTableModel, groupStartedOnPage, groupRowsOnPage, groupNodesRemain, currentPageIndex);
					paginatedGroupedTableModels.add(clonedGroupTableModel.groupedTableModel);

					DefaultMutableTreeNode newNode = clonedGroupTableModel.node;
					TreeNode[] path = newNode.getPath();
					for (int i = 0; i < path.length; i++) {
						destNodeObjects[i] = path[i];
					}

					rowsToUse = rowsPerPage;
					pageRowCount[0] = 0;
				}

				// we can us this level to determine the pagination.
				pageRowCount[0] += rowsNeededForGroupHeader;  // Increment for the group level
				indicesPageNumbers.add(paginatedGroupedTableModels.size() - 1);

				TableModel srcTableModel = ((TableModelTreeNode)srcNodeObject).getTableModel();  // This is a deligated table model.

				int rowsRemaining = srcTableModel.getRowCount();
				//groupNodesRemain[groupLevel] = rowsRemaining;

				DeligatedTableModel deligatedSrcTableModel = (DeligatedTableModel) srcTableModel;
				TableModel underlyingTableModel = deligatedSrcTableModel.getModel();

				int firstRow = deligatedSrcTableModel.getFirstRowIndex();
				int lastRow = deligatedSrcTableModel.getLastRowIndex();

				boolean addedDataOnPage = false;
				while (rowsRemaining > 0) {
					rowsToUse = rowsPerPage - pageRowCount[0];
					if (rowsToUse > rowsRemaining) {
						rowsToUse = rowsRemaining;
					}

					if (rowsToUse <= 0) {
						int currentPageIndex = paginatedGroupedTableModels.size() - 1;
						ClonedGroupTableModel clonedGroupTableModel= createNewGroupedTableModel((TableModelTreeNode)srcNodeObject, destNodeObjects, sourceGroupedTableModel, groupStartedOnPage, groupRowsOnPage, groupNodesRemain, currentPageIndex);
						paginatedGroupedTableModels.add(clonedGroupTableModel.groupedTableModel);

						DefaultMutableTreeNode newNode = clonedGroupTableModel.node;
						TreeNode[] path = newNode.getPath();
						for (int i = 0; i < path.length; i++) {
							destNodeObjects[i] = path[i];
						}

						pageRowCount[0] = 0;
						rowsToUse = rowsPerPage - pageRowCount[0];
						if (rowsToUse > rowsRemaining) {
							rowsToUse = rowsRemaining;
						}
					}

					int lastRowToUse = firstRow + rowsToUse - 1;  // subtract 1 to get the correct index.
					if (lastRowToUse > lastRow) {
						lastRowToUse = lastRow;
					}

					DeligatedTableModel newDtm = new DeligatedTableModel(underlyingTableModel, firstRow, lastRowToUse);

					MutableTreeNode childNode = new TableModelTreeNode(newDtm);
					//((DefaultMutableTreeNode)((TableModelTreeNode)srcNodeObject).getParent()).add(childNode);  // TODO verify this for the NO group case
					((DefaultMutableTreeNode)destNodeObjects[groupLevel]).add(childNode);
					addedDataOnPage = true;

					pageRowCount[0] += rowsToUse;
					firstRow = lastRowToUse + 1;
					lastRow = deligatedSrcTableModel.getLastRowIndex(); // reset to end, so that on 2nd pass on a paginated page, correct end of table is detected.
					rowsRemaining -= rowsToUse;

					for (int i = 0; i < rowsToUse; i++) {
						indicesPageNumbers.add(paginatedGroupedTableModels.size() - 1);
					}

					for (int i = 0; i < groupRowsOnPage.length; i++) {
						groupRowsOnPage[i] += rowsToUse;
					}

					//groupNodesRemain[groupLevel] = groupNodesRemain[groupLevel]  - rowsToUse ;

//					if (rowsRemaining > 0) {
//						ClonedGroupTableModel clonedGroupTableModel= createNewGroupedTableModel((TableModelTreeNode)srcNodeObject, sourceGroupedTableModel);
//						DefaultMutableTreeNode newNode = clonedGroupTableModel.node;
//						TreeNode[] path = newNode.getPath();
//						for (int i = 0; i < path.length; i++) {
//							destNodeObjects[i] = path[i];
//						}
//					}
				}  // end while

				if (pageRowCount[0] + rowsNeededForGroupHeader >= rowsPerPage) {

					// decrement count as we need to ensure that if the parent node is 0 then we dont mark it as continued.
					int nl = groupNodesRemain.length - 1;
					while (true) {
						groupNodesRemain[nl]--;
						if (groupNodesRemain[nl] == 0) {
							nl--;
						} else {
							break;
						}
					}

					int currentPageIndex = paginatedGroupedTableModels.size() - 1;
					ClonedGroupTableModel clonedGroupTableModel= createNewGroupedTableModel((TableModelTreeNode)srcNodeObject, destNodeObjects, sourceGroupedTableModel, groupStartedOnPage, groupRowsOnPage, groupNodesRemain, currentPageIndex);
					paginatedGroupedTableModels.add(clonedGroupTableModel.groupedTableModel);

					DefaultMutableTreeNode newNode = clonedGroupTableModel.node;
					TreeNode[] path = newNode.getPath();
					for (int i = 0; i < path.length; i++) {
						destNodeObjects[i] = path[i];
					}

					pageRowCount[0] = 0;
					rowsToUse = rowsPerPage - pageRowCount[0];
					if (rowsToUse > rowsRemaining) {
						rowsToUse = rowsRemaining;
					}
				}

			}
		}
	}

	private ClonedGroupTableModel createNewGroupedTableModel(TableModelTreeNode srcNodeObject, TreeNode[] destNodeObjects, AbstractGroupedTableModel sourceGroupedTableModel, int[] groupStartedOnPage, int[] groupRowsOnPage, int[] groupNodesRemain, int currentPageIndex) {
		List<DefaultMutableTreeNode> parentPath = new ArrayList<DefaultMutableTreeNode>();
		TreeNode node = srcNodeObject;
		while (null != (node = node.getParent())) {
			// node = node.getParent();

			DefaultMutableTreeNode dmtnode = (DefaultMutableTreeNode) node;
			TreeNode[] path = dmtnode.getPath();
			int level = path.length - 1;

			node = destNodeObjects[level];

			DefaultMutableTreeNode dtn = (DefaultMutableTreeNode)((DefaultMutableTreeNode)node).clone();
			parentPath.add(0, dtn);

			Map<String,Object> userObject = (Map<String,Object>)((DefaultMutableTreeNode)node).getUserObject();
			if (null != userObject) {
				Map<String,Object> newUserObject =( HashMap<String,Object>)((HashMap<String,Object>)userObject).clone();
				// newUserObject.putAll(userObject);

				PaginatedGroupedTableModelNodeUserObject paginatedGroupedTableModelNodeUserObject = (PaginatedGroupedTableModelNodeUserObject)userObject.get(PaginatedGroupedTableModelNodeUserObject.class.getName());

				PaginatedGroupedTableModelNodeUserObject newPaginatedGroupedTableModelNodeUserObject = (PaginatedGroupedTableModelNodeUserObject)paginatedGroupedTableModelNodeUserObject.clone();
				newUserObject.put(PaginatedGroupedTableModelNodeUserObject.class.getName(), newPaginatedGroupedTableModelNodeUserObject);
				dtn.setUserObject(newUserObject);

				int nodesRemainForLevel = groupNodesRemain[level];
				if (nodesRemainForLevel > 0) {
					paginatedGroupedTableModelNodeUserObject.setContinuedOnNextPage(true);
				} else {
					paginatedGroupedTableModelNodeUserObject.setContinuedOnNextPage(false);
				}
			}

			Map<String,Object> newUserObject = (Map<String,Object>)((DefaultMutableTreeNode)dtn).getUserObject();
			if (null != newUserObject) {
				PaginatedGroupedTableModelNodeUserObject paginatedGroupedTableModelNodeUserObject = (PaginatedGroupedTableModelNodeUserObject)newUserObject.get(PaginatedGroupedTableModelNodeUserObject.class.getName());

				int rowsOnPrevPage = groupRowsOnPage[level];
				boolean fromPrevPage = (rowsOnPrevPage > 0) ? true : false;
				paginatedGroupedTableModelNodeUserObject.setContinuedFromPreviousPage(fromPrevPage);
			}

		}

		DefaultMutableTreeNode pnode = parentPath.get(0);
		DefaultGroupedTableModel dgtm = new DefaultGroupedTableModel(pnode, sourceGroupedTableModel.getGroupingModel(), sourceGroupedTableModel.getModel());
		setGroupedColumns(sourceGroupedTableModel, dgtm);
		for (int i = 1; i < parentPath.size(); i++) {
			DefaultMutableTreeNode cnode = parentPath.get(i);
			pnode.add(cnode);
			pnode = cnode;
		}

		ClonedGroupTableModel clonedGroupTableModel = new ClonedGroupTableModel(dgtm, pnode);
		return clonedGroupTableModel;
	}

	private class ClonedGroupTableModel {
		AbstractGroupedTableModel groupedTableModel;
		DefaultMutableTreeNode node;

		public ClonedGroupTableModel(AbstractGroupedTableModel groupedTableModel, DefaultMutableTreeNode node) {
			this.groupedTableModel = groupedTableModel;
			this.node = node;
		}
	};


		/*
		DefaultMutableTreeNode(point) // each GroupNode is this - with point indicating the range of values.
			// Rows:  valueModel is the main table (not a subset) and x and y are the range for this table.
			TableModel childTable = new DeligatedTableModel(valueModel, point.x, point.y);
				// This translates to rows:  based on (y - x)
			MutableTreeNode childNode = new TableModelTreeNode(childTable);
				return new TableModelRowNode(TableModelTreeNode.this, tableModel, cindex++);
		*/

//	}

//	protected void doIt(GroupedTableModel pageModel, TreeNode nodeObject, List<Object> groupValues, int rowsOnThisPage) {
//		if (null != nodeObject) {
//			TreeNode node = (TreeNode) nodeObject;
//			for(int i = 0; i < node.getChildCount(); i++) {
//				TreeNode cnode = node.getChildAt(i);
//				if (null != cnode) {
//					if (cnode instanceof TableModelRowNode) {
//						// actual row node.
//					} else if (cnode instanceof TableModelTreeNode) {
//						// uncomment the following if all rows need to be traveresed.
//						// printRows(model, cnode, groupValues, indent + "    ");
//
//						rowsOnThisPage++; // Increment to count the group rows as a single row.
//
//						TableModelTreeNode newNode = (TableModelTreeNode)((TableModelTreeNode)cnode).clone();
//
//						TableModel tmodel = ((TableModelTreeNode)cnode).getTableModel();
//						TableModelPrinter tmp = new TableModelPrinter();
//						tmp.print(tmodel, "Table Model from TableModelTreeNode " + groupValues);
//					} else if (cnode instanceof DefaultMutableTreeNode) {
//						// Traverse through the nodes.
//						DefaultMutableTreeNode tnode = (DefaultMutableTreeNode)cnode;
//						int groupLevel = 0;
//						if (null != tnode.getPath()) {
//							groupLevel = tnode.getPath().length - 2; //-1 for root node and -1 for self as 0 based
//						}
//
//						Point p = (Point)((DefaultMutableTreeNode)cnode).getUserObject();
//						int rowToQuery = p.x;
//						int columnToQuery = pageModel.getGroupColumnIndex(groupLevel);
//
//						Object groupValue = pageModel.getGroupingValue(rowToQuery, columnToQuery);
//						groupValues.add(groupValue);
//							doIt(pageModel, cnode, groupValues, rowsOnThisPage);
//						groupValues.remove(groupValues.size() -1);
//					}
//				}
//			}
//		}
//	}

}
