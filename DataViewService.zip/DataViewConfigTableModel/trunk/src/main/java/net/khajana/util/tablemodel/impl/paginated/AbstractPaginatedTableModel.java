/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.tablemodel.impl.paginated;

import javax.swing.table.TableModel;

import net.khajana.util.tablemodel.DecoratedTableModel;
import net.khajana.util.tablemodel.impl.DeligatedTableModel;
import net.khajana.util.tablemodel.paginated.PaginatedTableModel;

/**
 *
 * @author ms889296
 */
public abstract class AbstractPaginatedTableModel extends DecoratedTableModel implements PaginatedTableModel {

	/**
	 * Value indicates, as to how many rows are allowed per page.
	 */
	private int rowsPerPage;
	
	/**
	 * The page number for each row index. eg. <br> a[0] = 0  = row 0, page 0, <br>  a[1] = 0 = row 1, page 0, <br> a[2] = 1 = row 2, page 1. <br> as it can be seen, everything is 0, based, so page 0 really means page 1 of a document, and row 0 is really the 1st row of the document.
	 */
	private int[] indicesPageNumber;

	/**
	 * each offset in the array indicates the 1st row index of that page. eg. <br> a[0] = 0; page 1 start at row 0 <br> a[1] = 2; page 1 starts at row 2  <br>
	 */
	private int[] firstRowOfPage;
	private int lastRowOfLastPage;

	public AbstractPaginatedTableModel(TableModel tableModel) {
		super(tableModel);
	}

	protected void init(int[] indicesPageNumber, int[] firstRowOfPage, int lastRowOfLastPage) {
		this.indicesPageNumber = indicesPageNumber;
		this.firstRowOfPage = firstRowOfPage;
		this.lastRowOfLastPage = lastRowOfLastPage;
	}

	protected abstract void paginateIt();
	
	public void paginate() {
		paginateIt();
	}
	
	/**
	 * @return  Returns the rowsPerPage.
	 */
	public int getRowsPerPage() {
		return rowsPerPage;
	}

	/**
	 * @param rowsPerPage  The rowsPerPage to set.
	 */
	public void setRowsPerPage(int rowsPerPage) {
		this.rowsPerPage = rowsPerPage;
	}

	public int getPageCount() {
		return firstRowOfPage.length;
	}

	public TableModel getPage(int pageNumber) {
		int firstRowIndex = firstRowOnPage(pageNumber);
		int lastRowIndex = lastRowOnPage(pageNumber);
		return new DeligatedTableModel(this, firstRowIndex, lastRowIndex);
	}

	public int getPageNumber(int rowIndex) {
		return indicesPageNumber[rowIndex];
	}

	private int firstRowOnPage(int pageNumber) {
		return firstRowOfPage[pageNumber];
	}
	private int lastRowOnPage(int pageNumber) {
		if (pageNumber >= firstRowOfPage.length-1) {
			return lastRowOfLastPage;
		}
		return firstRowOfPage[pageNumber+1] - 1;
	}
}
