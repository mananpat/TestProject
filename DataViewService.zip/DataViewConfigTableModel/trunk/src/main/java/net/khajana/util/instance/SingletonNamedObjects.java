/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.instance;

import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;

/**
 *
 * @author ms889296
 */
public class SingletonNamedObjects<T> implements NamedObject {

	/**
	 * internal object used for caching instances of reflection class instances.
	 * Used for singleton purpose.
	 */
	private Map<String, T> cache = new HashMap<String, T>();
	private String name;

	public SingletonNamedObjects() {
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public T getInstance(String className)
		throws ClassNotFoundException, IllegalAccessException, InstantiationException, ClassCastException, InvocationTargetException {
		return getInstance(className, null);
	}

	public T getInstance(String className, Map<String, String> attributeValues)
		throws ClassNotFoundException, IllegalAccessException, InstantiationException, ClassCastException, InvocationTargetException {
		className = className.intern();
		String key = getKey(className, attributeValues);
		T typeInstance = cache.get(key);
		if (null == typeInstance) {
			typeInstance = createInstance(className, attributeValues);
			cache.put(key, typeInstance);
		}
		return typeInstance;
	}

	private String getKey(String className, Map<String, String> attributeValues) {
		String skey = className;

		if (null != attributeValues) {
			String[] keys = attributeValues.keySet().toArray(new String[attributeValues.size()]);
			Arrays.sort(keys);

			for (int i = 0; i < keys.length; i++) {
				String key = keys[i];
				String value = attributeValues.get(key);
				skey += ",";
				skey += key + "=" + value;
			}
		}

		return skey;
	}

	private T createInstance(String className, Map<String, String> attributeValues)
		throws ClassNotFoundException, IllegalAccessException, InstantiationException, ClassCastException, InvocationTargetException {

		Class<?> clazz = Class.forName(className, true, this.getClass().getClassLoader());

		Object o = clazz.newInstance();
		if (null != attributeValues && attributeValues.size() > 0) {
			BeanUtils.populate(o, attributeValues);
		}
		return (T)o;
	}
}
