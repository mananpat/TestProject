/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.tableview.impl;

import net.khajana.util.tablemodel.enums.VariableSeperator;
import net.khajana.util.tableview.ViewColumn;

import org.apache.commons.lang.builder.HashCodeBuilder;

/**
 *
 * @author ms889296
 */
public class DefaultViewColumn implements ViewColumn, java.io.Serializable {

	private String name;
	private String dataSourceName;

	public DefaultViewColumn() {
	}
	public DefaultViewColumn(String name, String dataSourceName) {
		this.name = name;
		this.dataSourceName = dataSourceName;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	public String getDataSourceName() {
		return dataSourceName;
	}
	public void setDataSourceName(String dataSourceName) {
		this.dataSourceName = dataSourceName;
	}

	
	public String getLogicalName() {
		return getDataSourceName() + VariableSeperator.MULTI_VALUE + getName();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null) {
			return false;
		}

		if (obj instanceof DefaultViewColumn == false) {
			return false;
		}

		DefaultViewColumn rhs = (DefaultViewColumn) obj;
		if (name == rhs.name && dataSourceName == rhs.dataSourceName) {
			return true;
		}
		if (name == null || rhs.name == null) {
			return false;
		}
		if (dataSourceName == null || rhs.dataSourceName == null) {
			return false;
		}

		return name.equals(rhs.name) && dataSourceName.equals(rhs.dataSourceName);
	}
	@Override
	public int hashCode() {
	    return new HashCodeBuilder(17, 37).
	       append(dataSourceName).
	       append(name).
	       toHashCode();
	}

}
