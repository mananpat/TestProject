/*
 *  Copyright (C) 2012 khajana.net
 *
 *  This library is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published
 *  by the Free Software Foundation, either version 3 of the License, or
 *  any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library.  If not, see <http://www.gnu.org/licenses/>.
 */	

package net.khajana.util.treetablemodel.impl.grouped;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.table.TableModel;

import net.khajana.util.tablemodel.aggrigated.Aggrigator;
import net.khajana.util.treetablemodel.grouped.AggrigatedGroupedTableModel;
import net.khajana.util.treetablemodel.grouped.GroupedTableModel;
import net.khajana.util.treetablemodel.impl.AbstractTreeTableModel;

/**
 *
 * @author ms889296
 */
public abstract class AbstractGroupedTableModel extends AbstractTreeTableModel implements GroupedTableModel, AggrigatedGroupedTableModel {

	private TableModel groupingTableModel;
	private TableModel valueTableModel;
	
	private List<Integer> groupColumns = new ArrayList<Integer>();
	private List<AggrigatedColumn> aggrigatedColumns = new ArrayList<AggrigatedColumn>();
	private String[] aggrigationCategoryOrder;

	public AbstractGroupedTableModel() {
		// For serialization
	}
	public AbstractGroupedTableModel(Object root, TableModel tableModel) {
		super(root);
		
		this.groupingTableModel = tableModel;
		this.valueTableModel = tableModel;
	}

	/**
	 * Use this consturctor if you have two table models where all the rows are identical except that one of them
	 * includes the columns that you want to group on and the other one includes the columns that actually want
	 * as the values of each nodes.
	 */
	public AbstractGroupedTableModel(Object root, TableModel groupingTableModel, TableModel valueTableModel) {
		super(root);
		if (groupingTableModel == null || valueTableModel == null) {
			throw new IllegalArgumentException("groupingTableModel and valueTableModel can not be null");
		}
		this.groupingTableModel = groupingTableModel;
		this.valueTableModel = valueTableModel;
	}

	public TableModel getGroupingModel() {
		return groupingTableModel;
	}
	
	public TableModel getModel() {
		return valueTableModel;
	}
	
	public int getColumnCount() {
		return valueTableModel.getColumnCount();
	}
	public String getColumnName(int columnIndex) {
		return valueTableModel.getColumnName(columnIndex);
	}

	public void addGroupColumn(int columnIndex) {
		if (getGroupLevel(columnIndex) == -1) {
			groupColumns.add(columnIndex);
		}
	}
	public void removeAllGroupColumns() {
		groupColumns.clear();
	}
	public void removeGroupColumn(int columnIndex) {
		int index = getGroupLevel(columnIndex);
		if (index != -1) {
			groupColumns.remove(index);
		}
	}

	public int[] getGroupColumns() {
		int[] columnIndexes = new int[groupColumns.size()];
		for (int i = 0, j = groupColumns.size(); i < j; i++) {
			columnIndexes[i] = groupColumns.get(i);
		}
		return columnIndexes;
	}

	public int getGroupColumnIndex(int groupLevel) {
		return groupColumns.get(groupLevel);
	}
	public String getGroupColumnName(int groupLevel) {
		return groupingTableModel.getColumnName(groupColumns.get(groupLevel));
	}

	public Object getGroupingValue(int rowIndex, int columnIndex) {
		return groupingTableModel.getValueAt(rowIndex, columnIndex);
	}
	/**
	 * returns the depth of the groping for the columnIndex
	 * @param columnIndex the column index for which we want to check the group depth
	 * @return the depth of the group for the column or -1 if not grouped.
	 */
	private int getGroupLevel(int columnIndex) {
		return groupColumns.indexOf(columnIndex);
	}

	/*
	private GroupColumn groupColumn(int columnIndex) {
		int index = groupColumnIndex(columnIndex);
		if (index > -1) {
			return groupColumns.get(index);
		}
		return null;
	}

	private GroupColumn groupColumnRead(int columnIndex) {
		int index = groupColumnIndex(columnIndex);
		if (index > -1) {
			return groupColumns.get(index);
		}
		return nullGroupColumn;
	}
	*/

	
	/*
	private Object [] getNodesAtLevel(int groupLevel) {
		MutableTreeNode root = (MutableTreeNode)getRoot();
		Object [] nodes = getNodesAtLevel(root, 1, groupLevel);
		return nodes;
	}

	
	private Object [] getNodesAtLevel(TreeNode node, int currentLevel, final int groupLevel) {
		if (currentLevel == groupLevel) {
			Object [] nodes = new Object[node.getChildCount()];
			for (int i = 0; i < nodes.length; i++) {
				nodes[i] = node.getChildAt(i);
			}
			return nodes;
		}
		
		List<Object> nodes = new ArrayList<Object>();
		
		int numbOfChildren = node.getChildCount();
		for(int i = 0; i < numbOfChildren; i++) {
			TreeNode childNode = node.getChildAt(i);
			Object [] childrenNodes = getNodesAtLevel(childNode, ++currentLevel, groupLevel);
			if (null != childrenNodes) {
				nodes.addAll(Arrays.asList(childrenNodes));
			}
		}

		return nodes.toArray();
	}	
	*/

	public void addAggrigator(int columnIndex, int groupLevel, Aggrigator aggrigator) {
		AggrigatedColumn agc = new AggrigatedColumn(columnIndex, groupLevel, aggrigator);
		int idx = aggrigatedColumns.indexOf(agc);
		if (idx == -1) {
			aggrigatedColumns.add(agc);
		} else {
			AggrigatedColumn eagc = aggrigatedColumns.get(idx);
			eagc.addAggrigator(aggrigator);
		}
	}
	
	public void removeAggrigator(int columnIndex, int groupLevel, Aggrigator aggrigator) {
		AggrigatedColumn agc = new AggrigatedColumn(columnIndex, groupLevel, aggrigator);
		int idx = aggrigatedColumns.indexOf(agc);
		if (idx != -1) {
			aggrigatedColumns.remove(idx);
		}
	}	

	public Aggrigator[] getAggrigators(int columnIndex, int groupLevel) {
		AggrigatedColumn agc = new AggrigatedColumn(columnIndex, groupLevel, null);
		int idx = aggrigatedColumns.indexOf(agc);
		if (idx != -1) {
			AggrigatedColumn eagc = aggrigatedColumns.get(idx);
			return eagc.getAggrigators();
		}
		return null;
	}

	protected Aggrigator getAggrigators(int columnIndex, int groupLevel, String category) {
		Aggrigator[] columnAggrigators = getAggrigators(columnIndex, groupLevel);
		if (null == columnAggrigators) {
			return null;
		}
		for (int i = 0; i < columnAggrigators.length; i++) {
			if (columnAggrigators[i].getCategory().equals(category)) {
				return columnAggrigators[i];
			}
		}
		return null;
	}

	protected Aggrigator[] getAggrigators(int groupLevel, String category) {
		Aggrigator[] columnAggrigators = getAggrigatorAtGroupLevel(groupLevel);
		if (null == columnAggrigators) {
			return null;
		}
		List<Aggrigator> aggs = new ArrayList<Aggrigator>();
		for (int i = 0; i < columnAggrigators.length; i++) {
			if (columnAggrigators[i].getCategory().equals(category)) {
				aggs.add(columnAggrigators[i]);
			}
		}
		if (aggs.size() == 0) {
			return null;
		}
		return aggs.toArray(new Aggrigator[aggs.size()]);	
	}

	protected Aggrigator[] getAggrigatorAtGroupLevel(int groupLevel) {
		List<Aggrigator> aggs = new ArrayList<Aggrigator>();
		for (AggrigatedColumn aggrigatedColumn : aggrigatedColumns) {
			if (aggrigatedColumn.getGroupLevel() == groupLevel) {
				aggs.addAll(Arrays.asList(aggrigatedColumn.getAggrigators()));
			}
		}
		if (aggs.size() == 0) {
			return null;
		}
		return aggs.toArray(new Aggrigator[aggs.size()]);	
	}

	public String[] getAggrigationCategoryOrder() {
		return aggrigationCategoryOrder;
	}

	public void setAggrigationCategoryOrder(String[] aggrigationCategoryOrder) {
		this.aggrigationCategoryOrder = aggrigationCategoryOrder;
	}

	/*
	protected Aggrigator[] getAggrigators(int columnIndex, int groupLevel) {
		List<Aggrigator> aggs = new ArrayList<Aggrigator>();
		for (AggrigatedColumn aggrigatedColumn : aggrigatedColumns) {
			if (aggrigatedColumn.getGroupLevel() == groupLevel && aggrigatedColumn.getColumnIndex() == columnIndex) {
				aggs.addAll(Arrays.asList(aggrigatedColumn.getAggrigators()));
			}
		}
		if (aggs.size() == 0) {
			return null;
		}
		return aggs.toArray(new Aggrigator[aggs.size()]);	
	}
*/
	
	private static class AggrigatedColumn {
		private int columnIndex;
		private int groupLevel;
		private List<Aggrigator> aggrigators = new ArrayList<Aggrigator>();
		
		public AggrigatedColumn() {
			// for serialization
		}
		public AggrigatedColumn(int columnIndex, int groupLevel, Aggrigator aggrigator) {
			this.columnIndex = columnIndex;
			this.groupLevel = groupLevel;
			this.aggrigators.add(aggrigator);
		}

		@Override
		public boolean equals(Object obj) {
			if (!(obj instanceof AggrigatedColumn)) {
				return false;
			}
			AggrigatedColumn agc = (AggrigatedColumn) obj;
			return columnIndex == agc.columnIndex && groupLevel == agc.groupLevel;
		}
		
		public int getColumnIndex() {
			return columnIndex;
		}
		public int getGroupLevel() {
			return groupLevel;
		}
		
		public Aggrigator[] getAggrigators() {
			return aggrigators.toArray(new Aggrigator[aggrigators.size()]);
		}
		
		public void addAggrigator(Aggrigator aggrigator) {
			aggrigators.add(aggrigator);
		}
		/* TODO this has been commented out b/c the NamedObject is not implemented anymore.  need to review and redesign		

		public void removeAggrigator(Aggrigator aggrigator) {
			int idx = indexOf(aggrigator);
			if (idx > -1) {
				aggrigators.remove(idx);
			}
		}

		public void removeAggrigator(String category, String aggrigatorName) {
			int idx = indexOf(category, aggrigatorName);
			if (idx > -1) {
				aggrigators.remove(idx);
			}
		}

		public int indexOf(Aggrigator aggrigator) {
			for (int i = 0; i < aggrigators.size(); i++) {
				if (aggrigator.getCategory().equals(aggrigators.get(i).getCategory()) 
						&& aggrigator.getName().equals(aggrigators.get(i).getName())) {
					return i;
				}
			}
			return -1;
		}

		public int indexOf(String category, String aggrigatorName) {
			for (int i = 0; i < aggrigators.size(); i++) {
				if (category.equals(aggrigators.get(i).getCategory()) 
						&& aggrigatorName.equals(aggrigators.get(i).getName())) {
					return i;
				}
			}
			return -1;
		}
*/	
	}
}
