/**
 * 
 */
package com.citi.ef.util.dataview.config.dao;

import org.springframework.dao.DataAccessException;

import com.citi.ef.util.dataview.config.domain.Report;

/**
 * @author mp14693
 *
 */
public interface ReportDao {

	public Report getReportById(Integer reportId) throws DataAccessException;
	
	public Report getReportByNameAndCat(String name, String category) throws DataAccessException;	
	
	/*public Integer insertReport(Report report) throws DataAccessException;
	
	public boolean updateReport(Report report) throws DataAccessException;*/
	
	public Integer saveReport(Report report) throws DataAccessException;
	
}
