/**
 * 
 */
package com.citi.ef.util.dataview.config.dao.handlers;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.ibatis.sqlmap.client.extensions.ParameterSetter;
import com.ibatis.sqlmap.client.extensions.ResultGetter;
import com.ibatis.sqlmap.client.extensions.TypeHandlerCallback;

/**
 * @author mp14693
 *
 */
public class BlobByteHandlerCallback implements TypeHandlerCallback {

	private static final Logger log = Logger.getLogger(BlobByteHandlerCallback.class);
	
	/* (non-Javadoc)
	 * @see com.ibatis.sqlmap.client.extensions.TypeHandlerCallback#getResult(com.ibatis.sqlmap.client.extensions.ResultGetter)
	 */
	public Object getResult(ResultGetter blobData) throws SQLException {
		Object result  =null;
		if(blobData != null && blobData.getBytes() != null && blobData.getBytes().length > 0){			
			ByteArrayInputStream bis = new ByteArrayInputStream((blobData.getBytes()));
			ObjectInput in = null;			
			try 
			{			
			  in = new ObjectInputStream(bis);
			  result = in.readObject(); 
			} catch(ClassNotFoundException io){
				String message = "Error in BlobByteHandlerCallback while converting blob into bytes.";
				log.error(message, io);
				throw new SQLException(message, io);
			} catch(IOException io){
				String message = "Error in BlobByteHandlerCallback  while converting blob into bytes.";
				log.error(message, io);
				throw new SQLException(message, io);						
			}			
			finally {
				try {
				  bis.close();
				  in.close();					
				} catch(IOException io){
					String message = "Error in BlobByteHandlerCallback in closing streams  while converting blob into bytes.";
					log.error(message, io);
					throw new SQLException(message, io);							
				}
			}
		}
		
		return result;
	}

	/* (non-Javadoc)
	 * @see com.ibatis.sqlmap.client.extensions.TypeHandlerCallback#setParameter(com.ibatis.sqlmap.client.extensions.ParameterSetter, java.lang.Object)
	 */
	public void setParameter(ParameterSetter setter, Object parameter) throws SQLException {		
		if(parameter != null){
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			ObjectOutput out = null;
			byte[] resultBytes = null;
			try {
				out = new ObjectOutputStream(bos);   
				out.writeObject(parameter);
				resultBytes = bos.toByteArray();	
				setter.setBytes(resultBytes);
			} catch(IOException io){
				String message = "Error in BlobByteHandlerCallback while converting bytes into blob.";
				log.error(message, io);
				throw new SQLException(message, io);
			}			
			finally {
				try {
				  out.close();
				  bos.close();					
				} catch(IOException io){
					String message = "Error in BlobByteHandlerCallback in closing streams while converting bytes into blob.";
					log.error(message, io);
					throw new SQLException(message, io);											
				}
			}
		}		
	}

	/* (non-Javadoc)
	 * @see com.ibatis.sqlmap.client.extensions.TypeHandlerCallback#valueOf(java.lang.String)
	 */
	public Object valueOf(String arg0) {
		// TODO Auto-generated method stub
		return null;
	}

}
