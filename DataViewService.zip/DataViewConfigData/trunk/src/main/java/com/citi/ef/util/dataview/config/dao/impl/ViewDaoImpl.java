/**
 * 
 */
package com.citi.ef.util.dataview.config.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.citi.ef.util.dataview.config.dao.ViewDao;
import com.citi.ef.util.dataview.config.domain.View;

/**
 * @author mp14693
 *
 */
public class ViewDaoImpl extends SqlMapClientDaoSupport  implements ViewDao {

	private static final Logger log = Logger.getLogger(ViewDaoImpl.class);
	
	/**
	 * 
	 * @param viewId
	 * @return
	 * @throws DataAccessException
	 */
	public View getViewById(Integer viewId) throws DataAccessException {
		if(log.isDebugEnabled())
			log.debug("Inside getViewById");
		
		Map<String, Integer> map = new HashMap<String,Integer>();
		map.put("viewId", viewId);					
		return (View) getSqlMapClientTemplate().queryForObject("getViewDetailsById", map);        
	}	
	
		
	public List<View> getViewByReportId(Integer reportId) throws DataAccessException {
		if(log.isDebugEnabled())
			log.debug("Inside getViewByReportId");
				
		Map<String, Integer> map = new HashMap<String, Integer>();
		map.put("reportId", reportId);
		return (List<View>)getSqlMapClientTemplate().queryForList("getViewDetailsByReportId", map);        
	}
	
	public View getViewByName(String viewName) throws DataAccessException {
		if(log.isDebugEnabled())
			log.debug("Inside getViewByName");		
			
		Map<String, String> map = new HashMap<String, String>();
		map.put("name", viewName);					
		return (View) getSqlMapClientTemplate().queryForObject("getViewDetailsByName", map);        
	}
	
	
	/*public Integer insertView(View view) throws DataAccessException {
		if(view.getViewId() == null || view.getViewId() <= 0)
			return (Integer) getSqlMapClientTemplate().insert("insertViewDetail", view);		
		return null;
	}
	
	public boolean updateView(View view) throws DataAccessException {
		if(view.getViewId() != null && view.getViewId() > 0){
			int result = getSqlMapClientTemplate().update("updateViewDetail", view);
			if (result != 0) 
				return true;
		}						
		return false;
	}*/
	
	public Integer savetView(View view) throws DataAccessException {
	if(view.getViewId() == null || view.getViewId() <= 0){
		return (Integer) getSqlMapClientTemplate().insert("insertViewDetail", view);
		}
		else {
			int result = getSqlMapClientTemplate().update("updateViewDetail", view);
			if (result != 0) 
				return view.getViewId();
		}						
		return null;
	}	
}
