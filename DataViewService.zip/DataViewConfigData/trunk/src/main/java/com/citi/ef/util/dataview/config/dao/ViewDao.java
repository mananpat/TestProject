/**
 * 
 */
package com.citi.ef.util.dataview.config.dao;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.citi.ef.util.dataview.config.domain.View;

/**
 * @author mp14693
 *
 */
public interface ViewDao  {

	public View getViewById(Integer viewId) throws DataAccessException;
	
	public List<View> getViewByReportId(Integer reportId) throws DataAccessException;	
	
	public View getViewByName(String name) throws DataAccessException;	
	
	/*public Integer insertView(View view) throws DataAccessException;
	
	public boolean updateView(View view) throws DataAccessException;*/
	
	public Integer savetView(View view) throws DataAccessException;
	 
	
}
