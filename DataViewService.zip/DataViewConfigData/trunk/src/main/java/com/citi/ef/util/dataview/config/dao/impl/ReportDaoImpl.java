/**
 * 
 */
package com.citi.ef.util.dataview.config.dao.impl;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.ibatis.SqlMapClientTemplate;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.citi.ef.util.dataview.config.dao.ReportDao;
import com.citi.ef.util.dataview.config.domain.Report;

/**
 * @author mp14693
 *
 */
public class ReportDaoImpl extends SqlMapClientDaoSupport  implements ReportDao {

	private static final Logger log = Logger.getLogger(ReportDaoImpl.class);
		
	/* (non-Javadoc)
	 * @see com.citi.ef.util.dataview.dal.dao.ReportDao#getReport(java.lang.String)
	 */	 
	public Report getReportByNameAndCat(String name, String category) throws DataAccessException {
		if(log.isDebugEnabled())
			log.debug("Inside gerReportByNameAndCat");		
		SqlMapClientTemplate smct = getSqlMapClientTemplate();	
		Map<String, String> map = new HashMap<String, String>();
		map.put("name", name);
		map.put("category", category);			
		return (Report) smct.queryForObject("getReportDetailsByNameAndCat", map);        
	}	
	
	/* (non-Javadoc)
	 * @see com.citi.ef.util.dataview.dal.dao.ReportDao#getReport(java.lang.String)
	 */
	public Report getReportById(Integer reportId) throws DataAccessException {
		SqlMapClientTemplate smct = getSqlMapClientTemplate();	
		Map<String, Integer> map = new HashMap<String, Integer>();
		map.put("reportId", reportId);					
		return (Report) smct.queryForObject("getReportDetailsByReportId", map);        
	}	
	
	/*public Integer insertReport(Report report) throws DataAccessException {
		if(report.getReportId() == null || report.getReportId() <= 0)
			return (Integer) getSqlMapClientTemplate().insert("insertReportDetail", report);		
		return null;
	}
	
	public boolean updateReport(Report report) throws DataAccessException {
		if(report.getReportId() != null && report.getReportId() > 0){
			int result = getSqlMapClientTemplate().update("updateReportDetail", report);
			if (result != 0) 
				return true;
		}				
		return false;
	}*/
	
	public Integer saveReport(Report report) throws DataAccessException {
		if(report.getReportId() == null || report.getReportId() <= 0)
			return (Integer) getSqlMapClientTemplate().insert("insertReportDetail", report);		
		else{
			int result = getSqlMapClientTemplate().update("updateReportDetail", report);
			if (result != 0) 
				return report.getReportId();
		}				
		return null;
	}
	
}