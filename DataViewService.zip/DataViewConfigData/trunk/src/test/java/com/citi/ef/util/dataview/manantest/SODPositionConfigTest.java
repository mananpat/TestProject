/**
 * 
 */
package com.citi.ef.util.dataview.manantest;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.citi.ef.util.dataview.config.boot.DefaultConfiguration;
import com.citi.ef.util.dataview.config.dao.ReportDao;
import com.citi.ef.util.dataview.config.dao.ViewDao;
import com.citi.ef.util.dataview.config.dao.impl.ReportDaoImpl;
import com.citi.ef.util.dataview.config.dao.impl.ViewDaoImpl;
import com.citi.ef.util.dataview.config.domain.Report;
import com.citi.ef.util.dataview.config.domain.View;
import com.citi.ef.util.dataview.dao.BaseDaoTest;
import com.ibatis.sqlmap.client.SqlMapClient;

/**
 * @author mp14693
 *
 */
public class SODPositionConfigTest extends BaseDaoTest {
	
	private static final Logger log = Logger.getLogger(SODPositionConfigTest.class);
	
	protected static String REPORT_NAME 	= "SOD Position Report";
	protected static String CATEGORY		= "SOD Position Category";				
	protected static String VIEW_NAME		= "SOD Position View";
	
	protected static String REPORT_FILE_NAME 	= "SODPositionReportConfig_1.xml";
	protected static String VIEW_FILE_NAME 		= "SODPositionViewConfig_1.xml";
	
	private ViewDao viewDao;
	private ReportDao reportDao;
	
	@Before    
    public void setUp() {
		SqlMapClient sqlMapClient = (SqlMapClient) DefaultConfiguration.getBean("DataViewConfigSqlMapClient");		
		viewDao = new ViewDaoImpl();
		reportDao = new ReportDaoImpl();
		
		((ViewDaoImpl)viewDao).setSqlMapClient(sqlMapClient);
		((ReportDaoImpl)reportDao).setSqlMapClient(sqlMapClient);
		
		REPORT_NAME = REPORT_NAME + "_" + System.currentTimeMillis();
		CATEGORY = CATEGORY + "_" + System.currentTimeMillis();
		VIEW_NAME = VIEW_NAME + "_" + System.currentTimeMillis();
	}
	
	@After
    public void tearDown() {
		/*Report preUpdateReportByNameCat = reportDao.getReportByNameAndCat(REPORT_NAME, CATEGORY);
		Assert.assertNotNull(preUpdateReportByNameCat);
		Integer reportId = preUpdateReportByNameCat.getReportId();							
		preUpdateReportByNameCat.setActive(false);
		preUpdateReportByNameCat.setUpdatedBy("mp14693");		
		Integer result = reportDao.saveReport(preUpdateReportByNameCat);
		Assert.assertNotNull(result);		
		Assert.assertEquals(result, preUpdateReportByNameCat.getReportId());
		
		Report postInvalidate = reportDao.getReportById(reportId);
		Assert.assertNull(postInvalidate);	*/	
	}	
		
	@Test    
	public void testInsertView() {
		log.info("Starting testInsertView");
		try
		{	
			Report report = prepareReport(REPORT_FILE_NAME, REPORT_NAME, CATEGORY);			
			Integer reportId = reportDao.saveReport(report);
			Assert.assertNotNull(reportId);
			Assert.assertTrue(reportId > 0);
			
			
			View view = prepareView(VIEW_FILE_NAME, VIEW_NAME, reportId);			
			Integer viewId = viewDao.savetView(view);
			Assert.assertNotNull(viewId);
			Assert.assertTrue(viewId > 0);
			
			View savedView = viewDao.getViewById(viewId);
			Assert.assertNotNull(savedView);
			Assert.assertEquals(savedView.getViewId(), viewId);
			Assert.assertEquals(savedView.getReportId(), reportId);
		}
		catch(Exception de){
			log.error("Error occurred in testInsertView", de);
			Assert.fail(de.toString());
		}
		log.info("End of testInsertView");
    }
}
	