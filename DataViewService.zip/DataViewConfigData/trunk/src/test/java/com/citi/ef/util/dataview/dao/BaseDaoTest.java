/**
 * 
 */
package com.citi.ef.util.dataview.dao;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.util.Date;

import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.xml.sax.helpers.DefaultHandler;

import com.citi.ef.util.dataview.config.ReportConfig;
import com.citi.ef.util.dataview.config.ViewConfig;
import com.citi.ef.util.dataview.config.domain.Report;
import com.citi.ef.util.dataview.config.domain.View;


/**
 * @author mp14693
 *
 */
public abstract class BaseDaoTest {

	final static Logger log = Logger.getLogger(BaseDaoTest.class);
	
	public Report prepareReport(String fileName, String reportName, String category) throws Exception {
		ReportConfig reportConfig = (ReportConfig) loadConfigFromFile("Report", fileName);
		Assert.assertNotNull(reportConfig);
		
		        
		
		reportConfig.setName(reportName);
		reportConfig.setCategory(category);
		
		Report report = new Report();			
		report.setName(reportName);
		report.setCategory(category);
		report.setCreatedBy("mp14693");
		report.setCreatedDateTime(new Date());
		report.setUpdatedBy("mp14693");
		report.setUpdatedDateTime(new Date());
		report.setActive(true);
		report.setReportId(-1);
		report.setVersion(1);
		report.setConfig(reportConfig);		
		return report;
	}
	
	public View prepareView(String viewConfigFile, String viewName, Integer reportId) throws Exception {
		ViewConfig viewConfig = (ViewConfig) loadConfigFromFile("View", viewConfigFile);
		Assert.assertNotNull(viewConfig);
		
		viewConfig.setReportId(reportId);
		viewConfig.setName(viewName);
				
		View view = new View();
		view.setViewId(-1);
		view.setReportId(reportId);
		view.setName(viewName);
		view.setCreatedBy("mp14693");
		view.setCreatedDateTime(new Date());
		view.setUpdatedBy("mp14693");
		view.setUpdatedDateTime(new Date());
		view.setActive(true);
		view.setVersion(1);
		view.setConfig(viewConfig);		
		return view;
	}
	
	public Object loadConfigFromFile(String configName, String fileName) throws JAXBException, FileNotFoundException{		
		log.info("inside loadConfigFromFile..");						
		Object config = null;
		if(configName.equalsIgnoreCase("Report")){
			JAXBContext context = JAXBContext.newInstance(com.citi.ef.util.dataview.config.ReportConfig.class);
			Unmarshaller u = context.createUnmarshaller();
			InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream(fileName);
			if (inputStream == null) {
				throw new FileNotFoundException(String.format("%1s configuraiton file either not found or object can't be prepared from file %2s", configName, fileName));			
			}
			config = (ReportConfig)u.unmarshal(inputStream);	        
		}			
		else if(configName.equalsIgnoreCase("View")){
			JAXBContext context = JAXBContext.newInstance(com.citi.ef.util.dataview.config.ViewConfig.class);
			Unmarshaller u = context.createUnmarshaller();
			InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream(fileName);
			if (inputStream == null) {
				throw new FileNotFoundException(String.format("%1s configuraiton file either not found or object can't be prepared from file %2s", configName, fileName));	
			}
			config = (ViewConfig)u.unmarshal(inputStream);					
		}	
			
		return config;
	}
	
	public byte[] getByteArray(Object object) throws IOException{		
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		ObjectOutput out = null;
		byte[] resultBytes = null;
		try{
			out = new ObjectOutputStream(bos);   
		  out.writeObject(object);
		  resultBytes = bos.toByteArray();		
		} finally {
		  out.close();
		  bos.close();
		}
		
		return resultBytes;
	}
	
	public Object getObjectFromBytes(byte[] bytes) throws ClassNotFoundException, IOException{		
		ByteArrayInputStream bis = new ByteArrayInputStream(bytes);
		ObjectInput in = null;
		Object o =null;
		try {
		  in = new ObjectInputStream(bis);
		  o = in.readObject(); 		  
		} finally {
		  bis.close();
		  in.close();
		}
		
		return o;
	}
	
	
}
