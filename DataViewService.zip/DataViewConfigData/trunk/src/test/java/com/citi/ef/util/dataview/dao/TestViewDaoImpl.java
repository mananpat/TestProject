/**
 * 
 */
package com.citi.ef.util.dataview.dao;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.citi.ef.util.dataview.config.boot.DefaultConfiguration;
import com.citi.ef.util.dataview.config.dao.ReportDao;
import com.citi.ef.util.dataview.config.dao.ViewDao;
import com.citi.ef.util.dataview.config.dao.impl.ReportDaoImpl;
import com.citi.ef.util.dataview.config.dao.impl.ViewDaoImpl;
import com.citi.ef.util.dataview.config.domain.Report;
import com.citi.ef.util.dataview.config.domain.View;
import com.ibatis.sqlmap.client.SqlMapClient;

/**
 * @author mp14693
 *
 */
public class TestViewDaoImpl extends BaseDaoTest {
	
	private static final Logger log = Logger.getLogger(TestViewDaoImpl.class);
	
	protected static String REPORT_NAME 	= "ViewTest_001";
	protected static String CATEGORY		= "ViewTestCategory_001";				
	protected static String VIEW_NAME		= "ViewName_001";
	
	protected static String REPORT_FILE_NAME 	= "ReportConfig_001.xml";
	protected static String VIEW_FILE_NAME 		= "ViewConfig_001.xml";
	
	private ViewDao viewDao;
	private ReportDao reportDao;
	
	@Before    
    public void setUp() {
		SqlMapClient sqlMapClient = (SqlMapClient) DefaultConfiguration.getBean("DataViewConfigSqlMapClient");		
		viewDao = new ViewDaoImpl();
		reportDao = new ReportDaoImpl();
		
		((ViewDaoImpl)viewDao).setSqlMapClient(sqlMapClient);
		((ReportDaoImpl)reportDao).setSqlMapClient(sqlMapClient);
		
		REPORT_NAME = REPORT_NAME + "_" + System.currentTimeMillis();
		CATEGORY = CATEGORY + "_" + System.currentTimeMillis();
		VIEW_NAME = VIEW_NAME + "_" + System.currentTimeMillis();
	}
	
	@After
    public void tearDown() {
		Report preUpdateReportByNameCat = reportDao.getReportByNameAndCat(REPORT_NAME, CATEGORY);
		Assert.assertNotNull(preUpdateReportByNameCat);
		Integer reportId = preUpdateReportByNameCat.getReportId();							
		preUpdateReportByNameCat.setActive(false);
		preUpdateReportByNameCat.setUpdatedBy("mp14693");		
		Integer result = reportDao.saveReport(preUpdateReportByNameCat);
		Assert.assertNotNull(result);		
		Assert.assertEquals(result, preUpdateReportByNameCat.getReportId());
		
		Report postInvalidate = reportDao.getReportById(reportId);
		Assert.assertNull(postInvalidate);		
	}	
		
	@Test    
	public void testInsertView() {
		log.info("Starting testInsertView");
		try
		{	
			Report report = prepareReport(REPORT_FILE_NAME, REPORT_NAME, CATEGORY);			
			Integer reportId = reportDao.saveReport(report);
			Assert.assertNotNull(reportId);
			Assert.assertTrue(reportId > 0);
			
			
			View view = prepareView(VIEW_FILE_NAME, VIEW_NAME, reportId);			
			Integer viewId = viewDao.savetView(view);
			Assert.assertNotNull(viewId);
			Assert.assertTrue(viewId > 0);
			
			View savedView = viewDao.getViewById(viewId);
			Assert.assertNotNull(savedView);
			Assert.assertEquals(savedView.getViewId(), viewId);
			Assert.assertEquals(savedView.getReportId(), reportId);
		}
		catch(Exception de){
			log.error("Error occurred in testInsertView", de);
			Assert.fail(de.toString());
		}
		log.info("End of testInsertView");
    }
	
	
	
	/*@Test    
	public void testUpdateView() {				
		try
		{	
			ViewConfig viewConfig = (ViewConfig)loadConfigFromFile("View");
			Assert.assertNotNull(viewConfig);			
			viewConfig.setName("View for " + REPORT_NAME);			
			View view = new View();
			view.setViewId(-1);
			view.setReportId(reportId);
			view.setName("View for " + REPORT_NAME);
			view.setCreatedBy("mp14693");
			view.setCreatedDateTime(new Date());
			view.setUpdatedBy("mp14693");
			view.setUpdatedDateTime(new Date());
			view.setActive(true);
			view.setVersion(1);								
			view.setConfig(viewConfig);				
			
			boolean result = dao.updateView(view);
			Assert.assertTrue(result);
			
			List<View> preViewList = dao.getViewByReportId(reportId);
			Assert.assertNotNull(preViewList);
			
			View preView = preViewList.get(0);			
			Assert.assertTrue(preView != null);
			Integer viewId = preView.getViewId();
			
			String newName = preView.getName() + "_U1" ; 
			preView.setName(newName);
			
			boolean updateResult = dao.updateView(preView);
			Assert.assertTrue(updateResult);
			
			View updatedView = dao.getViewById(viewId);
			Assert.assertNotNull(updatedView);
			
			Assert.assertEquals(newName, updatedView.getName());
			
			
		}
		catch(Exception de){
			log.error("Error occurred in testInsertReport", de);
			Assert.fail(de.toString());
		}
    }
	
	@Test    
	public void testInactiveView() {	
		
		try
		{
			ViewConfig viewConfig = (ViewConfig)loadConfigFromFile("View");
			Assert.assertNotNull(viewConfig);			
			viewConfig.setName("View for " + REPORT_NAME);			
			View view = new View();
			view.setViewId(-1);
			view.setReportId(reportId);
			view.setName("View for " + REPORT_NAME);
			view.setCreatedBy("mp14693");
			view.setCreatedDateTime(new Date());
			view.setUpdatedBy("mp14693");
			view.setUpdatedDateTime(new Date());
			view.setActive(true);
			view.setVersion(1);								
			view.setConfig(viewConfig);				
			
			boolean result = dao.updateView(view);
			Assert.assertTrue(result);
			
			List<View> preViewList = dao.getViewByReportId(reportId);
			Assert.assertNotNull(preViewList);
			
			View preView = preViewList.get(0);			
			Assert.assertTrue(preView != null);
			Integer viewId = preView.getViewId();
						
			preView.setActive(false);
			
			boolean updateResult = dao.updateView(preView);
			Assert.assertTrue(updateResult);
			
			View updatedView = dao.getViewById(viewId);
			Assert.assertNull(updatedView);
		}
		catch(Exception de){
			log.error("Error occurred in testInsertReport", de);
			Assert.fail(de.toString());
		}	
	}*/
	
}
