/**
 * 
 */
package com.citi.ef.util.dataview.dao;

import javax.xml.bind.JAXBException;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.dao.DataAccessException;

import com.citi.ef.util.dataview.config.boot.DefaultConfiguration;
import com.citi.ef.util.dataview.config.dao.impl.ReportDaoImpl;
import com.citi.ef.util.dataview.config.domain.Report;
import com.ibatis.sqlmap.client.SqlMapClient;

/**
 * @author mp14693
 *
 */
public class TestReportDaoImpl extends BaseDaoTest {
	
	private static final Logger log = Logger.getLogger(TestReportDaoImpl.class);
	
	protected static String REPORT_NAME 	= "ReportTest_001";
	protected static String CATEGORY		= "ReportTestCategory_001";				
	protected static String FILE_NAME		= "ReportConfig_001.xml";
	
	ReportDaoImpl dao;
	
	@Before    
    public void setUp() {
		SqlMapClient sqlMapClient = (SqlMapClient) DefaultConfiguration.getBean("DataViewConfigSqlMapClient");		
		dao = new ReportDaoImpl();
		dao.setSqlMapClient(sqlMapClient);		
		REPORT_NAME = REPORT_NAME + "_" + System.currentTimeMillis();
		CATEGORY = CATEGORY + "_" + System.currentTimeMillis();			
	}
	
	@After
    public void tearDown() {
		Report preUpdateReportByNameCat = dao.getReportByNameAndCat(REPORT_NAME, CATEGORY);
		Assert.assertNotNull(preUpdateReportByNameCat);
		Integer reportId = preUpdateReportByNameCat.getReportId();
							
		preUpdateReportByNameCat.setActive(false);
		preUpdateReportByNameCat.setUpdatedBy("mp14693");
		
		Integer result = dao.saveReport(preUpdateReportByNameCat);
		Assert.assertNotNull(result);		
		Assert.assertEquals(result, preUpdateReportByNameCat.getReportId());
		
		Report postInvalidate = dao.getReportById(reportId);
		Assert.assertNull(postInvalidate);		
	}
	
		
	@Test    
	public void testInsertReport() {
		log.info("Starting testInsertReport");
		try
		{	
			Report report = prepareReport(FILE_NAME, REPORT_NAME, CATEGORY);
			
			Integer reportId = dao.saveReport(report);
			Assert.assertNotNull(reportId);
			Assert.assertTrue(reportId > 0);
			
			Report savedReport = dao.getReportById(reportId);
			Assert.assertNotNull(savedReport);
			Assert.assertEquals(savedReport.getReportId(), reportId);			
			
		}
		catch(Exception de){
			log.error("Error occurred in testInsertReport", de);
			Assert.fail(de.toString());
		}
		log.info("End of testInsertReport");
    }
	
	@Test    
	public void testUpdateReport() {				
		try
		{			
			Report report = prepareReport(FILE_NAME, REPORT_NAME, CATEGORY);			
			Integer reportId = dao.saveReport(report);
			Assert.assertNotNull(reportId);
			Assert.assertTrue(reportId > 0);
			
			Report preUpdateReportByNameCat = dao.getReportByNameAndCat(REPORT_NAME, CATEGORY);
			Assert.assertNotNull(preUpdateReportByNameCat);
			Assert.assertEquals(preUpdateReportByNameCat.getName(), REPORT_NAME);
			Assert.assertEquals(preUpdateReportByNameCat.getCategory(), CATEGORY);
								
			preUpdateReportByNameCat.setActive(true);
			preUpdateReportByNameCat.setUpdatedBy("mp14693");
			
			Integer result = dao.saveReport(preUpdateReportByNameCat);
			Assert.assertNotNull(result);
			Assert.assertEquals(result, preUpdateReportByNameCat.getReportId());
			
			Report postUpdateReportByNameCat = dao.getReportByNameAndCat(REPORT_NAME, CATEGORY);
			Assert.assertNotNull(postUpdateReportByNameCat);
			Assert.assertTrue(preUpdateReportByNameCat.getVersion() +1 == postUpdateReportByNameCat.getVersion());
			
		}
		catch(Exception de){
			log.error("Error occurred in testUpdateReport", de);
			Assert.fail(de.toString());
		}
    }
	
	@Test    
	public void testGetReportByReportId() {
		try
		{				
			Report report = prepareReport(FILE_NAME, REPORT_NAME, CATEGORY);			
			Integer reportId = dao.saveReport(report);
			Assert.assertNotNull(reportId);
			Assert.assertTrue(reportId > 0);
			
			Report preUpdateReportByNameCat = dao.getReportByNameAndCat(REPORT_NAME, CATEGORY);
			Assert.assertNotNull(preUpdateReportByNameCat);
			Assert.assertEquals(preUpdateReportByNameCat.getName(), REPORT_NAME);
			Assert.assertEquals(preUpdateReportByNameCat.getCategory(), CATEGORY);
							
			/*JAXBContext ctx = JAXBContext.newInstance(Report.class);				
		    Marshaller marshaller = ctx.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			marshaller.marshal(reportById.getConfig(), System.out);	*/		
		}		
		catch (JAXBException e2) {		
			e2.printStackTrace();
		}
		catch(DataAccessException de){
			log.error("Error occurred in testGetReportByReportId", de);
			Assert.fail(de.toString());
		}
		catch(Exception de){
			log.error("Error occurred in testGetReportByReportId", de);
			Assert.fail(de.toString());
		}
		
    }
		
	@Test    
	public void _testInactiveReport() {
		try
		{	
			Report report = prepareReport(FILE_NAME, REPORT_NAME, CATEGORY);			
			Integer reportId = dao.saveReport(report);
			Assert.assertNotNull(reportId);
			Assert.assertTrue(reportId > 0);
			
			Report preUpdateReportByNameCat = dao.getReportById(reportId);
			Assert.assertNotNull(preUpdateReportByNameCat);
			Assert.assertEquals(preUpdateReportByNameCat.getReportId(), reportId);
						
			preUpdateReportByNameCat.setActive(false);
			preUpdateReportByNameCat.setUpdatedBy("mp14693");
			
			Integer result = dao.saveReport(preUpdateReportByNameCat);
			Assert.assertNotNull(result);		
			Assert.assertEquals(result, preUpdateReportByNameCat.getReportId());
			
			Report postInvalidate = dao.getReportById(reportId);
			Assert.assertNull(postInvalidate);
		}
		catch(Exception de){
			log.error("Error occurred in testInactiveReport", de);
			Assert.fail(de.toString());
		}	
		
    }
}
