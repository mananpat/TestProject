/**
 * 
 */
package com.citi.ef.util.dataview.config.boot;

import java.sql.Connection;
import java.sql.DatabaseMetaData;

import org.apache.commons.dbcp.BasicDataSource;
import org.apache.log4j.Logger;

/**
 * @author mp14693
 *
 */
public class DefaultConfigurationTest {

	private static final Logger log = Logger.getLogger(DefaultConfigurationTest.class);
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			log.info("DB Connection Test ! ! !");
			Object obj = DefaultConfiguration.getBean("DataViewConfig_DataSource_ConnectionPool");
			if(obj != null){
				BasicDataSource dataSource = (BasicDataSource) obj;
				Connection conn = dataSource.getConnection();
				DatabaseMetaData dbMetaData = conn.getMetaData();
				
				log.info("Server Name: "+ dbMetaData.getDatabaseProductName());
				log.info("Server Version: "+ dbMetaData.getDatabaseProductVersion());
				
				log.info("End of DB MetaData. Connection Successful");
			}
			else
				log.error("Failed to retrieve ConnectionFactory object from application context");
		}
		catch(Exception e){
			log.error("One or more execption thrown while looking up ConnectinFactory", e);
		}
	}

}
