package com.citi.ef.util.dataview.config.service.dao.impl;
/**
 * 
 */


import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.citi.ef.util.dataview.config.boot.DefaultConfiguration;
import com.ibatis.sqlmap.client.SqlMapClient;

/**
 * @author mp14693
 *
 */
public class TestSODPositionDaoImpl {
	
	private static final Logger log = Logger.getLogger(TestSODPositionDaoImpl.class);
	
		
	SODPositionDaoImpl dao;
	
	@Before    
    public void setUp() {
		SqlMapClient sqlMapClient = (SqlMapClient) DefaultConfiguration.getBean("DataViewConfigSqlMapClient");		
		dao = new SODPositionDaoImpl();
		dao.setSqlMapClient(sqlMapClient);
	}
	
		
	@Test    
	public void testLoadPositionData() {				
		try
		{
			dao.loadPosition();
		}
		catch(Exception de){
			log.error("Error occurred in testInsertReport", de);
			Assert.fail(de.toString());
		}
    }
}
