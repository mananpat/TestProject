/**
 * 
 */
package com.citi.ef.util.dataview.config.service.processor;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.citi.ef.util.dataview.config.Response;
import com.citi.ef.util.dataview.config.boot.DefaultConfiguration;
import com.citi.ef.util.dataview.config.service.sdo.Request;

/**
 * @author mp14693
 *
 */
public class TestSODPositionViewProcessor {

	private static final Logger log = Logger.getLogger(TestSODPositionViewProcessor.class);
	
	private ViewProcessor sodPositionViewProcessor;
	
	@Before    
    public void setUp() {
		sodPositionViewProcessor = (SODPositionViewProcessor) DefaultConfiguration.getBean("SODPositionViewProcessor");		
	}
	
		
	@Test    
	public void testSODPositionProcessor() {				
		try
		{
			log.info("Before viewProcessor request!!");
			Request request = new Request();
			request.setViewId(new Integer(18));
			Response response = sodPositionViewProcessor.process(request);			
			log.info("After viewProcessor request!!");
			
		}
		catch(Exception de){
			log.error("Error occurred in testSODPositionProcessor", de);
			Assert.fail(de.toString());
		}
    }
}
