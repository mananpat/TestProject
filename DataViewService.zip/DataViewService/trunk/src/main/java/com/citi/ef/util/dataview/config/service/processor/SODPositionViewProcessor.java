/**
 * 
 */
package com.citi.ef.util.dataview.config.service.processor;

import javax.swing.table.TableModel;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

import net.khajana.processor.TableModelProcessor;
import net.khajana.util.tableview.TableViewResults;

import org.apache.log4j.Logger;

import com.citi.ef.util.dataview.config.ViewConfig;
import com.citi.ef.util.dataview.config.dao.ReportDao;
import com.citi.ef.util.dataview.config.dao.ViewDao;
import com.citi.ef.util.dataview.config.domain.Report;
import com.citi.ef.util.dataview.config.domain.View;
import com.citi.ef.util.dataview.config.service.dao.SODPositionDao;
import com.citi.ef.util.dataview.config.service.sdo.Request;
import com.citi.ef.util.dataview.config.Response;

/**
 * @author mp14693
 *
 */
public class SODPositionViewProcessor extends BaseViewProcessor implements ViewProcessor {

	private static final Logger log = Logger.getLogger(SODPositionViewProcessor.class);
	
	private boolean isInitialized = false;

	private ViewDao viewDao;
	private ReportDao reportDao;
	
	private SODPositionDao sodPositonDao;
	
	private TableModelProcessor tableModelProcessor;
		
	public boolean init() {
		/*if(!isInitialized){
			
		}*/	
		
		return true;
	}
	
	/**
	 * 
	 */	
	public Response process(Request request){
		Response response = null;
		try{
			init();
			
			if(request == null)
				return new Response();
			
			//Integer reportId  = request.getReportId();
			Integer viewId  = request.getViewId();
			
			View view = viewDao.getViewById(viewId);
			
			//test print the data
			JAXBContext ctx = JAXBContext.newInstance(ViewConfig.class);				
		    Marshaller marshaller = ctx.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			marshaller.marshal(view.getConfig(), System.out);		
			
			TableModel origDataTableModel = sodPositonDao.loadPosition();
			Object result = tableModelProcessor.process(origDataTableModel, view.getConfig(), null);
			
			if(result != null){
				Report report = reportDao.getReportById(view.getReportId());
				GUIClientResponse resPrep = new GUIClientResponse(report, ((TableViewResults)result).getNonNullTableModel());
				response = resPrep.prepareResponse();
			}
			
			
			JAXBContext ctx2 = JAXBContext.newInstance(Response.class);				
		    Marshaller marshaller2 = ctx2.createMarshaller();
		    marshaller2.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		    marshaller2.marshal(response, System.out);
			
			
			log.info("View Processor Completed");
			
			
			/*TableModelProcessor tblModelProcessor = new TableModelProcessorImpl();
			tblModelProcessor.process(tableModel, viewConfig, outputFormat);
			
			
			//Object result = tableModelProcessor.process(origDataTableModel, viewConfig, null);
			
			
			
			/*TableModelProcessor tblModelProcessor = new TableModelProcessorImpl();
			tblModelProcessor.process(tableModel, viewConfig, outputFormat);
			*/
		}
		catch(Exception e){
			log.error("One or more error(s) while processing in SODPositionViewProcessor. ",e);
		}
		return response;
	}

	public SODPositionDao getSodPositonDao() {
		return sodPositonDao;
	}

	public void setSodPositonDao(SODPositionDao sodPositonDao) {
		this.sodPositonDao = sodPositonDao;
	}

	public TableModelProcessor getTableModelProcessor() {
		return tableModelProcessor;
	}

	public void setTableModelProcessor(TableModelProcessor tableModelProcessor) {
		this.tableModelProcessor = tableModelProcessor;
	}

	public ViewDao getViewDao() {
		return viewDao;
	}

	public void setViewDao(ViewDao viewDao) {
		this.viewDao = viewDao;
	}

	public ReportDao getReportDao() {
		return reportDao;
	}

	public void setReportDao(ReportDao reportDao) {
		this.reportDao = reportDao;
	}

	
}
