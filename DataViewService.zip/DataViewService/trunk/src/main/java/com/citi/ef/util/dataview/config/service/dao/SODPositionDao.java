/**
 * 
 */
package com.citi.ef.util.dataview.config.service.dao;

import javax.swing.table.TableModel;

import org.springframework.dao.DataAccessException;

/**
 * @author mp14693
 *
 */
public interface SODPositionDao {

	public TableModel loadPosition() throws DataAccessException;
}
