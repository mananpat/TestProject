/**
 * 
 */
package com.citi.ef.util.dataview.config.service.processor;

import com.citi.ef.util.dataview.config.Response;
import com.citi.ef.util.dataview.config.service.sdo.Request;

/**
 * @author mp14693
 *
 */
public interface ViewProcessor {
	
	public boolean init();
	
	public Response process(Request request);
}
