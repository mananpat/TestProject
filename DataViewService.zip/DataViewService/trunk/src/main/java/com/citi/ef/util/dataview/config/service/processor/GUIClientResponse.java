/**
 * 
 */
package com.citi.ef.util.dataview.config.service.processor;

import java.util.ArrayList;
import java.util.List;

import javax.swing.table.TableModel;

import org.apache.log4j.Logger;

import com.citi.ef.util.dataview.config.Column;
import com.citi.ef.util.dataview.config.DataGrid;
import com.citi.ef.util.dataview.config.ReportData;
import com.citi.ef.util.dataview.config.ReportHeader;
import com.citi.ef.util.dataview.config.Response;
import com.citi.ef.util.dataview.config.Row;
import com.citi.ef.util.dataview.config.Type;
import com.citi.ef.util.dataview.config.domain.Report;

/**
 * @author mp14693
 *
 */
public class GUIClientResponse {

	private static final Logger log = Logger.getLogger(SODPositionViewProcessor.class);
	
	private Response response;
	private TableModel tableModel;
	private Report report;
		
	public GUIClientResponse(){
		
	}
	
	public GUIClientResponse(Report report, TableModel tableModel){
		this.report = report;
		this.tableModel = tableModel;
	}
	
	/**
	 * 
	 */	
	public Response prepareResponse(){
		try{
			log.info("Inside prepareResponse for GUIClientResponse");
			response = new Response();
			prepareReportHeader();
			prepareReportData();
			prepareReportFooter();
			log.info("End of prepareResponse for GUIClientResponse");
		}
		catch(Exception e){
			log.error("One or more error(s) while preparing reponse in GUIClientResponse");
			response = null;
		}
		
		return response;
	}
	
	/*
	 * 
	 */
	private void prepareReportHeader(){
		String[] viewColumnIds = new String[tableModel.getColumnCount()];
		List<Column> responseColumns = new ArrayList<Column>();
		
		for (int i = 0; i < tableModel.getColumnCount(); i++)
			viewColumnIds[i] = tableModel.getColumnName(i);
			
		List<Column> reportConfigColumns = this.report.getConfig().getColumn();
		if(reportConfigColumns != null && !reportConfigColumns.isEmpty()){
			for (int i = 0; i < viewColumnIds.length; i++){
				for(Column column : reportConfigColumns){
					if(viewColumnIds[i].equals("products$"+column.getColumnId())){
						column.setColumnIndex(i); //override the index based on this view config;
						responseColumns.add(column);					
					}
				}
			}
		}
		
		ReportHeader header = new ReportHeader();
		header.setHeader("This is test and optional Header");
		header.getColumn().addAll(responseColumns);
		response.setHeader(header);
	}
		
	/*
	 * 
	 */
	private void prepareReportData(){
		List<DataGrid> dataGridList = new ArrayList<DataGrid>();
		
		DataGrid dataGrid = new DataGrid();		
		for(int i = 0; i < tableModel.getRowCount(); i++) {
			Row row = new Row();
			row.setType(Type.DATA);						
			List<Object> cellValueList = new ArrayList<Object>();
			for (int j = 0; j < tableModel.getColumnCount(); j++) {				
				/*if (j > 0) {					
				} else if (j == 0) {
					System.out.print("");
				}*/
				//System.out.print("\"" + tableModel.getValueAt(i,j) + "\"");				
				cellValueList.add(tableModel.getValueAt(i,j) != null ? tableModel.getValueAt(i,j) : "NULL");
			}			
			row.getCellValue().addAll(cellValueList);
			dataGrid.getRow().add(row);			
		}
		
		dataGridList.add(dataGrid);
		
		
		ReportData data = new ReportData();
		data.getDataGrid().addAll(dataGridList);		
		response.getData().add(data);		
	}
	
	/*
	 * 
	 */
	private void prepareReportFooter(){		
		response.setFooter("This is sample footer ----Page 1");
	}
	
	
}
