/**
 * 
 */
package com.citi.ef.util.dataview.config.service.dao.impl;

import java.util.HashMap;
import java.util.Map;

import javax.swing.table.TableModel;

import net.khajana.util.tablemodel.TableModelPrinter;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.citi.ef.util.dataview.config.service.dao.SODPositionDao;
import com.citi.ef.util.dataview.config.service.dao.handlers.TableModelResultDataMap;

/**
 * @author mp14693
 *
 */
public class SODPositionDaoImpl extends SqlMapClientDaoSupport implements SODPositionDao {

	private static final Logger log = Logger.getLogger(SODPositionDaoImpl.class);
	
	
	public TableModel loadPosition() throws DataAccessException {
		Integer dataSetId = 0;
		Map<String, Integer> dataSetIdMap = (Map<String, Integer>) getSqlMapClientTemplate().queryForObject("getPositionDataSetId");
		if(dataSetIdMap != null && dataSetIdMap.keySet().size() > 0){
			dataSetId = (Integer) dataSetIdMap.get("PositionDataSetId");			
		}
		
		if(dataSetId > 0){
			Map<String, Integer> map = new HashMap<String, Integer>();
			map.put("positionDataSetId", dataSetId);			
			TableModelResultDataMap tableModelResult = (TableModelResultDataMap) getSqlMapClientTemplate().queryForObject("getPositionData", map);
						
			if(log.isDebugEnabled()){
				TableModelPrinter printer = new TableModelPrinter();	        
				printer.print(tableModelResult.getTableModel(), "Table Model Retrived from Data Source", true, true, true);
			}
			return tableModelResult.getTableModel();
		}		
		
		return null;
	}
}
