/**
 * 
 */
package com.citi.ef.util.dataview.config.service.dao.handlers;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import com.ibatis.sqlmap.client.extensions.ParameterSetter;
import com.ibatis.sqlmap.client.extensions.ResultGetter;
import com.ibatis.sqlmap.client.extensions.TypeHandlerCallback;

/**
 * @author mp14693
 *
 */
public class TableModelResultSetHandlerCallback implements TypeHandlerCallback {

	/* (non-Javadoc)
	 * @see com.ibatis.sqlmap.client.extensions.TypeHandlerCallback#getResult(com.ibatis.sqlmap.client.extensions.ResultGetter)
	 */
	public TableModel  getResult(ResultGetter getter) throws SQLException {
		ResultSet rs = getter.getResultSet();  
        ResultSetMetaData rsmd = rs.getMetaData();  
        int numColumns = rsmd.getColumnCount();  
        List<String> colNames = new ArrayList<String>();  
                
        //Get the column names; column indices start from 1  
        for (int i=1; i<numColumns+1;i++)
            colNames.add(rsmd.getColumnName(i));        
               
        List<Object[]> dataRows = new ArrayList<Object[]>();
        
        Object cellValue;  
        
        // do while loop is used here since in iBatis, the resultset begins at the first record unlike jdbc where the cursor is positioned before the first record.  
        do {  
            Object[] row = new Object[colNames.size()];  
            for(int index=0; index < colNames.size(); index++){            
                cellValue = rs.getObject((String)colNames.get(index));
                //Integer columnDataType  = colNameTypeMap.get((String)colNames.get(index));
                row[index] = cellValue instanceof String ? ((String)cellValue).trim() : cellValue;
                
                /*switch (columnDataType) {
				case -7:
					//BIT
					break;
				case -6:
					//TINYINT
					
					break;
				case -5:
					//BIGINT
					break;
				case -4:
					//LONGVARBINARY
					break;
				case 12:
					//VARCHAR
					
					break;
				default:
					break;
				}
                if(columnDataType.equalsIgnoreCase("VARCHAR")){
                	row[index] = cellValue instanceof String ? ((String)cellValue).trim() : cellValue;
                }
                else if (columnDataType.equals("INTEGER")){
                }
                else if (columnDataType.equals("FLOAT")){
                }*/
                /*
                -7	BIT
			-6	TINYINT
			-5	BIGINT
			-4	LONGVARBINARY 
			-3	VARBINARY
			-2	BINARY
			-1	LONGVARCHAR
			0	NULL
			1	CHAR
			2	NUMERIC
			3	DECIMAL
			4	INTEGER
			5	SMALLINT
			6	FLOAT
			7	REAL
			8	DOUBLE
			12	VARCHAR
			91	DATE
			92	TIME
			93	TIMESTAMP
			1111 	OTHER
                */
                
                //row[index] = cellValue instanceof String ? ((String)cellValue).trim() : cellValue;
            }  
            
            if(row.length != 0){  
            	dataRows.add(row);  
            }  
        }        
        while (rs.next());  
        
        //prepare for TableModel
        Object[][] dataRowsArray = new Object[dataRows.size()][colNames.size()];				
		for(int i = 0 ; i < dataRows.size(); i++)		
			dataRowsArray[i] = dataRows.get(i);
				
		//TODO- prefix the source on colnames;products$
		String[] columnHeader = colNames.toArray(new String[colNames.size()]);		
		for(int j = 0 ; j < columnHeader.length; j++)
			columnHeader[j] = "products$"+columnHeader[j];
		
		TableModel model = new DefaultTableModel(dataRowsArray, columnHeader);		
		
		return model;
	}

	/* (non-Javadoc)
	 * @see com.ibatis.sqlmap.client.extensions.TypeHandlerCallback#setParameter(com.ibatis.sqlmap.client.extensions.ParameterSetter, java.lang.Object)
	 */
	public void setParameter(ParameterSetter arg0, Object arg1)
			throws SQLException {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see com.ibatis.sqlmap.client.extensions.TypeHandlerCallback#valueOf(java.lang.String)
	 */
	public Object valueOf(String arg0) {
		// TODO Auto-generated method stub
		return null;
	}

}
