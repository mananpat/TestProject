package com.citi.ef.util.dataview.config.service.boot;



import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Properties;
import java.util.StringTokenizer;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 *  This class is to load instance.properties file and its extentions properties, by consolidating into one properties file.
 *  
 *  It consolidates "spring.configurations" key from all files into a global list. 
 *  All other keys are added to one properties, where key with same name will be overwritten by preceeding 
 *  one in the configured "instance.ext.properties" key.   
 *  It also trims and remove any white spaces in the entries. White spaces are preserved if enclosed using double quotes.
 */
public class InstancePropertiesLoader {

	private static final Log logger = LogFactory.getLog(InstancePropertiesLoader.class);
	
	private static final String SPRING_CONFIG = "spring.configurations";
	private static final String INST_EXT_PROPERTIES = "instance.ext.properties";	
	private static final String defaultConfigFileName = null;
	
	public static Properties loadInstanceProperties(String instancePropertiesFileName) {
		Properties properties = loadFile(instancePropertiesFileName);
		if(properties != null){
			loadInstanceExtProperties(properties);
			
			if(logger.isDebugEnabled()){
				for (Iterator<Object> iterator = properties.keySet().iterator(); iterator.hasNext();) {
					String key = (String) iterator.next();
					String value = (String) properties.get(key);
					logger.debug(key + " : " + value);					
				}
			}
			
			return properties;
		}
		else
			return null;
	}
	
	/*
	 * This method loads all properties file configured using "instance.ext.properties" key in instance.properties file.
	 *  
	 * It consolidates all spring-config files configured using "spring.configuration" key from all properties files, string value sepearated by colon
	 * All other values are added instance.properties where key with same name will be overwritten by preceeding one in the configured list.   
	 * 
	 */
	public static void loadInstanceExtProperties(Properties instanceProperties) {
		String springConfList = instanceProperties.getProperty(SPRING_CONFIG);
		
		String extProperties = instanceProperties.getProperty(INST_EXT_PROPERTIES);
		if(extProperties != null) {
			StringTokenizer st = new StringTokenizer(extProperties, ";,");		
			while(st.hasMoreElements()) {
				String fileName = (String)st.nextElement();
				Properties prop = loadFile(fileName);
				if(null != prop) {
					String springConfNames = prop.getProperty(SPRING_CONFIG);
					if(springConfNames != null){
						if (springConfList == null )
							springConfList=springConfNames;
						else
							springConfList += ";" + springConfNames;
					}						
					instanceProperties = mergeProperties(instanceProperties,prop,false);
				}
				else
					logger.warn("Could not load properties file '" + fileName + "'.");
			}
			instanceProperties.put(INST_EXT_PROPERTIES, extProperties);
		}
		if(springConfList != null && !springConfList.trim().equals("")){			
			instanceProperties.put(SPRING_CONFIG, springConfList);
		}
		cleanupInstancePropertiesEntries(instanceProperties);
	}	
	
	/*
	 * The following API merges the parent and child property list. 
	 * If override is true child properties override the parent properties.
	 */
	@SuppressWarnings("unchecked")
	public static Properties mergeProperties(Properties parent, Properties child, boolean override) {
		if (parent == null ) return child;
		if (child == null) return parent;
		if (override) {
			parent.putAll(child);
		} 
		else {
			Enumeration e = child.propertyNames();
			while (e.hasMoreElements()){
				String key = (String) e.nextElement();
				if (parent.getProperty(key) == null) 
					parent.setProperty(key, child.getProperty(key));
			}
		}
		return parent;
	}
	
	/*
	 * Load properties file.
	 */
	private static Properties loadFile(String fileName) {
		InputStream is = null;
		try {			
			is = InstancePropertiesLoader.class.getResourceAsStream("/"+ fileName);
			if (is != null ) {
				Properties newProp = new Properties();
				newProp.load(is);				
				return newProp;
			}
		
		} catch (Exception e) {
			if(logger.isDebugEnabled())
				logger.error("Exception while reading data for file '" + fileName + "'. ", e );			
			else
				logger.warn("Exception while reading data for file '" + fileName + "'. ", e );
			
			return null;
		}
		finally
		{
			try
			{
				is.close();
			}
			catch(IOException ie){
				if(logger.isDebugEnabled())
					logger.error("IOException while closing inputstream for file '" + fileName + "'. ", ie );
				else
					logger.warn("IOException while closing inputstream for file '" + fileName + "'. ", ie );
			}
		}
		return null;
	}
	
	/*
	 * This method is to remove any blanks, ltrim, rtrim, any space in the any key or value of instance.properties entries.
	 *  
	 */
	public static void cleanupInstancePropertiesEntries(Properties instanceProperties) {
		Properties tempProperties = new Properties();		
		for (Iterator<Object> keyIterator = instanceProperties.keySet().iterator(); keyIterator.hasNext();) {
			String key = (String) keyIterator.next();
			String value = (String) instanceProperties.get(key);			
			key = formatString(key);
			value = formatString(value);						
			tempProperties.put(key, value);
		}		
		instanceProperties.putAll(tempProperties);		
	}
	
	/*
	 * 
	 * Replace string against regex Pattern.
	 * Cannot replace all space because spaces between quotes should be preserved.
	 * If any " " (double quotes) then it will not be removed.
	 */
	public static String formatString(String value) {	
		return value == null? null:value.trim();
	}

}

