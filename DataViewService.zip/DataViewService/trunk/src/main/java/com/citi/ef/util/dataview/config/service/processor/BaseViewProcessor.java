/**
 * 
 */
package com.citi.ef.util.dataview.config.service.processor;

/**
 * @author mp14693
 *
 */
public abstract class BaseViewProcessor {
	
	

}
