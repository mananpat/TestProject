package com.citi.ef.util.dataview.config.service.boot;


import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.StringTokenizer;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.beans.factory.support.BeanDefinitionReader;
import org.springframework.beans.factory.support.PropertiesBeanDefinitionReader;
import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
import org.springframework.context.support.GenericApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.UrlResource;


public class DefaultConfiguration {
	
	private static final Log log = LogFactory.getLog(DefaultConfiguration.class);	
		
	private static final String SPRING_CONFIG = "spring.configurations";
	private static String defaultPropertiesFileName = "instance.properties";
	private static String defaultConfigFileName = null;
	
	private static Properties instanceProperties;	
	private static GenericApplicationContext context = new GenericApplicationContext();
	private static PropertyPlaceholderConfigurer configurer = new PropertyPlaceholderConfigurer();

	static 
	{		
		instanceProperties = InstancePropertiesLoader.loadInstanceProperties(defaultPropertiesFileName);
		if(null == instanceProperties)
			log.error("Unable to load "+ defaultPropertiesFileName + " file. Check configuration.");		
		
		String confList = instanceProperties.getProperty(SPRING_CONFIG);
		if(confList != null) 
			defaultConfigFileName = confList;
	
		configurer.setProperties(instanceProperties);
		
		/*String myConfigFileNames = System.getProperty(SPRING_CONFIG);
		if(myConfigFileNames != null) 
			defaultConfigFileName = myConfigFileNames;*/
		if(defaultConfigFileName != null && !defaultConfigFileName.equals("")){
			StringTokenizer st = new StringTokenizer(defaultConfigFileName, ";,");
			List<String> fileList = new ArrayList<String>();
			while(st.hasMoreElements()) {
				fileList.add((String)st.nextElement());
			}		
		
			String [] configFiles;
			if (!fileList.isEmpty()){
				configFiles = new String[fileList.size()];
				fileList.toArray(configFiles);
			}
			else {
				configFiles = new String[] {defaultConfigFileName};			
			}		
	
			for (String url:configFiles) {
				loadBeanDefinitions(url);
			}
		}
		
		context.addBeanFactoryPostProcessor(configurer);
		context.refresh();
	}
	
	public static synchronized Object getBean(String beanId){
		Object bean = context.getBean(beanId);		
		return bean;
	}

	public static GenericApplicationContext getContext() {
		return context;
	}

	public static void loadBeanDefinitions(String url) {
		String protocol = "";
		if (url.indexOf(':') != -1) {
			protocol = url.substring(0, url.indexOf(':'));
		}
		if (protocol.equals("file") || protocol.equals("http")) {
			loadBeanDefinitionsFromUrl(url);
		} else if (protocol.equals("classpath")) {
			loadBeanDefinitionsFromClasspath(url);
		} else {
			loadBeanDefinitions("file:" + url);
		}
	}

	public static void loadBeanDefinitionsFromClasspath(String url) {
		String resourceName = url.substring(url.indexOf(':') + 1);
		BeanDefinitionReader reader = null;
		if (url.endsWith(".xml")) {
			reader = new XmlBeanDefinitionReader(context);
		} else if (url.endsWith(".properties")) {
			reader = new PropertiesBeanDefinitionReader(context);
		}
		if (reader != null) {
			reader.loadBeanDefinitions(new ClassPathResource(resourceName));
		} else {
			throw new RuntimeException(
					"No BeanDefinitionReader associated with " + url);
		}
	}

	public static void loadBeanDefinitionsFromUrl(String url) {
		BeanDefinitionReader reader = null;
		if (url.endsWith(".xml")) {
			reader = new XmlBeanDefinitionReader(context);
		} else if (url.endsWith(".properties")) {
			reader = new PropertiesBeanDefinitionReader(context);
		}
		if (reader != null) {
			try {
				reader.loadBeanDefinitions(new UrlResource(url));
			} catch (BeansException e) {
				log.error("error", e);
				throw new RuntimeException("BeansException : " + e.getMessage());
			} catch (MalformedURLException e) {
				log.error("error", e);
				throw new RuntimeException("MalformedUrlException : "
						+ e.getMessage());
			}
		} else {
			throw new RuntimeException(
					"No BeanDefinitionReader associated with " + url);
		}
	}

	public static Properties getInstanceProperties() {
		return instanceProperties;
	}

	public static void setInstanceProperties(Properties instanceProperties) {
		DefaultConfiguration.instanceProperties = instanceProperties;
	}
	
	public static String getDefaultPropertiesFileName() {
		return defaultPropertiesFileName;
	}

	public static void setDefaultPropertiesFileName(String defaultPropertiesFileName) {
		DefaultConfiguration.defaultPropertiesFileName = defaultPropertiesFileName;
	}
}
