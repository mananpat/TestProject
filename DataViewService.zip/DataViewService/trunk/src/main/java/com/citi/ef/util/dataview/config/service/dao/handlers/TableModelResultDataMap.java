package com.citi.ef.util.dataview.config.service.dao.handlers;

import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

public class TableModelResultDataMap {
    
	private TableModel tableModel = new DefaultTableModel();

	public TableModel getTableModel() {
		return tableModel;
	}

	public void setTableModel(TableModel tableModel) {
		this.tableModel = tableModel;
	}
    
   
}
