/**
 * 
 */
package com.citi.ef.util.dataview.config.service.dao.handlers;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.ibatis.sqlmap.client.extensions.ParameterSetter;
import com.ibatis.sqlmap.client.extensions.ResultGetter;
import com.ibatis.sqlmap.client.extensions.TypeHandlerCallback;

/**
 * @author mp14693
 *
 */
public class ResultSetHandlerCallback implements TypeHandlerCallback {

	/* (non-Javadoc)
	 * @see com.ibatis.sqlmap.client.extensions.TypeHandlerCallback#getResult(com.ibatis.sqlmap.client.extensions.ResultGetter)
	 */
	public Map<String, List<?>>  getResult(ResultGetter getter) throws SQLException {
		Map<String, List<?>> result = new LinkedHashMap<String, List<?>>();
        ResultSet rs = getter.getResultSet();  
        ResultSetMetaData rsmd = rs.getMetaData();  
        int numColumns = rsmd.getColumnCount();  
        List<String> colNames = new ArrayList<String>();  
         //Get the column names; column indices start from 1  
        for (int i=1; i<numColumns+1;i++) {  
            colNames.add(rsmd.getColumnName(i));   
        }  
        List<Map<String,Object>> rows = new ArrayList<Map<String,Object>>();  
        Map<String,Object> row;  
        Object cellValue;  
        // do while loop is used here since in iBatis, the resultset begins at the first record unlike jdbc where the cursor is positioned before the first record.  
        do{  
            row = new HashMap<String, Object>();  
            for(String colName : colNames){           
                cellValue=rs.getObject(colName);  
                row.put(colName, (cellValue instanceof String ? rs.getString(colName).trim() : cellValue));  
            }  
            if(row.size() != 0){  
                rows.add(row);  
            }  
        }
        while (rs.next());  
        
        result.put("RESULT_ROWS",rows);  
        
        /*TableModel tableModel = new DefaultTableModel(dataRowsArray, headers);
        return tableModel;*/
        return result;  
        
	}

	/* (non-Javadoc)
	 * @see com.ibatis.sqlmap.client.extensions.TypeHandlerCallback#setParameter(com.ibatis.sqlmap.client.extensions.ParameterSetter, java.lang.Object)
	 */
	public void setParameter(ParameterSetter arg0, Object arg1)
			throws SQLException {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see com.ibatis.sqlmap.client.extensions.TypeHandlerCallback#valueOf(java.lang.String)
	 */
	public Object valueOf(String arg0) {
		// TODO Auto-generated method stub
		return null;
	}

}
