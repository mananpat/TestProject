package com.ml.elt.s1.sw.features.queryprofile;

import java.lang.reflect.Method;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ml.elt.s1.profile.exception.ProfileException;
import com.ml.elt.s1.profile.intface.DataConverter;

public class BookingServiceDataConverter extends DataConverter {
	private static Log log = LogFactory.getLog(BookingServiceDataConverter.class);
	private static final String ENUM_PACKAGE_PREFIX = "com.ml.elt.s1.core.sdo.enums.";
	private static final String ENUM_CONVERT_METHOD = "fromId";
	public static final String TYPE_ENUM = "ENUM";
	
	@SuppressWarnings("unchecked")
	public Object convert(Object propValue, String type) throws ProfileException {
		if (propValue == null || type == null)
			return null;
		if (type.startsWith(TYPE_ENUM)) {
			type = type.replaceAll(TYPE_ENUM, "");
			type = type.replace('(', ' ');
			type = type.replace(')', ' ');
			String clazzName = new StringBuilder(ENUM_PACKAGE_PREFIX).append(
					type.trim()).toString();
			try {
				Class clazz = Class.forName(clazzName);
				Method method = clazz.getMethod(ENUM_CONVERT_METHOD,
						new Class[] { String.class }); // s();
				propValue = method.invoke(null, (String) propValue);
				return propValue;
			} catch (Exception e) {
				log.warn(String.format("Cannot convert string %1$s to type %2$s: Message: %3$s", propValue, clazzName, e.getMessage()));
				return null;
			} 
		} else
			return super.convert(propValue, type);

	}
}
