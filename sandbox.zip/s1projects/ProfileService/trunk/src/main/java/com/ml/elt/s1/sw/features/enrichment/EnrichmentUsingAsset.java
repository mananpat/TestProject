package com.ml.elt.s1.sw.features.enrichment;

import org.apache.log4j.Logger;

import com.ml.elt.s1.core.sdo.Client;
import com.ml.elt.s1.core.sdo.IncomingTrade;
import com.ml.elt.s1.core.sdo.Instrument;
import com.ml.elt.s1.platform.container.exception.CacheAccessException;
import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.platform.container.service.cache.CacheDas;
import com.ml.elt.s1.sw.plugins.exception.BaseExceptionDescriptions;
import com.ml.elt.s1.sw.plugins.exception.LookupCalendarException;

/**
 * 
 */
public class EnrichmentUsingAsset implements Enrichment{

	private static Logger log = Logger.getLogger(EnrichmentUsingAsset.class);
	protected CacheDas das;
	protected Instrument underlying;

	public EnrichmentUsingAsset(CacheDas das) {
		this.das = das;
	}
	
	public void lookup(IncomingTrade trade) throws CacheAccessException, LookupCalendarException {
		try {
			underlying = (Instrument)das.read(Instrument.class, trade.getUnderlyingInstId());
			if(underlying == null)
				throw new DASException("Invalid Instrument");
			populateSecurityId(trade);
			if (trade.getClientEntity() == null)
				this.populateClientEntity(trade);
			if (trade.getUnderCcy() == null)
				populateUnderlyingCurrency(trade);

			if (trade.getUnderlyingExchangeId()== null)
				populateUnderlyingExchange(trade);
			if (trade.getUnderModel()== null)
				populateUnderlyingModel(trade);

			if (trade.getTradeInstMarket() == null )
				populateMarket(trade);
			
			if (trade.getUnitSize()==null)
				populateUnitSize(trade);
			
			if (trade.getCusip()==null)
				populateCusip(trade);
			
			if (trade.getRic()==null)
				populateRic(trade);
			
			if (trade.getSedol()==null)
				populateSedol(trade);
			
			if (trade.getIsin()==null)
				populateIsin(trade);
			
			if (trade.getBloombergTicker()==null)
				populateTicker(trade);

		} catch (DASException dase) {
			log.warn("Cache Read Exception",dase);
			throw new CacheAccessException(BaseExceptionDescriptions.CACHE_READ_FAILED_IN_instrument, dase);
		}
	}

	/**
	 * @param trade
	 * @throws DASException
	 */
	protected void populateUnderlyingCurrency(IncomingTrade trade)
	        throws DASException {
		if (trade.getUnderlyingInstId() != null && 
				!trade.getUnderlyingInstId().equals("")) {
			if (underlying != null 
					&& underlying.getPayCurrency() != null
					&& !underlying.getPayCurrency().equals("")) {
					trade.setUnderCcy(underlying.getPayCurrency());
			}
		}
	}

	protected void populateCusip(IncomingTrade trade)
		throws DASException {
		if (trade.getUnderlyingInstId() != null && 
				!trade.getUnderlyingInstId().equals("")) {
			if (underlying != null 
					&& underlying.getCusip() != null
					&& !underlying.getCusip().equals("")) {
					trade.setCusip(underlying.getCusip());
			}
		}
	}
	
	protected void populateTicker(IncomingTrade trade)
		throws DASException {
		if (trade.getUnderlyingInstId() != null && 
				!trade.getUnderlyingInstId().equals("")) {
			if (underlying != null 
					&& underlying.getBloombergTicker() != null
					&& !underlying.getBloombergTicker().equals("")) {
					trade.setBloombergTicker(underlying.getBloombergTicker());
			}
		}
	}
	
	protected void populateSedol(IncomingTrade trade)
		throws DASException {
		if (trade.getUnderlyingInstId() != null && 
				!trade.getUnderlyingInstId().equals("")) {
			if (underlying != null 
					&& underlying.getSedol() != null
					&& !underlying.getSedol().equals("")) {
					trade.setSedol(underlying.getSedol());
			}
		}
	}
	
	protected void populateIsin(IncomingTrade trade)
		throws DASException {
		if (trade.getUnderlyingInstId() != null && 
				!trade.getUnderlyingInstId().equals("")) {
			if (underlying != null 
					&& underlying.getIsin() != null
					&& !underlying.getIsin().equals("")) {
					trade.setIsin(underlying.getIsin());
			}
		}
	}
	
	protected void populateRic(IncomingTrade trade)
		throws DASException {
		if (trade.getUnderlyingInstId() != null && 
				!trade.getUnderlyingInstId().equals("")) {
			if (underlying != null 
				&& underlying.getRic() != null
				&& !underlying.getRic().equals("")) {
				trade.setRic(underlying.getRic());
			}
		}
	}

	/**
	 * @param trade
	 * @throws DASException
	 */
	protected void populateUnderlyingExchange(IncomingTrade trade)
	        throws DASException {
		String underlyingExchange = trade.getUnderlyingExchangeId();
		if (underlyingExchange  == null || "".equals(underlyingExchange)) {
			if (underlying != null){
				String underExchange = underlying.getExchID();
				if(underExchange != null && !"".equals(underExchange.trim())) {
					trade.setUnderlyingExchangeId(underExchange);
				}
			}
		}
	}
	
	/**
	 * @param trade
	 * @throws DASException
	 */
	protected void populateMarket(IncomingTrade trade)
	        throws DASException {
		String market = trade.getTradeInstMarket();
		if (market == null || "".equals(market)) {
			if (underlying != null){
				market = underlying.getMarket();
				if(market != null && !"".equals(market.trim())) {
					trade.setTradeInstMarket(market);
				}
			}
		}
	}

	/**
	 * @param trade
	 * @throws DASException
	 */
	protected void populateUnitSize(IncomingTrade trade)
	        throws DASException {
		Integer unitSize = trade.getUnitSize();
		if (unitSize == null) {
			if (underlying != null){
				unitSize = underlying.getUnitSize();
				if(unitSize != null) {
					trade.setUnitSize(unitSize);
				}
			}
		}
	}
	
	
	/**
	 * @param trade
	 * @throws DASException
	 */
	protected void populateUnderlyingModel(IncomingTrade trade)
	        throws DASException {
		String tradeUnderModel = trade.getUnderModel();
		if ( tradeUnderModel== null || 
			 "".equals(tradeUnderModel)) {
			if (underlying != null){
				String underlyingModel = underlying.getModel();
				if(underlyingModel != null && !"".equals(underlyingModel.trim())) {
					trade.setUnderModel(underlyingModel);
				}
			}
		}
	}

	/**
	 * @param trade
	 * @throws DASException
	 */
	protected void populateSecurityId(IncomingTrade trade)
	        throws DASException {
		if (trade.getSecurityId() == null) {
			trade.setSecurityId(trade.getUnderlyingInstId());
		}
	}
	
	protected void populateClientEntity (IncomingTrade trade) throws DASException {
		if (trade.getClientShortName() != null && !trade.getClientShortName().equals(""))
		{
			Client client = (Client)das.read(Client.class, trade.getClientShortName(), false);
			if (client != null)
				trade.setClientEntity(client.getDefaultEntity());
		}
	}

}
