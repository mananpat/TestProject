package com.ml.elt.s1.ps.plugins.jmx;

import java.util.List;

import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.platform.container.jmx.AbstractDynamicMBean;
import com.ml.elt.s1.platform.container.service.cache.CachableObject;
import com.ml.elt.s1.platform.plugins.cache.opencache.GenericCacheDas;

public class ReindexCache extends AbstractDynamicMBean {
	
	public String reindexCachedClass(String className){
		GenericCacheDas das = new GenericCacheDas();
		das.connect(null);
		try {
			List<CachableObject> list = das.read(Class.forName(className.trim()));
			if(list != null && !list.isEmpty()) das.write(list);
			return "Reindex ok:" + className + "(" + list.size() + " items reindexed)";
		} catch (DASException e) {
			return "Failed reindex:" + e.getMessage();
		} catch (ClassNotFoundException e) {
			return "Failed reindex. ClassNotFoundException:" + className;
		}		
	}
	
	public String reindexPickerBean (){
		return reindexCachedClass("com.ml.elt.s1.picker.PickerBean");
	}
	
	public String reindexClient(){
		return reindexCachedClass("com.ml.elt.s1.core.sdo.Client");
	}
	
	public String reindexInstrument(){
		return reindexCachedClass("com.ml.elt.s1.core.sdo.Instrument");
	}		
}
