package com.ml.elt.s1.sw.features.enrichment.tr;

import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ml.elt.s1.core.sdo.IncomingTrade;
import com.ml.elt.s1.platform.container.service.cache.CacheDas;
import com.ml.elt.s1.profile.intface.ILookupGenerator;
import com.ml.elt.s1.sw.features.queryprofile.ExtractCriteriaValueFromAsset;
import com.ml.elt.s1.sw.features.queryprofile.PropertyCode;

public class BookingServiceLookupGenerator implements ILookupGenerator {
	private static Log log = LogFactory.getLog(BookingServiceLookupGenerator.class);
	
	private CacheDas cacheDas;
	
	private EnrichmentTRUsingAsset enrichmentUsingAsset;
	
	public BookingServiceLookupGenerator() {
	}
	
	public void generateLookups(Map<String, Object> lookups, String userId) {
		try {
			IncomingTrade incomingTrade = new IncomingTrade ();
			incomingTrade.setUpdateUser(userId);
			Object underlyingId = lookups.get(PropertyCode.UNDERLYING);
			if (underlyingId != null) {
				incomingTrade.setUnderlyingInstId(underlyingId.toString());
			}
			Object desk = lookups.get(PropertyCode.DESK);
			if (desk != null)
				incomingTrade.setBusinessUnit(desk.toString());
			if(enrichmentUsingAsset == null)
				enrichmentUsingAsset = new EnrichmentTRUsingAsset(cacheDas);
			ExtractCriteriaValueFromAsset.doIt(incomingTrade, lookups, cacheDas);			
		}
		catch (Exception e) {
			log.error ("Error while extracting lookup properties", e);
		}		
	}

	public CacheDas getCacheDas() {
		return cacheDas;
	}

	public void setCacheDas(CacheDas cacheDas) {
		this.cacheDas = cacheDas;
	}

}
