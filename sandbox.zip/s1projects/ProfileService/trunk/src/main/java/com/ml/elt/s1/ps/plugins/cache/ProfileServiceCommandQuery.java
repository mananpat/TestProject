/**
 * 
 */
package com.ml.elt.s1.ps.plugins.cache;

import java.util.List;

import com.ml.elt.s1.core.sdo.Client;
import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.platform.container.service.cache.CachableObject;
import com.ml.elt.s1.platform.container.service.cache.CacheDas;

/**
 * @author pagarwa2
 *
 */
public class ProfileServiceCommandQuery {

	public static  List<CachableObject> getClients(CacheDas cacheDas) throws DASException {	
		List<CachableObject> client = cacheDas.read(Client.class);
		if (client == null)
			return null;
		return client;
	}

}
