package com.ml.elt.s1.sw.features.queryprofile;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ml.elt.s1.core.sdo.Client;
import com.ml.elt.s1.core.sdo.enums.Classification;
import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.platform.container.service.cache.CachableObject;
import com.ml.elt.s1.platform.container.service.cache.CacheDas;
import com.ml.elt.s1.profile.core.sdo.ClientData;
import com.ml.elt.s1.profile.impl.LookupIndex;
import com.ml.elt.s1.profile.impl.LookupResultSet;
import com.ml.elt.s1.profile.impl.ProfileHierarchy;
import com.ml.elt.s1.profile.intface.IHierarchyLoader;
import com.ml.elt.s1.ps.plugins.cache.ProfileServiceCommandQuery;

public class ClientDataLoader implements IHierarchyLoader, Serializable{
	private static final long serialVersionUID = -1903233441589111162L;
	
	private static Log log = LogFactory.getLog(ClientDataLoader.class);
	private static final String clientShortName = "clientShortName";
	private static Map<String, ClientData> clientDataMap = new HashMap<String, ClientData>();
	private boolean init= true;
	private CacheDas cacheDas;

	public ClientDataLoader(CacheDas das){
		try {
			cacheDas = das.newInstance(null, null);
			cacheDas.connect(null);
		} catch (DASException dasEx) {
			log.error("Unable to Connect to cache",dasEx);
		}
	}
	
	public synchronized void init() throws DASException{
		if(init){
			loadClientData();	
			init=!init;
		}
	}
	
	public Map<String, ProfileHierarchy> getHierarchyMap() {
		return null;
	}

	public void loadHierarchy(ProfileHierarchy hierarchy) {
	}

	
	public void helpSearch(LookupIndex index, LookupResultSet lrSet) {
		Map<String, Object> copyLookUpValues = new HashMap<String, Object>();
		copyLookUpValues.putAll(lrSet.lookupValues);
		if(lrSet != null && lrSet.lookupValues!=null ){
			String clientName = (String)lrSet.lookupValues.get(clientShortName);
			if(clientName != null ){
				lrSet.lookupValues.put(clientShortName,clientName);
				index.search(lrSet,false);
				ClientData clientData = getParentTree(clientName);
				if(clientData!=null) {
					searchClientHierarchy(clientData,index,lrSet);
				}
				lrSet.lookupValues.put(clientShortName,LookupIndex.NULL_KEY);
				index.search(lrSet,true);
			} else {
				index.search(lrSet,true);
			}
		}
		lrSet.lookupValues.clear();
		lrSet.lookupValues.putAll(copyLookUpValues);
	}
	
	
	
	public synchronized void loadClientData() {
		try {
			log.info("Start of Client Tree Creation");
			clientDataMap.clear();
			Long startTime = System.currentTimeMillis();
			List<CachableObject> list = ProfileServiceCommandQuery.getClients(cacheDas);
			Map<Integer, List<Client>> clientListMap = new HashMap<Integer, List<Client>>();
			if (list != null && !list.isEmpty()) {
				List<Client> clients = new ArrayList<Client>();
				Client clientObj = null;
				Integer cprId = null;
				List<Client> clientList = null;
				for (CachableObject obj : list) {
					clientObj = (Client) obj;
					cprId = clientObj.getCounterpartyId();
					clientList = clientListMap.get(cprId);
					if (clientList == null) {
						clientList = new ArrayList<Client>(4);
						clientListMap.put(cprId, clientList);
					}
					clientList.add(clientObj);
					clients.add(clientObj);
					clientObj.getClassification();
				}
//				Integer iaCprid = null;
//				Integer parentCprid = null;
				Integer globalParentCprid = null;
				for (Client client : clients) {
					cprId = client.getCounterpartyId();
//					iaCprid = client.getIacounterpartyId();
//					parentCprid = client.getParentCprId();
					globalParentCprid = client.getGlobalParentCprId();
//					if (iaCprid != null && !cprId.equals(iaCprid)
//							&& iaCprid != 0) {
//						clientList = clientListMap.get(iaCprid);
//						addParentName(client, clientList);
//					}
//					
//					if (parentCprid != null && !cprId.equals(parentCprid)
//							&& parentCprid != 0) {
//						clientList = clientListMap.get(parentCprid);
//						addParentName(client, clientList);
//					}
					if (globalParentCprid != null && 
						globalParentCprid != 0 && !globalParentCprid.equals(cprId))
							clientList = clientListMap.get(globalParentCprid);
						else 
							clientList =null;
						addParentName(client, clientList);
				}
			}
			Long endTime = System.currentTimeMillis();
			log.info("End of client Tree Creation:" + (endTime - startTime));

		} catch (DASException e) {
			log.error("Failed loading client hierarchy", e);
		}
	}

	protected void addParentName(Client child, List<Client> parentList) {
		if (child != null ) {
			String childName = child.getShortName();
			ClientData childData = clientDataMap.get(childName);
			if (childData == null) {
				childData = new ClientData(childName);
				clientDataMap.put(childName, childData);
			}
			if(parentList != null && !parentList.isEmpty()){
				for (Client parent : parentList) {
					if(parent.getClassification() == null || !(Classification.ALLOCATION.equals(parent.getClassification())))
						childData.addParentString(parent.getShortName());
				}
			}
		}
	}

	protected ClientData getParentTree(String childName){
		ClientData childData = clientDataMap.get(childName);
		if(childData!=null){
			synchronized (childData) {
				Set<String> dataSet = childData.getParentSet();
				if(dataSet!=null && !dataSet.isEmpty()){
					Set<String> processed = new HashSet<String>();
					processed.add(childName);
					parentSearch(childData, processed);
				}
			}
		}
		return childData;
	}
	
	
	protected ClientData flushClientData(String childName){
		ClientData childData = getParentTree(childName);
		synchronized (childData) {
			List<ClientData> listData = childData.getParentList();
			if(listData!=null && !listData.isEmpty()){
				for(ClientData data:listData)
					flushData(data);
			}
		}
		return childData;
	}
	
	protected void flushData(ClientData childData){
		synchronized (childData) {
			List<ClientData> listData = childData.getParentList();
			if(listData!=null && !listData.isEmpty()){
				for(ClientData data:listData){
					if(data.getParentList()!=null)
						flushData(data);
				}
				childData.flushParentList();
			}
		}
	}

	
	protected void parentSearch(ClientData clientData, Set<String> processed){
		synchronized (clientData) {
			if(clientData!=null && processed!=null){
				if(clientData.getParentList()==null || clientData.getParentList().isEmpty()){
					Set<String> parentSet = clientData.getParentSet();
					if(parentSet!=null && !parentSet.isEmpty()){
						for(String parent :parentSet){
							if(!processed.contains(parent)){
								ClientData parentData = clientDataMap.get(parent);
								processed.add(parent);
								if(parentData!=null){
									clientData.addParent(parentData);
									parentSearch(parentData,processed);
								}
							}
						}
					}
				}
			}
		}
	}
	

	
	protected void searchClientHierarchy(ClientData clientData, LookupIndex index, LookupResultSet lrSet) {
		if(clientData != null){
			List<ClientData> parentList = clientData.getParentList();
			if(parentList!=null && !parentList.isEmpty()){
				for(ClientData pClientData : parentList){
					String clientName = pClientData.getShortName();  
					lrSet.lookupValues.put(clientShortName,clientName);
					index.search(lrSet,false);
				}
				for(ClientData pClientData : parentList){
					searchClientHierarchy(pClientData, index,lrSet);
				}
			} 
		}
	}
}
