/**
 * 
 */
package com.ml.elt.s1.ps.plugins.jmx;

import javax.management.MBeanServer;
import javax.management.ObjectName;

import com.ml.elt.s1.platform.container.jmx.AbstractDynamicMBean;
import com.ml.elt.s1.platform.container.service.boot.Startstop;
import com.ml.elt.s1.platform.container.service.cache.CacheDas;
import com.ml.elt.s1.platform.plugins.boot.BootController;
import com.ml.elt.s1.platform.plugins.boot.DefaultConfiguration;
import com.ml.elt.s1.profile.plugins.jmx.LoadPickersData;
import com.ml.elt.s1.profile.plugins.jmx.LoadProfileData;
import com.ml.elt.s1.ps.platform.ApplicationConstants;


/**
 * @author mpatel12
 *
 */
public class JMXInit extends AbstractDynamicMBean implements Startstop {

	private String JMXDomain = "S1.ProfileService";
	public boolean restart() {
		return startup(null);
	}

	public boolean shutdown() {
		if(Boolean.valueOf(DefaultConfiguration.getInstanceProperties().getProperty(ApplicationConstants.INSTANCE_MODE_TESTING, "false"))){
			MBeanServer server = BootController.getMbeanServer();
			try {
				server.unregisterMBean(new ObjectName(JMXDomain, "type", "Reindex Cache"));
				server.unregisterMBean(new ObjectName(JMXDomain, "type", "Load Profiles Data"));
				server.unregisterMBean(new ObjectName(JMXDomain, "type", "Load Pickers Data"));
				server.unregisterMBean(new ObjectName(JMXDomain, "type", "Load client"));
				server.unregisterMBean(new ObjectName(JMXDomain, "type", "Load instrument"));				
			} catch (Exception e) {
			}		
		}
		return true;
	}

	public boolean startup(CacheDas cacheDas) {
		if(Boolean.valueOf(DefaultConfiguration.getInstanceProperties().getProperty(ApplicationConstants.INSTANCE_MODE_TESTING, "false"))){
			MBeanServer server = BootController.getMbeanServer();
			try {
				server.registerMBean(new ReindexCache(), new ObjectName(JMXDomain, "type", "Reindex Cache"));			
				server.registerMBean(new LoadProfileData(), new ObjectName(JMXDomain, "type", "Load Profiles Data"));
				server.registerMBean(new LoadPickersData(), new ObjectName(JMXDomain, "type", "Load Pickers Data")); 
				server.registerMBean(new LoadClient(), new ObjectName(JMXDomain, "type", "Load client"));
				server.registerMBean(new LoadInstrument(), new ObjectName(JMXDomain, "type", "Load instrument"));
				
			} catch (Exception e) {
			}
		}
		return true;
	}

}
