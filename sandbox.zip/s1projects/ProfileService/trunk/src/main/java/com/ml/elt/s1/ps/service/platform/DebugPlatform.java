/**
 * 
 */
package com.ml.elt.s1.ps.service.platform;


import jade.Boot;


/**
 * @author mpatel12
 *
 */
public class DebugPlatform extends Boot {

	//run it with gui
	public final static String[] defaultPlatformForDebug = new String[]{		
		"-host", "localhost", "-port", "11723", "-local-host", "localhost", "-local-port", "11723",  "StartStop:com.ml.elt.s1.platform.plugins.boot.StartupShutdown"
	}; 

	public DebugPlatform(String[] arg0) {
		super(arg0);
	}
	
	public static void main(String[] args){
		if (args != null && args.length > 0 ) new DebugPlatform(args);
		else {
			new DebugPlatform(defaultPlatformForDebug);
		}
	}

}
