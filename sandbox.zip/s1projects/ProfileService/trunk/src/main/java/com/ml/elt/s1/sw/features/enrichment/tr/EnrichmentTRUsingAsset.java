package com.ml.elt.s1.sw.features.enrichment.tr;

import org.apache.log4j.Logger;

import com.ml.elt.s1.core.sdo.IncomingTrade;
import com.ml.elt.s1.core.sdo.Instrument;
import com.ml.elt.s1.platform.container.exception.CacheAccessException;
import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.platform.container.service.cache.CacheDas;
import com.ml.elt.s1.sw.features.enrichment.EnrichmentUsingAsset;
import com.ml.elt.s1.sw.plugins.exception.BaseExceptionDescriptions;
import com.ml.elt.s1.sw.plugins.exception.LookupCalendarException;

/**
 * 
 */
public class EnrichmentTRUsingAsset extends EnrichmentUsingAsset{

	private static Logger log = Logger.getLogger(EnrichmentTRUsingAsset.class);

	public EnrichmentTRUsingAsset(CacheDas das) {
		super(das);
	}
	
	public void lookup(IncomingTrade trade) throws CacheAccessException, LookupCalendarException {
		
		try {
			underlying = (Instrument)das.read(Instrument.class, trade.getUnderlyingInstId());
			if(underlying == null)
				throw new DASException("Invalid Instrument");
			populateSecurityId(trade);
			if (trade.getClientEntity() == null)
				this.populateClientEntity(trade);
			if (trade.getUnderCcy() == null)
				populateUnderlyingCurrency(trade);

			if (trade.getUnderlyingExchangeId()== null)
				populateUnderlyingExchange(trade);
			if (trade.getUnderModel()== null)
				populateUnderlyingModel(trade);

			if (trade.getTradeInstMarket() == null )
				populateMarket(trade);
			
			if (trade.getUnitSize()==null)
				populateUnitSize(trade);
			
			if (trade.getCusip()==null)
				populateCusip(trade);
			
			if (trade.getRic()==null)
				populateRic(trade);
			
			if (trade.getSedol()==null)
				populateSedol(trade);
			
			if (trade.getIsin()==null)
				populateIsin(trade);
			
			if (trade.getBloombergTicker()==null)
				populateTicker(trade);

		} catch (DASException dase) {
			log.warn("Cache Read Exception",dase);
			throw new CacheAccessException(BaseExceptionDescriptions.CACHE_READ_FAILED_IN_instrument, dase);
		}
	}
}
