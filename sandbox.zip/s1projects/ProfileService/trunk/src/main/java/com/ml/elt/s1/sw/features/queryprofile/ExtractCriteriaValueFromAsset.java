/*******************************************************************************
 * Copyright (c) Merrill Lynch  All rights reserved.
 *
 * This file is part of Global Swap Platform
 *
 * This file may be distributed under the terms of the Merrill Lynch
 * license as defined by Merrill Lynch and appearing in the file
 * LICENSE included in the packaging of this file.
 *
 * This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING
 * THE WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE.
 *
 * See www.ml.com for licensing information.
 *
 * Contact info@ml.com if any conditions of this licensing
 * are not clear to you.
 ******************************************************************************/

package com.ml.elt.s1.sw.features.queryprofile;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.ml.elt.s1.core.sdo.IncomingTrade;
import com.ml.elt.s1.core.sdo.Instrument;
import com.ml.elt.s1.core.sdo.SwapTrade;
import com.ml.elt.s1.entitlement.core.sdo.RamUsers;
import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.platform.container.service.cache.CachableObject;
import com.ml.elt.s1.platform.container.service.cache.CacheDas;
import com.ml.elt.s1.profile.core.das.cache.ProfileCommandQuery;
import com.ml.elt.s1.profile.core.sdo.PickerBean;

/**
 * @author dqian
 *
 */
public class ExtractCriteriaValueFromAsset {
	private static Logger log = Logger.getLogger(ExtractCriteriaValueFromAsset.class);

	/**
	 * @param swapTrade
	 * @param criteriaValues
	 * @throws DASException
	 */
	public static void doIt(IncomingTrade swapTrade, 
			Map<String, Object> criteriaValues, 
			CacheDas das) throws DASException {
		if(log.isDebugEnabled()) log.debug("Look up necessary attributes from asset if it is not set in the input trade (externalTransId:" + swapTrade.getExternalTransId() + "). ");
		if (swapTrade.getUnderlyingInstId() != null && !swapTrade.getUnderlyingInstId().equals("")) {
			Instrument asset = (Instrument)das.read(Instrument.class, Instrument.getCacheKey(swapTrade.getUnderlyingInstId()));
			if(asset != null){
				getUnderExchange(swapTrade, criteriaValues, asset);
				getUnderlyingModel(swapTrade, criteriaValues, asset);
				getSettleCurrency(swapTrade, criteriaValues, asset);
				getUnderlyingSettleOffset(swapTrade, criteriaValues, asset);
				getUnderlyingMarket(swapTrade, criteriaValues, asset,das);
				getUnderlyingRegion(swapTrade, criteriaValues, asset,das);
			}
			else
				log.warn("Underlying Instrument can't be found. Profile lookup can't proceed ");
		}
		getTradingDesk (swapTrade, criteriaValues, das);
	}
	
	@SuppressWarnings("unchecked")
	private static void getTradingDesk(IncomingTrade trade, Map<String, Object> criteriaValues, CacheDas das) throws DASException {
		if (trade.getBusinessUnit() != null)
			criteriaValues.put(PropertyCode.DESK, trade.getBusinessUnit());
		else if (trade.getUpdateUser() != null) {
			log.debug("Update user is in the input message (externalTransId:" + trade.getExternalTransId() + "). Use it in criteriaValues: " + trade.getUpdateUser());
			String key = RamUsers.getCacheKey(trade.getUpdateUser());
			// Disabling lazy loading as ram_users are being loaded at startup.
			CachableObject object = das.read(RamUsers.class, key, false);
			if (object != null) {
				String desk = ((RamUsers) object).getDesk();
				if (desk != null) {
					criteriaValues.put(PropertyCode.DESK, desk);
					trade.setBusinessUnit(desk);
				}
			} else {
				log.info("Ram_User info not present for user "+trade.getUpdateUser()+" in Cache. If present in database. Please reload entitlements.");
			}
		}
	}
	
	private static void getUnderExchange(SwapTrade swapTrade, Map<String, Object> criteriaValues, Instrument asset) {
		if (criteriaValues.get(PropertyCode.UNDERL_EXCH_ID) == null && asset != null && !asset.getExchID().equals("")) {
			if(log.isDebugEnabled())log.debug("UNDERL_EXCH_ID is in the asset (" + asset.getId() + ") (externalTransId:" + swapTrade.getExternalTransId() + "). Use it in criteriaValues:" + asset.getExchID());
			criteriaValues.put(PropertyCode.UNDERL_EXCH_ID, asset.getExchID());
		}
	}

	/**
	 * @param swapTrade
	 * @param criteriaValues
	 * @param asset
	 */
	private static void getUnderlyingSettleOffset(SwapTrade swapTrade, Map<String, Object> criteriaValues, Instrument asset) {
		if (criteriaValues.get(PropertyCode.UNDERL_SETL_OFFSET) == null && asset != null && asset.getSettleOffset() >= 0) {
			if(log.isDebugEnabled()) log.debug("UNDERL_SETL_OFFSET is in the asset (" + asset.getId() + ") (externalTransId:" + swapTrade.getExternalTransId() + "). Use it in criteriaValues:" + asset.getSettleOffset());
			criteriaValues.put(PropertyCode.UNDERL_SETL_OFFSET, asset.getSettleOffset());
		}
	}


	/**
	 * @param swapTrade
	 * @param criteriaValues
	 * @param asset
	 */
	private static void getSettleCurrency(SwapTrade swapTrade, Map<String, Object> criteriaValues, Instrument asset) {
		if (criteriaValues.get(PropertyCode.UNDERL_SETL_CCY) == null && asset != null && asset.getPayCurrency() != null && !asset.getPayCurrency().equals("")) {
			if(log.isDebugEnabled())log.debug("PAY_CCY is in the asset  (" + asset.getId() + ") (externalTransId:" + swapTrade.getExternalTransId() + "). Use it in criteriaValues:" + asset.getPayCurrency());
			criteriaValues.put(PropertyCode.UNDERL_SETL_CCY, asset.getPayCurrency());
		}
	}


	/**
	 * @param swapTrade
	 * @param criteriaValues
	 * @param asset
	 */
	private static void getUnderlyingModel(SwapTrade swapTrade, Map<String, Object> criteriaValues, Instrument asset) {
		if (criteriaValues.get(PropertyCode.UNDERL_MODEL) == null && asset != null && asset.getModel() != null && !asset.getModel().equals("")) {
			if(log.isDebugEnabled()) log.debug("UNDERL_MODEL is in the asset (" + asset.getId() + ") (externalTransId:" + swapTrade.getExternalTransId()+ "). Use it in criteriaValues:" + asset.getModel());
			criteriaValues.put(PropertyCode.UNDERL_MODEL, asset.getModel().trim());
		}
	}
	
	@SuppressWarnings("unchecked")
	private static void getUnderlyingMarket(SwapTrade swapTrade, Map<String, Object> criteriaValues, Instrument asset, CacheDas das) {
		if (criteriaValues.get(PropertyCode.MARKET) == null && asset != null && asset.getExchID() != null && !asset.getExchID().equals("")) {
			if(log.isDebugEnabled()) log.debug("MARKET is in the asset (" + asset.getId() + ") (externalTransId:" + swapTrade.getExternalTransId()+ "). Use it in criteriaValues:" + asset.getExchID());
			String exchId = asset.getExchID().trim();
			String country=null;
			try {
				List qres = ProfileCommandQuery.getUnderlyingMarket(exchId);
			    if(qres != null && qres.size()>0){
			    	if(log.isDebugEnabled())log.debug(String.format("Query returns %1$s items", qres.size()));
			    	 country = ((PickerBean)qres.get(0)).getParentType();			    	
			    }
			} catch (DASException e) {
				log.error(e.getMessage());
			}				    
			if(country != null && !"".equals(country)){
	    		criteriaValues.put(PropertyCode.MARKET, country);
			}
		}
	}
	
	@SuppressWarnings("unchecked")
	private static void getUnderlyingRegion(SwapTrade swapTrade, Map<String, Object> criteriaValues, Instrument asset, CacheDas das) {
		if (criteriaValues.get(PropertyCode.UNDERREGION) == null)
		{
			String country = (String) criteriaValues.get(PropertyCode.MARKET);
			if (country != null && !"".equals(country)){
				String region = null;
				try {
					List qres = ProfileCommandQuery.getUnderlyingRegion(country);
					if(qres != null && qres.size()>0){
						if(log.isDebugEnabled())log.debug(String.format("Query returns %1$s items", qres.size()));
						region = ((PickerBean)qres.get(0)).getParentType();						
					}
				} catch (DASException e) {
				log.error(e.getMessage());
			}
			if(region != null && !region.equals(""))
				criteriaValues.put(PropertyCode.UNDERREGION, region);
			}
		}
	}
}