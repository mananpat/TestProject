package com.ml.elt.s1.ps.plugins.jobs.commands;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ml.elt.s1.core.sdo.Instrument;
import com.ml.elt.s1.platform.container.service.Request;
import com.ml.elt.s1.platform.container.service.Response;
import com.ml.elt.s1.platform.container.service.cache.CachableObject;
import com.ml.elt.s1.platform.container.service.cache.CacheDas;
import com.ml.elt.s1.platform.container.service.processor.MessageProcessor;
import com.ml.elt.s1.platform.plugins.boot.DefaultConfiguration;
import com.ml.elt.s1.platform.plugins.cache.opencache.GenericCacheDas;
import com.ml.elt.s1.platform.plugins.das.Das;
import com.ml.elt.s1.platform.plugins.das.RamDas;
import com.ml.elt.s1.ps.plugins.jobs.JobProcessor;
import com.ml.elt.s1.sw.core.das.iface.InstrumentDao;

public class ReloadInstruments implements MessageProcessor {

	private static Log log = LogFactory.getLog(JobProcessor.class);
	private static boolean futureLoad;
	static {
		 String strFurtureLoad = DefaultConfiguration.getInstanceProperties().getProperty("instance.load.instrument.future","false");
		 if(strFurtureLoad!=null && "true".equalsIgnoreCase(strFurtureLoad)){
			 futureLoad = true;
		 }else {
			 futureLoad = false;
		 }
	}
	
	public static final String CACHE_DAS = "cacheDas";
	
	private Das daoManagerDb;
	private CacheDas cacheDas;

	public ReloadInstruments() {
		daoManagerDb = new RamDas();
		cacheDas = (CacheDas)DefaultConfiguration.getBean(CACHE_DAS);
	}

	public Response process(Request arg0) {
		Response resp = new Response();
		try {
			InstrumentDao dbDao = (InstrumentDao) daoManagerDb.getDao(Instrument.class);
			log.info("reloading Instruments ....");
			Map<String, Instrument> map = dbDao.getInstrumentMap();
			if(futureLoad){
				Map<String,Instrument> futMap = dbDao.getFutInstrumentMap();
				if(futMap!=null && !futMap.isEmpty()){
					if(map==null)map=new HashMap<String, Instrument>();
					map.putAll(futMap);
				}
			}

			List<CachableObject> list = cacheDas.read(Instrument.class);
			if(list != null && !list.isEmpty() && map.size() > 0) {
				List<Instrument> tobeRemoved = new ArrayList<Instrument>(); 
				for(CachableObject object:list) {
					Instrument instrument = (Instrument)object;
					if(map.get(instrument.getId()) == null) {
						tobeRemoved.add(instrument);
					}
				}
				if(tobeRemoved != null && !tobeRemoved.isEmpty()) {
					cacheDas.remove(tobeRemoved);
					log.info("Removed the following instruments from cache:" + tobeRemoved);
				}
				((GenericCacheDas)cacheDas).write(new ArrayList<Instrument>(map.values()), false, false);
				log.info("updated " + map.size() + " instruments into cache.");
			}
			log.info("done -- reloading Instruments.");
		}
		catch(Throwable t){
			log.warn("failed -- reloading Instruments.", t);
		}
		return resp;
	}

}
