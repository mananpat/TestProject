package com.ml.elt.s1.sw.features.enrichment;

import com.ml.elt.s1.core.sdo.IncomingTrade;
import com.ml.elt.s1.platform.container.exception.CacheAccessException;
import com.ml.elt.s1.sw.plugins.exception.TradeProcessingException;

public interface Enrichment {
	public void lookup(IncomingTrade incomingTrade) throws TradeProcessingException, CacheAccessException ;
}
