package com.ml.elt.s1.ps.plugins.jobs;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ml.elt.s1.platform.container.service.Request;
import com.ml.elt.s1.platform.container.service.Response;
import com.ml.elt.s1.platform.container.service.cache.CacheDas;
import com.ml.elt.s1.platform.container.service.processor.MessageProcessor;

public class JobProcessor implements MessageProcessor {
	private static Log log = LogFactory.getLog(JobProcessor.class);
	private CacheDas cacheDas;

	public Response process(Request req) {
		Response resp = new Response();
		
		Object[] array = req.getData();
		if(array != null && array.length > 0){
			String className = (String)array[0];
			try {
				Object obj = Class.forName(className).newInstance();
				if(obj instanceof MessageProcessor) {
					MessageProcessor processor = (MessageProcessor)obj;
					Object[] parameter = null;
					if(array.length == 2) {
						parameter = new Object[]{array[1]};
					}
					else {
						parameter = new Object[0];
					}
					resp = processor.process(new Request(parameter, req.getServiceContext()));
				}
			} catch (Exception e) {
				log.error(e);
			}			
		}
		return resp;
	}

	public CacheDas getCacheDas() {
		return cacheDas;
	}

	public void setCacheDas(CacheDas cacheDas) {
		this.cacheDas = cacheDas;
	}

}
