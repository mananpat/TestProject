package com.ml.elt.s1.ps.plugins.cache.loaders;

import java.util.List;

import com.ml.elt.s1.core.sdo.Client;
import com.ml.elt.s1.platform.container.service.cache.CacheDas;
import com.ml.elt.s1.platform.plugins.das.Das;
import com.ml.elt.s1.profile.plugins.cache.Worker;
import com.ml.elt.s1.sw.core.das.iface.ClientDao;

public class ClientLoader extends Worker {
	private List<String> clientShortNameList;

	public ClientLoader(Das daoManagerDb, CacheDas cacheDas) {
		super(daoManagerDb, cacheDas);
	}

	public ClientLoader(Das daoManagerDb, CacheDas cacheDas, List<String> clientShortNameList) {
		super(daoManagerDb, cacheDas);
		this.clientShortNameList = clientShortNameList;
	}

	public void doWork() throws Exception {
		ClientDao dbDao = (ClientDao) daoManagerDb.getDao(Client.class);
		CacheDas localCacheDas = cacheDas.newInstance(null, null);
		localCacheDas.connect(null);
		localCacheDas.setClass(Client.class);
		log.info("loading Clients ....");
		if (clientShortNameList == null || clientShortNameList.isEmpty()){
			List<Client> list = dbDao.getClients();
			if(list!=null && !list.isEmpty()){
				localCacheDas.write(list);
			}
		}
		else {
			for (String clientShortName : clientShortNameList) {
				Client client = dbDao.getClient(clientShortName);
				if (client != null)
					localCacheDas.write(client);
			}
		}
		localCacheDas.close();
		log.info("done -- loading Clients.");
	}
}

