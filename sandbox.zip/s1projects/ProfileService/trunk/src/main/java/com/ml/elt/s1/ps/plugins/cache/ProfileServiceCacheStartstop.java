/**
 * 
 */
package com.ml.elt.s1.ps.plugins.cache;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ml.elt.s1.core.sdo.Instrument;
import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.platform.container.exception.ExceptionHandler;
import com.ml.elt.s1.platform.container.service.boot.Startstop;
import com.ml.elt.s1.platform.container.service.cache.CacheDas;
import com.ml.elt.s1.platform.plugins.boot.DefaultConfiguration;
import com.ml.elt.s1.platform.plugins.das.Das;
import com.ml.elt.s1.platform.plugins.das.RamDas;
import com.ml.elt.s1.profile.plugins.cache.Worker;
import com.ml.elt.s1.ps.plugins.cache.loaders.ClientLoader;
import com.ml.elt.s1.ps.plugins.cache.loaders.InstrumentLoader;
import com.ml.elt.s1.ps.plugins.cache.loaders.RamGroupsLoader;
import com.ml.elt.s1.sw.plugins.exception.FatalPlatformException;

/**
 * @author mpatel12
 *
 */
public class ProfileServiceCacheStartstop implements Startstop {

	private static Log log = LogFactory.getLog(ProfileServiceCacheStartstop.class);
	public final static String CACHE_CONFIGURATION_ERROR = "Cache server is not configured.";
	
	private Das daoManagerDb;
	private CacheDas cacheDas;
	public long lock = 0;
	
	ThreadGroup group = new ThreadGroup("Profile Service Cache loader:" + System.currentTimeMillis());
	
	public ProfileServiceCacheStartstop() {
		daoManagerDb = new RamDas();
	}
	
	/* (non-Javadoc)
	 * @see com.ml.elt.s1.platform.container.service.boot.Startstop#restart()
	 */
	public boolean restart() {
		return shutdown() && startup(this.cacheDas);
	}

	/* (non-Javadoc)
	 * @see com.ml.elt.s1.platform.container.service.boot.Startstop#shutdown()
	 */
	public boolean shutdown() {
		try {
			CacheDas localCacheDas = cacheDas.newInstance(null, null);
			localCacheDas.remove(Instrument.class);
		}		
		catch(DASException e) {
			log.error("ProfileServiceCacheStartstop Shutdown Failed",e);
			return false;
		}
		
		return true;
	}

	/* (non-Javadoc)
	 * @see com.ml.elt.s1.platform.container.service.boot.Startstop#startup(com.ml.elt.s1.platform.container.service.cache.CacheDas)
	 */
	public boolean startup(CacheDas cacheDas) {		
		log.debug("Inside startup in ProfileServiceCacheStartstop.");
		this.cacheDas = cacheDas;		
		if (cacheDas == null) 
			throw new FatalPlatformException(CACHE_CONFIGURATION_ERROR);
		
		loadInstruments();	
		loadRamGroups();
		loadClients();
		
		while( lock > 0) {
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				ExceptionHandler.getInstance().handleFatalException("Failed in cache initial loader.", e);
			}
		}
		
		log.debug("Done loading cache data. End of startup in ProfileServiceCacheStartstop.");
		return true;		
	}
	
	public void createIndexes() {	
	}

	private void execute(Worker worker) {
		execute(worker, true);
	}
	
	private void execute(Worker worker, boolean isNoJoin) {		
		try {
			worker.setCounter(lock);
			Thread thread = new Thread(worker);
			thread.start();
			if (!isNoJoin) thread.join();
		} catch (Throwable e) {
			log.error(e);
		}				
	}
	
	public void loadInstruments() {
		execute(new InstrumentLoader(daoManagerDb, cacheDas));
	}
	
	public void loadClients() {
		execute(new ClientLoader(daoManagerDb, cacheDas),false);
	}
	
	public void loadRamGroups() {
		execute(new RamGroupsLoader(daoManagerDb, cacheDas));
	}
	
	@SuppressWarnings("unchecked")
	public static void main(String[] args){
		try {
			ProfileServiceCacheStartstop cacheInit = new ProfileServiceCacheStartstop();
			CacheDas cacheDas = (CacheDas)DefaultConfiguration.getBean("cacheDas");
			cacheDas.connect(null);
			cacheInit.startup(cacheDas);
			List list = cacheDas.read(Instrument.class);
			System.out.println(list);
			list = cacheDas.execute("SELECT DISTINCT * FROM /default/" + "com.ml.elt.s1.sw.core.sdo".replace('.', '_') + "/Instrument");
			System.out.println(list);
		}
		catch(DASException e){
			e.printStackTrace();
		}
	}

}
