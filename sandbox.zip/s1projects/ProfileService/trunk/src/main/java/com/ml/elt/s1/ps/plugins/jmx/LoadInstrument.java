package com.ml.elt.s1.ps.plugins.jmx;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import com.ml.elt.s1.core.sdo.Instrument;
import com.ml.elt.s1.platform.container.jmx.AbstractDynamicMBean;
import com.ml.elt.s1.platform.container.service.cache.CacheDas;
import com.ml.elt.s1.platform.plugins.boot.DefaultConfiguration;
import com.ml.elt.s1.ps.plugins.cache.CacheReloaderHelper;

public class LoadInstrument extends AbstractDynamicMBean {
	protected CacheReloaderHelper helper;
	protected CacheDas cacheDas;
	
	public LoadInstrument() {
		cacheDas = (CacheDas)DefaultConfiguration.getBean("cacheDas");
		helper = new CacheReloaderHelper();
		helper.setCacheDas(cacheDas);
	}

	public Instrument loadInstrument(String instId) {
		return helper.loadInstrument(instId);
	}
	
	public Instrument loadAnyInstrument(String instId) {
		return helper.loadAnyInstrument(instId);
	}

	public List<String> loadInstruments(String instrumentIds){
		List<String> list = new ArrayList<String>();
		StringTokenizer st = new StringTokenizer(instrumentIds, ",;:");
		while(st.hasMoreElements()){
			String id = (String)st.nextElement();
			Instrument instrument = helper.loadInstrument(id);
			if (instrument != null)list.add(instrument.toString());
			else list.add("Failed reload a Instrument by id:" + id );
		}
		return list;
	}
}
