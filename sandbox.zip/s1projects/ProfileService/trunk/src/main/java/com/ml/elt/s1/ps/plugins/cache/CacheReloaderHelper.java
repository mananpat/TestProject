package com.ml.elt.s1.ps.plugins.cache;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ml.elt.s1.core.sdo.Client;
import com.ml.elt.s1.core.sdo.Instrument;
import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.platform.container.service.cache.CachableObject;
import com.ml.elt.s1.platform.container.service.cache.CacheDas;
import com.ml.elt.s1.platform.plugins.das.Das;
import com.ml.elt.s1.platform.plugins.das.RamDas;
import com.ml.elt.s1.profile.plugins.cache.Worker;
import com.ml.elt.s1.sw.core.das.iface.ClientDao;
import com.ml.elt.s1.sw.core.das.iface.InstrumentDao;

public class CacheReloaderHelper {
	private ThreadGroup threadGroup = new ThreadGroup("Cache loader:" + System.currentTimeMillis());

	private static Log log = LogFactory.getLog(CacheReloaderHelper.class);
	private CacheDas cacheDas;
	private Das daoManagerDb;
	private static int batchSize = 200;	

	private void execute(Runnable worker, boolean isNoJoin) {
		Thread thread = new Thread(threadGroup, worker);
		thread.start();
		try {
			if (!isNoJoin) thread.join();
		} catch (InterruptedException e) {
			log.error(e);
		}
	}
	
	public CacheReloaderHelper() {
		daoManagerDb = new RamDas();
	}

	public CacheDas getCacheDas() {
		return cacheDas;
	}

	public void setCacheDas(CacheDas cacheDas) {
		this.cacheDas = cacheDas;
	}

	public Client loadClient(String clientShortName) {
		if (clientShortName == null || "".equals(clientShortName.trim()))
			return null;
		ClientDao dbDao = (ClientDao) daoManagerDb.getDao(Client.class);
		Client client = null;
		try {
			CacheDas localCacheDas = cacheDas.newInstance(null, null);
			localCacheDas.setClass(Client.class);
			client = dbDao.getClient(clientShortName);
			if (client != null)
				localCacheDas.write(client);
			localCacheDas.close();			
		} catch (DASException dasEx) {
			log.error(
					"Unable to load the Client ShortName=" + clientShortName,
					dasEx);
		}
		return client;
	}

	public Instrument loadInstrument(String instId) {
		if (instId == null || "".equals(instId.trim()))
			return null;
		InstrumentDao dbDao = (InstrumentDao) daoManagerDb
				.getDao(Instrument.class);
		Instrument inst = null;
		try {
			CacheDas localCacheDas = cacheDas.newInstance(null, null);
			localCacheDas.setClass(Instrument.class);
			inst = dbDao.getInstrument(instId);
			if (inst != null)
				localCacheDas.write(inst);
			localCacheDas.close();
		} catch (DASException dasEx) {
			log.error("Unable to load the Instrument id=" + instId, dasEx);
		}
		return inst;
	}
	
	public Instrument loadAnyInstrument(String instId) {
		if (instId == null || "".equals(instId.trim()))
			return null;
		InstrumentDao dbDao = (InstrumentDao) daoManagerDb.getDao(Instrument.class);
		Instrument inst = null;
		try {
			CacheDas localCacheDas = cacheDas.newInstance(null, null);
			localCacheDas.setClass(Instrument.class);
			inst = dbDao.getAnyInstrument(instId);
			if (inst != null)
				localCacheDas.write(inst);
			localCacheDas.close();
		} catch (DASException dasEx) {
			log.error("Unable to load the Instrument id=" + instId, dasEx);
		}
		return inst;
	}
	
	private Worker setCounter(boolean writeToCache, List<List<? extends CachableObject>>  groups, Worker worker) {
		worker.setWriteToCache(writeToCache);
		worker.setGroups(groups);
		return worker;
	}

	
}
