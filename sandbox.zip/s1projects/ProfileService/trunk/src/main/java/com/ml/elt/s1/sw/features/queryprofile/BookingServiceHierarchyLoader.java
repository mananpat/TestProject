package com.ml.elt.s1.sw.features.queryprofile;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ml.elt.s1.core.sdo.Client;
import com.ml.elt.s1.core.sdo.enums.Classification;
import com.ml.elt.s1.core.sdo.enums.ClientStatus;
import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.platform.container.service.cache.CacheDas;
import com.ml.elt.s1.profile.impl.LookupIndex;
import com.ml.elt.s1.profile.impl.LookupResultSet;
import com.ml.elt.s1.profile.impl.ProfileHierarchy;
import com.ml.elt.s1.profile.intface.IHierarchyLoader;
import com.ml.elt.s1.core.das.cache.BaseCommandQuery;

public class BookingServiceHierarchyLoader implements IHierarchyLoader, Serializable {
	private static final long serialVersionUID = 1L;
	private static Log log = LogFactory.getLog(BookingServiceHierarchyLoader.class); 
	private transient CacheDas cacheDas;
	private Map<String, ProfileHierarchy> hierarchyMap = new HashMap<String, ProfileHierarchy> ();

	
	public void init() {
	}

	public void loadHierarchy(ProfileHierarchy hierarchy) {		
		if (!hierarchy.getProfileProperty().equals(PropertyCode.CLIENT))
			return;	
		try {
			Client client = BaseCommandQuery.getClient(hierarchy.getPropertyValue(), cacheDas);
			if (client == null || client.getClientStatus() == ClientStatus.DISABLED) {
				log.warn ("No clients found for the short name: " + hierarchy.getPropertyValue());
				return;
			}
			
			this.loadClientHierarchy(hierarchy, client, hierarchy);			
		}
		catch (DASException e) {
			log.error ("Failed loading client hierarchy", e);
		}
	}
	
	private void loadClientHierarchy (ProfileHierarchy parent, Client client, ProfileHierarchy topParent) throws DASException {
		
		if (Classification.ALLOCATION.equals(client.getClassification())) {
			log.warn ("Found fund of type Allocation: " + parent.getPropertyValue());
			return;
		}
		
		Collection<Client> children = BaseCommandQuery.getChildClient(client.getCounterpartyId(), cacheDas);	
		if (children == null || children.size () == 0)
			return;
		for (Client chd : children) {
			if (chd.getCounterpartyId().equals(client.getCounterpartyId()))
				continue;
			Integer pCprId = null;
			if (chd.getIacounterpartyId() != null && client.getCounterpartyId().equals(chd.getIacounterpartyId()))
				pCprId = chd.getIacounterpartyId();
			else if (chd.getParentCprId() != null && client.getCounterpartyId().equals(chd.getParentCprId()))
				pCprId = chd.getParentCprId();
			else if (chd.getGlobalParentCprId() != null && client.getCounterpartyId().equals(chd.getGlobalParentCprId()))
				pCprId = chd.getGlobalParentCprId();
			if ((client.getIacounterpartyId() == null || (client.getIacounterpartyId().equals(client.getCounterpartyId())))
					&& (pCprId == null || (pCprId.equals(chd.getCounterpartyId())))
					&& client.getCounterpartyId().equals(chd.getCounterpartyId())) 
			{
				log.info("Found client siblings: " + client.getShortName() + ", " + chd.getShortName());
				continue;
			}
			
			ProfileHierarchy childHierarchy = this.hierarchyMap.get(chd.getShortName());
			if (childHierarchy == null) {
				childHierarchy = new ProfileHierarchy ();
				childHierarchy.setProfileProperty(parent.getProfileProperty());
				childHierarchy.setPropertyValue(chd.getShortName());
				if (checkForCircularDependency(parent, childHierarchy, topParent))
					continue;
				log.info("Found client parent - child: " + client.getShortName() + " - " + chd.getShortName());
				childHierarchy.getParent().add(parent);
				parent.getChildren().add(childHierarchy);
				this.loadClientHierarchy(childHierarchy, chd, topParent);
				this.hierarchyMap.put(chd.getShortName(), childHierarchy);
			}
			else { 
				if (checkForCircularDependency(parent, childHierarchy, topParent))
					continue;
				childHierarchy.getParent().add(parent);
				log.info("Found client parent - child: " + client.getShortName() + " - " + chd.getShortName());
				parent.getChildren().add(childHierarchy);
			}
		}		
		this.removeRedundantHierarchy(parent);
	}
	
	private boolean checkForCircularDependency (ProfileHierarchy parent, ProfileHierarchy childHierarchy, ProfileHierarchy topParent) {
		if (checkForCircularHierarchy(parent, childHierarchy, parent))
			return true;		
		return false;
	}
	
	private boolean checkForCircularHierarchy (ProfileHierarchy hier, ProfileHierarchy child, ProfileHierarchy startPoint) {
		if (hier.getProfileProperty().equals(child.getProfileProperty()) && hier.getPropertyValue().equals(child.getPropertyValue()))
			return true;
		for (ProfileHierarchy parent : hier.getParent()) {
			if (checkForCircularHierarchy(parent, child, startPoint))
			{
				StringBuilder builder = new StringBuilder ();
				builder.append("Found circular parent child hierarchy: ");
				builder.append("\n");
				builder.append(parent.getPropertyValue());
				builder.append("..");
				builder.append(hier.getPropertyValue());
				builder.append("..");
				if (!startPoint.getPropertyValue().equals(startPoint.getPropertyValue())) {
					builder.append(startPoint.getPropertyValue());
					builder.append("..");
				}
				builder.append(parent.getPropertyValue());
				log.warn(builder.toString());
				return true;
			}
		}
		return false;
	}
	
	private void removeRedundantHierarchy (ProfileHierarchy parentHierarchy) {
		if (parentHierarchy.getChildren() == null || parentHierarchy.getChildren().isEmpty())
			return;
		List<ProfileHierarchy> redundant = new ArrayList<ProfileHierarchy> ();
		for (ProfileHierarchy hier : parentHierarchy.getChildren()) {
			for (ProfileHierarchy hier2 : parentHierarchy.getChildren()) {
				if (hier2 == hier)
					continue;
				if (this.checkRedundantHierarchy(hier2.getChildren(), hier)) {
					redundant.add(hier);
					break;
				}
			}
		}
		if (!redundant.isEmpty())
			parentHierarchy.getChildren().removeAll(redundant);
    }   
	
	private boolean checkRedundantHierarchy (Collection<ProfileHierarchy> hierarchyList, ProfileHierarchy toCheckHierarchy) {
		if (hierarchyList == null)
			return false;
		for (ProfileHierarchy hier : hierarchyList) {
			if (hier.getPropertyValue().equals(toCheckHierarchy.getPropertyValue()))
				return true;
			boolean childReturn = this.checkRedundantHierarchy(hier.getChildren(), toCheckHierarchy);
			if (childReturn)
				return true;
		}
		return false;
	}
	
	public void setCacheDas(CacheDas cacheDas) {
		this.cacheDas = cacheDas;
	}

	public CacheDas getCacheDas() {
		return cacheDas;
	}

	public Map<String, ProfileHierarchy> getHierarchyMap() {
		return hierarchyMap;
	}

	public void helpSearch(LookupIndex index, LookupResultSet lrSet) {
		// TODO Auto-generated method stub
		
	}

}
