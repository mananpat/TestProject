package com.ml.elt.s1.ps.plugins.cache.loaders;

import java.util.List;

import com.ml.elt.s1.core.sdo.Instrument;
import com.ml.elt.s1.platform.container.service.cache.CacheDas;
import com.ml.elt.s1.platform.plugins.boot.DefaultConfiguration;
import com.ml.elt.s1.platform.plugins.das.Das;
import com.ml.elt.s1.profile.plugins.cache.Worker;
import com.ml.elt.s1.sw.core.das.iface.InstrumentDao;

public class InstrumentLoader extends Worker {
	private static boolean futureLoad;
	static {
		 String strFurtureLoad = DefaultConfiguration.getInstanceProperties().getProperty("instance.load.instrument.future","false");
		 if(strFurtureLoad!=null && "true".equalsIgnoreCase(strFurtureLoad)){
			 futureLoad = true;
		 }else {
			 futureLoad = false;
		 }
	}
	
	public InstrumentLoader(Das daoManagerDb, CacheDas cacheDas) {
		super(daoManagerDb, cacheDas);
	}

	public void doWork() throws Exception {
		InstrumentDao dbDao = (InstrumentDao) daoManagerDb
		        .getDao(Instrument.class);
		log.info("loading Instruments ....");
		List<Instrument> list = dbDao.getInstrumentList();
		write(list);
		if(futureLoad){
			list = dbDao.getFutInstrumentList();
			write(list);
		}
		log.info("done -- loading Instruments.");
	}
}
