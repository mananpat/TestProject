package com.ml.elt.s1.ps.plugins.cache.loaders;

import java.util.ArrayList;
import java.util.List;

import com.ml.elt.s1.entitlement.EntitlementHandler;
import com.ml.elt.s1.entitlement.core.das.iface.RamGroupPickerDao;
import com.ml.elt.s1.entitlement.core.das.iface.RamGroupUserDao;
import com.ml.elt.s1.entitlement.core.das.iface.RamUsersDao;
import com.ml.elt.s1.entitlement.core.sdo.RamGroupPicker;
import com.ml.elt.s1.entitlement.core.sdo.RamGroupUser;
import com.ml.elt.s1.entitlement.core.sdo.RamUsers;
import com.ml.elt.s1.platform.container.service.cache.CacheDas;
import com.ml.elt.s1.platform.plugins.das.Das;
import com.ml.elt.s1.profile.plugins.cache.Worker;

public class RamGroupsLoader extends Worker {

	private static final String none = "None";
	
	public RamGroupsLoader(Das daoManagerDb, CacheDas cacheDas) {
		super(daoManagerDb, cacheDas);
	}
	
	public void doWork() throws Exception {
		RamGroupUserDao dbDao = (RamGroupUserDao) daoManagerDb.getDao(RamGroupUser.class);
		log.info("loading RAM Groups...");
		List<RamGroupUser> list = dbDao.getAllRamGroups();
		
		// Adding admin group. The group is not present in database.
		RamGroupUser adminUser = new RamGroupUser();
		adminUser.setUserId(EntitlementHandler.ALL_RAM_ROLES);
		adminUser.setGroupId(EntitlementHandler.ENTITLEMENT_ADMIN);
		list.add(adminUser);
		write(list);
		log.info("done - loading RAM Groups and writing to cache.");

		log.info("loading RamUsers...");
		RamUsersDao ramUserDao = (RamUsersDao) daoManagerDb.getDao(RamUsers.class);
		List<RamUsers> allRamUsers = ramUserDao.getUserDataForAllUsers();
		write(allRamUsers);
		log.info("done - loading RamUsers and writing to cache.");		
		
		RamGroupPickerDao ramGroupDBDao = (RamGroupPickerDao) daoManagerDb.getDao(RamGroupPicker.class);
		log.info("loading Traders...");
		List<String> groupList= new ArrayList<String>();
		groupList.add("TRADERS");
		groupList.add("TRADER");
		List<RamGroupPicker> traderPicker = ramGroupDBDao.getPickerForGroup(groupList);
		for (RamGroupPicker ramGroupPicker : traderPicker)
			ramGroupPicker.setGroupId("TRADER");		
		write(traderPicker);
		log.info("done - loading Traders and writing to cache.");

		log.info("loading Marketers...");
		groupList= new ArrayList<String>();
		groupList.add("MARKETER");
		List<RamGroupPicker> marketerPicker = ramGroupDBDao.getPickerForGroup(groupList);
		for (RamGroupPicker ramGroupPicker : marketerPicker){
			ramGroupPicker.setGroupId("MARKETER");
		}

		//Add None to market Picker
		RamGroupPicker noneMarketer = new RamGroupPicker();
		noneMarketer.setUserId(none);
		noneMarketer.setDescription(none);
		noneMarketer.setGroupId("MARKETER");
		marketerPicker.add(noneMarketer);
		
		write(marketerPicker);
		log.info("done - loading Marketers and writing to cache.");
	}
	
}
