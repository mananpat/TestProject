package com.ml.elt.s1.ps.plugins.jmx;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import com.ml.elt.s1.core.sdo.Client;
import com.ml.elt.s1.platform.container.jmx.AbstractDynamicMBean;
import com.ml.elt.s1.platform.container.service.cache.CacheDas;
import com.ml.elt.s1.platform.plugins.boot.DefaultConfiguration;
import com.ml.elt.s1.ps.plugins.cache.CacheReloaderHelper;
import com.ml.elt.s1.sw.features.queryprofile.ClientDataLoader;

public class LoadClient extends AbstractDynamicMBean {
	protected CacheReloaderHelper helper;
	protected CacheDas cacheDas;
	protected ClientDataLoader clienData;
	
	public LoadClient() {
		cacheDas = (CacheDas)DefaultConfiguration.getBean("cacheDas");
		helper = new CacheReloaderHelper();
		helper.setCacheDas(cacheDas);
		clienData = new ClientDataLoader(cacheDas);
	}

	public List<String> loadClients(String clientShortNames) {
		List<String> list = new ArrayList<String>();
		StringTokenizer st = new StringTokenizer(clientShortNames, ",;:");
		while(st.hasMoreElements()){
			String clientShortName = (String)st.nextElement();
			Client client = helper.loadClient(clientShortName);
			if (client != null){
				list.add(client.toString());
			} else {
				list.add("Failed reload client by id:" + clientShortName );
			}
		}
		return list;
	}
	
	
	public List<String> reloadClientProfileDataMap(){
		List<String> list = new ArrayList<String>();
		try{
			if(clienData!=null){
				clienData.loadClientData();
				list.add("Done Client Data Load ");
			}
		}catch(Throwable t){
			list.add("Unable to load Client Data" + t.getMessage());
		}
		return list;
	}
}
