package com.ml.elt.s1.ps.platform;

public class ApplicationConstants {

	public static final String INSTANCE_MODE_TESTING = "instance.mode.testing";
}
