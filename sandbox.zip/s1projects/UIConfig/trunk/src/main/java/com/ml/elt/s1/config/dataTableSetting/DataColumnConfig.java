package com.ml.elt.s1.config.dataTableSetting;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAttribute;

public class DataColumnConfig implements Serializable {
		
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	private Integer id;

	
	private String name;

	
	private String dataSourceName;

	
	private String filterValue;

	
	private String desc;

	
	private Integer order;

	
	private String type = "System.String";

	
	private String title;

	
	private boolean readOnly;

	
	private boolean serializable = true;

	
	private Integer width;

	
	private String format;

	
	private String mask;

	
	private String hAlign = "Left";

	
	private String tooltip;

	
	private String tooltipColumn;

	
	private String tooltipFormat;
	
	
	private String pickerType;

	
	private boolean hidden;

	
	private boolean queriable = true;
	
	private String inquirable = "Yes";
	
	private boolean autoRefresh;
	
	
	private String displayMember;
	

	private String dependency;
	
	
	private boolean invalidValues;

	
	private String characterCasing = "Normal";
	
	@XmlAttribute
	public boolean isAutoRefresh() {
		return autoRefresh;
	}
	
	public void setAutoRefresh(boolean autoRefresh) {
		this.autoRefresh = autoRefresh;
	}
	
	@XmlAttribute(name="case")
	public String getCharacterCasing() {
		return characterCasing;
	}
	
	public void setCharacterCasing(String characterCasing) {
		this.characterCasing = characterCasing;
	}
	
	@XmlAttribute
	public String getDataSourceName() {
		return dataSourceName;
	}
	
	public void setDataSourceName(String dataSourceName) {
		this.dataSourceName = dataSourceName;
	}
	
	@XmlAttribute
	public String getDesc() {
		return desc;
	}
	
	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	@XmlAttribute
	public String getFilterValue() {
		return filterValue;
	}
	
	public void setFilterValue(String filterValue) {
		this.filterValue = filterValue;
	}
	
	@XmlAttribute
	public String getFormat() {
		return format;
	}
	
	public void setFormat(String format) {
		this.format = format;
	}
	
	@XmlAttribute
	public String getHAlign() {
		return hAlign;
	}
	
	public void setHAlign(String align) {
		hAlign = align;
	}
	
	@XmlAttribute
	public boolean isHidden() {
		return hidden;
	}
	
	public void setHidden(boolean hidden) {
		this.hidden = hidden;
	}
	
	@XmlAttribute
	public Integer getId() {
		return id;
	}
	
	public void setId(Integer id) {
		this.id = id;
	}
	
	@XmlAttribute
	public String getMask() {
		return mask;
	}
	
	public void setMask(String mask) {
		this.mask = mask;
	}
	
	@XmlAttribute
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	@XmlAttribute
	public Integer getOrder() {
		return order;
	}
	
	public void setOrder(Integer order) {
		this.order = order;
	}
	
	@XmlAttribute
	public String getPickerType() {
		return pickerType;
	}
	
	public void setPickerType(String pickerType) {
		this.pickerType = pickerType;
	}
	
	@XmlAttribute
	public boolean isQueriable() {
		return queriable;
	}
	
	public void setQueriable(boolean queriable) {
		this.queriable = queriable;
	}
	
	@XmlAttribute
	public String getInquirable() {
		return inquirable;
	}

	public void setInquirable(String inquirable) {
		this.inquirable = inquirable;
	}
	
	@XmlAttribute
	public boolean isReadOnly() {
		return readOnly;
	}
	
	public void setReadOnly(boolean readOnly) {
		this.readOnly = readOnly;
	}
	
	@XmlAttribute
	public boolean isSerializable() {
		return serializable;
	}
	
	public void setSerializable(boolean serializable) {
		this.serializable = serializable;
	}
	
	@XmlAttribute
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	@XmlAttribute
	public String getTooltip() {
		return tooltip;
	}
	
	public void setTooltip(String tooltip) {
		this.tooltip = tooltip;
	}
	
	@XmlAttribute
	public String getTooltipColumn() {
		return tooltipColumn;
	}
	
	public void setTooltipColumn(String tooltipColumn) {
		this.tooltipColumn = tooltipColumn;
	}
	
	@XmlAttribute
	public String getTooltipFormat() {
		return tooltipFormat;
	}
	
	public void setTooltipFormat(String tooltipFormat) {
		this.tooltipFormat = tooltipFormat;
	}
	
	@XmlAttribute
	public String getType() {
		return type;
	}
	
	public void setType(String type) {
		this.type = type;
	}
	
	@XmlAttribute
	public Integer getWidth() {
		return width;
	}
	
	public void setWidth(Integer width) {
		this.width = width;
	}

	public void setDependency(String dependency) {
		this.dependency = dependency;
	}
	
	@XmlAttribute
	public String getDependency() {
		return dependency;
	}

	@XmlAttribute
	public String getDisplayMember() {
		return displayMember;
	}

	public void setDisplayMember(String displayMember) {
		this.displayMember = displayMember;
	}
	
	@XmlAttribute
	public boolean isInvalidValues() {
		return invalidValues;
	}

	public void setInvalidValues(boolean invalidValues) {
		this.invalidValues = invalidValues;
	}
}
