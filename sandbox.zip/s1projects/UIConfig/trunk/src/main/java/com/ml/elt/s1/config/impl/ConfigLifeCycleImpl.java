package com.ml.elt.s1.config.impl;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ml.elt.s1.config.dataTableSetting.DataColumnConfig;
import com.ml.elt.s1.config.dataTableSetting.DataTableConfig;
import com.ml.elt.s1.config.intrface.ConfigLifeCycle;
import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.profile.core.das.cache.ProfileCommandQuery;
import com.ml.elt.s1.profile.core.sdo.Application;
import com.ml.elt.s1.profile.core.sdo.LookupProperties;
import com.ml.elt.s1.profile.core.sdo.Property;
import com.ml.elt.s1.profile.core.sdo.PropertyGroup;
import com.ml.elt.s1.profile.core.sdo.PropertyGroupMapping;
import com.ml.elt.s1.profile.core.sdo.util.PropertyGroupCodeUtil;
import com.ml.elt.s1.profile.exception.ProfileException;
import com.ml.elt.s1.profile.impl.ProfileIndex;
import com.ml.elt.s1.profile.impl.ProfileLoader;
import com.ml.elt.s1.profile.impl.ProfileProcessorImpl;
import com.ml.elt.s1.profile.intface.ProfileProcessor;


public class ConfigLifeCycleImpl implements ConfigLifeCycle {
	
	private static Log log = LogFactory.getLog(ConfigLifeCycleImpl.class);
	
	private ProfileProcessor profileProcessor;
	
	// Identifiers used for creating criteria values map used for lookup
	private static final String GRID_CONFIG = "GRID_CONFIG"; // application name as defined in database
	private static final String GRID_CONFIG_APP_NAME = "appName"; // property name defined in property table for application
	private static final String GRID_CONFIG_PROP_NAME = "propertyName"; // property name defined in property table 
	private static final String GRID_CONFIG_GROUP_NAME = "groupName"; // property name defined in property table
	
	private static final String TABLE_CONFIG = "TABLE_CONFIG";
	
	public ConfigLifeCycleImpl() {
		profileProcessor = new ProfileProcessorImpl();
	}

	public List<DataTableConfig> getConfigById(String appCode) {
		try
		{	
			ProfileIndex prfIndex = ProfileLoader.getInstance ().getProfileIndex();		
			if (prfIndex == null) {
				log.error("Profile Index doesn't exist.");
				return null;
			}
			
			Application application = prfIndex.getApplication(appCode);
			if (application == null) {
				log.warn(String.format("Application \"%1$s\" doesn't exist in ProfileIndex.", appCode));
				return null;
			}
			
			List<DataTableConfig> retList = new ArrayList<DataTableConfig>();
			DataTableConfig appConfig = this.getTableConfigForGroup(application, null);
			appConfig.setColumn(new ArrayList<DataColumnConfig> ());
			
			List<LookupProperties> listLookupProperties = ProfileCommandQuery.getLookupPropertiesOfApplication(application.getId());			
			if (listLookupProperties != null && !listLookupProperties.isEmpty()){
				for (LookupProperties lookup : listLookupProperties) {
					Property property = ProfileCommandQuery.getPropertyById(lookup.getPropertyId());
					DataColumnConfig config = this.getConfigForProperty(application,null, property);
					config.setOrder(Integer.valueOf(lookup.getLookupRank()));
					appConfig.getColumn().add(config);
				}
			}
			
			retList.add(appConfig);
			
			List<PropertyGroup> propertyGroupList = ProfileCommandQuery.getPropertyGroupsOfApplication(application.getId());
			if(propertyGroupList != null && !propertyGroupList.isEmpty()){
				for (PropertyGroup group : propertyGroupList) {
					DataTableConfig tableConfig = this.getTableConfigForGroup(application, group);
					List<DataColumnConfig> columnConfigs = new ArrayList<DataColumnConfig>();
					tableConfig.setColumn(columnConfigs);
					List<PropertyGroupMapping> pgmList = ProfileCommandQuery.getPropertyGroupMappingOfPropertyGroup(group.getId());
					if(pgmList == null || pgmList.isEmpty())
						continue;
					for (PropertyGroupMapping pgm : pgmList) {
						Property property = ProfileCommandQuery.getPropertyById(pgm.getPropertyId());				
						columnConfigs.add(this.getConfigForProperty(application, group, property));				
					}
					retList.add(tableConfig);					
				}
			}
			return retList;
		}
		catch(DASException de){
			log.error("Exception while retrieving Config.", de);			
		}		
		
		return null;
	}

	private DataColumnConfig getConfigForProperty (Application application, PropertyGroup group, Property property) {
		DataColumnConfig colConfig = new DataColumnConfig();
		colConfig.setName(property.getPropertyCode());
		colConfig.setTitle(property.getDescription());
		Map<String, Object> criteriaValues = new HashMap<String, Object>(2);
		criteriaValues.put(GRID_CONFIG_APP_NAME, application.getApplicationCode());
		criteriaValues.put(GRID_CONFIG_PROP_NAME, property.getPropertyCode());
		if(group!=null){
			criteriaValues.put(GRID_CONFIG_GROUP_NAME, group.getPropertyGroupCode());
		} else {
			String propertyGroupCode = PropertyGroupCodeUtil.getPropertyGroupCodeByPropertyId(application.getId(), property.getId());
			if (propertyGroupCode != null)
				criteriaValues.put(GRID_CONFIG_GROUP_NAME, propertyGroupCode);
		}
		
		setConfigValues(colConfig, criteriaValues, GRID_CONFIG);
		return colConfig;
	}
	
	private void setConfigValues (Object config, Map<String, Object> criteriaValues, String app) {
		Map<String, List<Object>> propValues = null;
		try {
			propValues = profileProcessor.getTargetValues(app, criteriaValues).propertyValues;
		} catch (ProfileException e) {
		
			log.error(e.getMessage());
		}

		if (propValues != null) {
			//using reflection to do it.. need to test it ..
			for (String key : propValues.keySet()) {
				try {
					if(PropertyUtils.getPropertyType(config, key) == null)
						continue;
					List<Object> val = propValues.get(key);
					if(val!= null && val.size() == 1 && val.get(0)!= null )
						BeanUtils.setProperty(config, key, val.get(0));
					
				} 
				catch (Exception e) {
					log.error ("Property not found:", e);
				}
			}
		}
	}
	
	private DataTableConfig getTableConfigForGroup (Application application, com.ml.elt.s1.profile.core.sdo.PropertyGroup propertyGroup) {
		DataTableConfig tableConfig = new DataTableConfig();
		if (propertyGroup != null) {
			tableConfig.setName(propertyGroup.getPropertyGroupCode());
			tableConfig.setDescription(propertyGroup.getDescription());
		}
		else {
			tableConfig.setName(application.getApplicationCode());
			tableConfig.setDescription(application.getDescription());
		}		
		
		Map<String, Object> criteriaValues = new HashMap<String, Object>(2);
		criteriaValues.put(GRID_CONFIG_APP_NAME, application.getApplicationCode());
		if (propertyGroup != null) 
			criteriaValues.put(GRID_CONFIG_GROUP_NAME, propertyGroup.getPropertyGroupCode());		
		setConfigValues(tableConfig, criteriaValues, TABLE_CONFIG);
		return tableConfig;
	}	
}
