package com.ml.elt.s1.config.intrface;

import java.util.List;

import com.ml.elt.s1.config.dataTableSetting.DataTableConfig;


/**
 * @author anagrawa
 * Provides create, retrieve, update and delete functionality for profile service
 */
public interface ConfigLifeCycle {
	
	/**
	 * @param applicationCode : Name of the application
	 * @param ruleId : defines id of rule
	 * @return : Map of propertycode and property value
	 * @throws ProfileException
	 */
	public List<DataTableConfig> getConfigById(String applicationCode);
}
