package com.ml.elt.s1.config.dataTableSetting;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;

public class DataTableConfig implements Serializable {
		
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String name;
	
	private String baseGrid;
	
	private String description;
	
	private boolean readOnly;
	
	private boolean headerVisible = true;
	
	private boolean sort = false;
	
	private boolean addNew;

	private List<DataColumnConfig> column;
	
	private String primaryKey;
	
	private String filterColumn;
	
	private String valueColumn;
	
	private String displayColumn;
	
	private String title = "";
	
	private String parent = "";
	
	private String parentKey;

	private String foreignKey;

	private String model;

	private String topic;

	private String selector;

	private String subject;

	private Boolean shared = false;

	private int order;

	
	@XmlAttribute
	public boolean isAddNew() {
		return addNew;
	}
	
	public void setAddNew(boolean addNew) {
		this.addNew = addNew;
	}
	
	@XmlAttribute
	public String getBaseGrid() {
		return baseGrid;
	}
	
	public void setBaseGrid(String baseGrid) {
		this.baseGrid = baseGrid;
	}
	
	public List<DataColumnConfig> getColumn() {
		return column;
	}
	
	public void setColumn(List<DataColumnConfig> column) {
		this.column = column;
	}
	
	@XmlAttribute
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	@XmlAttribute
	public String getDisplayColumn() {
		return displayColumn;
	}
	
	public void setDisplayColumn(String displayColumn) {
		this.displayColumn = displayColumn;
	}

	@XmlAttribute
	public String getFilterColumn() {
		return filterColumn;
	}
	
	public void setFilterColumn(String filterColumn) {
		this.filterColumn = filterColumn;
	}
	
	@XmlAttribute
	public boolean isHeaderVisible() {
		return headerVisible;
	}
	
	public void setHeaderVisible(boolean headerVisible) {
		this.headerVisible = headerVisible;
	}
	
	@XmlAttribute
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	@XmlAttribute
	public String getParent() {
		return parent;
	}
	
	public void setParent(String parent) {
		this.parent = parent;
	}
	
	@XmlAttribute
	public String getPrimaryKey() {
		return primaryKey;
	}
	
	public void setPrimaryKey(String primaryKey) {
		this.primaryKey = primaryKey;
	}

	@XmlAttribute
	public boolean isReadOnly() {
		return readOnly;
	}
	
	public void setReadOnly(boolean readOnly) {
		this.readOnly = readOnly;
	}
	
	@XmlAttribute
	public boolean isSort() {
		return sort;
	}
	
	public void setSort(boolean sort) {
		this.sort = sort;
	}
	
	@XmlAttribute
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	@XmlAttribute
	public String getValueColumn() {
		return valueColumn;
	}
	
	public void setValueColumn(String valueColumn) {
		this.valueColumn = valueColumn;
	}
	
	@XmlAttribute
	public String getForeignKey() {
		return foreignKey;
	}

	public void setForeignKey(String foreignKey) {
		this.foreignKey = foreignKey;
	}
	
	@XmlAttribute
	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}
	
	@XmlAttribute
	public String getParentKey() {
		return parentKey;
	}

	public void setParentKey(String parentKey) {
		this.parentKey = parentKey;
	}
	
	@XmlAttribute
	public String getSelector() {
		return selector;
	}

	public void setSelector(String selector) {
		this.selector = selector;
	}
	
	@XmlAttribute
	public Boolean getShared() {
		return shared;
	}

	public void setShared(Boolean shared) {
		this.shared = shared;
	}
	
	@XmlAttribute
	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}
	
	@XmlAttribute
	public String getTopic() {
		return topic;
	}

	public void setTopic(String topic) {
		this.topic = topic;
	}
	
	public void setOrder(int order) {
		this.order = order;
	}
	
	@XmlAttribute
	public int getOrder() {
		return order;
	}
}
