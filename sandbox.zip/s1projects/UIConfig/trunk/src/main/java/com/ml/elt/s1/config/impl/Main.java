package com.ml.elt.s1.config.impl;

import java.util.List;

import com.ml.elt.s1.config.dataTableSetting.DataColumnConfig;
import com.ml.elt.s1.config.dataTableSetting.DataTableConfig;


public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		ConfigLifeCycleImpl impl = new ConfigLifeCycleImpl ();
		List<DataTableConfig> config = impl.getConfigById("INSTRUMENT_CONFIG");
		
		for(DataTableConfig grid : config){
			System.out.println(grid.getName());
			List<DataColumnConfig> column =  grid.getColumn();
			for(DataColumnConfig col: column){
				System.out.println(col.getName());
				System.out.println(col.getPickerType());
			}
			
		}
		
	}

}
