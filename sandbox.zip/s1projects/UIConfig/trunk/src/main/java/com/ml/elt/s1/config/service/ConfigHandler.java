package com.ml.elt.s1.config.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ml.elt.s1.config.dataTableSetting.DataColumnConfig;
import com.ml.elt.s1.config.dataTableSetting.DataSetting;
import com.ml.elt.s1.config.dataTableSetting.DataTableConfig;
import com.ml.elt.s1.config.intrface.ConfigLifeCycle;
import com.ml.elt.s1.entitlement.EntitlementHandler;
import com.ml.elt.s1.entitlement.core.sdo.enums.Entitlement;
import com.ml.elt.s1.platform.container.ServiceContext;
import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.platform.container.exception.MessageException;
import com.ml.elt.s1.platform.container.service.MetaData;
import com.ml.elt.s1.platform.container.service.Request;
import com.ml.elt.s1.platform.container.service.Response;
import com.ml.elt.s1.platform.container.service.processor.MessageProcessor;
import com.ml.elt.s1.platform.plugins.connector.ems.OutputData;
import com.ml.elt.s1.profile.exception.ProfileException;


public class ConfigHandler implements MessageProcessor {
	private static Log log = LogFactory.getLog(ConfigHandler.class);

	private ConfigLifeCycle configLifeCycle ;
	private EntitlementHandler entitlementHandler;
	
	private Response resp;
	private ServiceContext context;
	
	@SuppressWarnings("unchecked")
	public Response process(Request request) {
		resp = new Response();
		Object[] array = request.getData();
		context = request.getServiceContext();
		String userId = (String) context.getMetaData().getData("userId");
		String command = (String)context.getMetaData().getData("command");
		String appCode = (String)context.getMetaData().getData("appCode");
		try {
			if (array != null) {
//			 1. receiving config request message 
				log.info("Processing GUI CONFIG SERVICE ");
				if (command.equalsIgnoreCase("getConfig")) {
					DataSetting settings = new DataSetting ();
					List<DataTableConfig> dataTableConfig = configLifeCycle.getConfigById(appCode);
					applyEntitlements(userId, appCode, dataTableConfig);
					settings.setDataTable(dataTableConfig);
					resp.addOutput(settings);
					publishEof(context, resp);
				}
			}
		}
		catch (Exception e) {
			log.error(e);
			handleDefaultException(array, e);
		}
		return resp;
	}
	
	private void applyEntitlements(String userId, String appCode, List<DataTableConfig> tableConfigList) throws ProfileException, DASException {
		log.info("Retreiving Entitlements for User Id : "+userId+" Application : "+appCode);
		if (tableConfigList == null  || tableConfigList.isEmpty() ) return;
		boolean firstLoop = true;
		for (DataTableConfig currConfig : tableConfigList) {
			String tableName = currConfig.getName();
			log.debug("Processing Table :"+ tableName);
			List<DataColumnConfig> colConfigList = currConfig.getColumn();
			if (colConfigList == null || colConfigList.isEmpty()) continue;
			for (DataColumnConfig colConfig : colConfigList){
				if (colConfig != null ) {
					String field = colConfig.getName();
					if (field == null) continue;
				   /*
					* In First loop if user roles are not present in cache. Query them from database.
					* In subsequent calls do no query database, even if they are not present in cache.
					*/
					Entitlement fieldEntitlement = entitlementHandler.getFieldEntitlement(userId, appCode,tableName,field,firstLoop); 
					if (firstLoop) firstLoop=false;
					if (log.isDebugEnabled()) 
						log.debug("Field : "+ field +" Entitlement : " +fieldEntitlement);
					if ( fieldEntitlement == Entitlement.WRITE && (! colConfig.isReadOnly() )) 
						colConfig.setReadOnly(false);
					else 
						colConfig.setReadOnly(true);
				}
			}
		}
	}
	
	@SuppressWarnings("unchecked")
	private void publishEof(ServiceContext context, Response resp) {
		OutputData eofData = new OutputData();
		eofData.setData(new DataSetting ());
		MetaData metadata = new MetaData();
		Map map = new HashMap(context.getMetaData().getMap());
		map.put("type", "eof");
		metadata.setMap(map);
		eofData.setMetaData(metadata);
		resp.addOutput(eofData);	
	}
		
	private void handleDefaultException(Object[] array, Throwable e) {
		resp.addException(new MessageException(array, new Exception(e)));
		context.getMetaData().setData("type", "???????");
	}

	public ConfigLifeCycle getConfigLifeCycle() {
		return configLifeCycle;
	}

	public void setConfigLifeCycle(ConfigLifeCycle config) {
		this.configLifeCycle = config;
	}

	public EntitlementHandler getEntitlementHandler() {
    	return entitlementHandler;
    }

	public void setEntitlementHandler(EntitlementHandler entitlementHandler) {
    	this.entitlementHandler = entitlementHandler;
    }
	
}
