package com.ml.elt.s1.config.dataTableSetting;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement
public class DataSetting {
	private List<DataTableConfig> dataTable;

	public void setDataTable(List<DataTableConfig> grid) {
		this.dataTable = grid;
	}

	public List<DataTableConfig> getDataTable() {
		return dataTable;
	}
}
