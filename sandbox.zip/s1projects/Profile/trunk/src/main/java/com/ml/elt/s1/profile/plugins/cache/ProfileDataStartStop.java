package com.ml.elt.s1.profile.plugins.cache;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.platform.container.exception.ExceptionHandler;
import com.ml.elt.s1.platform.container.service.boot.Startstop;
import com.ml.elt.s1.platform.container.service.cache.CacheDas;
import com.ml.elt.s1.platform.plugins.das.Das;
import com.ml.elt.s1.platform.plugins.das.RamDas;
import com.ml.elt.s1.profile.core.sdo.Application;
import com.ml.elt.s1.profile.core.sdo.ClientEmailAuditProperty;
import com.ml.elt.s1.profile.core.sdo.Contact;
import com.ml.elt.s1.profile.core.sdo.GiveupBrokerCodes;
import com.ml.elt.s1.profile.core.sdo.PriceTolerances;
import com.ml.elt.s1.profile.core.sdo.LookupProperties;
import com.ml.elt.s1.profile.core.sdo.MarketCharges;
import com.ml.elt.s1.profile.core.sdo.PickerBean;
import com.ml.elt.s1.profile.core.sdo.Property;
import com.ml.elt.s1.profile.core.sdo.PropertyGroup;
import com.ml.elt.s1.profile.core.sdo.PropertyGroupMapping;
import com.ml.elt.s1.profile.core.sdo.Rule;
import com.ml.elt.s1.profile.core.sdo.RuleProperty;
import com.ml.elt.s1.profile.core.sdo.StaticData;
import com.ml.elt.s1.profile.impl.ProfileLoader;
import com.ml.elt.s1.profile.plugins.cache.loaders.ApplicationLoader;
import com.ml.elt.s1.profile.plugins.cache.loaders.ClientEmailAuditPropertyLoader;
import com.ml.elt.s1.profile.plugins.cache.loaders.ContactLoader;
import com.ml.elt.s1.profile.plugins.cache.loaders.GiveupBrokerCodesLoader;
import com.ml.elt.s1.profile.plugins.cache.loaders.PriceToleranceLoader;
import com.ml.elt.s1.profile.plugins.cache.loaders.LookupPropertyLoader;
import com.ml.elt.s1.profile.plugins.cache.loaders.MarketChargesLoader;
import com.ml.elt.s1.profile.plugins.cache.loaders.PickerBeanLoader;
import com.ml.elt.s1.profile.plugins.cache.loaders.PropertyGroupLoader;
import com.ml.elt.s1.profile.plugins.cache.loaders.PropertyGroupMappingLoader;
import com.ml.elt.s1.profile.plugins.cache.loaders.PropertyLoader;
import com.ml.elt.s1.profile.plugins.cache.loaders.RuleLoader;
import com.ml.elt.s1.profile.plugins.cache.loaders.RulePropertyLoader;
import com.ml.elt.s1.profile.plugins.cache.loaders.StaticDataLoader;
import com.ml.elt.s1.sw.plugins.exception.FatalPlatformException;

/**
 * @author mpatel12
 *
 * Profile Data Start Stop
 * 
 */
public class ProfileDataStartStop implements Startstop {
	
	private static Log log = LogFactory.getLog(ProfileDataStartStop.class);

	ThreadGroup group = new ThreadGroup("Profile Data loader:" + System.currentTimeMillis());
	public Long lock = 0L;
	
	public final static String CACHE_CONFIGURATION_ERROR = "Cache server is not configured.";
	
	private Das daoManagerDb;
	private CacheDas cacheDas;
	
	private List<Long> appIds = new ArrayList<Long>();
	
	public ProfileDataStartStop() {
		daoManagerDb = new RamDas();
	}
	
	
	public boolean startup(CacheDas cacheDas) {		
		log.debug("Inside startup in ProfileDataStartStop.");
		this.cacheDas = cacheDas;		
		if (cacheDas == null) 
			throw new FatalPlatformException(CACHE_CONFIGURATION_ERROR);
		
		loadContact();
		loadLookupProperties();
		loadProperties();
		loadPropertyGroups();
		loadPropertyGroupMappings();
		
		loadApplications();
		loadRules();
		loadRuleProperties();
		loadMarketCharges();		
		loadGiveupBrokerCodes();
		loadStaticData();
		loadPickerBean();
		loadPriceTolerances();
		loadClientEmailAuditProperty();
		
		
		while( lock > 0) {
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				ExceptionHandler.getInstance().handleFatalException("Failed in cache initial loader.", e);
			}
		}
		
		try
		{
			ProfileLoader profileLoader = ProfileLoader.getInstance();
			profileLoader.reloadProfile();
		}
		catch(Throwable t){
			throw new FatalPlatformException("Exceptions in reloadProfile in ProfileDataStartStop.");
		}
		
		log.debug("Done loading cache data. End of startup in ProfileDataStartStop.");
		return true;		
	}	
	
	public boolean restart() {
		return shutdown() && startup(this.cacheDas);
	}

	public boolean shutdown() {
		try {
			CacheDas localCacheDas = cacheDas.newInstance(null, null);
			localCacheDas.remove(Application.class);
			localCacheDas.remove(LookupProperties.class);
			localCacheDas.remove(Property.class);
			localCacheDas.remove(Rule.class);
			localCacheDas.remove(RuleProperty.class);
			localCacheDas.remove(PropertyGroup.class);
			localCacheDas.remove(PropertyGroupMapping.class);
			localCacheDas.remove(Contact.class);
			localCacheDas.remove(StaticData.class);
			localCacheDas.remove(MarketCharges.class);
			localCacheDas.remove(GiveupBrokerCodes.class);
			localCacheDas.remove(PickerBean.class);
			localCacheDas.remove(PriceTolerances.class);
			localCacheDas.remove(ClientEmailAuditProperty.class);
		}	
		catch(DASException e) {
			log.error("Exceptions in shutdown in ProfileDataStartStop.", e);
			return false;
		}
		return true;
	}

		
	public void createIndexes() {		
	}
		
	private void execute(Worker worker) {
		execute(worker, true);
	}
	
	private void execute(Worker worker, boolean isNoJoin) {
		try {
			worker.setCounter(lock);
			Thread thread = new Thread(group, worker);
			thread.start();		
			if (!isNoJoin) thread.join();
		} catch (InterruptedException e) {
			log.error(e);
		}
	}

	/*
	 *  All Loaders
	 */
	
	public void loadApplications() {
		execute(new ApplicationLoader(daoManagerDb, cacheDas,appIds), false);
	}
		
	public void loadLookupProperties() {
		execute(new LookupPropertyLoader(daoManagerDb, cacheDas), false);
	}
	
	public void loadRules() {
		execute(new RuleLoader(daoManagerDb, cacheDas,appIds),false);
	}
	
	public void loadRuleProperties() {
		execute(new RulePropertyLoader(daoManagerDb, cacheDas,appIds),false);
	}
	
	public void loadMarketCharges() {
		execute(new MarketChargesLoader(daoManagerDb, cacheDas));
	}
	
	public void loadGiveupBrokerCodes() {
		execute(new GiveupBrokerCodesLoader(daoManagerDb, cacheDas));
	}
	
	public void loadPriceTolerances() {
		execute(new PriceToleranceLoader(daoManagerDb, cacheDas));
	}
	public void loadProperties() {
		execute(new PropertyLoader(daoManagerDb, cacheDas));
	}
	
	public void loadPropertyGroups() {
		execute(new PropertyGroupLoader(daoManagerDb, cacheDas));
	}
	
	public void loadPropertyGroupMappings() {
		execute(new PropertyGroupMappingLoader(daoManagerDb, cacheDas));
	}
	
	public void loadStaticData() {
		execute(new StaticDataLoader(daoManagerDb, cacheDas),false);
	}
	
	public void loadPickerBean()
	{
		execute(new PickerBeanLoader(daoManagerDb, cacheDas)); 
	}
	
	public void loadContact() {
		execute(new ContactLoader(daoManagerDb, cacheDas));
	}
	
	public void loadClientEmailAuditProperty() {
		log.info("Loading Client Email Audit");
		execute(new ClientEmailAuditPropertyLoader(daoManagerDb, cacheDas));
	}
}
