package com.ml.elt.s1.profile.transfer.gui;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAttribute;

public class PropertyBean implements Serializable {
	private static final long serialVersionUID = 2L;
	
	private Long ruleId;
	private String propertyCode;
	private String group;
	private String property;
	private String value;
	
    public PropertyBean() {
    }

    public PropertyBean(Long ruleId, String propertyCode, String propertyValue, String propertyDescription, String propertyCodeCode) {
    	this.ruleId = ruleId;
    	this.propertyCode = propertyCode;
    	this.value = propertyValue;
    	this.group = propertyCodeCode; 
    	this.property = propertyDescription;
    }
    
    public String toString(){
    	StringBuffer sf = new StringBuffer();
    	sf.append("[PropertyBean: RuleId: " + ruleId + " Property Code: " + propertyCode + " Description: " + property + " Value "+ value + "]");
    	return sf.toString();
    }

	/**
	 * @return the ruleId
	 */
    
    @XmlAttribute
	public Long getRuleId() {
		return ruleId;
	}

	/**
	 * @param ruleId the ruleId to set
	 */
	public void setRuleId(Long ruleId) {
		this.ruleId = ruleId;
	}

	/**
	 * @return the propertyCode
	 */
	@XmlAttribute
	public String getPropertyCode() {
		return propertyCode;
	}

	/**
	 * @param propertyCode the propertyCode to set
	 */
	public void setPropertyCode(String propertyCode) {
		this.propertyCode = propertyCode;
	}

	/**
	 * @return the group
	 */
	@XmlAttribute
	public String getGroup() {
		return group;
	}

	/**
	 * @param group the group to set
	 */
	public void setGroup(String group) {
		this.group = group;
	}

	/**
	 * @return the property
	 */
	@XmlAttribute
	public String getProperty() {
		return property;
	}

	/**
	 * @param property the property to set
	 */
	public void setProperty(String property) {
		this.property = property;
	}

	/**
	 * @return the value
	 */	
	public String getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}
}
