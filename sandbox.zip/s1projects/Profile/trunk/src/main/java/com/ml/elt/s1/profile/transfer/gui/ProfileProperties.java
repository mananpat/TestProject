package com.ml.elt.s1.profile.transfer.gui;

import java.io.Serializable;

public class ProfileProperties implements Serializable {
	private static final long serialVersionUID = 2L;
	
	private String group;
	private String property;
	private String desc;
	private String pickerType;
	private String type;
	public void setGroup(String group) {
		this.group = group;
	}
	public String getGroup() {
		return group;
	}
	public void setProperty(String property) {
		this.property = property;
	}
	public String getProperty() {
		return property;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String getDesc() {
		return desc;
	}
	public void setPickerType(String pickerType) {
		this.pickerType = pickerType;
	}
	public String getPickerType() {
		return pickerType;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getType() {
		return type;
	}
	
}