/**
 * 
 */
package com.ml.elt.s1.profile.core.das.iface;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.platform.container.service.das.Dao;
import com.ml.elt.s1.profile.core.sdo.Contact;

/**
 * @author mpatel12
 *
 */
public interface ContactDao extends Dao {
	
	/**
	 * returns Contact List
	 * @return Contact
	 * @throws DataAccessException
	 */
	public List<Contact> getAllContacts() throws DASException; 
	
	/**
	 * returns Contact
	 * @return Contact
	 * @throws DataAccessException
	 */
	public Contact getContactById(Long id) throws DASException;
	
	/**
	 * save Contact
	 * @return Contact
	 * @throws DataAccessException
	 */
	public boolean saveContact(Contact contact) throws DASException;
	
	/**
	 * update Contact
	 * @return Contact
	 * @throws DataAccessException
	 */
	//public void updateContact(Contact contact) throws DASException;
	
}
