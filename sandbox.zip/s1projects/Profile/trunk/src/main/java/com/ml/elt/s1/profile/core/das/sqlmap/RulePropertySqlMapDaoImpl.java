package com.ml.elt.s1.profile.core.das.sqlmap;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.orm.ibatis.SqlMapClientTemplate;

import com.ibatis.sqlmap.client.SqlMapClient;
import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.profile.core.das.iface.RulePropertyDao;
import com.ml.elt.s1.profile.core.sdo.RuleProperty;

public class RulePropertySqlMapDaoImpl extends SqlMapClientTemplate implements RulePropertyDao {

	private DataSourceTransactionManager dsTxManager =null;
	
	public DataSourceTransactionManager getDsTxManager() {
		return dsTxManager;
	}

	public void setDsTxManager(DataSourceTransactionManager dsTxManager) {
		this.dsTxManager = dsTxManager;
	}

	@SuppressWarnings("unchecked")
	public List<RuleProperty> getAllRuleProperties() throws DASException {
		try {
			return (List<RuleProperty>)queryForList("getAllRuleProperties");
		}catch(DataAccessException daEx){
			throw new DASException(daEx);
		}
	}
	
	@SuppressWarnings("unchecked")
	public List<RuleProperty> getAllRulePropertiesByApp(List<Long> appIds) throws DASException {
		List<RuleProperty> rulePropList = null;
		try {
			if(appIds !=null && !appIds.isEmpty()){
				rulePropList = (List<RuleProperty>)queryForList("getAllRulePropertiesByApp",appIds);
			}
		}catch(DataAccessException daEx){
			throw new DASException(daEx);
		}
		return rulePropList;		
	}
	
	public RuleProperty getRuleProperty(Long rulePropertyId) throws DASException {
		try {
			return (RuleProperty)queryForObject("getRuleProperty",rulePropertyId);
		}catch(DataAccessException daEx){
			throw new DASException(daEx);
		}
	}

	@SuppressWarnings("unchecked")
	public List<RuleProperty> getRulePropertyList(List<Long> rulePropertyIds)
			throws DASException {
		List<RuleProperty> rulePropList = null;
		try {
			if(rulePropertyIds!=null && !rulePropertyIds.isEmpty()){
				rulePropList = (List<RuleProperty>)queryForList("getRulePropertyList",rulePropertyIds);
			}
		}catch(DataAccessException daEx){
			throw new DASException(daEx);
		}
		return rulePropList;
	}

	@SuppressWarnings("unchecked")
	public List<RuleProperty> getRulePropertyListForRuleId(Long ruleId)
			throws DASException {
		List<RuleProperty> rulePropList = null;
		try {
			if(ruleId!=null){
				rulePropList = (List<RuleProperty>)queryForList("getRulePropertyListForRuleId",ruleId);
			}
		}catch(DataAccessException daEx){
			throw new DASException(daEx);
		}
		return rulePropList;
	}
	
	@SuppressWarnings("unchecked")
	public Map<Long, RuleProperty> getRulePropertyMap(List<Long> rulePropertyIds)
			throws DASException {
		Map<Long, RuleProperty> rulePropMap = null;
		try {
			if(rulePropertyIds!=null && !rulePropertyIds.isEmpty()){
				rulePropMap = (Map<Long, RuleProperty>)queryForMap("getRulePropertyList",rulePropertyIds,"id");
			}
		}catch(DataAccessException daEx){
			throw new DASException(daEx);
		}
		return rulePropMap;
	}

	@SuppressWarnings("unchecked")
	public Map<Long, RuleProperty> getRulePropertyMapForRuleId(Long ruleId)
			throws DASException {
		Map<Long, RuleProperty> rulePropMap = null;
		try {
			if(ruleId!=null){
				rulePropMap = (Map<Long, RuleProperty>)queryForMap("getRulePropertyListForRuleId",ruleId,"id");
			}
		}catch(DataAccessException daEx){
			throw new DASException(daEx);
		}
		return rulePropMap;
	}

	@SuppressWarnings("unchecked")
	public List<RuleProperty> getRulePropertyListForRuleIds(List<Long> ruleIds)
			throws DASException {
		List<RuleProperty> rulePropList = null;
		try {
			if(ruleIds!=null && !ruleIds.isEmpty()){
				rulePropList = (List<RuleProperty>)queryForList("getRulePropertyListForRuleIds",ruleIds);
			}
		}catch(DataAccessException daEx){
			throw new DASException(daEx);
		}
		return rulePropList;
	}

	
	@SuppressWarnings("unchecked")
	public Map<Long, RuleProperty> getRulePropertyMapForRuleIds(List<Long> ruleIds) throws DASException {
		Map<Long, RuleProperty> rulePropMap = null;
		try {
			if(ruleIds!=null && !ruleIds.isEmpty()){
				rulePropMap = (Map<Long, RuleProperty>)queryForMap("getRulePropertyListForRuleIds",ruleIds,"id");
			}
		}catch(DataAccessException daEx){
			throw new DASException(daEx);
		}
		return rulePropMap;
	}

	public boolean updateRuleProperty(RuleProperty ruleProperty) throws DASException {
		boolean bret= false;
		SqlMapClient sqlMap = getSqlMapClient();
		try {
			sqlMap.startTransaction();
			update("updateRuleProperty", ruleProperty);
		}catch(DataAccessException daEx){
			throw new DASException(daEx);
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				sqlMap.endTransaction();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return bret;
	}

	public boolean deleteRuleProperty(RuleProperty ruleProperty) throws DASException {
		boolean bret= false;
		try {
			delete("deleteRuleProperty", ruleProperty);
		}catch(DataAccessException daEx){
			throw new DASException(daEx);
		}

		return bret;
	}


	public RuleProperty insertRuleProperty(RuleProperty ruleProperty) throws DASException {
		try {
			Object obj = insert("insertRuleProperty", ruleProperty);
			if(obj!=null){
				ruleProperty.setId((Long)obj);
			}
		}catch(DataAccessException daEx){
			throw new DASException(daEx);
		}
		return ruleProperty;
	}
}

