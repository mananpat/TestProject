package com.ml.elt.s1.profile.intface;

import com.ml.elt.s1.profile.exception.ProfileException;

public interface DataTypeConverter {
	
	public Object convert(Object propValue, String type) throws ProfileException;
	
	public String getDisplayString (Object propValue, String type);	

	public Boolean isAList (String propCode);
	

}
