package com.ml.elt.s1.profile.transfer.gui;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ContactBean implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private Long id;
	
	private String firstName;
	
	private String lastName;
	
	private String middleName;
	
	private String email;
	
	private String company;
	
	private String role;
	
	private String recipientType;
	
	private String updateUser;
	
	private List<ErrorBean> errors;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getRecipientType() {
		return recipientType;
	}

	public void setRecipientType(String recipientType) {
		this.recipientType = recipientType;
	}
	
	
	public Object getCacheKey(){
		return id;	
	}
	
	public static Object getCacheKey(Long id) {
		return id == null ? null : id;
	}
	
	/**
	 * @return the updateUser
	 */
	public String getUpdateUser() {
		return updateUser;
	}

	/**
	 * @param updateUser the updateUser to set
	 */
	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}
	
	public List<ErrorBean> getErrors() {
		return errors;
	}

	public void setErrors(List<ErrorBean> errors) {
		this.errors = errors;
	}
	
	public void addErrors(ErrorBean o) {
		if(errors == null) errors = new ArrayList<ErrorBean>(0);
		errors.add(o);
	}
	
	public void addAllErrors(List<ErrorBean> list) {
		if(errors == null) errors = new ArrayList<ErrorBean>(0);
		errors.addAll(list);
	}

	
	public String toString(){
		StringBuffer strBld = new StringBuffer();
		strBld.append("\t id:"+id);
		strBld.append("\t firstName"+firstName);
		strBld.append("\t middleName:"+middleName);
		strBld.append("\t lastName:"+lastName);
		strBld.append("\t email:"+email);
		strBld.append("\t company:"+company);
		strBld.append("\t role:"+role);
		strBld.append("\t recipientType:"+recipientType);
		return strBld.toString(); 
	}
	
}
