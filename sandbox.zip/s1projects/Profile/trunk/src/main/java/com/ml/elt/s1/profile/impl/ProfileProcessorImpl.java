/**
 * 
 */
package com.ml.elt.s1.profile.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ml.elt.s1.platform.container.Component;
import com.ml.elt.s1.platform.plugins.boot.DefaultConfiguration;
import com.ml.elt.s1.profile.core.das.cache.ProfileCommandQuery;
import com.ml.elt.s1.profile.core.sdo.Application;
import com.ml.elt.s1.profile.core.sdo.LookupProperties;
import com.ml.elt.s1.profile.core.sdo.Property;
import com.ml.elt.s1.profile.core.sdo.PropertyGroup;
import com.ml.elt.s1.profile.core.sdo.PropertyGroupMapping;
import com.ml.elt.s1.profile.exception.ProfileException;
import com.ml.elt.s1.profile.intface.IHierarchyLoader;
import com.ml.elt.s1.profile.intface.ProfileProcessor;


public class ProfileProcessorImpl extends Component implements ProfileProcessor {

	private static Log log = LogFactory.getLog(ProfileProcessorImpl.class);
	private static ProfilePropertiesMananger profilePropertiesMananger = null;
	
	static {
    	try 
    	{
    		Object obj = DefaultConfiguration.getBean("profilePropertiesMananger");
	    	if(profilePropertiesMananger == null){
		    	if(obj != null)
		    		profilePropertiesMananger = (ProfilePropertiesMananger) obj;    	
		    	else
		    		log.error("Profile Properties Manager Configuration is missing");	    	
	    	}
    	} catch(Throwable t) {
    		log.error("Error while loading bean from configuration", t);
    	}  
	}
	
	public ProfileProcessorImpl() {		
	}
	
	public void reloadProfile (boolean initializing) throws ProfileException {
		ProfileLoader.getInstance().reloadProfile();
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ml.elt.s1.profile.ProfileProcessor#getCriteriaProperties(java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public List<String> getCriteriaProperties(String criteriaCategoryCode)throws ProfileException {
		log.debug("getCriteriaProperties()");
		if (ProfileLoader.getInstance().getProfileIndex() == null) throw new ProfileException("profile data not loaded");
		Map<String, Application> critCategMap = ProfileLoader.getInstance().getProfileIndex().getApplicationMap();
		if (critCategMap.containsKey(criteriaCategoryCode)) {
			try {
				Application app = critCategMap.get(criteriaCategoryCode);
				List<LookupProperties> critPropList = ProfileCommandQuery.getLookupPropertiesOfApplication(app.getId());
				List<String> res = new ArrayList<String>(critPropList.size());
				for (LookupProperties cp : critPropList) {
					res.add(ProfileCommandQuery.getPropertyById(cp.getPropertyId()).getPropertyCode());
				}
				return res;
			}
			catch(Throwable t) {
				throw new ProfileException(t);
			}
		}
		throw new ProfileException(String.format("Criteria Category Code \"%1$s\" not found",criteriaCategoryCode));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ml.elt.s1.profile.ProfileProcessor#getTargetProperties(java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public Map<String, Boolean> getTargetProperties(String criteriaCategoryCode)throws ProfileException {
		log.debug("getTargetProperties()");
		if (ProfileLoader.getInstance().getProfileIndex() == null)
			throw new ProfileException("profile data not loaded");
		Map<String, Application> critCategMap = ProfileLoader.getInstance().getProfileIndex().getApplicationMap();
		if (critCategMap.containsKey(criteriaCategoryCode)) {
			try {
				Application app = critCategMap.get(criteriaCategoryCode);
				List<PropertyGroup> targPropList = ProfileCommandQuery.getPropertyGroupsOfApplication(app.getId()); 
				Map<String, Boolean> res = new HashMap<String, Boolean>(targPropList.size());
				for (PropertyGroup cp : targPropList) {
					List<PropertyGroupMapping> groupMap = ProfileCommandQuery.getPropertyGroupMappingOfPropertyGroup(cp.getParentGroupId()); 
					for (PropertyGroupMapping pgm : groupMap) {
						Boolean required = false;
						if (pgm.getRequiredFlag() == "Y")
							required = true;
						res.put(ProfileCommandQuery.getPropertyById(pgm.getPropertyId()).getPropertyCode(), required);
					}
				}
				return res;
			}
			catch(Throwable t) {
				throw new ProfileException(t);
			}
		}
		throw new ProfileException(String.format("Criteria Category Code \"%1$s\" not found",criteriaCategoryCode));
	}
	
	public Map<String, String> getPropertyDataTypes () throws ProfileException {
		Map<String, String> retValues = new HashMap<String, String> ();
		Map<String, Property> propMap = getPropertyMap();
		if (propMap == null)
			return null;
		for (Property prop : propMap.values()) {
			retValues.put(prop.getPropertyCode(), prop.getDataType());
		}
		return retValues;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ml.elt.s1.profile.ProfileProcessor#getTargetValues(java.lang.String,
	 *      java.util.Map)
	 */
	public LookupResultSet getTargetValues(String criteriaCategoryCode, Map<String, Object> criteriaValues)throws ProfileException {
		log.debug("getTargetValues()");
		if (ProfileLoader.getInstance().getProfileIndex() == null) throw new ProfileException("profile data not loaded");
		LookupIndex critNdx = ProfileLoader.getInstance().getProfileIndex().getLookupIndex(criteriaCategoryCode);
		if (critNdx != null) {
			LookupResultSet context = new LookupResultSet();

			IHierarchyLoader hierarchy = profilePropertiesMananger.getApplicationHierarchyLoader(criteriaCategoryCode);
			
			context.lookupValues = criteriaValues;
			context.propertyTypesMap = ProfileLoader.getInstance().getProfileIndex().getPropertyTypeMaps();

			if(hierarchy != null){
				hierarchy.helpSearch(critNdx,context);
			} else { 
				critNdx.search(context,true);
			}
			return context; 
		}
		throw new ProfileException(String.format("Criteria Category Code \"%1$s\" not found",criteriaCategoryCode));
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ml.elt.s1.profile.intface.ProfileProcessor#getTargetListValues(java.lang.String,
	 *      java.util.Map)
	 */
	@SuppressWarnings("unchecked")
	public LookupResultSet getTargetConvertedValues(String criteriaCategoryCode, Map<String, Object> criteriaValues)throws ProfileException {
		return getTargetValues(criteriaCategoryCode, criteriaValues);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ml.elt.s1.profile.ProfileProcessor#getProperties()
	 */
	private Map<String, Property> getPropertyMap() throws ProfileException {
		log.debug("getPropertyMap()");
		if (ProfileLoader.getInstance().getProfileIndex() == null)
			throw new ProfileException("profile data not loaded");
		return ProfileLoader.getInstance().getProfileIndex().getPropertyMap();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ml.elt.s1.profile.intface.ProfileProcessor#getPropertyDataTypeMap()
	 */
	public Map<String, String> getPropertyDataTypeMap() throws ProfileException {
		Map<String, Property> propMap = getPropertyMap();
		if (propMap == null)
			return null;
		Map<String, String> propDataTypeMap = new HashMap<String, String>();
		for (String key : propMap.keySet()) {
			Property property = propMap.get(key);
			if (property != null) {
				propDataTypeMap.put(key, property.getDataType());
			}
		}
		return propDataTypeMap;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ml.elt.s1.profile.intface.ProfileProcessor#setObjectAttributes(java.lang.Object,
	 *      java.util.List)
	 */
	public void setObjectAttributes(Object anObject, List<String> errStrings)
			throws ProfileException {

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ml.elt.s1.profile.intface.ProfileProcessor#setObjectAttributes(java.lang.Object,
	 *      java.util.Map, java.util.List)
	 */
	public void setObjectAttributes(Object anObject, String appCode,Map<String, Object> critPropValues, List<String> errStrings)throws ProfileException {
		if (critPropValues == null || critPropValues.size() == 0)
			throw new ProfileException("Criteria Properties can't be null");
		Map<String, List<Object>> profileValues = getTargetValues(appCode, critPropValues).propertyValues;
		if (profileValues == null || profileValues.size() == 0)
			throw new ProfileException("Retrieved profile values can't be null");

		for (String key : profileValues.keySet()) {
			try {
				if(PropertyUtils.getPropertyType(anObject,key) == null){
					log.info("Can't find any field matching " + key + " in bean "+anObject.getClass().getName());
					continue;
				}
				List<Object> val = profileValues.get(key);
				if(val.size() == 1)
					PropertyUtils.setProperty(anObject, key, val.get(0));
				else
					PropertyUtils.setProperty(anObject, key, val);
			} 
			catch (Exception e) {
				log.error(null, e);
				
			}
		}
	}
	
}
