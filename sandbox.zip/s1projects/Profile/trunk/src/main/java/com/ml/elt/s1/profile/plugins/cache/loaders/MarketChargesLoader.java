/**
 * 
 */
package com.ml.elt.s1.profile.plugins.cache.loaders;

import java.util.List;

import com.ml.elt.s1.platform.container.service.cache.CacheDas;
import com.ml.elt.s1.platform.plugins.das.Das;
import com.ml.elt.s1.profile.core.das.util.DBDataLoader;
import com.ml.elt.s1.profile.core.sdo.MarketCharges;
import com.ml.elt.s1.profile.plugins.cache.Worker;


/**
 * @author mpatel12
 *
 */
public class MarketChargesLoader extends Worker {

	
	public MarketChargesLoader(Das daoManagerDb, CacheDas cacheDas) {	
		super(daoManagerDb, cacheDas);
	}
	
	public void doWork() throws Exception {
		List<MarketCharges> list = DBDataLoader.loadMarketCharges(false);
		if(list != null && !list.isEmpty()){
			write(list);
		}
	}

}
