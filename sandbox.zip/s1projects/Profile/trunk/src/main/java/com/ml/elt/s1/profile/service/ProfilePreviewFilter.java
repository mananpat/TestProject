package com.ml.elt.s1.profile.service;

import java.util.HashMap;
import java.util.Map;

import com.ml.elt.s1.platform.container.ServiceContext;
import com.ml.elt.s1.platform.container.service.MetaData;
import com.ml.elt.s1.platform.container.service.Request;
import com.ml.elt.s1.platform.container.service.Response;
import com.ml.elt.s1.platform.container.service.processor.MessageProcessor;
import com.ml.elt.s1.platform.plugins.connector.ems.OutputData;
import com.ml.elt.s1.profile.transfer.gui.ProfileDataList;
import com.ml.elt.s1.profile.util.ProfileOperation;

public class ProfilePreviewFilter implements MessageProcessor {

	public Response process(Request req) {
		Response res = new Response();
		
		if (req != null) {
			ServiceContext context = req.getServiceContext();
			String command = (String)context.getMetaData().getData("command");
			if (!command.equalsIgnoreCase(ProfileOperation.PRF_GETPROPS))
				return res;				
			Object[] objs = req.getData();
			for(Object obj : objs){
				if (obj instanceof ProfileDataList) {
					ProfileDataList inProfileList = (ProfileDataList)obj;
					ProfileDataList outProfileList = new ProfileDataList();
					outProfileList.setRules(inProfileList.getRules());
					res.addOutput(outProfileList);
				}
			}
			context.getMetaData().setData("reqtype","xml-preview-grid");
			publishEof(context, res);
			return res;
		}		
		return res;
	}
	
	@SuppressWarnings("unchecked")
	private void publishEof(ServiceContext context, Response resp) {
		OutputData eofData = new OutputData();
		eofData.setData(new ProfileDataList ());
		MetaData metadata = new MetaData();
		Map map = new HashMap(context.getMetaData().getMap());
		map.put("type", "eof");
		metadata.setMap(map);
		eofData.setMetaData(metadata);
		resp.addOutput(eofData);	
			
	}
}
