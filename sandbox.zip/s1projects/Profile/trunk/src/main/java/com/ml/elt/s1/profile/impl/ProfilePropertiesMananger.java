/**
 * 
 */
package com.ml.elt.s1.profile.impl;

import java.util.List;
import java.util.Map;

import com.ml.elt.s1.profile.intface.DataConverter;
import com.ml.elt.s1.profile.intface.IHierarchyLoader;
import com.ml.elt.s1.profile.intface.ILookupGenerator;

/**
 * @author mpatel12
 *
 */
public class ProfilePropertiesMananger {

//	private static Log log = LogFactory.getLog(ProfilePropertiesMananger.class);
	
//	private boolean init = false;
	
	private Map<String, ILookupGenerator> applicationLookupGeneratorsMap;
	private Map<String, DataConverter> applicationDataConverterMap;
	private Map<String, IHierarchyLoader> applicationHierarchyLoaderMap;
	private Map<String, List<String>> applicationValiatorMap;
	
	private final static String DEFAULT = "DEFAULT";
	
	public ILookupGenerator getApplicationLookupGenerators(String appCode) {
		if(applicationLookupGeneratorsMap != null)
			return applicationLookupGeneratorsMap.get(appCode);
		else
			return null;				
	}
	
	/**
	 * @return the applicationLookupGeneratorsMap
	 */
	public Map<String, ILookupGenerator> getApplicationLookupGeneratorsMap() {
		return applicationLookupGeneratorsMap;
	}

	/**
	 * @param applicationLookupGeneratorsMap the applicationLookupGeneratorsMap to set
	 */
	public void setApplicationLookupGeneratorsMap(
			Map<String, ILookupGenerator> applicationLookupGeneratorsMap) {
		this.applicationLookupGeneratorsMap = applicationLookupGeneratorsMap;
	}

	/**
	 * @return the applicationDataConverterMap
	 */
	public Map<String, DataConverter> getApplicationDataConverterMap() {
		return applicationDataConverterMap;
	}

	/**
	 * @param applicationDataConverterMap the applicationDataConverterMap to set
	 */
	public void setApplicationDataConverterMap(
			Map<String, DataConverter> applicationDataConverterMap) {
		this.applicationDataConverterMap = applicationDataConverterMap;
	}

	/**
	 * @return the applicationHierarchyLoaderMap
	 */
	
	public DataConverter getApplicationDataConverter(String appCode) {
		DataConverter dataConverter = null;
		if(this.applicationDataConverterMap != null)
			dataConverter =  applicationDataConverterMap.get(appCode);
		if(dataConverter == null){
			dataConverter = applicationDataConverterMap.get(DEFAULT);
		}
		return dataConverter;
	}


	/**
	 * @return the applicationHierarchyLoaderMap
	 */
	public Map<String, IHierarchyLoader> getApplicationHierarchyLoaderMap() {
		return applicationHierarchyLoaderMap;
	}

	/**
	 * @param applicationHierarchyLoaderMap the applicationHierarchyLoaderMap to set
	 */
	public void setApplicationHierarchyLoaderMap(
			Map<String, IHierarchyLoader> applicationHierarchyLoaderMap) {
		this.applicationHierarchyLoaderMap = applicationHierarchyLoaderMap;
	}

	public IHierarchyLoader getApplicationHierarchyLoaderMap(String appCode) {
		return applicationHierarchyLoaderMap.get(appCode);
	}
	
	/**
	 * @return the applicationValiatorMap
	 */
	public IHierarchyLoader  getApplicationHierarchyLoader(String appCode) {
		if(applicationHierarchyLoaderMap!=null)
			return applicationHierarchyLoaderMap.get(appCode);
		else 
			return null;
	}

	
	public Map<String, List<String>> getApplicationValiatorMap() {
		return applicationValiatorMap;
	}

	/**
	 * @param applicationValiatorMap the applicationValiatorMap to set
	 */
	public void setApplicationValiatorMap(
			Map<String, List<String>> applicationValiatorMap) {
		this.applicationValiatorMap = applicationValiatorMap;
	}
	public List<String> getApplicationValiator(String appCode) {
		if(this.applicationValiatorMap !=null)
			return applicationValiatorMap.get(appCode);
		else 
			return null;
	}
}
