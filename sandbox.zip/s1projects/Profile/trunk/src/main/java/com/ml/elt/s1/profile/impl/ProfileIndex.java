/**
 * 
 */
package com.ml.elt.s1.profile.impl;

import java.io.Serializable;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.ml.elt.s1.profile.core.sdo.Application;
import com.ml.elt.s1.profile.core.sdo.Property;
import com.ml.elt.s1.profile.core.sdo.Rule;

/**
 * @author schuz
 *
 */
public class ProfileIndex implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private Map<String, Property> propertyMap = new ConcurrentHashMap<String, Property> ();
	private Map<String, String> propertyTypeMaps = new ConcurrentHashMap<String, String> ();
	private Map<String, Application> applicationMap = new ConcurrentHashMap<String, Application> ();	
	private Map<Long, Rule> ruleMap = new ConcurrentHashMap<Long, Rule> ();
	private Map<String, LookupIndex> lookupIndexMap;	
	
	/**
	 * @return the propertyMap
	 */
	public Map<String, Property> getPropertyMap() {
		return propertyMap;
	}

	/**
	 * @param propertyMap the propertyMap to set
	 */
	public void setPropertyMap(Map<String, Property> propertyMap) {
		this.propertyMap = propertyMap;
	}
	
	
	public void addProperty(String key, Property value) {
		propertyMap.put(key, value);
	}


	public Property getProperty(String key) {
		return propertyMap.get(key);
	}

	/**
	 * @return the Criteria Category Map
	 */
	public Map<String, Application> getApplicationMap() {
		return applicationMap;
	}

	/**
	 * @param applicationCode the Criteria Category Map to set
	 */
	public void setApplicationMap(Map<String, Application> applicationCode) {
		this.applicationMap = applicationCode;
	}


	public void addApplication(String key, Application value) {
		this.applicationMap.put(key, value);
	}

	public Application getApplication(String appCode) {
		return applicationMap.get(appCode);
	}

	/**
	 * @return the Criteria Index Map.
	 */
	public Map<String, LookupIndex> getLookupIndexMap() {
		if(lookupIndexMap == null) lookupIndexMap = new ConcurrentHashMap<String, LookupIndex>();
		return lookupIndexMap;
	}
	
	
	
	/**
	 * @return the Criteria Index.
	 */
	public LookupIndex getLookupIndex(String appCode) {
		if(lookupIndexMap == null)
			return null;
		else 
			return lookupIndexMap.get(appCode);
	}

	/**
	 * Add Criteria Index to Criteria Index Map.
	 * @param critCategCode the Criteria Category Code for the Criteria Index.
	 * @param critNdx the Criteria Index to add.
	 */
	public void addLookupIndex(String lookupCode, LookupIndex lookupIndex) {
		if(lookupIndexMap == null) lookupIndexMap = new ConcurrentHashMap<String, LookupIndex>();
		lookupIndexMap.put(lookupCode, lookupIndex);
	}

	public Map<Long, Rule> getRuleMap() {
		return ruleMap;
	}
	
	public void setRuleMap(Map<Long, Rule> ruleMap) {
		this.ruleMap = ruleMap;
	}

	public Rule getRule(Long ruleId) {
		return ruleMap.get(ruleId);
	}

	public Rule addRule(Long ruleId, Rule rule) {
		return ruleMap.put(ruleId,rule);
	}

	
	public void setPropertyTypeMaps(Map<String, String> propertyTypeMaps) {
		this.propertyTypeMaps = propertyTypeMaps;
	}

	public Map<String, String> getPropertyTypeMaps() {
		return propertyTypeMaps;
	}
	
	public void addPropertyType(String  key, String value) {
		propertyTypeMaps.put(key, value);
	}	

}
