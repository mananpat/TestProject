package com.ml.elt.s1.profile.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ml.elt.s1.platform.container.ServiceContext;
import com.ml.elt.s1.platform.container.service.Request;
import com.ml.elt.s1.platform.container.service.Response;
import com.ml.elt.s1.platform.container.service.processor.MessageProcessor;
import com.ml.elt.s1.profile.exception.ProfileException;
import com.ml.elt.s1.profile.intface.ProfileLifeCycle;
import com.ml.elt.s1.profile.transfer.gui.AppBean;
import com.ml.elt.s1.profile.transfer.gui.ContactBean;
import com.ml.elt.s1.profile.transfer.gui.ErrorBean;
import com.ml.elt.s1.profile.transfer.gui.ProfileAmendReportBean;
import com.ml.elt.s1.profile.transfer.gui.ProfileDataList;
import com.ml.elt.s1.profile.transfer.gui.PropertyBean;
import com.ml.elt.s1.profile.transfer.gui.RuleBean;
import com.ml.elt.s1.profile.util.ProfileApplicationConstant;
import com.ml.elt.s1.profile.util.ProfileOperation;

/**
 * @author mpatel12
 *
 * Profile Operation Handler
 * 
 */
public class ProfileHandler implements MessageProcessor {

	private static Log log = LogFactory.getLog(ProfileHandler.class);

	private ProfileLifeCycle profileLifeCycle;
	private Response finalResponse;
	private ServiceContext context;
	
	public ProfileLifeCycle getProfileLifeCycle() {
		return profileLifeCycle;
	}

	public void setProfileLifeCycle(ProfileLifeCycle profileLifeCycle) {
		this.profileLifeCycle = profileLifeCycle;
	}
	
	public Response process(Request request) {
		finalResponse = new Response();
		Object[] array = request.getData();
		if (array == null)
			return finalResponse;
		
		try 
		{	
			context = request.getServiceContext();	
			String command = (String)context.getMetaData().getData(ProfileApplicationConstant.CONTEXT_COMMAND);					
			String userId = (String)context.getMetaData().getData(ProfileApplicationConstant.CONTEXT_USERID);
			
			if (command == null) 
			{
				String message = "Profile Request is Invalid. Command is not specified in the request.";
				log.error(message);
				handleDefaultException(array, null, message);
				return finalResponse;
			}
			
			log.info("ProfileHandler: Profile Request Command: " + command + ", UserId: "+userId);
			
			ProfileDataList incomingProfileDataList = null;
			
			//forward reload request to ReloadProcessor and reload/refresh after sending same request to all S1 nodes to reload.
			if (command.equalsIgnoreCase(ProfileOperation.PRF_RELOAD)){
				for (Object obj : array)
					finalResponse.addOutput(obj);				
				return finalResponse;
			}
			
			for (Object object : array) {
				if(object instanceof ProfileDataList)
					incomingProfileDataList = (ProfileDataList)object;
				
				if (command.equalsIgnoreCase(ProfileOperation.PRF_GET_ALL_APPS)) {
					ProfileDataList profileResponse = new ProfileDataList();
					List<AppBean> apps = profileLifeCycle.getAllApplications();
					profileResponse.setApps(apps);
					context.getMetaData().setData("reqtype", "xml-application");
					finalResponse.addOutput(profileResponse);				
				} else if (command.equalsIgnoreCase(ProfileOperation.PRF_GETPROPS)) {
					executeRuleProperties(incomingProfileDataList);
				} else if (command.equalsIgnoreCase(ProfileOperation.PRF_GET_RULE_PROPERTIES)) {
					executeGetRuleProperties(incomingProfileDataList);				
				} else if (command.equalsIgnoreCase(ProfileOperation.PRF_GET_ALL_RULES) ||
				 		   command.equalsIgnoreCase(ProfileOperation.PRF_REFRESH)) {
					executeGetAllRules(incomingProfileDataList);			
				}
				else if (command.equalsIgnoreCase(ProfileOperation.PRF_CREATE_OR_UPDATE)){
					executeSaveOrUpdate(incomingProfileDataList);
				} else if (command.equalsIgnoreCase(ProfileOperation.PRF_GET_NEW_RULE)
						|| command.equalsIgnoreCase(ProfileOperation.PRF_GET_CLONE_RULE)) {
					ProfileDataList profileResponse = new ProfileDataList();
					List<RuleBean> ruleResponseList = new ArrayList<RuleBean>();					
					long ruleId = profileLifeCycle.getNextRuleId();
					RuleBean rule = new RuleBean ();
					rule.setRuleId(ruleId);
					rule.setActive(true);
					rule.setCommand(command);
					
					ruleResponseList.add(rule);
					profileResponse.setRules(ruleResponseList);
					context.getMetaData().setData("reqtype", "xml-rule-grid");
					finalResponse.addOutput(profileResponse);				
				} else if (command.equalsIgnoreCase(ProfileOperation.PRF_REFRESH_PICKERS)) {
					profileLifeCycle.reloadPickersData();
					finalResponse.addOutput("Reload successful");
				} else if (command.equalsIgnoreCase(ProfileOperation.PRF_REFRESH_CONTACT)) {
					List<ContactBean> contacts = profileLifeCycle.getAllContacts ();
					ProfileDataList profileResponse = new ProfileDataList();
					profileResponse.setContacts(contacts);
					finalResponse.addOutput(profileResponse);
				} else if (command.equalsIgnoreCase(ProfileOperation.PRF_SAVE_CONTACT)) {					
					executeSaveContact(incomingProfileDataList);
				} else if (command.equalsIgnoreCase(ProfileOperation.PRF_AMEND_REPORT)) {
					executeAmendReportRequest(incomingProfileDataList);
				}
			}		
		}
		catch (Throwable t) {
			String message = "One or more error(s) occurred while executing profile request."; 
			log.error(message, t);
			handleDefaultException(array, t, message);
		}
		return finalResponse;
	}
	
	private void handleDefaultException(Object[] array, Throwable t, String exceptionMessages) {		
		String exceptions;
		if (exceptionMessages == null || exceptionMessages.equals("")) 
			exceptions = formatExceptionMessage(t);		
		else
			exceptions = exceptionMessages;
		
		ProfileDataList prfResponse = new ProfileDataList ();
		List<ErrorBean> errors = new ArrayList<ErrorBean> ();
		ErrorBean bean = new ErrorBean ();
		bean.setRuleId(0);
		bean.setErrorMsg(exceptions);
		errors.add(bean);		
		prfResponse.setErrors(errors);
		finalResponse.addOutput(prfResponse);				
	}
	
	protected String formatExceptionMessage(Throwable t) {
		if(t == null)
			return null;
		
		String exceptions = t.getMessage();
		Throwable temp = t;
		while ((temp = temp.getCause()) != null) {
			if (temp.getMessage() != null)exceptions += temp.getMessage() + ". ";
		}
		if (exceptions == null || exceptions.equals("")) {
			StackTraceElement[] elements = t.getStackTrace();
			for (StackTraceElement ele : elements) {
					exceptions =  ele.getClassName() + "." + ele.getMethodName() + "()" + ele.getFileName() + ":" + ele.getLineNumber() + ")";
			}
		}
		return exceptions;
	}
	
	private ErrorBean validateAppCode(ProfileDataList prfFromGui) {
		String appCode = (String)context.getMetaData().getData("appCode");
		ErrorBean error = null; 
		if(appCode == null || "".equals(appCode)){
			error = new ErrorBean();
			error.setRuleId(0);
			error.setErrorMsg("Profile Request is Invalid. Application Code is either missing or invalid.");
		}
		return error;
	}
	
	
	private ErrorBean validateProfileDataList(ProfileDataList prfFromGui) {
		ErrorBean error = null;
		if(prfFromGui == null){
			error = new ErrorBean ();
			error.setRuleId(0);
			error.setErrorMsg("Profile Request is Invalid. Profile data are either missing or invalid.");
		}
		return error;
	}
	
	
	private List<ErrorBean> validateProfileRequest(ProfileDataList incomingProfileDataList, boolean checkAppCode, boolean dataList){
		List<ErrorBean> errorList = new ArrayList<ErrorBean>(4);
		ErrorBean error = null;
		if(checkAppCode){
			error = validateAppCode(incomingProfileDataList);
			if(error != null)
				errorList.add(error);
		}
		if(dataList){
			error = validateProfileDataList(incomingProfileDataList);
			if(error != null)
				errorList.add(error);
		}
		return errorList;
	}
		
	private void executeGetAllRules(ProfileDataList incomingProfileDataList) throws ProfileException {		
		List<ErrorBean> requestErrors = validateProfileRequest(incomingProfileDataList,true,false);
		if(requestErrors != null && !requestErrors.isEmpty()){
			ProfileDataList prfResponse = new ProfileDataList ();			
			prfResponse.addAllError(requestErrors);
			finalResponse.addOutput(prfResponse);							
		}		
		else
		{
			String appCode = (String)context.getMetaData().getData("appCode");
			List<RuleBean> rules = profileLifeCycle.getRules(appCode);
			ProfileDataList prfResponse = new ProfileDataList();
			prfResponse.setRules(rules);
			context.getMetaData().setData("reqtype", "xml-rule-grid");
			finalResponse.addOutput(prfResponse);
		}	
	}
	
	private void executeRuleProperties(ProfileDataList incomingProfileDataList) throws ProfileException {		
		List<ErrorBean> requestErrors = validateProfileRequest(incomingProfileDataList,true,true);
		if(requestErrors != null && !requestErrors.isEmpty()){
			ProfileDataList prfResponse = new ProfileDataList ();			
			prfResponse.addAllError(requestErrors);
			finalResponse.addOutput(prfResponse);							
		}		
		else
		{	
			String appCode = (String)context.getMetaData().getData("appCode");
			ProfileDataList prfResponse = new ProfileDataList();
			List<RuleBean> incomingRuleList = incomingProfileDataList.getRules();
			if (incomingRuleList == null || incomingRuleList.size() == 0) {
				List<ErrorBean> errors = new ArrayList<ErrorBean>();
				ErrorBean bean = new ErrorBean ();
				bean.setRuleId(0);
				bean.setErrorMsg("Profile Request is Invalid. Profile data are either missing or invalid.");
				errors.add(bean);
				prfResponse.addAllError(requestErrors);
				finalResponse.addOutput(prfResponse);
				return;
			}			
			
			RuleBean rule = incomingRuleList.get(0);
			rule.setUpdateUser(incomingProfileDataList.getUserId());
			RuleBean retVal = profileLifeCycle.getProperties(appCode, rule);
			prfResponse.setProfileProperty(rule.getProfileProperty ());
			prfResponse.setErrors(rule.getErrors());
			List<RuleBean> rules = new ArrayList<RuleBean> ();
			rules.add(retVal);
			prfResponse.setRules(rules);
			context.getMetaData().setData("reqtype", "xml-preview-property");
			finalResponse.addOutput(prfResponse);		
		}
	}
	
	private void executeSaveOrUpdate(ProfileDataList incomingProfileDataList) throws ProfileException {		
		List<ErrorBean> requestErrors = validateProfileRequest(incomingProfileDataList,true,true);
		if(requestErrors != null && !requestErrors.isEmpty()){
			ProfileDataList prfResponse = new ProfileDataList ();			
			prfResponse.addAllError(requestErrors);
			finalResponse.addOutput(prfResponse);							
		}		
		else
		{
			String appCode = (String)context.getMetaData().getData("appCode");	
			ProfileDataList prfResponse = profileLifeCycle.saveProfile(appCode, incomingProfileDataList);
			finalResponse.addOutput(prfResponse);
		}	
	}
	
	private void executeGetRuleProperties(ProfileDataList incomingProfileDataList) throws ProfileException {		
		List<ErrorBean> requestErrors = validateProfileRequest(incomingProfileDataList,true,true);
		if(requestErrors != null && !requestErrors.isEmpty()){
			ProfileDataList prfResponse = new ProfileDataList ();			
			prfResponse.addAllError(requestErrors);
			finalResponse.addOutput(prfResponse);							
		}		
		else
		{
			String appCode = (String)context.getMetaData().getData("appCode");	
			List<RuleBean> incomingRuleList = incomingProfileDataList.getRules();
			ProfileDataList prfResponse = new ProfileDataList ();		
			if (incomingRuleList == null || incomingRuleList.size() == 0){				
				List<ErrorBean> errors = new ArrayList<ErrorBean>();
				ErrorBean bean = new ErrorBean ();
				bean.setRuleId(0);
				bean.setErrorMsg("Profile Request is Invalid. Profile data are either missing or invalid.");
				errors.add(bean);
				prfResponse.addAllError(requestErrors);
				finalResponse.addOutput(prfResponse);
				return;					
			}
			
			ArrayList<PropertyBean> propsBean = new ArrayList<PropertyBean> ();
			for (RuleBean rule : incomingRuleList) {
				rule =  profileLifeCycle.getProfileById(appCode, rule.getRuleId());
				if (rule != null) 
					propsBean.addAll(rule.getProfileProperty ());							
			}
			
			prfResponse.setProfileProperty(propsBean);
			context.getMetaData().setData("reqtype", "xml-rule-property");
			finalResponse.addOutput(prfResponse);
		}	
	}
	
	
	private void validateSaveContactRequest(ProfileDataList incomingProfileDataList){		
		List<ErrorBean> errorList = new ArrayList<ErrorBean>();		
		ErrorBean error = null;
		
		if(incomingProfileDataList == null){
			error = new ErrorBean();
			error.setRuleId(0);
			error.setErrorMsg("Profile Request is Invalid. Profile Data is either missing or invalid.");
			errorList.add(error);
		}
		
		error = validateAppCode(incomingProfileDataList);
		if(error != null)
			errorList.add(error);
		
		if(incomingProfileDataList.getContacts() == null || incomingProfileDataList.getContacts().isEmpty()){
			error = new ErrorBean();
			error.setRuleId(0);
			error.setErrorMsg("Contact Save Request is Invalid. Profile Data is either missing or invalid.");
			errorList.add(error);
		}
		
		String pretext = "Contact Save Request is Invalid. ";
		StringBuffer errorMessage = null;
		for(ContactBean contact : incomingProfileDataList.getContacts()){
			errorMessage = new StringBuffer();
			if(contact.getFirstName() == null || "".equals(contact.getFirstName()))
				errorMessage.append("First Name is either empty or invalid. ");
			/*if(contact.getMiddleName() == null || "".equals(contact.getMiddleName()))
				errorMessage.append("Middle Name is either empty or invalid. ");*/
			if(contact.getLastName() == null || "".equals(contact.getLastName()))
				errorMessage.append("Last Name is either empty or invalid. ");			
			if(contact.getRole() == null || "".equals(contact.getRole()))
				errorMessage.append("Role is either empty or invalid. ");
			if(contact.getRecipientType() == null || "".equals(contact.getRecipientType()))
				errorMessage.append("Recipient Type is either empty or invalid. ");
			if(contact.getEmail() == null || "".equals(contact.getEmail()))
				errorMessage.append("Email is either empty or invalid. ");
			if(contact.getCompany() == null || "".equals(contact.getCompany()))
				errorMessage.append("Company is either empty or invalid. ");
			
			if(errorMessage.length() > 0){
				error = new ErrorBean();
				error.setRuleId(contact.getId());
				error.setErrorMsg(pretext + errorMessage.toString().trim());
				errorList.add(error);
				
				List<ErrorBean> contactErrors = new ArrayList<ErrorBean>();
				contactErrors.add(error);
				contact.setErrors(contactErrors);
			}
		}
		
		incomingProfileDataList.setErrors(errorList);
	}
	
	private void executeSaveContact(ProfileDataList incomingProfileDataList) throws ProfileException {		
		validateSaveContactRequest(incomingProfileDataList);
		if(incomingProfileDataList.getErrors() != null && !incomingProfileDataList.getErrors().isEmpty()){
			ProfileDataList prfResponse = new ProfileDataList ();			
			prfResponse.addAllError(incomingProfileDataList.getErrors());		
			finalResponse.addOutput(prfResponse);
		}
		else
		{	
			ProfileDataList prfResponse = profileLifeCycle.saveContacts(incomingProfileDataList);					
			finalResponse.addOutput(prfResponse);
		}	
	}
	
	private void executeAmendReportRequest(ProfileDataList incomingProfileDataList) throws ProfileException {		
		List<ErrorBean> requestErrors = validateProfileRequest(incomingProfileDataList,true,true);
		if(requestErrors != null && !requestErrors.isEmpty()){
			ProfileDataList prfResponse = new ProfileDataList ();			
			prfResponse.addAllError(requestErrors);
			finalResponse.addOutput(prfResponse);							
		}		
		else
		{
			List<RuleBean> incomingRuleList = incomingProfileDataList.getRules();
			List<Long> ruleIdList = new ArrayList<Long> ();
			if (incomingRuleList != null && !incomingRuleList.isEmpty()) {
				for (RuleBean rule : incomingRuleList) {
					if (rule.getRuleId() != null)
						ruleIdList.add(rule.getRuleId());						
				}			
			}
			List<ProfileAmendReportBean> ret =  profileLifeCycle.getAmendmentTrailReport(ruleIdList, incomingProfileDataList.getUpdateTime(), incomingProfileDataList.getUpdateTimeTo());
			ProfileDataList prfResponse = new ProfileDataList();
			prfResponse.setProfileAmendReports(ret);
			finalResponse.addOutput(prfResponse);			
		}	
	}
	
}
