/**
 * 
 */
package com.ml.elt.s1.profile.core.das.iface;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.platform.container.service.das.Dao;
import com.ml.elt.s1.profile.core.sdo.LookupProperties;

/**
 * @author mpatel12
 *
 */
public interface LookupPropertiesDao extends Dao {

	/**
	 * returns LookupProperties List
	 * @return LookupProperties
	 * @throws DataAccessException
	 */
	public List<LookupProperties> getAllLookupProperties() throws DASException;
	
	/**
	 * returns LookupProperties List
	 * @return LookupProperties
	 * @throws DataAccessException
	 */
	public List<LookupProperties> getLookupPropertiesByAppCode(String appCode) throws DASException;
	
	 
}
