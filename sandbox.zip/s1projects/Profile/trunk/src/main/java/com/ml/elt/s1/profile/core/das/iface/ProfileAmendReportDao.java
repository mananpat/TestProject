package com.ml.elt.s1.profile.core.das.iface;

import java.util.Date;
import java.util.List;

import org.springframework.dao.DataAccessException;

import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.platform.container.service.das.Dao;
import com.ml.elt.s1.profile.transfer.gui.ProfileAmendReportBean;

/**
 * @author pagarwa2
 *
 */
public interface ProfileAmendReportDao extends Dao {
	/**
	 * returns ProfileAmendReportBean List
	 * @return Application
	 * @throws DataAccessException
	 */
	public List<ProfileAmendReportBean> getProfileAmendReport(List<Long> ruleIds, Date startDate, Date endDate) throws DASException;
	
	/**
	 * returns ProfileAmendReportBean List
	 * @return Application
	 * @throws DataAccessException
	 */	
	public List<ProfileAmendReportBean> getAllProfileAmendReport() throws DASException; 
}
