package com.ml.elt.s1.profile.core.sdo;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.ml.elt.s1.platform.plugins.cache.CacheObject;
import com.ml.elt.s1.platform.plugins.cache.PrimaryKey;

@XmlRootElement(name = "pickerBean")
public class PickerBean  extends CacheObject implements Serializable {

	private static final long serialVersionUID = 2L;
	
	private Long id;
	private String pickerName;
	private String pickerValue;
	private String description;
	private String parentType;
	private String parentPickerType;
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getParentPickerType() {
		return parentPickerType;
	}
	public void setParentPickerType(String parentPickerType) {
		this.parentPickerType = parentPickerType;
	}
	public String getParentType() {
		return parentType;
	}
	public void setParentType(String parentType) {
		this.parentType = parentType;
	}
	public String getPickerName() {
		return pickerName;
	}
	public void setPickerName(String pickerName) {
		this.pickerName = pickerName;
	}
	@XmlElement(name="value")
	public String getPickerValue() {
		return pickerValue;
	}
	public void setPickerValue(String value) {
		this.pickerValue = value;
	}
	
	public String getCacheKey(){
		if (primaryKey == null){
			Object[] key = new Object[]{getPickerName(),getPickerValue()};
			primaryKey = new PrimaryKey(key, this.getClass().getName(), true, true);
		}
		return primaryKey.getStringKey();
	}
}
