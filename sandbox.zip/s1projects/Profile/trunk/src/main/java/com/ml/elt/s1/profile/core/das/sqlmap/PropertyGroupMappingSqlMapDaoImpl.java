/**
 * 
 */
package com.ml.elt.s1.profile.core.das.sqlmap;

import java.util.List;

import org.springframework.orm.ibatis.SqlMapClientTemplate;

import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.profile.core.das.iface.PropertyGroupMappingDao;
import com.ml.elt.s1.profile.core.sdo.PropertyGroupMapping;

/**
 * @author mpatel12
 *
 */
public class PropertyGroupMappingSqlMapDaoImpl extends SqlMapClientTemplate implements PropertyGroupMappingDao {
	
	/* (non-Javadoc)
	 * @see com.ml.elt.s1.core.das.iface.PropertyGroupMappingDao#getAllPropertyGroupMapping()
	 */
	@SuppressWarnings("unchecked")
	public List<PropertyGroupMapping> getAllPropertyGroupMappings()
			throws DASException {
		try {
			List<PropertyGroupMapping> list = (List<PropertyGroupMapping>) queryForList("getAllPropertyGroupMappings");
			return list;
		} catch (org.springframework.dao.DataAccessException ex) {
			throw new DASException(ex);
		}		
	}

	/* (non-Javadoc)
	 * @see com.ml.elt.s1.core.das.iface.PropertyGroupMappingDao#getPropertyGroupMappingByPropertyGroupId(int)
	 */
	@SuppressWarnings("unchecked")
	public List<PropertyGroupMapping> getPropertyGroupMappingsByPropertyGroupId(
			long propertyGroupId) throws DASException {
		try {
			List<PropertyGroupMapping> list = (List<PropertyGroupMapping>) queryForList("getPGMByPropGroupPropId", propertyGroupId);
			return list;
		} catch (org.springframework.dao.DataAccessException ex) {
			throw new DASException(ex);
		}	
	}

	/* (non-Javadoc)
	 * @see com.ml.elt.s1.core.das.iface.PropertyGroupMappingDao#getPropertyGroupMappingByPropertyId(int)
	 */
	/*@SuppressWarnings("unchecked")
	public List<PropertyGroupMapping> getPropertyGroupMappingByPropertyId(
			int propertyId) throws DASException {
		try {
			List<PropertyGroupMapping> list = (List<PropertyGroupMapping>) queryForList("getPGMByPropGroupId", propertyId);
			return list;
		} catch (org.springframework.dao.DataAccessException ex) {
			throw new DASException(ex);
		}	
	}*/
}
