package com.ml.elt.s1.profile.intface;

import java.util.Date;
import java.util.List;

import com.ml.elt.s1.profile.core.sdo.Rule;
import com.ml.elt.s1.profile.exception.ProfileException;
import com.ml.elt.s1.profile.transfer.gui.AppBean;
import com.ml.elt.s1.profile.transfer.gui.ContactBean;
import com.ml.elt.s1.profile.transfer.gui.ProfileAmendReportBean;
import com.ml.elt.s1.profile.transfer.gui.ProfileDataList;
import com.ml.elt.s1.profile.transfer.gui.RuleBean;

/**
 * @author anagrawa
 * Provides create, retrieve, update and delete functionality for profile service
 */
public interface ProfileLifeCycle {
	
	/**
	 * @param applicationCode: Name of the application
	 * @param ruleProperties : Map of property names and values for the new rule
	 * @throws ProfileException
	 */
	public List<AppBean> getAllApplications () throws ProfileException;	
	
	
	public List<RuleBean> getRules (String applicationCode) throws ProfileException;
	
	
	public RuleBean getProperties (String appCode, RuleBean rule) throws ProfileException;
	
	/**
	 * @param applicationCode : Name of the application
	 * @param ruleProperties: Map of property names and values for the new rule
	 * @throws ProfileException
	 */
	public ProfileDataList saveProfile (String applicationCode, ProfileDataList incomingList) throws ProfileException;
	
	/**
	 * @param applicationCode : Name of the application
	 * @return : Map of rule id as key and map (of propertycode and propertyValue) as  value
	 * @throws ProfileException
	 */
	public RuleBean getProfileById(String applicationCode, Long ruleId) throws ProfileException;
		
	public List<ContactBean> getAllContacts() throws ProfileException;
	
	public ProfileDataList saveContacts(ProfileDataList incomingProfDataList) throws ProfileException;
	
	public void saveContactsToCache(ProfileDataList incomingProfDataList) throws ProfileException; 
	
	public List<ProfileAmendReportBean> getAmendmentTrailReport (List<Long> ruleIds, Date startTime, Date endTime) throws ProfileException;
	
	public void rebuildProfileIndex() throws ProfileException;
	
	public void rebuildProfileIndex(String applicationCode) throws ProfileException;
	
	public void rebuildProfileIndex(String applicationCode, Long ruleId) throws ProfileException;
	
	public Rule reloadProfileRuleData(Long ruleId) throws ProfileException;
	
	public void reloadProfileData() throws ProfileException;
	
	public void reloadPickersData() throws ProfileException;
	
	public long getNextRuleId () throws ProfileException;
	
}
