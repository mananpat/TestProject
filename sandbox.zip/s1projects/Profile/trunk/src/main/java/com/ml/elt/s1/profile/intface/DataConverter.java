package com.ml.elt.s1.profile.intface;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ml.elt.s1.profile.core.das.cache.ProfileCommandQuery;
import com.ml.elt.s1.profile.core.das.util.DBDataLoader;
import com.ml.elt.s1.profile.core.sdo.Contact;
import com.ml.elt.s1.profile.core.sdo.GiveupBrokerCodes;
import com.ml.elt.s1.profile.core.sdo.PriceTolerances;
import com.ml.elt.s1.profile.core.sdo.MarketCharges;
import com.ml.elt.s1.profile.core.sdo.Rule;
import com.ml.elt.s1.profile.exception.ProfileException;
import com.ml.elt.s1.profile.util.ProfileApplicationConstant;

public class DataConverter {
	private static Log log = LogFactory.getLog(DataConverter.class);
	
	public static final String TYPE_STRING = "STRING";
    public static final String TYPE_DOUBLE = "DOUBLE";
    public static final String TYPE_CONTACT = "CONTACT";
    public static final String TYPE_BOOLEAN = "BOOLEAN";
    public static final String TYPE_INTEGER = "INTEGER";
    public static final String TYPE_LONG = "LONG";
    public static final String TYPE_FLOAT = "FLOAT";
    public static final String TYPE_DATETIME = "DATE";
    public static final String TYPE_SHORT = "SHORT";	
    public static final String TYPE_MARKET = ProfileApplicationConstant.MARKET_CHARGES;
    public static final String TYPE_GIVEUP = ProfileApplicationConstant.GIVEUP_BROKER_CODES;
    public static final String TYPE_TOLERANCE = ProfileApplicationConstant.PRICE_TOLERANCES;
	
	private static final String DISPLAYFORMAT = "dd-MMM-yyyy";
	private DateFormat displayFormat = new SimpleDateFormat(DISPLAYFORMAT);

	// TODO : To be removed ... kept for backward compatibility
	private static final String DATETIMEFORMAT = "MM/dd/yyyy";
	private DateFormat dateFormat = new SimpleDateFormat(DATETIMEFORMAT);
	
	public DataConverter() {
	}
	
	public String getDisplayString(Object propValue, String type) {
		if (type.equalsIgnoreCase(TYPE_CONTACT)) {
			Contact contact = (Contact) propValue;
			if (contact != null)
				return contact.getId().toString();
		}
		if (type.equalsIgnoreCase(TYPE_DATETIME)) {
			Date date = (Date) propValue;
			if (date != null)
				synchronized (displayFormat) {
					return this.displayFormat.format(date);	
				}
		}
		if (type.equalsIgnoreCase(TYPE_MARKET)) {
			MarketCharges charges = (MarketCharges) propValue;
			if (charges != null)
				return charges.getId().toString();
		}
		if (type.equalsIgnoreCase(TYPE_GIVEUP)) {
			GiveupBrokerCodes codes = (GiveupBrokerCodes) propValue;
			if (codes != null) {
				return codes.getId().toString();
			}
		}
		if (type.equalsIgnoreCase(TYPE_TOLERANCE)) {
			PriceTolerances codes = (PriceTolerances) propValue;
			if (codes != null) {
				return codes.getId().toString();
			}
		}
		return propValue.toString();
	}
	
	public Boolean isAList (String propCode) {
		if (propCode.equals("FORMULA"))
			return false;
		return true;
	}

	@SuppressWarnings("unchecked")
	public Object convert(Object propValue, String type) throws ProfileException {
		if (propValue == null || type == null)
			return null;
		if (type.equalsIgnoreCase(TYPE_STRING))
			return propValue;
		if (type.equalsIgnoreCase(TYPE_CONTACT)) {
			try {
				String propString = propValue.toString();
				if (propString == null || propString.length() == 0)
					return null;
				Long contactId = Long.parseLong(propString);
				Contact contact = ProfileCommandQuery.getContactById(contactId);
				return contact;
			} catch (Exception e) {
				log.warn(String.format("Cannot convert string %1$s to type Contacts: Message: %2$s", propValue, e.getMessage()));
				return null;
			}
		}
		if (type.equalsIgnoreCase(TYPE_MARKET)) {
			try {
				String propString = propValue.toString();
				if (propString == null || propString.length() == 0)
					return null;
				Long marketId = Long.parseLong(propString);
				Rule rule = ProfileCommandQuery.getRuleById(marketId);
				if (rule != null && rule.getActiveFlag())
					return DBDataLoader.getMarketChargesFromRule(rule);
				return null;
			} catch (Exception e) {
				log.warn(String.format("Cannot convert string %1$s to type Market Charges: Message: %2$s", propValue, e.getMessage()));
				return null;
			}
		}
		if (type.equalsIgnoreCase(TYPE_GIVEUP)) {
			try {
				String propString = propValue.toString();
				if (propString == null || propString.length() == 0)
					return null;
				Long marketId = Long.parseLong(propString);
				Rule rule = ProfileCommandQuery.getRuleById(marketId);
				if (rule != null && rule.getActiveFlag())
					return DBDataLoader.getGiveupBrokerCodesFromRule(rule);
				return null;
			} catch (Exception e) {
				log.warn(String.format("Cannot convert string %1$s to type Giveup Broker Codes: Message: %2$s", propValue, e.getMessage()));
				return null;
			}
		}
		if (type.equalsIgnoreCase(TYPE_TOLERANCE)) {
			try {
				String propString = propValue.toString();
				if (propString == null || propString.length() == 0)
					return null;
				Long marketId = Long.parseLong(propString);
				Rule rule = ProfileCommandQuery.getRuleById(marketId);
				if (rule != null && rule.getActiveFlag())
					return DBDataLoader.getPriceTolerancesFromRule(rule);
				return null;
			} catch (Exception e) {
				log.warn(String.format("Cannot convert string %1$s to type Price Tolerance Codes: Message: %2$s", propValue, e.getMessage()));
				return null;
			}
		}
		if (type.equalsIgnoreCase(TYPE_DOUBLE)) {
			propValue = Double.parseDouble((String) propValue);
			return propValue;
		}
		if (type.equalsIgnoreCase(TYPE_BOOLEAN)) {
			if (propValue.toString().equalsIgnoreCase("t")
					|| propValue.toString().equalsIgnoreCase("true"))
				propValue = Boolean.TRUE;
			else
				propValue = Boolean.FALSE;
			// anObject = Boolean.parseBoolean((String)anObject);
			return propValue;
		}
		if (type.equalsIgnoreCase(TYPE_INTEGER)) {
			propValue = Integer.parseInt((String) propValue);
			return propValue;
		}
		if (type.equalsIgnoreCase(TYPE_SHORT)) {
			propValue = Short.parseShort((String) propValue);
			return propValue;
		}
		if (type.equalsIgnoreCase(TYPE_LONG)) {
			propValue = Long.parseLong((String) propValue);
			return propValue;
		}
		if (type.equalsIgnoreCase(TYPE_FLOAT)) {
			propValue = Float.parseFloat((String) propValue);
			return propValue;
		}
		if (type.equalsIgnoreCase(TYPE_DATETIME)) {
			try {
				synchronized (dateFormat) {
					propValue = dateFormat.parse(propValue.toString());	
				}
			} catch (ParseException e) {
				log.warn(String.format("Cannot convert string %1$s to type Date: Message: %2$s", propValue, e.getMessage()));
			}
			return propValue;
		}
		else
			return propValue;

	}
}
