/**
 * 
 */
package com.ml.elt.s1.profile.core.das.sqlmap;

import java.util.List;

import org.springframework.orm.ibatis.SqlMapClientTemplate;

import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.profile.core.das.iface.PropertyDao;
import com.ml.elt.s1.profile.core.sdo.Property;

/**
 * @author mpatel12
 *
 */
public class PropertySqlMapDaoImpl extends SqlMapClientTemplate implements PropertyDao {

	/* (non-Javadoc)
	 * @see com.ml.elt.s1.core.das.iface.PropertyDao#getPropertyById(long)
	 */
	@SuppressWarnings("unchecked")
	public List<Property> getAllProperties() throws DASException {
		try {
			return (List<Property>) queryForList("getAllProperties");
		} catch (org.springframework.dao.DataAccessException ex) {
			throw new DASException(ex);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.ml.elt.s1.core.das.iface.PropertyDao#getPropertyById(long)
	 */
	public Property getPropertyById(long propertyId) throws DASException {
		try {
			return (Property) queryForObject("getPropertyById", propertyId);
		} catch (org.springframework.dao.DataAccessException ex) {
			throw new DASException(ex);
		}
	}

}
