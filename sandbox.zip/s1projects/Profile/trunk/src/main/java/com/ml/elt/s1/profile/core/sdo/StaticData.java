package com.ml.elt.s1.profile.core.sdo;

import com.ml.elt.s1.platform.plugins.cache.PrimaryKey;

/**
 * StaticData
 */
public class StaticData extends ProfileDomainObject {

	private static final long serialVersionUID = 1L;

	private Long id;
	private Long pickerListId;
	private String value;
	private String description;
	private Long parentId;
	
	//private Pickerlist pickerlist;
	
	public StaticData() {
	}

	/*public StaticData(long id, Pickerlist pickerlist, String value) {
		this.id = id;
		this.pickerlist = pickerlist;
		this.value = value;
	}

	public StaticData(long id, Pickerlist pickerlist, String value,
			String description, String createUser, Date createTs,
			String updateUser, Date updateTs, Long parentId) {
		this.id = id;
		this.pickerlist = pickerlist;
		this.value = value;
		this.description = description;
		this.createUser = createUser;
		this.createTs = createTs;
		this.updateUser = updateUser;
		this.updateTs = updateTs;
		this.parentId = parentId;
	}
*/
	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	public Long getParentId() {
		return parentId;
	}

	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}
	
	public Long getPickerListId() {
		return pickerListId;
	}

	public void setPickerListId(Long pickerListId) {
		this.pickerListId = pickerListId;
	}
	
//	public Pickerlist getPickerlist() {
//		return this.pickerlist;
//	}
//
//	public void setPickerlist(Pickerlist pickerlist) {
//		this.pickerlist = pickerlist;
//	}
	
	/* (non-Javadoc)
	 * @see com.ml.elt.s1.platform.plugins.cache.CacheObject#getCacheKey()
	 */
	@Override
	public String getCacheKey(){
		if (primaryKey == null){
			Object[] key = new Object[]{getId()};
			primaryKey = new PrimaryKey(key, this.getClass(), true, true);
		}
		return primaryKey.getStringKey();
	}

	public static String getCacheKey(Long id){
		Object[] key = new Object[]{id};
		PrimaryKey primaryKey = new PrimaryKey(key, StaticData.class, true, true);
		return primaryKey.getStringKey();
	}
	
	public String getPath(){
		return getClass().getPackage().getName().replace('.', '_')
		+ "/" + getClass().getSimpleName()
		+ "/" + getPickerListId();
	}

	
}
