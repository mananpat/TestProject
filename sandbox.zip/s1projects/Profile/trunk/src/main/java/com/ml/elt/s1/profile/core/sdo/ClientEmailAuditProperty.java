package com.ml.elt.s1.profile.core.sdo;

import com.ml.elt.s1.platform.plugins.cache.PrimaryKey;

public class ClientEmailAuditProperty extends ProfileDomainObject {
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private String propertyCode;
	private String propertyType;
	private Boolean isActive;	
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPropertyCode() {
		return propertyCode;
	}

	public void setPropertyCode(String propertyCode) {
		this.propertyCode = propertyCode;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	@Override
	public String getCacheKey(){
		return getId().toString();
	}

	public static String getCacheKey(Long id){
		return id.toString();
	}

	public String getPropertyType() {
		return propertyType;
	}

	public void setPropertyType(String propertyType) {
		this.propertyType = propertyType;
	}
}
