package com.ml.elt.s1.profile.core.sdo;

import com.ml.elt.s1.platform.plugins.cache.PrimaryKey;

public class ClientEmailAudit extends ProfileDomainObject {
	private static final long serialVersionUID = 1L;
	
	private Long instId;
	private Long propertyID;
	private Integer version;
	private String auditValue;
	
	@Override
	public String getCacheKey(){
		if (primaryKey == null){
			Object[] key = new Object[]{getInstId()};
			primaryKey = new PrimaryKey(key, this.getClass(), true, true);
		}
		return primaryKey.getStringKey();
	}

	public static String getCacheKey(Long instId){
		Object[] key = new Object[]{instId};
		PrimaryKey primaryKey = new PrimaryKey(key, Property.class, true, true);
		return primaryKey.getStringKey();
	}

	public String getAuditValue() {
		return auditValue;
	}

	public void setAuditValue(String auditValue) {
		this.auditValue = auditValue;
	}

	public Long getInstId() {
		return instId;
	}

	public void setInstId(Long instId) {
		this.instId = instId;
	}

	public Long getPropertyID() {
		return propertyID;
	}

	public void setPropertyID(Long propertyID) {
		this.propertyID = propertyID;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}
}
