/**
 * 
 */
package com.ml.elt.s1.profile.service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ml.elt.s1.platform.container.ServiceContext;
import com.ml.elt.s1.platform.container.exception.ExceptionHandler;
import com.ml.elt.s1.platform.container.service.Request;
import com.ml.elt.s1.platform.container.service.Response;
import com.ml.elt.s1.platform.container.service.processor.MessageProcessor;
import com.ml.elt.s1.platform.plugins.boot.DefaultConfiguration;
import com.ml.elt.s1.profile.core.das.util.DBDataLoader;
import com.ml.elt.s1.profile.core.sdo.Rule;
import com.ml.elt.s1.profile.exception.ProfileException;
import com.ml.elt.s1.profile.intface.ProfileLifeCycle;
import com.ml.elt.s1.profile.transfer.gui.ProfileDataList;
import com.ml.elt.s1.profile.transfer.gui.RuleBean;
import com.ml.elt.s1.profile.util.ProfileApplicationConstant;
import com.ml.elt.s1.profile.util.ProfileOperation;

/**
 * @author mpatel12
 *
 * Processor to receive Profile Service update messages to cache can be refreshed in S1 Booking Node.
 * 
 */
public class ProfileServiceUpdateListener implements MessageProcessor {

	private static Log log = LogFactory.getLog(ProfileServiceUpdateListener.class);
		
	private ProfileLifeCycle prfLifeCycle = null;	
	private static Set<String> profileApplicationSet = null;
	
	static 
	{
		String profileApplicationsStr = DefaultConfiguration.getInstanceProperties().getProperty("profileApplications");		
		if(profileApplicationsStr != null && !"".equals(profileApplicationsStr)){
			if(profileApplicationSet == null)
				profileApplicationSet = new HashSet<String>();
			StringTokenizer strTokenizer = new StringTokenizer(profileApplicationsStr, ",");
			while (strTokenizer.hasMoreTokens()) {
				profileApplicationSet.add((String)strTokenizer.nextElement());
	        }			
		}	
		if(log.isDebugEnabled())
			log.debug("Profile Application Configured are : '" + profileApplicationsStr.toString() + "'");
	}
	
	public ProfileLifeCycle getPrfLifeCycle() {
		return prfLifeCycle;
	}

	public void setPrfLifeCycle(ProfileLifeCycle prfLifeCycle) {
		this.prfLifeCycle = prfLifeCycle;
	}
	
	/* (non-Javadoc)
	 * @see com.ml.elt.s1.platform.container.service.processor.MessageProcessor#process(com.ml.elt.s1.platform.container.service.Request)
	 */
	public Response process(Request request) {
		
		if (request == null)
			return new Response();
		
		Object[] array = request.getData();
		ServiceContext context = request.getServiceContext();
		
		if (array == null || context == null)
			return new Response();
		
		try 
		{
			String command = (String)context.getMetaData().getData(ProfileApplicationConstant.CONTEXT_BROADCAST_COMMAND);	
			String appCode = (String)context.getMetaData().getData(ProfileApplicationConstant.CONTEXT_APP_CODE);	
			String userId = (String)context.getMetaData().getData(ProfileApplicationConstant.CONTEXT_USERID);
						
			boolean isAppMarketCharges = ProfileApplicationConstant.MARKET_CHARGES.equalsIgnoreCase(appCode);
			boolean isAppGiveupBrokerCodes = ProfileApplicationConstant.GIVEUP_BROKER_CODES.equalsIgnoreCase(appCode);
			boolean isAppPriceTolerances = ProfileApplicationConstant.PRICE_TOLERANCES.equalsIgnoreCase(appCode);
			boolean isAppRefresh = ProfileOperation.PRF_REFRESH.equalsIgnoreCase(command);
			
			if(profileApplicationSet == null || profileApplicationSet.isEmpty() || !profileApplicationSet.contains(appCode))
				return new Response();	
			
			if (command == null) {
				log.warn("Invalid Profile Service Update Message.  Either Command is null or invalid in the request.");			
				return new Response();
			}
			
			try {
				if(ProfileOperation.PRF_CREATE_OR_UPDATE.equalsIgnoreCase(command)||
				   ProfileOperation.PRF_SAVE_CONTACT.equalsIgnoreCase(command) ||
				   ProfileOperation.PRF_RELOAD.equalsIgnoreCase(command) ||
				   ProfileOperation.PRF_REFRESH.equalsIgnoreCase(command)) {
				   
					log.info("ProfileServiceUpdateListener: Profile Service message for "+ appCode + ", Request Type: " + command + ", UserId: "+userId);
					
					if(ProfileOperation.PRF_RELOAD.equalsIgnoreCase(command)) {
						prfLifeCycle.reloadProfileData();
					} else if(ProfileOperation.PRF_SAVE_CONTACT.equalsIgnoreCase(command)) {
						if(array!=null && array.length>0){
							for(Object obj : array){
								if (obj instanceof ProfileDataList) {
									prfLifeCycle.saveContactsToCache((ProfileDataList)obj);
								}
							}
						}
					} else {	
						Set<Long> ruleIdSetToReload = extractRuleIdFromUpdateRequest(array);
						if(ruleIdSetToReload != null && !ruleIdSetToReload.isEmpty()) {
							for(Long ruleId : ruleIdSetToReload){
								if(ruleId != null){
									Rule rule = prfLifeCycle.reloadProfileRuleData(ruleId);
									if(!isAppRefresh)
										prfLifeCycle.rebuildProfileIndex(appCode,ruleId);
									if(isAppMarketCharges){
										DBDataLoader.updateMarketCharges(rule);
									}
									if(isAppGiveupBrokerCodes){
										DBDataLoader.updateGiveupBrokerCodes(rule);
									}
									if(isAppPriceTolerances){
										DBDataLoader.updatePriceTolerances(rule);
									}
								}
							}
							if(isAppRefresh)
								prfLifeCycle.rebuildProfileIndex(appCode);
						}						
					}
				}
			} catch (ProfileException ex) {
				String message = "Failed to reload Profile in ProfileServiceUpdateListener.";			
				ExceptionHandler.getInstance().handleSystemException(message, ex);
			}
		} catch (Throwable t) {			
			String message = "One or more error(s) have occurred in ProfileServiceUpdateListener.";			
			ExceptionHandler.getInstance().handleSystemException(message, t);			
		}
		return new Response();
	}
	
	private Set<Long> extractRuleIdFromUpdateRequest(Object[] objs){		
		if(objs == null || objs.length == 0)
			return null;		
		ProfileDataList requestProfileDataList = null;
		Set<Long> ruleIdSet = new HashSet<Long>();
		for(Object obj : objs){
			if (obj instanceof ProfileDataList) {
				requestProfileDataList = (ProfileDataList)obj;				
				List<RuleBean> ruleBeanList = requestProfileDataList.getRules();
				if(ruleBeanList != null && !ruleBeanList.isEmpty()){
					for(RuleBean ruleBean : ruleBeanList){
						if(ruleBean.getRuleId() != null)
							ruleIdSet.add(ruleBean.getRuleId());
					}
				}
			}			
		}		
		return ruleIdSet;
	}
}
