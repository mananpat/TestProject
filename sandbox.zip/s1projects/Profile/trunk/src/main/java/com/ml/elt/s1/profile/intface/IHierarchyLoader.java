package com.ml.elt.s1.profile.intface;

import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.profile.impl.LookupIndex;
import com.ml.elt.s1.profile.impl.LookupResultSet;
import com.ml.elt.s1.profile.impl.ProfileHierarchy;
import java.util.Map;

public interface IHierarchyLoader {
	void loadHierarchy (ProfileHierarchy hierarchy);
	
	Map<String, ProfileHierarchy> getHierarchyMap ();
	
	void init() throws DASException;
	
	void helpSearch(LookupIndex lIndex, LookupResultSet lrSet);
}
