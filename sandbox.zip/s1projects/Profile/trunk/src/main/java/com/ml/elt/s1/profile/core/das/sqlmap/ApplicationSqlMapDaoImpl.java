/**
 * 
 */
package com.ml.elt.s1.profile.core.das.sqlmap;

import java.util.List;

import org.springframework.orm.ibatis.SqlMapClientTemplate;

import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.profile.core.das.iface.ApplicationDao;
import com.ml.elt.s1.profile.core.sdo.Application;

/**
 * @author mpatel12
 *
 */
public class ApplicationSqlMapDaoImpl extends SqlMapClientTemplate implements
		ApplicationDao {

	/* (non-Javadoc)
	 * @see com.ml.elt.s1.core.das.iface.ApplicationDao#getAllApplications()
	 */
	@SuppressWarnings("unchecked")
	public List<Application> getAllApplications() throws DASException {
		try {
			return (List<Application>) queryForList("getAllApplications");			
		} catch (org.springframework.dao.DataAccessException ex) {
			throw new DASException(ex);
		}
	}

	@SuppressWarnings("unchecked")
	public List<Application> getApplicationsByAppCode(List<String> appCodeList) throws DASException{
		try {
			return (List<Application>) queryForList("getApplicationByAppCodeList", appCodeList);			
		} catch (org.springframework.dao.DataAccessException ex) {
			throw new DASException(ex);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.ml.elt.s1.core.das.iface.ApplicationDao#getApplicationByAppCode(java.lang.String)
	 */
	public Application getApplicationByAppCode(String appCode) throws DASException {
		try {
			return (Application) queryForObject("getApplicationByAppCode", appCode);
		} catch (org.springframework.dao.DataAccessException ex) {
			throw new DASException(ex);
		}
	}

}
