package com.ml.elt.s1.profile.plugins.amendmentreport;

import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="amendmentReportRequest")
public class AmendmentReportRequest {
	private List<String> bookId;
	private List<String> clientShortName;
	private List<Long> origTransId;
	private Date dateTimeFrom;
	private Date dateTimeTo;	
	private String command;
	private List<Long> ruleId;
	public List<Long> getRuleId() {
		return ruleId;
	}
	public void setRuleId(List<Long> ruleId) {
		this.ruleId = ruleId;
	}
	public String getCommand() {
		return command;
	}
	public void setCommand(String command) {
		this.command = command;
	}	
	public List<String> getBookId() {
		return bookId;
	}
	public void setBookId(List<String> bookId) {
		this.bookId = bookId;
	}
	public List<String> getClientShortName() {
		return clientShortName;
	}
	public void setClientShortName(List<String> clientShortName) {
		this.clientShortName = clientShortName;
	}
	public Date getDateTimeFrom() {
		return dateTimeFrom;
	}
	public void setDateTimeFrom(Date dateTimeFrom) {
		this.dateTimeFrom = dateTimeFrom;
	}
	public Date getDateTimeTo() {
		return dateTimeTo;
	}
	public void setDateTimeTo(Date dateTimeTo) {
		this.dateTimeTo = dateTimeTo;
	}
	public List<Long> getOrigTransId() {
		return origTransId;
	}
	public void setOrigTransId(List<Long> origTransId) {
		this.origTransId = origTransId;
	}

}
