/**
 * 
 */
package com.ml.elt.s1.profile.core.das.iface;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.platform.container.service.das.Dao;
import com.ml.elt.s1.profile.core.sdo.PropertyGroup;

/**
 * @author mpatel12
 *
 */
public interface PropertyGroupDao extends Dao {

	/**
	 * returns PropertyGroup List
	 * @return PropertyGroup
	 * @throws DataAccessException
	 */
	public List<PropertyGroup>  getAllPropertyGroups() throws DASException;
	
	/**
	 * returns PropertyGroup List
	 * @return PropertyGroup
	 * @throws DataAccessException
	 */
	public List<PropertyGroup>  getPropertyGroupsByAppId(long appId) throws DASException;
	
	/**
	 * returns PropertyGroup List
	 * @return PropertyGroup
	 * @throws DataAccessException
	 */
	public List<PropertyGroup>  getPropertyGroupsByPropGroupCode(String propertyGroupCode) throws DASException;
}
