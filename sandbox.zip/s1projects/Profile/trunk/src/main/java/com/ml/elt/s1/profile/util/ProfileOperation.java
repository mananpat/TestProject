package com.ml.elt.s1.profile.util;

public class ProfileOperation 
{
	public static final String PRF_CREATE_OR_UPDATE = "createOrUpdateProfiles";	
	public static final String PRF_GET_ALL_APPS = "getApps";
	public static final String PRF_GET_ALL_RULES = "getRules";	
	public static final String PRF_GET_RULE_PROPERTIES = "getAllValuesForProfile";
	public static final String PRF_GETPROPS = "getProperties";
	
	public static final String PRF_REFRESH = "refresh";
	public static final String PRF_RELOAD = "reload";
	
	public static final String PRF_GET_NEW_RULE = "getNewRuleId";
	public static final String PRF_GET_CLONE_RULE = "getClonedRuleId";	
	
	public static final String PRF_REFRESH_PICKERS = "refreshPickers";
	public static final String PRF_REFRESH_CONTACT = "refreshContacts";
	public static final String PRF_SAVE_CONTACT = "saveContacts";
	public static final String PRF_AMEND_REPORT = "getAmendmentReport";
	
}