package com.ml.elt.s1.profile.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ml.elt.s1.platform.container.ServiceContext;
import com.ml.elt.s1.platform.container.service.MetaData;
import com.ml.elt.s1.platform.container.service.Request;
import com.ml.elt.s1.platform.container.service.Response;
import com.ml.elt.s1.platform.container.service.processor.MessageProcessor;
import com.ml.elt.s1.platform.plugins.connector.ems.OutputData;
import com.ml.elt.s1.profile.transfer.gui.ProfileAmendReportBean;
import com.ml.elt.s1.profile.transfer.gui.ProfileDataList;
import com.ml.elt.s1.profile.transfer.gui.RuleBean;
import com.ml.elt.s1.profile.util.ProfileOperation;

public class ProfileFilter implements MessageProcessor {

	private int batchSize = 20;

	public int getBatchSize() {
		return batchSize;
	}

	public void setBatchSize(int batchSize) {
		this.batchSize = batchSize;
	}

	public Response process(Request req) {
		Response res = new Response();
		if (req != null) {
			ServiceContext context = req.getServiceContext();
			String appCode = (String)context.getMetaData().getData("appCode");
			String command = (String)context.getMetaData().getData("command");			
			String reqid = (String)context.getMetaData().getData("reqid");
			context.getMetaData().setData("errorReqId", reqid);
			
			if (command.equalsIgnoreCase(ProfileOperation.PRF_CREATE_OR_UPDATE) || command.equalsIgnoreCase(ProfileOperation.PRF_RELOAD)) {
				context.getMetaData().setData("reqid", appCode);
				return res;
			}
			
			Object[] objs = req.getData();
			for(Object obj : objs){
				if (obj instanceof ProfileDataList) {
					ProfileDataList inProfileList = (ProfileDataList)obj;
					ProfileDataList outProfileList = new ProfileDataList();
					if (!command.equalsIgnoreCase(ProfileOperation.PRF_GETPROPS))
						outProfileList.setRules(inProfileList.getRules());
					outProfileList.setProfileProperty(inProfileList.getProfileProperty());
					outProfileList.setApps(inProfileList.getApps());					
					outProfileList.setContacts(inProfileList.getContacts());
					outProfileList.setProfileAmendReports(inProfileList.getProfileAmendReports());
					if (!this.dispatch(context, outProfileList))
						res.addOutput(outProfileList);
				}
			}
			
			publishEof(context, res);
			return res;
		}		
		return res;
	}
	
	private boolean dispatch (ServiceContext context, ProfileDataList profileList) {
		if (profileList.getRules() != null) {
			int size = profileList.getRules().size();
			for (int i = 0; i < size; i += batchSize) {
				List<RuleBean> subList = profileList.getRules().subList(i, Math.min(i + batchSize, size));
				ProfileDataList batch = new ProfileDataList ();
				batch.setRules(subList);
				Response resp = new Response ();
				resp.addOutput(batch);
				context.dispatch(resp);
			}
			profileList.getRules().clear();
			return true;
		}
		
		if (profileList.getProfileAmendReports() != null) {
			int size = profileList.getProfileAmendReports().size();
			for (int i = 0; i < size; i += batchSize) {
				List<ProfileAmendReportBean> subList = profileList.getProfileAmendReports().subList(i, Math.min(i + batchSize, size));
				ProfileDataList batch = new ProfileDataList ();
				batch.setProfileAmendReports(subList);
				Response resp = new Response ();
				resp.addOutput(batch);
				context.dispatch(resp);
			}
			profileList.getProfileAmendReports().clear();
			return true;
		}
		return false;
	}
	
	@SuppressWarnings("unchecked")
	private void publishEof(ServiceContext context, Response resp) {
		OutputData eofData = new OutputData();
		eofData.setData(new ProfileDataList ());
		MetaData metadata = new MetaData();
		Map map = new HashMap(context.getMetaData().getMap());
		map.put("type", "eof");
		metadata.setMap(map);
		eofData.setMetaData(metadata);
		resp.addOutput(eofData);		
	}
}
