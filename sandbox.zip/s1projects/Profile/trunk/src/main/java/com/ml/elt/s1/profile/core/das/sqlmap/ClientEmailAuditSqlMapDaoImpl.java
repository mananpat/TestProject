package com.ml.elt.s1.profile.core.das.sqlmap;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.ibatis.SqlMapClientTemplate;

import com.ibatis.sqlmap.client.SqlMapClient;
import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.profile.core.das.iface.ClientEmailAuditDao;
import com.ml.elt.s1.profile.core.sdo.ClientEmailAudit;

public class ClientEmailAuditSqlMapDaoImpl extends SqlMapClientTemplate implements ClientEmailAuditDao {
	private static Logger log = Logger.getLogger(ClientEmailAuditSqlMapDaoImpl.class);

	@SuppressWarnings("unchecked")
	public List<ClientEmailAudit> getClientEmailAuditBySwpTrdId(List<Long> swpTrdIds) throws DASException {
		List<ClientEmailAudit> ret = null;
		try {
			ret = (List<ClientEmailAudit>) queryForList("getAuditByInstid", swpTrdIds);
		}
		catch (DataAccessException daEx) {
			throw new DASException(daEx);
		}
		return ret;
	}

	@SuppressWarnings("unchecked")
	public List<ClientEmailAudit> getLatestClientEmailAuditBySwpTrdId(List<Long> swpTrdIds) throws DASException {
		List<ClientEmailAudit> ret = null;
		try {

			ret = (List<ClientEmailAudit>) queryForList("getLatestAuditByInstid", swpTrdIds);
		}
		catch (DataAccessException daEx) {
			throw new DASException(daEx);
		}
		return ret;
	}

	public void insertEmailAudit(ClientEmailAudit audit) throws DASException {
		try {
			insert("insertAudit", audit);
		}
		catch (DataAccessException daEx) {
			throw new DASException(daEx);
		}
	}

	public void insertEmailAudit(List<ClientEmailAudit> audits) throws DASException, SQLException {
		if (audits != null && audits.size() > 0) {
			SqlMapClient sqlMapClient = getSqlMapClient();
			sqlMapClient.startTransaction();
			sqlMapClient.startBatch();
			for (ClientEmailAudit audit : audits) {
				audit.setCreateDateTime(new Timestamp(System.currentTimeMillis()));
				audit.setUpdateDateTime(new Timestamp(System.currentTimeMillis()));
				log.info("Audit Insert:" + audit.getPropertyID() + ":" + audit.getAuditValue());
				insertEmailAudit(audit);
			}
			sqlMapClient.executeBatch();
			sqlMapClient.commitTransaction();
		}
	}
}
