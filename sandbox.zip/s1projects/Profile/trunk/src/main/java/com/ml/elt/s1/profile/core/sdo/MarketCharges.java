package com.ml.elt.s1.profile.core.sdo;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

import com.ml.elt.s1.platform.container.service.cache.CachableObject;
@XmlRootElement(name = "marketCharges")
public class MarketCharges implements Serializable, CachableObject, Cloneable {
	private static final long serialVersionUID = 1L;

	private String description;
	private String formula;
	private Double rate;
	private String feetype;
	private String chargetype;
	private Boolean formulaCurrencyLocal;
	private String chargeBasis;
	private String formulaExchange;
	private String formulaMarket;
	private Boolean useDefault;
	

	private Long id;
	
	public MarketCharges() {
		
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getFormula() {
		return formula;
	}
	public void setFormula(String formula) {
		this.formula = formula;
	}
	public Double getRate() {
		return rate;
	}
	public void setRate(Double rate) {
		this.rate = rate;
	}

	public Object getCacheKey() {
		return id;
	}
	public String getFeetype() {
		return feetype;
	}
	public void setFeetype(String feeType) {
		this.feetype = feeType;
	}
	public String getChargetype() {
		return chargetype;
	}
	public void setChargetype(String chargeType) {
		this.chargetype = chargeType;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getChargeBasis() {
		return chargeBasis;
	}
	public void setChargeBasis(String chargeBasis) {
		this.chargeBasis = chargeBasis;
	}
	public String getFormulaExchange() {
		return formulaExchange;
	}
	public void setFormulaExchange(String exchange) {
		this.formulaExchange = exchange;
	}
	public String getFormulaMarket() {
		return formulaMarket;
	}
	public void setFormulaMarket(String market) {
		this.formulaMarket = market;
	}
	public Boolean getFormulaCurrencyLocal() {
		return formulaCurrencyLocal;
	}
	public void setFormulaCurrencyLocal(Boolean marketChargeCurr) {
		this.formulaCurrencyLocal = marketChargeCurr;
	}
	public void setUseDefault(Boolean useDefault) {
		this.useDefault = useDefault;
	}
	public Boolean getUseDefault() {
		return useDefault;
	}
	public Object clone() throws CloneNotSupportedException {
	    //get initial bit-by-bit copy, which handles all immutable fields
	    MarketCharges result = (MarketCharges)super.clone();

	    //mutable fields need to be made independent of this object, for reasons
	    //similar to those for defensive copies - to prevent unwanted access to
	    //this object's internal state
	    Double rate = new Double(this.getRate());
	    result.setRate(rate);
	    

	    return result;
	  }


		
}
