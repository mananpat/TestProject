/**
 * 
 */
package com.ml.elt.s1.profile.core.das.iface;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.platform.container.service.das.Dao;
import com.ml.elt.s1.profile.core.sdo.Pickerlist;

/**
 * @author mpatel12
 *
 */
public interface PickerListDao extends Dao {
	
	/**
	 * returns Pickerlist List
	 * @return Pickerlist
	 * @throws DataAccessException
	 */
	public List<Pickerlist> getAllPickerlist() throws DASException; 
}
