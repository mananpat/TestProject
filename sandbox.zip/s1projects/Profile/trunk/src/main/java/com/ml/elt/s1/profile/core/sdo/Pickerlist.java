package com.ml.elt.s1.profile.core.sdo;

import com.ml.elt.s1.platform.plugins.cache.PrimaryKey;


/**
 * Pickerlist
 */
public class Pickerlist extends ProfileDomainObject {
	
	private static final long serialVersionUID = 1L;

	private Long id;
	private String name;
	private Long parentId;
	private String description;	

//	private Set<StaticData> staticDatas = new HashSet<StaticData>(0);

	public Pickerlist() {
	}

	/*public Pickerlist(Long id, String name) {
		this.id = id;
		this.name = name;
	}

	public Pickerlist(Long id, String name, Long parentId,
			String description, String createUser, Date createTime,
			String updateUser, Date updateTime, Set<StaticData> staticDatas) {
		this.id = id;
		this.name = name;
		this.parentId = parentId;
		this.description = description;
		this.createUser = createUser;
		this.createTime = createTime;
		this.updateUser = updateUser;
		this.updateTime = updateTime;
		this.staticDatas = staticDatas;
	}*/

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getParentId() {
		return this.parentId;
	}

	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
//	public Set<StaticData> getStaticDatas() {
//		return this.staticDatas;
//	}
//
//	public void setStaticDatas(Set<StaticData> staticDatas) {
//		this.staticDatas = staticDatas;
//	}
	
	/* (non-Javadoc)
	 * @see com.ml.elt.s1.platform.plugins.cache.CacheObject#getCacheKey()
	 */
	@Override
	public String getCacheKey(){
		if (primaryKey == null){
			Object[] key = new Object[]{getId()};
			primaryKey = new PrimaryKey(key, this.getClass(), true, true);
		}
		return primaryKey.getStringKey();
	}

	public static String getCacheKey(Long id){
		Object[] key = new Object[]{id};
		PrimaryKey primaryKey = new PrimaryKey(key, Pickerlist.class, true, true);
		return primaryKey.getStringKey();
	}

}
