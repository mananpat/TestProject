package com.ml.elt.s1.profile.core.sdo.comparator;

import java.util.Comparator;

import com.ml.elt.s1.profile.core.sdo.LookupProperties;

public class LookupPropertiesComparator implements Comparator<LookupProperties> {

	public int compare(LookupProperties lp1, LookupProperties lp2) {
		int ret = 0;
		if (lp1 == null && lp1 == null) {
			ret = 0;
		} else if (lp1 == null) {
			ret = -1;
		} else if (lp1 == null) {
			ret = 1;
		} else {
			Short lp1rank = lp1.getLookupRank();
			Short lp2rank = lp2.getLookupRank();
			if (lp1rank == null && lp2rank == null) {
				ret = 0;
			} else if (lp1rank == null) {
				ret = -1;
			} else if (lp2rank == null) {
				ret = 1;
			} else {
				ret = lp1rank.compareTo(lp2rank);
			}
		}
		return ret;
	}
}
