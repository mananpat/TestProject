package com.ml.elt.s1.profile.core.das.sqlmap;

import java.util.Date;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.orm.ibatis.SqlMapClientTemplate;

import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.profile.core.das.ProfileAmend;
import com.ml.elt.s1.profile.core.das.iface.ProfileAmendReportDao;
import com.ml.elt.s1.profile.transfer.gui.ProfileAmendReportBean;

/**
 * @author pagarwa2
 *
 */
public class ProfileAmendReportSqlMapDaoImpl extends SqlMapClientTemplate implements
		ProfileAmendReportDao {

	@SuppressWarnings("unchecked")
	public List<ProfileAmendReportBean> getAllProfileAmendReport()
			throws DASException {
		try{
			return (List<ProfileAmendReportBean>)queryForList("getAllProfileAmendReport");
		}catch(DataAccessException daEx){
			throw new DASException(daEx);
		}
	}

	@SuppressWarnings("unchecked")
	public List<ProfileAmendReportBean> getProfileAmendReport(List<Long> ruleIds, Date startDate, Date endDate) 
			throws DASException {
		try{
			ProfileAmend profileAmend = new ProfileAmend();
			profileAmend.setEndDate(endDate);
			profileAmend.setStartDate(startDate);
			if(ruleIds != null && !ruleIds.isEmpty()){
				profileAmend.setRuleIds(ruleIds);			
				return (List<ProfileAmendReportBean>)queryForList("getProfileAmendReportByRule",profileAmend);
			}
			else
			{
				profileAmend.setRuleIds(ruleIds);			
				return (List<ProfileAmendReportBean>)queryForList("getProfileAmendReportByDate",profileAmend);
			}
		}catch(DataAccessException daEx){
			throw new DASException(daEx);
		}
		
	}
}
