package com.ml.elt.s1.profile.plugins.automailaudit;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import com.ml.elt.s1.profile.core.sdo.ClientEmailAuditProperty;


public class ClientEmailAuditLookupResultSet implements Serializable {
	private static final long serialVersionUID = 1L;
	
	// Property ID/Value
	private Map<Long, String> auditValues = new HashMap<Long, String>();
	
	// Property Name/Type
	private Map<String, ClientEmailAuditProperty> auditPropertyTypes = new HashMap<String, ClientEmailAuditProperty>();
	
	private Integer currentAuditVersion;
	
	public Integer getCurrentAuditVersion() {
		return currentAuditVersion;
	}
	public void setCurrentAuditVersion(Integer currentAuditVersion) {
		this.currentAuditVersion = currentAuditVersion;
	}
	public Map<Long, String> getAuditValues() {
		return auditValues;
	}
	public void setAuditValues(Map<Long, String> auditValues) {
		this.auditValues = auditValues;
	}
	public Map<String, ClientEmailAuditProperty> getAuditPropertyTypes() {
		return auditPropertyTypes;
	}
	public void setAuditPropertyTypes(Map<String, ClientEmailAuditProperty> auditPropertyTypes) {
		this.auditPropertyTypes = auditPropertyTypes;
	}
	
	public boolean isEmpty() {
		return auditValues.isEmpty();
	}
}
