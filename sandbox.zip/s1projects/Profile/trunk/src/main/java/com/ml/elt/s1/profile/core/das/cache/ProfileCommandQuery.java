/**
 * 
 */
package com.ml.elt.s1.profile.core.das.cache;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.platform.container.service.cache.CacheDas;
import com.ml.elt.s1.platform.plugins.boot.DefaultConfiguration;
import com.ml.elt.s1.profile.core.sdo.Application;
import com.ml.elt.s1.profile.core.sdo.Contact;
import com.ml.elt.s1.profile.core.sdo.LookupProperties;
import com.ml.elt.s1.profile.core.sdo.PickerBean;
import com.ml.elt.s1.profile.core.sdo.Pickerlist;
import com.ml.elt.s1.profile.core.sdo.Property;
import com.ml.elt.s1.profile.core.sdo.PropertyGroup;
import com.ml.elt.s1.profile.core.sdo.PropertyGroupMapping;
import com.ml.elt.s1.profile.core.sdo.Rule;
import com.ml.elt.s1.profile.core.sdo.RuleProperty;
import com.ml.elt.s1.profile.core.sdo.StaticData;
import com.ml.elt.s1.profile.core.sdo.util.PropertyGroupCodeUtil;

/**
 * @author mpatel12
 *
 */
public class ProfileCommandQuery {
	
	private static Log log = LogFactory.getLog(ProfileCommandQuery.class);
	
	private static CacheDas cacheDas;
	
	static {
		try {
			CacheDas tempCacheDas = (CacheDas)DefaultConfiguration.getBean("cacheDas");
			cacheDas= tempCacheDas.newInstance(null, null);
			cacheDas.connect(null);
		}
		catch(Throwable t) {
			log.error(t);
		}
	}

	@SuppressWarnings("unchecked")
	public static  List getUnderlyingMarket(String exchId) throws DASException {	
		List list = cacheDas.execute(
				"select " + PickerBean.class.getName() + " from /"
				+ cacheDas.getServerId()+ "/" + PickerBean.class.getPackage().getName().replace('.', '_')
				+ "/" + PickerBean.class.getSimpleName()   
				+ " where pickerName='EXCHANGES' and pickerValue='" + exchId + "' ");
		return list;
	}
	
	@SuppressWarnings("unchecked")
	public static  List getUnderlyingRegion(String country) throws DASException {	
		List list = cacheDas.execute(
			"select " + PickerBean.class.getName() + " from /"
			+ cacheDas.getServerId()+ "/" + PickerBean.class.getPackage().getName().replace('.', '_')
			+ "/" + PickerBean.class.getSimpleName()   
			+ " where pickerName='COUNTRY' and pickerValue='" + country + "' ");
		return list;
	}

	@SuppressWarnings("unchecked")
	public static  List getContacts() throws DASException {	
		return cacheDas.read(Contact.class);
	}
	
	public static  Contact getContactById(Long contactId) throws DASException {
		Object object = cacheDas.read(Contact.class, Contact.getCacheKey(contactId),false);
		return object == null? null:(Contact)object;
	}
	
	@SuppressWarnings("unchecked")
	public static  List getApplications() throws DASException {	
		return cacheDas.read(Application.class);
	}
	
	public static  Application getApplicationById(Long applicationId) throws DASException {	
		Object object =  cacheDas.read(Application.class, Application.getCacheKey(applicationId),false);
		if(object != null) 
			return (Application)object;
		else
			return null;
	}
	
	@SuppressWarnings("unchecked")
	public static Application getApplicationByCode(String applicationCode) throws DASException {
		List list = cacheDas.execute(
				"select " + Application.class.getName() + " from /"
				+ cacheDas.getServerId()+ "/" + Application.class.getPackage().getName().replace('.', '_')
				+ "/" + Application.class.getSimpleName()   
				+ " where applicationCode='" + applicationCode + "' ");
			if(list != null && !list.isEmpty()) {
				return (Application)list.get(0);
			}
			else
				return null;
	}


	@SuppressWarnings("unchecked")
	public static  List<LookupProperties> getLookupPropertiesOfApplication(Long applicationId) throws DASException {	
		List<LookupProperties> list = null;
		LookupProperties lookpProperties = new LookupProperties();
		lookpProperties.setApplicationId(applicationId);
		Map map = cacheDas.readNode(lookpProperties);
		if(map!=null && !map.isEmpty()){
			list = new ArrayList<LookupProperties>(map.values());
		}
		return list;
	}
	
	@SuppressWarnings("unchecked")
	public static  List<Rule> getRulesOfApplication(Long applicationId) throws DASException {	
		List<Rule> list = null;
		Rule rule = new Rule();
		rule.setApplicationId(applicationId);
		Map map = cacheDas.readNode(rule);
		if(map!=null && !map.isEmpty()){
			list = new ArrayList<Rule>(map.values());
		}
		return list;
	}
	
	@SuppressWarnings("unchecked")
	public static  Rule getRuleById(Long ruleId) throws DASException {
		Object object = cacheDas.read(Rule.class, Rule.getCacheKey(ruleId));
		return object == null? null:(Rule)object;
	}
	
	
	@SuppressWarnings("unchecked")
	public static  PropertyGroup getPropertyGroupById(Long propertyGroupId) throws DASException {
		Object object = cacheDas.read(PropertyGroup.class, PropertyGroup.getCacheKey(propertyGroupId));
		return object == null? null:(PropertyGroup)object;
	}
	

	public static  Property getPropertyById(Long propertyId) throws DASException {
		Object object = cacheDas.read(Property.class, Property.getCacheKey(propertyId),false);
		return object == null? null:(Property)object;
	}

	@SuppressWarnings("unchecked")
	public static  Property getPropertyByPropCode(String propCode) throws DASException {	
		List list = cacheDas.execute(
			"select " + Property.class.getName() + " from /"
			+ cacheDas.getServerId()+ "/" + Property.class.getPackage().getName().replace('.', '_')
			+ "/" + Property.class.getSimpleName()   
			+ " where propertyCode='" + propCode + "' ");
		
		if(list != null && !list.isEmpty()) {
			return (Property)list.get(0);
		}
		else
			return null;
	}
	
	
	public static  Pickerlist getPickerlistById(Long pickerlistId) throws DASException {
		Object object = cacheDas.read(Pickerlist.class, Pickerlist.getCacheKey(pickerlistId),false);
		return object == null? null:(Pickerlist)object;
	}

	public static  StaticData getStaticDataById(Long staticDataId) throws DASException {
		Object object = cacheDas.read(StaticData.class, StaticData.getCacheKey(staticDataId),false);
		return object == null? null:(StaticData)object;
	}
	
	@SuppressWarnings("unchecked")
	public static  List<PropertyGroupMapping> getPropertyGroupMappingOfPropertyGroup(Long propertyGroupId) throws DASException {	
		List<PropertyGroupMapping> list = null;
		PropertyGroupMapping propertyGroupMapping = new PropertyGroupMapping();
		propertyGroupMapping.setPropertyGroupId(propertyGroupId);
		Map map = cacheDas.readNode(propertyGroupMapping);
		if(map!=null && !map.isEmpty()){
			list = new ArrayList<PropertyGroupMapping>(map.values());
		}
		return list;
	}
	
	@SuppressWarnings("unchecked")
	public static  List<PropertyGroup> getPropertyGroupsOfApplication(Long applicationId) throws DASException {	
		List<PropertyGroup> list = null;
		PropertyGroup propertyGroup = new PropertyGroup();
		propertyGroup.setApplicationId(applicationId);
		Map map = cacheDas.readNode(propertyGroup);
		if(map!=null && !map.isEmpty()){
			list = new ArrayList<PropertyGroup>(map.values());
		}
		return list;
	}	
	
	public static String getPropertyGroupCodeByPropertyId(Long applicationId, Long propertyId) {
		return PropertyGroupCodeUtil.getPropertyGroupCodeByPropertyId(applicationId, propertyId);
	}
	
	@SuppressWarnings("unchecked")
	public static  List<RuleProperty> getRulePropertyByRuleId(Long ruleId) throws DASException {
		List<RuleProperty> list = null;
		RuleProperty ruleProperty = new RuleProperty();
		ruleProperty.setRuleId(ruleId);
		Map map = cacheDas.readNode(ruleProperty);
		if(map!=null && !map.isEmpty()){
			list = new ArrayList<RuleProperty>(map.values());
		}
		return list;
	}
	
	
	@SuppressWarnings("unchecked")
	public static  Map<Long,List<RuleProperty>> getRulePropertyMapByRuleId(Long ruleId) throws DASException {
		Map<Long,List<RuleProperty>>  mapRuleProp = null;
		RuleProperty ruleProperty = new RuleProperty();
		ruleProperty.setRuleId(ruleId);
		Map map = cacheDas.readNode(ruleProperty);
		if(map!=null && !map.isEmpty()){
			mapRuleProp = new HashMap<Long, List<RuleProperty>>();
			RuleProperty rProp = null;
			List<RuleProperty> list = null;
			Long key = null;
			for(Object obj:map.values()){
				rProp = (RuleProperty)obj;
				key = rProp.getPropertyId(); 
				list =  mapRuleProp.get(key);
				if(list==null){
					list = new ArrayList<RuleProperty>();
					mapRuleProp.put(key, list);
				}
				list.add(rProp);
			}
		}
		return mapRuleProp;
	}
	
	
	@SuppressWarnings("unchecked")
	public static  List<StaticData> getStaticDataOfPickerlist(Long pickerListId) throws DASException {	
		List<StaticData> list = null;
		StaticData staticData= new StaticData();
		staticData.setPickerListId(pickerListId);
		Map map = cacheDas.readNode(staticData);
		if(map!=null && !map.isEmpty()){
			list = new ArrayList<StaticData>(map.values());
		}
		return list;
	}

	@SuppressWarnings("unchecked")
	public static List<PropertyGroupMapping> getPropertyGroupMappingByPropertyId(Long propertyId) throws DASException {
		List list = cacheDas.execute(
				"select " + PropertyGroupMapping.class.getName() + " from /"
				+ cacheDas.getServerId()+ "/" + PropertyGroupMapping.class.getPackage().getName().replace('.', '_')
				+ "/" + PropertyGroupMapping.class.getSimpleName()   
				+ " where propertyId=" + propertyId );
			return list;
	}
}
