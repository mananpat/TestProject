/**
 * 
 */
package com.ml.elt.s1.profile.plugins.cache.loaders;

import java.util.List;

import org.apache.log4j.Logger;

import com.ml.elt.s1.platform.container.service.cache.CacheDas;
import com.ml.elt.s1.platform.plugins.das.Das;
import com.ml.elt.s1.profile.core.das.iface.RulePropertyDao;
import com.ml.elt.s1.profile.core.sdo.RuleProperty;
import com.ml.elt.s1.profile.plugins.cache.Worker;


/**
 * @author mpatel12
 *
 */
public class RulePropertyLoader extends Worker {

	private static Logger log = Logger.getLogger(RulePropertyLoader.class);
	
	private List<Long> appIds;
	
	public RulePropertyLoader(Das daoManagerDb, CacheDas cacheDas, List<Long> appIdList) {	
		super(daoManagerDb, cacheDas);
		appIds = appIdList;
	}
	
	@SuppressWarnings("unchecked")
	public void doWork() throws Exception {
		log.info("loading RuleProperties...");		
		List<RuleProperty> list = null;
		RulePropertyDao dbDao = (RulePropertyDao)daoManagerDb.getDao(RuleProperty.class);
		if(appIds != null && !appIds.isEmpty()){
			list = dbDao.getAllRulePropertiesByApp(appIds);
			if(list != null && !list.isEmpty()){
				write(list);
			}
			log.info("done - loading RuleProperties and writing to cache.");
		}	
	}
}
