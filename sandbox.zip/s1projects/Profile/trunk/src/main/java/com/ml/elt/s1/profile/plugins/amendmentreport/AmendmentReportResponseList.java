package com.ml.elt.s1.profile.plugins.amendmentreport;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class AmendmentReportResponseList{
	private List<AmendmentReportResponse> amendmentReportResponseList;

	public List<AmendmentReportResponse> getAmendmentReportResponseList() {
		return amendmentReportResponseList;
	}

	public void setAmendmentReportResponseList(
			List<AmendmentReportResponse> amendmentReportResponseList) {
		this.amendmentReportResponseList = amendmentReportResponseList;
	}
}
