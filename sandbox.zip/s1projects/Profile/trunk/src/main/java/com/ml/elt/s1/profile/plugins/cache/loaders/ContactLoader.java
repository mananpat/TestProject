/**
 * 
 */
package com.ml.elt.s1.profile.plugins.cache.loaders;

import java.util.List;

import org.apache.log4j.Logger;

import com.ml.elt.s1.platform.container.service.cache.CacheDas;
import com.ml.elt.s1.platform.plugins.das.Das;
import com.ml.elt.s1.profile.core.das.iface.ContactDao;
import com.ml.elt.s1.profile.core.sdo.Contact;
import com.ml.elt.s1.profile.plugins.cache.Worker;


/**
 * @author mpatel12
 *
 */
public class ContactLoader extends Worker {

	private static Logger log = Logger.getLogger(ContactLoader.class);
	
	public ContactLoader(Das daoManagerDb, CacheDas cacheDas) {	
		super(daoManagerDb, cacheDas);
	}
	
	public void doWork() throws Exception {		
		log.info("loading Contacts...");
		ContactDao contactDao = (ContactDao)daoManagerDb.getDao(Contact.class);
		List<Contact> list = contactDao.getAllContacts();
		if(list != null && !list.isEmpty()){
			write(list);
		}
		log.info("done - loading Contacts and writing to cache.");	
	}
}
