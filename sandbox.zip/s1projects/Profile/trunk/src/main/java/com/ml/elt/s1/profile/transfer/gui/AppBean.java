package com.ml.elt.s1.profile.transfer.gui;

public class AppBean {
	private String applicationCode;
	private String description;
	public void setApplicationCode(String applicationCode) {
		this.applicationCode = applicationCode;
	}
	public String getApplicationCode() {
		return applicationCode;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getDescription() {
		return description;
	}
	
}
