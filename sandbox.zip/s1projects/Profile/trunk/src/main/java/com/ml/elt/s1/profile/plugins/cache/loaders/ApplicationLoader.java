/**
 * 
 */
package com.ml.elt.s1.profile.plugins.cache.loaders;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;

import com.ml.elt.s1.platform.container.service.cache.CacheDas;
import com.ml.elt.s1.platform.plugins.boot.DefaultConfiguration;
import com.ml.elt.s1.platform.plugins.das.Das;
import com.ml.elt.s1.profile.core.das.iface.ApplicationDao;
import com.ml.elt.s1.profile.core.sdo.Application;
import com.ml.elt.s1.profile.plugins.cache.Worker;


/**
 * @author mpatel12
 *
 */
public class ApplicationLoader extends Worker {

	private static Logger log = Logger.getLogger(ApplicationLoader.class);
	
	private List<Long> appIds;
	
	public ApplicationLoader(Das daoManagerDb, CacheDas cacheDas, List<Long> appIdList) {	
		super(daoManagerDb, cacheDas);
		appIds = appIdList;
	}
	
	public void doWork() throws Exception {
		log.info("loading Applications...");
		ApplicationDao dbDao = (ApplicationDao) daoManagerDb.getDao(Application.class);
		List<String> appCodeList = null;		
		if(appCodeList == null) 
			appCodeList = getApplicationsToLoad();
		
		if(appCodeList != null && !appCodeList.isEmpty()) {
			List<Application> list = dbDao.getApplicationsByAppCode(appCodeList);
			if(list != null && !list.isEmpty()){
				write(list);
				for(Application app : list){
					appIds.add(app.getId());
				}
			}
		}
		
		log.info("done - loading Applications and writing to cache.");		
	}
	
	public List<String> getApplicationsToLoad() {
    	List<String> applicationCodeList = new ArrayList<String>();
	    Properties pro = DefaultConfiguration.getInstanceProperties();
	    String profileApplications = pro.getProperty("profileApplications");    	
	    if (profileApplications != null && !"".equals(profileApplications.trim())) {
	    	log.info("Profile Aplications configured: " + profileApplications);
	    	StringTokenizer st = new StringTokenizer(profileApplications,",;:");
	    	while (st.hasMoreElements()){
	    		applicationCodeList.add((String)st.nextElement());
	    	}
	    }
	    else 
	    	log.error("Property 'profileApplications' is not specified in instance.properties. Not loading any applications.");    	
    	
    	return applicationCodeList;
    }	
}
