package com.ml.elt.s1.profile.plugins.cache.loaders;

import java.util.List;

import com.ml.elt.s1.platform.container.service.cache.CacheDas;
import com.ml.elt.s1.platform.plugins.das.Das;
import com.ml.elt.s1.profile.core.das.util.DBDataLoader;
import com.ml.elt.s1.profile.core.sdo.GiveupBrokerCodes;
import com.ml.elt.s1.profile.plugins.cache.Worker;

public class GiveupBrokerCodesLoader extends Worker {

	public GiveupBrokerCodesLoader(Das daoManagerDb, CacheDas cacheDas) {
		super(daoManagerDb, cacheDas);
	}

	@Override
	public void doWork() throws Exception {
		List<GiveupBrokerCodes> list = DBDataLoader.loadGiveupBrokerCodes(false);
		if(list != null && !list.isEmpty()){
			write(list);
		}
	}

}
