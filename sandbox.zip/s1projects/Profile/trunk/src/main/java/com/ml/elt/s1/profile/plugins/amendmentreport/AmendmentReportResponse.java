package com.ml.elt.s1.profile.plugins.amendmentreport;

import java.util.Date;

public class AmendmentReportResponse{	
	private long origTransId;
	private long groupId;
	private String field;
	private String value;
	private String newValue;
	private String oldValue;
	private String updateUser;
	private Date updateDateTime;
	private long transId;
	private long ruleId;	
	private boolean activeFlag;
	private String operationType;
	private String ruleOperationType;
	
	public long getRuleId() {
		return ruleId;
	}
	public void setRuleId(long ruleId) {
		this.ruleId = ruleId;
	}	
	public boolean getActiveFlag() {
		return activeFlag;
	}
	public void setActiveFlag(boolean activeFlag) {
		this.activeFlag = activeFlag;
	}
	public String getOperationType() {
		return operationType;
	}
	public void setOperationType(String operationType) {
		this.operationType = operationType;
	}
	public String getRuleOperationType() {
		return ruleOperationType;
	}
	public void setRuleOperationType(String ruleOperationType) {
		this.ruleOperationType = ruleOperationType;
	}
	public long getTransId() {
		return transId;
	}
	public void setTransId(long transId) {
		this.transId = transId;
	}
	public long getOrigTransId() {
		return origTransId;
	}
	public void setOrigTransId(long origTransId) {
		this.origTransId = origTransId;
	}
	public String getField() {
		return field;
	}
	public void setField(String field) {
		this.field = field;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getOldValue() {
		return oldValue;
	}
	public void setOldValue(String oldValue) {
		this.oldValue = oldValue;
	}
	public String getUpdateUser() {
		return updateUser;
	}
	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}
	public Date getUpdateDateTime() {
		return updateDateTime;
	}
	public void setUpdateDateTime(Date updateDateTime) {
		this.updateDateTime = updateDateTime;
	}
	public String getNewValue() {
		return newValue;
	}
	public void setNewValue(String newValue) {
		this.newValue = newValue;
	}
	public long getGroupId() {
		return groupId;
	}
	public void setGroupId(long groupId) {
		this.groupId = groupId;
	}
	
		
}
