package com.ml.elt.s1.profile.util;

public class ProfileApplicationConstant {
	
	public static final String MARKET_CHARGES = "MARKET_CHARGES";
	public static final String GIVEUP_BROKER_CODES = "GIVEUP_BROKER_CODES";
	public static final String PRICE_TOLERANCES = "PRICE_TOLERANCES";
		
	public static final String REQ_TYPE = "reqtype";
	public static final String REQ_ID = "reqid";
	public static final String ERROR_REQ_ID = "errorReqId";
	
	public static final String TYPE = "type";
	public static final String EOF = "eof";
	
	public static final String XML_EXCEPTION = "xml-exception";
	public static final String XML_CONTACTS = "xml-contacts";
	public static final String XML_EXCEPTION_CONTACT = "xml-exception-contact";
	
	public static final String CONTEXT_APP_CODE = "appCode";
	public static final String CONTEXT_USERID = "userId";
	public static final String CONTEXT_COMMAND = "command";
	public static final String CONTEXT_BROADCAST_COMMAND = "broadcast-command";
	
	public static final String INSTANCE_LOAD_PICKERBEAN = "instance.profile.load.pickerbean";
	
}