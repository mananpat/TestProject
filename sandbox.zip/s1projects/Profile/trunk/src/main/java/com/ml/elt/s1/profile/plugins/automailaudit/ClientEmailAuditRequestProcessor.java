package com.ml.elt.s1.profile.plugins.automailaudit;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.ml.elt.s1.platform.container.exception.ExceptionHandler;
import com.ml.elt.s1.platform.container.service.cache.CacheDas;
import com.ml.elt.s1.platform.plugins.das.Das;
import com.ml.elt.s1.platform.plugins.das.RamDas;
import com.ml.elt.s1.profile.core.das.iface.ClientEmailAuditDao;
import com.ml.elt.s1.profile.core.sdo.ClientEmailAudit;
import com.ml.elt.s1.profile.core.sdo.ClientEmailAuditProperty;

/*
 * This Class is not defined as message processor right now as it has no request to make it directly accessible from user clients.
 * 
 * 
 * @author siucha
 *
 */
public class ClientEmailAuditRequestProcessor {
	private static Logger log = Logger.getLogger(ClientEmailAuditRequestProcessor.class);

	private Das daoManagerDb;
	private CacheDas cacheDas;
	private List<ClientEmailAuditProperty> properties;

	public ClientEmailAuditRequestProcessor(CacheDas cacheDas) {
		daoManagerDb = new RamDas();
		this.cacheDas = cacheDas;
		loadPropertiesFromCache();
	}

	public ClientEmailAuditLookupResultSet getLatestAuditWithActiveProperty(List<Long> swpTrdId) {
		ClientEmailAuditDao dao = (ClientEmailAuditDao) daoManagerDb.getDao(ClientEmailAudit.class);
		try {
			List<ClientEmailAudit> mailAudit = dao.getLatestClientEmailAuditBySwpTrdId(swpTrdId);
			return buildResultSet(mailAudit);
		}
		catch (Exception e) {
			ExceptionHandler.getInstance().handleSystemException(e);
			return null;
		}
	}

	public ClientEmailAuditLookupResultSet getAudits(List<Long> swpTrdIds) {
		return null;
	}

	// Save audit items into the profile database
	public void saveAudits(List<ClientEmailAudit> auditItems) {
		ClientEmailAuditDao dao = (ClientEmailAuditDao) daoManagerDb.getDao(ClientEmailAudit.class);
		try {			
			dao.insertEmailAudit(auditItems);
		}
		catch (Exception e) {
			ExceptionHandler.getInstance().handleSystemException(e);			
		}
	}

	public Map<String, ClientEmailAuditProperty> getPropertiesAsMap() {
		Map<String, ClientEmailAuditProperty> ret = new HashMap<String, ClientEmailAuditProperty>();
		for (ClientEmailAuditProperty property : properties) {
			ret.put(property.getPropertyCode(), property);
		}
		return ret;
	}

	@SuppressWarnings("unchecked")
	private void loadPropertiesFromCache() {
		String query = "select com.ml.elt.s1.profile.core.sdo.ClientEmailAuditProperty from /default/com_ml_elt_s1_profile_core_sdo/ClientEmailAuditProperty where id > 0";
		try {
			properties = (List<ClientEmailAuditProperty>) cacheDas.execute(query);
			log.info(properties.size() + " loaded in init of ClientEmailAuditRequestProcessor.");
		}
		catch (Throwable e) {
			properties = new ArrayList<ClientEmailAuditProperty>();
			String errMessage = e.getMessage();
			log.info(errMessage, e);
			ExceptionHandler.getInstance().handleSystemException(e);
		}
	}

	private ClientEmailAuditLookupResultSet buildResultSet(List<ClientEmailAudit> mailAudit) {
		ClientEmailAuditLookupResultSet ret = new ClientEmailAuditLookupResultSet();
		for (ClientEmailAudit audit : mailAudit) {
			ret.getAuditValues().put(audit.getPropertyID(), audit.getAuditValue());
			ret.setCurrentAuditVersion(audit.getVersion());
			log.info(audit.getInstId() + " Instrument ID loaded");
		}

		for (ClientEmailAuditProperty property : properties) {
			if (property.getIsActive()) {
				ret.getAuditPropertyTypes().put(property.getPropertyCode(), property);
			}
		}
		return ret;
	}
}
