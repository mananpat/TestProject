package com.ml.elt.s1.profile.plugins.cache;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ml.elt.s1.platform.container.exception.ExceptionHandler;
import com.ml.elt.s1.platform.container.service.cache.CachableObject;
import com.ml.elt.s1.platform.container.service.cache.CacheDas;
import com.ml.elt.s1.platform.plugins.das.Das;
import com.ml.elt.s1.platform.plugins.das.RamDas;
import com.ml.elt.s1.profile.core.sdo.Application;
import com.ml.elt.s1.profile.core.sdo.ClientEmailAuditProperty;
import com.ml.elt.s1.profile.core.sdo.Contact;
import com.ml.elt.s1.profile.core.sdo.GiveupBrokerCodes;
import com.ml.elt.s1.profile.core.sdo.PriceTolerances;
import com.ml.elt.s1.profile.core.sdo.LookupProperties;
import com.ml.elt.s1.profile.core.sdo.MarketCharges;
import com.ml.elt.s1.profile.core.sdo.PickerBean;
import com.ml.elt.s1.profile.core.sdo.Pickerlist;
import com.ml.elt.s1.profile.core.sdo.Property;
import com.ml.elt.s1.profile.core.sdo.PropertyGroup;
import com.ml.elt.s1.profile.core.sdo.PropertyGroupMapping;
import com.ml.elt.s1.profile.core.sdo.Rule;
import com.ml.elt.s1.profile.core.sdo.RuleProperty;
import com.ml.elt.s1.profile.core.sdo.StaticData;
import com.ml.elt.s1.profile.impl.ProfileLoader;
import com.ml.elt.s1.profile.plugins.cache.loaders.ApplicationLoader;
import com.ml.elt.s1.profile.plugins.cache.loaders.ClientEmailAuditPropertyLoader;
import com.ml.elt.s1.profile.plugins.cache.loaders.ContactLoader;
import com.ml.elt.s1.profile.plugins.cache.loaders.GiveupBrokerCodesLoader;
import com.ml.elt.s1.profile.plugins.cache.loaders.LookupPropertyLoader;
import com.ml.elt.s1.profile.plugins.cache.loaders.MarketChargesLoader;
import com.ml.elt.s1.profile.plugins.cache.loaders.PickerBeanLoader;
import com.ml.elt.s1.profile.plugins.cache.loaders.PriceToleranceLoader;
import com.ml.elt.s1.profile.plugins.cache.loaders.PropertyGroupLoader;
import com.ml.elt.s1.profile.plugins.cache.loaders.PropertyGroupMappingLoader;
import com.ml.elt.s1.profile.plugins.cache.loaders.PropertyLoader;
import com.ml.elt.s1.profile.plugins.cache.loaders.RuleLoader;
import com.ml.elt.s1.profile.plugins.cache.loaders.RulePropertyLoader;
import com.ml.elt.s1.profile.plugins.cache.loaders.StaticDataLoader;
import com.ml.elt.s1.sw.plugins.exception.FatalPlatformException;

/**
 * @author mpatel12
 *
 * Profile Data Start Stop
 * 
 */
public class ProfileDataReloader {
	
	private static Log log = LogFactory.getLog(ProfileDataReloader.class);

	ThreadGroup group = new ThreadGroup("Profile Data Reloader:" + System.currentTimeMillis());
	
	public Long lock = 0L;
	
	public final static String CACHE_CONFIGURATION_ERROR = "Cache server is not configured.";

	private List<Long> appIds = new ArrayList<Long>();
	
	private static final String reloadlock = "RELOAD_LOCK";
	
	
	public ProfileDataReloader() {
	}
	
	
	public boolean reloadData(CacheDas cacheDas) {
		Das daoManagerDb = new RamDas();
		synchronized (reloadlock) {
			appIds.clear();
			log.info("Inside startup in ProfileDataReloader.");
			if (cacheDas == null) 
				throw new FatalPlatformException(CACHE_CONFIGURATION_ERROR);
			
			List<List<? extends CachableObject>>  groups = new ArrayList<List<? extends CachableObject>>();
	
			execute(setCounter(false,groups,new ContactLoader(daoManagerDb, cacheDas)));
			execute(setCounter(false,groups,new PropertyLoader(daoManagerDb, cacheDas)));
			execute(setCounter(false,groups,new PropertyGroupLoader(daoManagerDb, cacheDas)));
			execute(setCounter(false,groups,new PropertyGroupMappingLoader(daoManagerDb, cacheDas)));
			execute(setCounter(false,groups,new LookupPropertyLoader(daoManagerDb, cacheDas)));
	
			execute(setCounter(false,groups,new ApplicationLoader(daoManagerDb, cacheDas,appIds)),false);
			execute(setCounter(false,groups,new RuleLoader(daoManagerDb, cacheDas,appIds)),false);
			execute(setCounter(false,groups,new RulePropertyLoader(daoManagerDb, cacheDas,appIds)),false);
			execute(setCounter(false,groups,new StaticDataLoader(daoManagerDb, cacheDas)),false);
			execute(setCounter(false,groups,new ClientEmailAuditPropertyLoader(daoManagerDb, cacheDas)), false);
	
			while( lock > 0) {
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					ExceptionHandler.getInstance().handleFatalException("Failed in cache initial loader.", e);
				}
			}
	
			
			try
			{
				cacheDas.remove(RuleProperty.class);
				cacheDas.remove(StaticData.class);
				cacheDas.remove(PickerBean.class);
				cacheDas.remove(Pickerlist.class);
				
				cacheDas.remove(Contact.class);
				cacheDas.remove(LookupProperties.class);
				cacheDas.remove(Property.class);
				cacheDas.remove(PropertyGroup.class);
				cacheDas.remove(PropertyGroupMapping.class);
				cacheDas.remove(Application.class);
				cacheDas.remove(Rule.class);
				cacheDas.remove(ClientEmailAuditProperty.class);
				
				for(List<? extends CachableObject> g : groups){
					if(g != null && !g.isEmpty()) 
						cacheDas.write(g);
				}
				cacheDas.remove(MarketCharges.class);
				cacheDas.remove(GiveupBrokerCodes.class);
				cacheDas.remove(PickerBean.class);
				cacheDas.remove(Pickerlist.class);
				cacheDas.remove(PriceTolerances.class);
				
				execute(new PickerBeanLoader(daoManagerDb, cacheDas),false);
				execute(new MarketChargesLoader(daoManagerDb, cacheDas),false);
				execute(new GiveupBrokerCodesLoader(daoManagerDb, cacheDas),false);
				execute(new PriceToleranceLoader(daoManagerDb, cacheDas),false);

			}
			catch(Throwable t){
				throw new FatalPlatformException("Exceptions in reloadProfile in ProfileDataReloader.");
			}

			while( lock > 0) {
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					ExceptionHandler.getInstance().handleFatalException("Failed in cache initial loader.", e);
				}
			}
			
			try
			{
				ProfileLoader profileLoader = ProfileLoader.getInstance();
				profileLoader.reloadProfile();
			}
			catch(Throwable t){
				log.error("Exceptions in reloadProfile in ProfileDataReloader.",t);
			}
			log.info("Done rebuildProfileIndex with DB Data refresh");
		}
		return true;		
	}
	
	
	public boolean rebuildProfileIndex(String appCode) {
		try
		{
			ProfileLoader profileLoader = ProfileLoader.getInstance();
			profileLoader.reloadProfile(appCode);
		}
		catch(Throwable t){
			log.error("Exceptions in rebuildProfileIndex for appcode:" + appCode,t);
		}
		log.info("Done rebuildProfileIndex for appcode:" + appCode);
		return true;
	}
	
	public boolean rebuildProfileIndex(String appCode,Long ruleId ) {
		try
		{
			ProfileLoader profileLoader = ProfileLoader.getInstance();
			profileLoader.reloadProfile(appCode,ruleId);
		}
		catch(Throwable t){
			log.error("Exceptions in rebuildProfileIndex for appcode:" + appCode + " ruleId:" + ruleId ,t);
		}
		log.info("Done rebuildProfileIndex for appcode:" + appCode + " ruleId:" + ruleId);
		return true;
	}

	
	private void execute(Worker worker) {
		execute(worker, true);
	}
	
	private void execute(Worker worker, boolean isNoJoin) {
		try {
			worker.setCounter(lock);
			Thread thread = new Thread(group, worker);
			thread.start();		
			if (!isNoJoin) thread.join();
		} catch (InterruptedException e) {
			log.error(e);
		}
	}
	
	private Worker setCounter(boolean writeToCache, List<List<? extends CachableObject>>  groups, Worker worker) {
		worker.setWriteToCache(writeToCache);
		worker.setGroups(groups);
		return worker;
	}
}
