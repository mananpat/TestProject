package com.ml.elt.s1.profile.core.das.util;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.platform.container.service.cache.CacheDas;
import com.ml.elt.s1.platform.plugins.boot.DefaultConfiguration;
import com.ml.elt.s1.platform.plugins.das.Das;
import com.ml.elt.s1.platform.plugins.das.RamDas;
import com.ml.elt.s1.profile.core.das.ProfileAmend;
import com.ml.elt.s1.profile.core.das.cache.ProfileCommandQuery;
import com.ml.elt.s1.profile.core.das.iface.ApplicationDao;
import com.ml.elt.s1.profile.core.das.iface.ContactDao;
import com.ml.elt.s1.profile.core.das.iface.LookupPropertiesDao;
import com.ml.elt.s1.profile.core.das.iface.PickerListDao;
import com.ml.elt.s1.profile.core.das.iface.ProfileAmendReportDao;
import com.ml.elt.s1.profile.core.das.iface.PropertyDao;
import com.ml.elt.s1.profile.core.das.iface.PropertyGroupDao;
import com.ml.elt.s1.profile.core.das.iface.PropertyGroupMappingDao;
import com.ml.elt.s1.profile.core.das.iface.RuleDao;
import com.ml.elt.s1.profile.core.das.iface.RulePropertyDao;
import com.ml.elt.s1.profile.core.das.iface.StaticDataDao;
import com.ml.elt.s1.profile.core.sdo.Application;
import com.ml.elt.s1.profile.core.sdo.Contact;
import com.ml.elt.s1.profile.core.sdo.GiveupBrokerCodes;
import com.ml.elt.s1.profile.core.sdo.PriceTolerances; 
import com.ml.elt.s1.profile.core.sdo.LookupProperties;
import com.ml.elt.s1.profile.core.sdo.MarketCharges;
import com.ml.elt.s1.profile.core.sdo.PickerBean;
import com.ml.elt.s1.profile.core.sdo.Pickerlist;
import com.ml.elt.s1.profile.core.sdo.Property;
import com.ml.elt.s1.profile.core.sdo.PropertyGroup;
import com.ml.elt.s1.profile.core.sdo.PropertyGroupMapping;
import com.ml.elt.s1.profile.core.sdo.Rule;
import com.ml.elt.s1.profile.core.sdo.RuleProperty;
import com.ml.elt.s1.profile.core.sdo.StaticData;
import com.ml.elt.s1.profile.transfer.gui.ProfileAmendReportBean;
import com.ml.elt.s1.profile.util.ProfileApplicationConstant;

public class DBDataLoader {

	private static Log log = LogFactory.getLog(DBDataLoader.class);
	
	private static ApplicationDao applicationDao;
	private static RuleDao ruleDao;
	private static RulePropertyDao rulePropertyDao;
	
	private static LookupPropertiesDao lookupPropertiesDao;
	
	private static PropertyGroupDao propertyGroupDao;
	private static PropertyGroupMappingDao propertyGroupMappingDao;
	
	private static PropertyDao propertyDao;
	
	private static PickerListDao pickerListDao;
	private static ContactDao contactDao;
	private static StaticDataDao staticDataDao;
	private static ProfileAmendReportDao profileAmendReportDao;
	
	private static CacheDas cacheDas;
	
	private static Map<Long, MarketCharges> marketCharges = new HashMap<Long, MarketCharges> ();
	
	private static Map<Long, GiveupBrokerCodes> giveupBrokerCodes = new HashMap<Long, GiveupBrokerCodes> ();
	
	private static Map<Long,PriceTolerances>  priceTolerances=new HashMap<Long, PriceTolerances> ();
	
	private static List<String> appCodeList = null;
	
	private static boolean loadPickBean = false;
	
	static {
		Das das = new RamDas();
		try {
			applicationDao = (ApplicationDao)das.getDao(Application.class);
			ruleDao = (RuleDao)das.getDao(Rule.class);
			rulePropertyDao = (RulePropertyDao)das.getDao(RuleProperty.class);
			
			lookupPropertiesDao = (LookupPropertiesDao)das.getDao(LookupProperties.class);
			
			propertyGroupDao = (PropertyGroupDao)das.getDao(PropertyGroup.class);
			propertyGroupMappingDao = (PropertyGroupMappingDao)das.getDao(PropertyGroupMapping.class);
			
			propertyDao = (PropertyDao)das.getDao(Property.class);
			
			pickerListDao = (PickerListDao)das.getDao(Pickerlist.class);
			
			contactDao = (ContactDao)das.getDao(Contact.class);
			
			staticDataDao = (StaticDataDao)das.getDao(StaticData.class);
			
			loadPickBean = Boolean.parseBoolean(DefaultConfiguration.getInstanceProperties().getProperty(ProfileApplicationConstant.INSTANCE_LOAD_PICKERBEAN, "false"));
			
			profileAmendReportDao = (ProfileAmendReportDao) das.getDao(ProfileAmend.class);
			
			CacheDas tempCacheDas = (CacheDas)DefaultConfiguration.getBean("cacheDas");
			cacheDas= tempCacheDas.newInstance(null, null);
			cacheDas.connect(null);
		}
		catch(Throwable t) {
			log.error("Error while loading DAO bean from configuration: ", t);
		}
	}
	
	public static void loadAllProfile() throws DASException{
		log.info("Loading Profile data from database...");
		long startTime = System.currentTimeMillis();
		loadAllApplications();
		loadLookupProperties();
		loadProperty();
		loadPropertyGroupMapping();
		loadPropertyGroups();
		loadRuleProperties();
		loadRules();
		long endTime = System.currentTimeMillis();
		log.info("Loading Profile data from database completed in " + (endTime-startTime) + " ms");
	}
	
	public static void loadAllPickers() throws DASException{
		log.info("Loading Pickers data from database...");
		long startTime = System.currentTimeMillis();
		loadStaticData();
		loadPickerBean();
		loadContacts();
		loadMarketCharges(true);
		loadGiveupBrokerCodes(true);
		long endTime = System.currentTimeMillis();
		log.info("Loading Pickers data from database completed in " + (endTime-startTime) + " ms");
	}
	
	public static List<Property> loadProperty() throws DASException {
		List<Property> list = propertyDao.getAllProperties();
		if(list != null && !list.isEmpty())
			cacheDas.write(list);
		return list;
	}
	
	public static List<Application> loadAllApplications() throws DASException{
		log.info("loading Applications...");
		if(appCodeList == null) 
			appCodeList = getApplicationsToLoad();
		return loadApplications(appCodeList);		
	}

	public static List<Application> loadApplications(List<String> appCodeList) throws DASException{
		if(appCodeList != null && !appCodeList.isEmpty()) {
			List<Application> list = applicationDao.getApplicationsByAppCode(appCodeList);
			if(list != null && !list.isEmpty())
				cacheDas.write(list);
			log.info("done - loading Applications and writing to cache.");		
			return list;
		}
		return null;
	}
	
	public static List<LookupProperties> loadLookupProperties() throws DASException {
		log.info("loading LookupProperties...");
		List<LookupProperties> list = lookupPropertiesDao.getAllLookupProperties();
		if(list != null && !list.isEmpty())
			cacheDas.write(list);
		log.info("done - loading LookupProperties and writing to cache.");	
		return list;
	}
	
	public static List<PropertyGroup> loadPropertyGroups() throws DASException {
		log.info("loading PropertyGroups...");
		List<PropertyGroup> list = propertyGroupDao.getAllPropertyGroups();
		if(list != null && !list.isEmpty())
			cacheDas.write(list);
		log.info("done - loading PropertyGroups and writing to cache.");
		return list;
	}
	public static List<PropertyGroupMapping> loadPropertyGroupMapping() throws DASException {
		log.info("loading PropertyGroupMapping...");
		List<PropertyGroupMapping> list = propertyGroupMappingDao.getAllPropertyGroupMappings();
		if(list != null && !list.isEmpty())
			cacheDas.write(list);
		log.info("done - loading PropertyGroupMapping and writing to cache.");
		return list;
	}
	
	@SuppressWarnings("unchecked")
	public static List<Rule> loadRules() throws DASException {
		log.info("loading Rules...");			
		List<Long> appIdList = null;
		List<Rule> list = null;
		List<Application> apps = ProfileCommandQuery.getApplications();
		if(apps != null && !apps.isEmpty()){
			appIdList = new ArrayList<Long>();		
			for (Application app : apps) {
				if(app != null)
					appIdList.add(app.getId());
			}
		}
		if(appIdList != null && !appIdList.isEmpty()){
			list = ruleDao.getAllRulesByApp(appIdList);
			if(list != null && !list.isEmpty())
				cacheDas.write(list);
		}
		
		log.info("done - loading Rules and writing to cache.");
		return list;
	}
	
	
	public static Rule loadRule(Long ruleId) throws DASException {
		Rule rule = null;
		if(ruleId!=null){
			rule = ruleDao.getRule(ruleId);
		}
		return rule ;
	}
	
	@SuppressWarnings("unchecked")
	public static List<RuleProperty> loadRuleProperties() throws DASException {
		log.info("loading RuleProperties...");		
		List<Long> appIdList = null;
		List<RuleProperty> list = null;
		List<Application> apps = ProfileCommandQuery.getApplications();
		if(apps != null && !apps.isEmpty()){
			appIdList = new ArrayList<Long>();		
			for (Application app : apps) {
				if(app != null)
					appIdList.add(app.getId());
			}
		}
		if(appIdList != null && !appIdList.isEmpty()){
			list = rulePropertyDao.getAllRulePropertiesByApp(appIdList);
			if(list != null && !list.isEmpty())
				cacheDas.write(list);
			log.info("done - loading RuleProperties and writing to cache.");
		}
		
		return list;
	}
	

	public static List<RuleProperty> loadRuleProperties(Long ruleId) throws DASException {
		List<RuleProperty> list = null;
		if(ruleId!=null){
			list = rulePropertyDao.getRulePropertyListForRuleId(ruleId);
		}
		return list;
	}

	
	public static List<Contact> loadContacts() throws DASException {
		log.info("loading Contacts...");
		List<Contact> list = contactDao.getAllContacts();
		if(list != null && !list.isEmpty())
			cacheDas.write(list);
		log.info("done - loading Contacts and writing to cache.");
		return list;
	}
	
	public static List<StaticData> loadStaticData() throws DASException{
		log.info("loading StaticData...");
		List<StaticData> list = staticDataDao.getAllStaticData();
		if(list != null && !list.isEmpty())
			cacheDas.write(list);
		log.info("done - loading StaticData and writing to cache.");
		return list;
	}
	
	@SuppressWarnings("unchecked")
	public static List<PickerBean> loadPickerBean() throws DASException{
		log.info("loading PickerBean...");
		List<Pickerlist> pickerList = pickerListDao.getAllPickerlist();
		List<PickerBean> listBean = new ArrayList<PickerBean>();
		
		if(loadPickBean && pickerList != null && !pickerList.isEmpty()) {
			cacheDas.write(pickerList);
		
			for(Pickerlist picker: pickerList){
				String pickerName = picker.getName();
				List<StaticData> staticData =  ProfileCommandQuery.getStaticDataOfPickerlist(picker.getId());
				Long pickerParentId = picker.getParentId();
				Pickerlist parentPicker = null;
				if(pickerParentId != null){
					parentPicker = ProfileCommandQuery.getPickerlistById(pickerParentId);
				}
				if(staticData==null){
					log.error("Picker Data is missing:"+picker.getId());
				}
				if(staticData!=null && !staticData.isEmpty()){
					for(StaticData sd : staticData){
						PickerBean bean = new PickerBean();
						String pickerVal =  sd.getValue();
						String descr = sd.getDescription();
						Long parentId = sd.getParentId();
						if(parentId != null && parentId!=0 && parentPicker != null){
							StaticData staData = ProfileCommandQuery.getStaticDataById(parentId);
							if(staData!=null){
								bean.setParentType(staData.getValue());
							}else {
								log.error("Unable to Find Static Data for:"+parentId);
							}
						}
						if (parentPicker != null) 
							bean.setParentPickerType(parentPicker.getName());
						bean.setPickerName(pickerName);
						bean.setPickerValue(pickerVal);
						bean.setDescription(descr);
						bean.setId(sd.getId());
						listBean.add(bean);
					}
				}
			}
			if(listBean != null && !listBean.isEmpty())
				cacheDas.write(listBean);
		}
		
		log.info("done - loading PickerBean and writing to cache.");
		return listBean;
	}
	
	public static List<GiveupBrokerCodes> loadGiveupBrokerCodes(boolean savetoCache) throws DASException {
		if (giveupBrokerCodes != null) {
			giveupBrokerCodes.clear();
		} else {
			giveupBrokerCodes = new HashMap<Long, GiveupBrokerCodes> ();
		}

		List<GiveupBrokerCodes> giveupBrokerCodesList = null;
		Application app = ProfileCommandQuery.getApplicationByCode(ProfileApplicationConstant.GIVEUP_BROKER_CODES);
		if (app != null) {
			log.info("loading GiveupBrokerCodes...");
			List<Rule> list = ProfileCommandQuery.getRulesOfApplication(app.getId());
			if (list != null && !list.isEmpty()) {
				giveupBrokerCodesList = new ArrayList<GiveupBrokerCodes> ();
				for (Rule rule : list) {
					if (rule.getActiveFlag()) {
						getGiveupBrokerCodesFromRule(rule);
					}
				}
				giveupBrokerCodesList.addAll(giveupBrokerCodes.values());
			}
			log.info("done - loading GiveupBrokerCodes and writing to cache.");
		} else {
			if (log.isDebugEnabled()) {
				log.debug("Application: GIVEUP_BROKER_CODES rules are not loaded because it is not configured.");
			}
		}
		
		return giveupBrokerCodesList;
	}
		
	public static List<PriceTolerances> loadPriceTolerances(boolean savetoCache) throws DASException {
		if (priceTolerances != null) {
			priceTolerances.clear();
		} else {
			priceTolerances = new HashMap<Long, PriceTolerances> ();
		}

		List<PriceTolerances> priceTolerancesList = null;
		Application app = ProfileCommandQuery.getApplicationByCode(ProfileApplicationConstant.PRICE_TOLERANCES);
		
		if (app != null) {
			log.info("loading PriceTolerances...");
			List<Rule> list = ProfileCommandQuery.getRulesOfApplication(app.getId());
			if (list != null && !list.isEmpty()) {
				priceTolerancesList = new ArrayList<PriceTolerances> ();
				for (Rule rule : list) {
					if (rule.getActiveFlag()) {
						getPriceTolerancesFromRule(rule);
					}
				}
				priceTolerancesList.addAll(priceTolerances.values());
			}
			log.info("done - loading PriceTolerances and writing to cache.");
		} else {
			if (log.isDebugEnabled()) {
				log.debug("Application: PRICE_TOLERANCES rules are not loaded because it is not configured.");
			}
		}
		
		return priceTolerancesList;
	}
	
	public static List<MarketCharges> loadMarketCharges(boolean savetoCache) throws DASException {		
		if(marketCharges != null) 
			marketCharges.clear();
		else 
			marketCharges = new HashMap<Long, MarketCharges> ();
		
		List<MarketCharges> marketChargesList = null;
		Application app = ProfileCommandQuery.getApplicationByCode(ProfileApplicationConstant.MARKET_CHARGES);
		if(app != null) {
			log.info("loading MarketCharges...");
			List<Rule> list = ProfileCommandQuery.getRulesOfApplication(app.getId());
			if(list != null && !list.isEmpty()){
				marketChargesList = new ArrayList<MarketCharges>();
				for (Rule rule : list) {
					if (rule.getActiveFlag())
						getMarketChargesFromRule(rule);				
				}
				marketChargesList.addAll(marketCharges.values());
			}
			log.info("done - loading MarketCharges and writing to cache.");
		}
		else {
			if(log.isDebugEnabled())
				log.debug("Application: MARKET_CHARGES rules are not loaded because it is not configured.");
		}
		return marketChargesList;
	}
	
	public static GiveupBrokerCodes getGiveupBrokerCodesFromRule (Rule rule) throws DASException {
		GiveupBrokerCodes code = null;
		if (giveupBrokerCodes != null && rule != null) {
			if (giveupBrokerCodes.containsKey(rule.getId())) {
				code = giveupBrokerCodes.get(rule.getId());
			} else {
				code = new GiveupBrokerCodes ();
				giveupBrokerCodes.put(rule.getId(), code);
			}
			code.setId(rule.getId());
			code.setDescription(rule.getDescription());
		}
		
		List<RuleProperty> listRuleProperty = ProfileCommandQuery.getRulePropertyByRuleId(rule.getId());
		if (listRuleProperty != null && !listRuleProperty.isEmpty()) for (RuleProperty ruleProp : listRuleProperty) {
			Long propId = ruleProp.getPropertyId();
			Property prop = ProfileCommandQuery.getPropertyById(propId);
			String [] propCodes = prop.getPropertyCode().split("_");
			StringBuilder beanName = new StringBuilder ();
			for (String propCode : propCodes) {
				if (beanName.length() == 0)
					beanName.append(propCode.toLowerCase());
				else {
					beanName.append(propCode.substring(0, 1).toUpperCase());
					beanName.append(propCode.substring(1).toLowerCase());
				}				
			}
			String propName = beanName.toString();
			try {
				if (PropertyUtils.getPropertyType(code, propName) == null) {
					log.warn ("Property not found in bean while loading giveup broker codes: " + propName);
					continue;
				}
				BeanUtils.setProperty(code, propName, ruleProp.getValue());
			}
			catch (Exception e) {
				log.error ("Exception while accessing property" + propName, e);
			}
		}
		return code;
	}
	
	
	
	public static PriceTolerances getPriceTolerancesFromRule (Rule rule) throws DASException {
		PriceTolerances code = null;
		if (priceTolerances != null && rule != null) {
			if (priceTolerances.containsKey(rule.getId())) {
				code = priceTolerances.get(rule.getId());
			} else {
				code = new PriceTolerances ();
				priceTolerances.put(rule.getId(), code);
			}
			code.setId(rule.getId());
			code.setDescription(rule.getDescription());
		}
		
		List<RuleProperty> listRuleProperty = ProfileCommandQuery.getRulePropertyByRuleId(rule.getId());
		if (listRuleProperty != null && !listRuleProperty.isEmpty()) for (RuleProperty ruleProp : listRuleProperty) {
			Long propId = ruleProp.getPropertyId();
			Property prop = ProfileCommandQuery.getPropertyById(propId);
			String [] propCodes = prop.getPropertyCode().split("_");
			StringBuilder beanName = new StringBuilder ();
			for (String propCode : propCodes) {
				if (beanName.length() == 0)
					beanName.append(propCode.toLowerCase());
				else {
					beanName.append(propCode.substring(0, 1).toUpperCase());
					beanName.append(propCode.substring(1).toLowerCase());
				}				
			}
			String propName = beanName.toString();
			try {
				if (PropertyUtils.getPropertyType(code, propName) == null) {
					log.warn ("Property not found in bean while loading price tolerances: " + propName);
					continue;
				}
				BeanUtils.setProperty(code, propName, ruleProp.getValue());
			}
			catch (Exception e) {
				log.error ("Exception while accessing property" + propName, e);
			}
		}
		return code;
	}
	
	public static MarketCharges getMarketChargesFromRule (Rule rule) throws DASException {
		MarketCharges charge = null;
		if(marketCharges!=null && rule!=null){
			if (marketCharges.containsKey(rule.getId()))
				charge = marketCharges.get(rule.getId());
			else {
				charge = new MarketCharges ();
				marketCharges.put(rule.getId(), charge);
			}
			charge.setId(rule.getId());
			charge.setDescription(rule.getDescription());
			List<RuleProperty> listRuleProperty = ProfileCommandQuery.getRulePropertyByRuleId(rule.getId());
			if(listRuleProperty != null && !listRuleProperty.isEmpty()) for (RuleProperty ruleProp : listRuleProperty) {
				Long propId = ruleProp.getPropertyId();
				Property prop = ProfileCommandQuery.getPropertyById(propId);
				String [] propCodes = prop.getPropertyCode().split("_");
				StringBuilder beanName = new StringBuilder ();
				for (String code : propCodes) {
					if (beanName.length() == 0)
						beanName.append(code.toLowerCase());
					else {
						beanName.append(code.substring(0, 1).toUpperCase());
						beanName.append(code.substring(1).toLowerCase());
					}				
				}
				String propName = beanName.toString();
				try {
					if (PropertyUtils.getPropertyType(charge, propName) == null) {
						log.warn ("Property not found in bean while loading market charges: " + propName);
						continue;
					}
					BeanUtils.setProperty(charge, propName, ruleProp.getValue());
				}
				catch (Exception e) {
					log.error ("Exception while accessing property" + propName, e);
				}
				
			}
		}
		return charge;
	}
	
	public static void updateGiveupBrokerCodes(Rule rule) throws DASException {
		GiveupBrokerCodes giveupBrokerCodes = getGiveupBrokerCodesFromRule(rule);
		if (giveupBrokerCodes != null) {
			cacheDas.write(giveupBrokerCodes);
		}
	}
	
	public static void updatePriceTolerances(Rule rule) throws DASException {
		PriceTolerances priceTolerances = getPriceTolerancesFromRule(rule);
		if (priceTolerances != null) {
			cacheDas.write(priceTolerances);
		}
	}
	
	public static void updateMarketCharges(Rule rule) throws DASException {
		MarketCharges marketCharges = getMarketChargesFromRule(rule);
		if(marketCharges!=null){
			cacheDas.write(marketCharges);
		}
	}
	
    /*
     * List of Profile Application to load. Configured in the profileService_default.properties.
     */
    public static List<String> getApplicationsToLoad() {
    	List<String> applicationList = new ArrayList<String>();
    	Properties pro = DefaultConfiguration.getInstanceProperties();
    	String profileApplications = pro.getProperty("profileApplications");    	
    	if (profileApplications != null && !"".equals(profileApplications.trim())) {
    		log.info("Profile Aplications configured: " + profileApplications);
    		StringTokenizer st = new StringTokenizer(profileApplications,",;:");
    		while (st.hasMoreElements()){
    			applicationList.add((String)st.nextElement());
    		}
    	}
    	else 
    		log.error("Property 'profileApplications' is not specified in instance.properties. Not loading any applications.");
    	return applicationList;
    }	
	
    public static List<ProfileAmendReportBean> getProfileAmendReport(List<Long> ruleIds, Date startTime, Date endTime) throws DASException {
    	return profileAmendReportDao.getProfileAmendReport(ruleIds, startTime, endTime);
    }
}
