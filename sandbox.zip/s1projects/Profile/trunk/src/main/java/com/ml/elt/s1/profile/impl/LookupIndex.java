/**
 * 
 */
package com.ml.elt.s1.profile.impl;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ml.elt.s1.profile.core.sdo.Rule;

/**
 * @author schuz
 * Defines node in the criteria index tree.
 * Holds Rule (if any) for the node and sub-index tree.
 * The Criteria Property Code Order Number corresponds to tree level.
 * The order number 1 corresponds to the root node; the last number corresponds
 * to ultimate leaves that don't have sub-indexes.
 */
public class LookupIndex implements Serializable{
	private static final long serialVersionUID = 1L;

	private static Log log = LogFactory.getLog(LookupIndex.class);

	public static final Byte NULL_KEY = '\0';

	private Rule rule;
	private String lookupPropertyCode;
	private Map<Object, LookupIndex> subIndexMap;
	
	/**
	 * @return the Criteria Property Code for the current index
	 */
	public String getLookupPropertyCode() {
		return lookupPropertyCode;
	}
	/**
	 * @param lookupPropertyCode the Criteria Property Code to set
	 */
	public void setLookupPropertyCode(String lookupPropertyCode) {
		this.lookupPropertyCode = lookupPropertyCode;
	}
	
	/**
	 * @return the Rule for current node in the tree
	 */
	public Rule getRule() {
		return rule;
	}
	/**
	 * @param rule the Rule to set
	 */
	public void setRule(Rule rule) {
		if(this.rule != null) {
			log.warn(String.format("redundant rule %1$s; the %2$s will be used", rule.getId(), this.rule.getId()));
		}
		else this.rule = rule;
	}
	
	/**
	 * @return the sub-index Map
	 */
	public Map<Object, LookupIndex> getSubIndexMap() {
		if(subIndexMap == null) subIndexMap = new HashMap<Object, LookupIndex>(4);
		return subIndexMap;
	}
	/**
	 * Get sub-index from the current index by the Key.
	 * @param key the Key to lookup.
	 * @return the found Criteria sub-index; null - if not found.
	 */
	public LookupIndex getSubIndex(Object key) {
		if(subIndexMap == null) subIndexMap = new HashMap<Object, LookupIndex>(4);
		if(subIndexMap.containsKey(key)) return subIndexMap.get(key);
		return null;
	}

	/**
	 * Creates and adds sub-index to the current index
	 * @param lookupPropertyCode the Criteria Property Code for the sub-index
	 * @param key
	 * @return created sub-index
	 */
	public LookupIndex addSubIndex(String lookupPropertyCode, Object key) {
		if(subIndexMap == null) subIndexMap = new HashMap<Object, LookupIndex>(4);
		LookupIndex subIndex = new LookupIndex();
		subIndex.lookupPropertyCode = lookupPropertyCode;
		subIndexMap.put(key, subIndex);
		return subIndex;
	}
	
	public void search(LookupResultSet context, boolean searchDeafault) {

		// drill down for specific key
		if (context.lookupValues.containsKey(lookupPropertyCode)) {
			Object criteriaValue = context.lookupValues.get(lookupPropertyCode);
			if (subIndexMap != null && subIndexMap.containsKey(criteriaValue.toString())) {
				LookupIndex subIndex = subIndexMap.get(criteriaValue.toString());
				subIndex.search(context,true);
			}
		}
		
		// search default
		if(searchDeafault){
			if (subIndexMap != null && subIndexMap.containsKey(NULL_KEY)) {
				LookupIndex subIndex = subIndexMap.get(NULL_KEY);
				subIndex.search(context,true);
			}
		}


		// current values
		if (rule != null && rule.getActiveFlag()) {
			log.debug(String.format("profile lookup found Rule: %1$s", rule.getId()));
			Map<String, List<Object>> rulePropMap = rule.getTargetRuleProperty();
			boolean propAdded = false;
			for (String propertyCode : rulePropMap.keySet()) {
				if (!context.propertyValues.containsKey(propertyCode)) {
					List<Object> value = rulePropMap.get(propertyCode);
					log.debug(String.format("set target property: %1$s = \"%2$s\"", propertyCode, value));
					context.propertyValues.put(propertyCode, value);
					context.rulesMap.put(propertyCode, rule.getId());
					propAdded = true;
				}
			}
			if (propAdded)
				context.rulesList.add( new Long (rule.getId()));
		}
	}
}
