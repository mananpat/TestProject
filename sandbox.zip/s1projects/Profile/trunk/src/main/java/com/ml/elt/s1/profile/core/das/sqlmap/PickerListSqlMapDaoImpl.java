/**
 * 
 */
package com.ml.elt.s1.profile.core.das.sqlmap;

import java.util.List;

import org.springframework.orm.ibatis.SqlMapClientTemplate;

import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.profile.core.das.iface.PickerListDao;
import com.ml.elt.s1.profile.core.sdo.Pickerlist;

/**
 * @author mpatel12
 *
 */
public class PickerListSqlMapDaoImpl extends SqlMapClientTemplate implements
		PickerListDao {

	/* (non-Javadoc)
	 * @see com.ml.elt.s1.core.das.iface.PickerListDao#getAllPickerlist()
	 */
	@SuppressWarnings("unchecked")
	public List<Pickerlist> getAllPickerlist() throws DASException {
		try {			
			return (List<Pickerlist>) queryForList("getAllPickerlist");			
		} catch (org.springframework.dao.DataAccessException ex) {
			throw new DASException(ex);
		}
	}

}
