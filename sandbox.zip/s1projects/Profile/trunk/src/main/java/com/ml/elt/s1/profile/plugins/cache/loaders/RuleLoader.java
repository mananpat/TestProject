/**
 * 
 */
package com.ml.elt.s1.profile.plugins.cache.loaders;

import java.util.List;

import org.apache.log4j.Logger;

import com.ml.elt.s1.platform.container.service.cache.CacheDas;
import com.ml.elt.s1.platform.plugins.das.Das;
import com.ml.elt.s1.profile.core.das.iface.RuleDao;
import com.ml.elt.s1.profile.core.sdo.Rule;
import com.ml.elt.s1.profile.plugins.cache.Worker;


/**
 * @author mpatel12
 *
 */
public class RuleLoader extends Worker {

	private static Logger log = Logger.getLogger(RuleLoader.class);
	
	List<Long> appIds;
	
	public RuleLoader(Das daoManagerDb, CacheDas cacheDas, List<Long> appIdList) {	
		super(daoManagerDb, cacheDas);
		appIds = appIdList;
	}
	
	public void doWork() throws Exception {
		log.info("loading Rules...");			
		List<Rule> list = null;
		RuleDao dbDao = (RuleDao) daoManagerDb.getDao(Rule.class);
		if(appIds != null && !appIds.isEmpty()){
			list = dbDao.getAllRulesByApp(appIds);
			if(list != null && !list.isEmpty()){
				write(list);
			}
		}
		
		log.info("done - loading Rules and writing to cache.");
	}
}
