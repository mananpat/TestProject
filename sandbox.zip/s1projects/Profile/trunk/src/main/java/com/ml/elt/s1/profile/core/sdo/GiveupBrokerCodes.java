package com.ml.elt.s1.profile.core.sdo;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

import com.ml.elt.s1.platform.container.service.cache.CachableObject;
@XmlRootElement(name = "giveupBrokerCodes")
public class GiveupBrokerCodes implements Serializable, CachableObject, Cloneable {
	private static final long serialVersionUID = 1L;

	private String description;
	private String brokercode;
	private String brokerviewcode;

	private Long id;

	public Object getCacheKey() {
		return id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getBrokercode() {
		return brokercode;
	}

	public void setBrokercode(String brokercode) {
		this.brokercode = brokercode;
	}

	public String getBrokerviewcode() {
		return brokerviewcode;
	}

	public void setBrokerviewcode(String brokerviewcode) {
		this.brokerviewcode = brokerviewcode;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Object clone() throws CloneNotSupportedException {
		//get initial bit-by-bit copy, which handles all immutable fields
		GiveupBrokerCodes code = (GiveupBrokerCodes)super.clone();

		//mutable fields need to be made independent of this object, for reasons
		//similar to those for defensive copies - to prevent unwanted access to
		//this object's internal state
		String broker = new String(this.getBrokercode());
		code.setBrokercode(broker);
		return code;
	}
}
