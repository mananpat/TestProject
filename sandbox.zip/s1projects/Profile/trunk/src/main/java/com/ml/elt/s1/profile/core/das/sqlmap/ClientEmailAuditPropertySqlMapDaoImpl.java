package com.ml.elt.s1.profile.core.das.sqlmap;

import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.orm.ibatis.SqlMapClientTemplate;

import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.profile.core.das.iface.ClientEmailAuditPropertyDao;
import com.ml.elt.s1.profile.core.sdo.ClientEmailAuditProperty;

public class ClientEmailAuditPropertySqlMapDaoImpl extends SqlMapClientTemplate implements ClientEmailAuditPropertyDao {

	@SuppressWarnings("unchecked")
	public List<ClientEmailAuditProperty> getAllClientEmailProperty() throws DASException {
		List<ClientEmailAuditProperty> ret = null;
		try {
			ret = (List<ClientEmailAuditProperty>) queryForList("getAllAutoMailProperties");
		}
		catch (DataAccessException daEx) {
			throw new DASException(daEx);
		}
		return ret;
	}

	@SuppressWarnings("unchecked")
	public List<ClientEmailAuditProperty> getAllActiveClientEmailProperty() throws DASException {
		List<ClientEmailAuditProperty> ret = null;
		try {
			String stat = "Y";
			ret = (List<ClientEmailAuditProperty>) queryForList("getActiveAutoMailProperties", stat);
		}
		catch (DataAccessException daEx) {
			throw new DASException(daEx);
		}
		return ret;
	}
}
