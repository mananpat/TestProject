package com.ml.elt.s1.profile.transfer.gui;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="ProfileDataList")
public class ProfileDataList  implements Serializable{
	private static final long serialVersionUID = 1L;
	private int count;
	private String userId;
	private String version;
	private Date createdTime;
	private Date updateTime;
	private Date updateTimeTo;
	private String hostName;
	
	private List<PropertyBean> profileProperty;
	private List<RuleBean> rules;
	private List<AppBean> apps;
	private List<ErrorBean> errors;
	private List<ContactBean> contacts;
	private List<ProfileAmendReportBean> profileAmendReports;
	
	@XmlAttribute
	public int getCount() {
		count = 0;
		if (profileProperty != null ) count += profileProperty.size();
		if (rules != null) count += rules.size();
		if (getApps() != null) count += getApps().size();
		if (errors != null) count += errors.size();
		if (contacts != null) count += contacts.size();
		if (profileAmendReports != null) count += profileAmendReports.size();
		
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	
	@XmlAttribute(required=true)
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	@XmlAttribute(required=true)
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	
	@XmlAttribute(required=true)
	public Date getCreatedTime() {
		return createdTime;
	}
	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	@XmlAttribute(required=true)
	public String getHostName() {
		return hostName;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	
	public List<PropertyBean> getProfileProperty() {
    	return profileProperty;
    }
	public void setProfileProperty(List<PropertyBean> profiles) {
    	this.profileProperty = profiles;
    }
	
	public void addRuleBean(RuleBean ruleBean) {
		if(rules == null) rules  = new ArrayList<RuleBean>();
		rules.add(ruleBean); 
	}
	
	public void setRules(List<RuleBean> rules) {
		this.rules = rules;
	}
	public List<RuleBean> getRules() {
		return rules;
	}
	
	public void setApps(List<AppBean> apps) {
		this.apps = apps;
	}
	public List<AppBean> getApps() {
		return apps;
	}

	public void setErrors(List<ErrorBean> errors) {
		this.errors = errors;
	}
	public List<ErrorBean> getErrors() {
		return errors;
	}
	public void addError(ErrorBean errorBean) {
		if(errors == null) errors  = new ArrayList<ErrorBean>();
		errors.add(errorBean); 
	}
	public void addAllError(List<ErrorBean> errorBeans) {
		if(errors == null) errors  = new ArrayList<ErrorBean>();
		errors.addAll(errorBeans); 
	}

	public void addContact(ContactBean contactBean) {
		if(contacts == null) contacts  = new ArrayList<ContactBean>();
		contacts.add(contactBean); 
	}
	
	public void setContacts(List<ContactBean> contact) {
		this.contacts = contact;
	}
	public List<ContactBean> getContacts() {
		return contacts;
	}
	public void addContacts(ContactBean o) {
		if(contacts==null) contacts = new ArrayList<ContactBean>(0);
		contacts.add(o);
	}
	
	public void addAllContacts(List<ContactBean> list) {
		if(contacts==null) contacts = new ArrayList<ContactBean>(0);
		contacts.addAll(list);
	}

	public List<ProfileAmendReportBean> getProfileAmendReports() {
		return profileAmendReports;
	}
	public void setProfileAmendReports(
			List<ProfileAmendReportBean> profileAmendReports) {
		this.profileAmendReports = profileAmendReports;
	}

	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	
	public Date getUpdateTimeTo() {
		return updateTimeTo;
	}
	public void setUpdateTimeTo(Date updateTimeTo) {
		this.updateTimeTo = updateTimeTo;
	}	

}
