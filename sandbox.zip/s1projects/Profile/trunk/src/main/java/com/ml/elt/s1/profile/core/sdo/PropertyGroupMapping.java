package com.ml.elt.s1.profile.core.sdo;

import com.ml.elt.s1.platform.plugins.cache.PrimaryKey;

/**
 * PropertyGroupMapping
 */
public class PropertyGroupMapping extends ProfileDomainObject {

	private static final long serialVersionUID = 1L;

	private Long id;	
	private Long propertyGroupId;
	private Long propertyId;
	private String requiredFlag;
	
	public PropertyGroupMapping() {
	}
	
	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getRequiredFlag() {
		return this.requiredFlag;
	}

	public void setRequiredFlag(String requiredFlag) {
		this.requiredFlag = requiredFlag;
	}
	
	public Long getPropertyGroupId() {
		return propertyGroupId;
	}

	public void setPropertyGroupId(Long propertyGroupId) {
		this.propertyGroupId = propertyGroupId;
	}

	public Long getPropertyId() {
		return propertyId;
	}

	public void setPropertyId(Long propertyId) {
		this.propertyId = propertyId;
	}
	
	/* (non-Javadoc)
	 * @see com.ml.elt.s1.platform.plugins.cache.CacheObject#getCacheKey()
	 */
	@Override
	public String getCacheKey(){
		if (primaryKey == null){
			Object[] key = new Object[]{getId()};
			primaryKey = new PrimaryKey(key, this.getClass(), true, true);
		}
		return primaryKey.getStringKey();
	}
	public static String getCacheKey(Long id){
		Object[] key = new Object[]{id};
		PrimaryKey primaryKey = new PrimaryKey(key, PropertyGroupMapping.class, true, true);
		return primaryKey.getStringKey();
	}
	
	public String getPath(){
		return getClass().getPackage().getName().replace('.', '_')
		+ "/" + getClass().getSimpleName()
		+ "/" + getPropertyGroupId();
	}
}
