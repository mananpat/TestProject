/**
 * 
 */
package com.ml.elt.s1.profile.plugins.cache.loaders;

import java.util.List;

import org.apache.log4j.Logger;

import com.ml.elt.s1.platform.container.service.cache.CacheDas;
import com.ml.elt.s1.platform.plugins.das.Das;
import com.ml.elt.s1.profile.core.das.iface.PropertyGroupDao;
import com.ml.elt.s1.profile.core.sdo.PropertyGroup;
import com.ml.elt.s1.profile.plugins.cache.Worker;


/**
 * @author mpatel12
 *
 */
public class PropertyGroupLoader extends Worker {

	private static Logger log = Logger.getLogger(PropertyGroupLoader.class);
	
	public PropertyGroupLoader(Das daoManagerDb, CacheDas cacheDas) {	
		super(daoManagerDb, cacheDas);
	}
	
	public void doWork() throws Exception {
		log.info("loading PropertyGroups...");
		PropertyGroupDao dbDao = (PropertyGroupDao) daoManagerDb.getDao(PropertyGroup.class);
		List<PropertyGroup> list = dbDao.getAllPropertyGroups();
		if(list != null && !list.isEmpty()){
			write(list);
		}
		log.info("done - loading PropertyGroups and writing to cache.");		
	}
}
