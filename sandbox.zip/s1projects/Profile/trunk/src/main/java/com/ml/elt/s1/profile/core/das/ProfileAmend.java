/**
 * 
 */
package com.ml.elt.s1.profile.core.das;

import java.util.Date;
import java.util.List;

public class ProfileAmend {
	
	private Date startDate;
	private Date endDate;
	private List<Long> ruleIds;
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public List<Long> getRuleIds() {
		return ruleIds;
	}
	public void setRuleIds(List<Long> ruleIds) {
		this.ruleIds = ruleIds;
	}
	
}
