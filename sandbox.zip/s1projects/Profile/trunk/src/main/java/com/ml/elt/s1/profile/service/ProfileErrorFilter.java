package com.ml.elt.s1.profile.service;

import java.util.HashMap;

import com.ml.elt.s1.platform.container.ServiceContext;
import com.ml.elt.s1.platform.container.service.MetaData;
import com.ml.elt.s1.platform.container.service.Request;
import com.ml.elt.s1.platform.container.service.Response;
import com.ml.elt.s1.platform.container.service.processor.MessageProcessor;
import com.ml.elt.s1.platform.plugins.connector.ems.OutputData;
import com.ml.elt.s1.profile.transfer.gui.ProfileDataList;
import com.ml.elt.s1.profile.util.ProfileApplicationConstant;

public class ProfileErrorFilter implements MessageProcessor {

	public Response process(Request req) {
		Response res = new Response();
		if (req != null) {
			ServiceContext context = req.getServiceContext();
			MetaData metaData = context.getMetaData();
			boolean resAdded = false;
			Object[] objs = req.getData();
			for(Object obj : objs){
				if (obj instanceof ProfileDataList) {
					ProfileDataList inProfileList = (ProfileDataList)obj;
					if (inProfileList.getErrors() == null || inProfileList.getErrors().size() == 0)
						continue;
					ProfileDataList outProfileList = new ProfileDataList();
					outProfileList.setErrors(inProfileList.getErrors());
					res.addOutput(outProfileList);
					resAdded = true;
				}
			}
			String reqType = (String)metaData.getData(ProfileApplicationConstant.REQ_TYPE);
			if(reqType != null && "xml-contacts".equals(reqType))
			{
				metaData.setData(ProfileApplicationConstant.REQ_TYPE,ProfileApplicationConstant.XML_EXCEPTION_CONTACT);
			}
			else
			{
				metaData.setData(ProfileApplicationConstant.REQ_TYPE,ProfileApplicationConstant.XML_EXCEPTION);
			}
			metaData.setData(ProfileApplicationConstant.REQ_ID, metaData.getData(ProfileApplicationConstant.ERROR_REQ_ID));
			if (resAdded)
				publishEof(context, res);
		}
		return res;
	}

	@SuppressWarnings("unchecked")
	private void publishEof(ServiceContext context, Response resp) {
		OutputData eofData = new OutputData();
		eofData.setData(new ProfileDataList ());
		MetaData metadata = new MetaData();
		HashMap map = new HashMap(context.getMetaData().getMap());
		map.put(ProfileApplicationConstant.TYPE, ProfileApplicationConstant.EOF);
		metadata.setMap(map);
		eofData.setMetaData(metadata);
		resp.addOutput(eofData);
	}
}
