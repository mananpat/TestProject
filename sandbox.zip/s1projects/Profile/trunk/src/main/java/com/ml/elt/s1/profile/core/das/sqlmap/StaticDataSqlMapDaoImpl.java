/**
 * 
 */
package com.ml.elt.s1.profile.core.das.sqlmap;

import java.util.List;

import org.springframework.orm.ibatis.SqlMapClientTemplate;

import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.profile.core.das.iface.StaticDataDao;
import com.ml.elt.s1.profile.core.sdo.StaticData;

/**
 * @author mpatel12
 *
 */
public class StaticDataSqlMapDaoImpl extends SqlMapClientTemplate implements
		StaticDataDao {

	/* (non-Javadoc)
	 * @see com.ml.elt.s1.core.das.iface.StaticDataDao#getAllStaticData()
	 */
	@SuppressWarnings("unchecked")
	public List<StaticData> getStaticDataByPickerList(int pickerListId) throws DASException{
		try {			
			List<StaticData> list = (List<StaticData>) queryForList("getStaticDataByPickerList", pickerListId);
			return list;
		} catch (org.springframework.dao.DataAccessException ex) {
			throw new DASException(ex);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.ml.elt.s1.core.das.iface.StaticDataDao#getAllStaticData()
	 */
	@SuppressWarnings("unchecked")
	public List<StaticData> getAllStaticData() throws DASException {
		try {			
			List<StaticData> list = (List<StaticData>) queryForList("getAllStaticData");
			return list;
		} catch (org.springframework.dao.DataAccessException ex) {
			throw new DASException(ex);
		}
	}

}
