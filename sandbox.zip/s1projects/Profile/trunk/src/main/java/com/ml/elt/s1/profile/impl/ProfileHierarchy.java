package com.ml.elt.s1.profile.impl;

import java.io.Serializable;
import java.util.Collection;
import java.util.HashSet;

public class ProfileHierarchy implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String profileProperty;
	private String propertyValue;
	private Collection<ProfileHierarchy> children;
	private Collection<ProfileHierarchy> parent;
	
	public String getProfileProperty() {
		return profileProperty;
	}
	
	public void setProfileProperty(String profileProperty) {
		this.profileProperty = profileProperty;
	}
	
	public String getPropertyValue() {
		return propertyValue;
	}
	
	public void setPropertyValue(String propertyValue) {
		this.propertyValue = propertyValue;
	}
	
	public void setChildren(Collection<ProfileHierarchy> children) {
		this.children = children;
	}

	public Collection<ProfileHierarchy> getChildren() {
		if (children == null)
			children = new HashSet<ProfileHierarchy> ();
		return children;
	}

	public void setParent(Collection<ProfileHierarchy> parent) {
		this.parent = parent;
	}

	public Collection<ProfileHierarchy> getParent() {
		if (parent == null)
			parent = new HashSet<ProfileHierarchy> ();
		return parent;
	}
}
