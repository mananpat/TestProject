/**
 * 
 */
package com.ml.elt.s1.profile.core.das.sqlmap;

import java.util.List;

import org.springframework.orm.ibatis.SqlMapClientTemplate;

import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.profile.core.das.iface.LookupPropertiesDao;
import com.ml.elt.s1.profile.core.sdo.LookupProperties;

/**
 * @author mpatel12
 *
 */
public class LookupPropertiesSqlMapDaoImpl extends SqlMapClientTemplate implements LookupPropertiesDao {

	/* (non-Javadoc)
	 * @see com.ml.elt.s1.core.das.iface.LookupPropertiesDao#getAllLookupProperties()
	 */
	@SuppressWarnings("unchecked")
	public List<LookupProperties> getAllLookupProperties() throws DASException {
		try {
			return (List<LookupProperties>)queryForList("getAllLookupProperties");			
		} catch (org.springframework.dao.DataAccessException ex) {
			throw new DASException(ex);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.ml.elt.s1.core.das.iface.LookupPropertiesDao#getLookupPropertiesByAppCode()
	 */
	@SuppressWarnings("unchecked")
	public List<LookupProperties> getLookupPropertiesByAppCode(String appCode) throws DASException {
		try {			
			return  (List<LookupProperties>) queryForList("getLookupPropertiesByAppCode", appCode);			
		} catch (org.springframework.dao.DataAccessException ex) {
			throw new DASException(ex);
		}
	}	
}
