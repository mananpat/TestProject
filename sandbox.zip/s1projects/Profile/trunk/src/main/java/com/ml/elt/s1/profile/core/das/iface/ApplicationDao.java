/**
 * 
 */
package com.ml.elt.s1.profile.core.das.iface;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.platform.container.service.das.Dao;
import com.ml.elt.s1.profile.core.sdo.Application;

/**
 * @author mpatel12
 *
 */
public interface ApplicationDao extends Dao {

	/**
	 * returns Application
	 * @return Application
	 * @throws DataAccessException
	 */
	public Application getApplicationByAppCode(String appCode) throws DASException;
	
	/**
	 * returns Application List
	 * @return Application
	 * @throws DataAccessException
	 */
	public List<Application> getApplicationsByAppCode(List<String> appCodeList) throws DASException;
	
	/**
	 * returns Application List
	 * @return Application
	 * @throws DataAccessException
	 */	
	public List<Application> getAllApplications() throws DASException; 
}
