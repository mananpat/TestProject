package com.ml.elt.s1.profile.core.sdo;

import com.ml.elt.s1.platform.plugins.cache.PrimaryKey;

/**
 * Application
 */
public class Application extends ProfileDomainObject {

	private static final long serialVersionUID = 1L;
	
	private Long id;
	private String applicationCode;
	private String description;
	private Byte viewOrder;	

	public Application() {
	}

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getApplicationCode() {
		return this.applicationCode;
	}

	public void setApplicationCode(String applicationCode) {
		this.applicationCode = applicationCode;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Byte getViewOrder() {
		return this.viewOrder;
	}

	public void setViewOrder(Byte viewOrder) {
		this.viewOrder = viewOrder;
	}
	
	/* (non-Javadoc)
	 * @see com.ml.elt.s1.platform.plugins.cache.CacheObject#getCacheKey()
	 */
	@Override
	public String getCacheKey(){
		if (primaryKey == null){
			Object[] key = new Object[]{getId()};
			primaryKey = new PrimaryKey(key, this.getClass(), true, true);
		}
		return primaryKey.getStringKey();
	}
	
	public static String getCacheKey(Long id){
		Object[] key = new Object[]{id};
		PrimaryKey primaryKey = new PrimaryKey(key, Application.class, true, true);
		return primaryKey.getStringKey();
	}
}
