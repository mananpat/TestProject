package com.ml.elt.s1.profile.impl;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ml.elt.s1.platform.container.exception.ConfigurationException;
import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.platform.plugins.boot.DefaultConfiguration;
import com.ml.elt.s1.profile.core.das.cache.ProfileCommandQuery;
import com.ml.elt.s1.profile.core.sdo.Application;
import com.ml.elt.s1.profile.core.sdo.LookupProperties;
import com.ml.elt.s1.profile.core.sdo.Property;
import com.ml.elt.s1.profile.core.sdo.PropertyGroup;
import com.ml.elt.s1.profile.core.sdo.PropertyGroupMapping;
import com.ml.elt.s1.profile.core.sdo.Rule;
import com.ml.elt.s1.profile.core.sdo.RuleProperty;
import com.ml.elt.s1.profile.core.sdo.comparator.LookupPropertiesComparator;
import com.ml.elt.s1.profile.core.sdo.util.PropertyGroupCodeUtil;
import com.ml.elt.s1.profile.exception.ProfileException;
import com.ml.elt.s1.profile.intface.DataConverter;
import com.ml.elt.s1.profile.intface.IHierarchyLoader;
import com.ml.elt.s1.rules.Validator;
import com.ml.elt.s1.rules.impl.ValidatorImpl;

public class ProfileLoader {
    
	private static Log log = LogFactory.getLog(ProfileLoader.class);
	
	private static ProfileIndex profileIndex;	
	private static ProfilePropertiesMananger propertiesManager = null;
	private static ProfileLoader instance = null;
	
	private static LookupPropertiesComparator lookupCmp = new LookupPropertiesComparator();
	
	private static final String  lock = "WRITE_LOCK"; 
	
	static {
    	try 
    	{
    		Object obj = DefaultConfiguration.getBean("profilePropertiesMananger");
	    	if(propertiesManager == null){
		    	if(obj != null)
		    		propertiesManager = (ProfilePropertiesMananger) obj;    	
		    	else
		    		log.error("Profile Properties Manager Configuration is missing");	    	
	    	}
    	} catch(Throwable t) {
    		log.error("Error while loading bean from configuration", t);
    	}  
	}
	
	public static synchronized ProfileLoader getInstance(){
		if(instance == null)
			instance = new ProfileLoader();
		return instance;
	}
	
	public ProfileIndex getProfileIndex() {
		return profileIndex;
    }
	
    private ProfileLoader() {    	
    }
    
    @SuppressWarnings("unchecked")
	public void reloadProfile() throws ProfileException {
    	synchronized (lock) {
    		log.info("Reloading Profiles and building indexes ...");
    		long startTime = System.currentTimeMillis();
			try 
			{
				List<Application> apps = ProfileCommandQuery.getApplications();
				ProfileIndex prfIndex = new ProfileIndex();
				if(apps!=null && !apps.isEmpty()){
					
					for (Application app : apps) {				
						prfIndex.addApplication(app.getApplicationCode(), app);
						buildIndexes(prfIndex, app.getApplicationCode());
					}
				}
				// synchronize to assure prfIndex is fully built and flushed from CPU cache
				// before profileIndex is assigned
				profileIndex = prfIndex;
				PropertyGroupCodeUtil.initPropertyGroupCodeMap();		
			}
			catch(Throwable t) {
				log.error("Error on index build",t);
				throw new ProfileException(t);
			}
			long endTime = System.currentTimeMillis();
			log.info("reloadProfile: Profile reload and indexes built completed in " + (endTime-startTime) + " ms");	
		}
	}  
   
	public void reloadProfile(String appCode) throws ProfileException {
    	synchronized (lock) {
			log.info("Reloading Profiles and building indexes ...");
			long startTime = System.currentTimeMillis();
			try 
			{
				Application app = ProfileCommandQuery.getApplicationByCode(appCode);
				if(app!=null){
					profileIndex.addApplication(app.getApplicationCode(), app);
					buildIndexes(profileIndex, app);
				}
			}
			catch(Throwable t) {
				log.error("Error on index build",t);
				throw new ProfileException(t);
			}
			
			long endTime = System.currentTimeMillis();
			log.info("reloadProfile: Profile reload and indexes built completed in " + (endTime-startTime) + " ms");
    	}
	}  

	public void reloadProfile(String appCode, Long ruleId) throws ProfileException {
		synchronized (lock) {
			log.info("Reloading Profiles and building indexes ...");
			long startTime = System.currentTimeMillis();
			try 
			{
				Application app = ProfileCommandQuery.getApplicationByCode(appCode);
				if(app!=null){
					buildRule(profileIndex, app,ruleId);
				}
			}
			catch(Throwable t) {
				log.error("Error on index build",t);
				throw new ProfileException(t);
			}
			
			long endTime = System.currentTimeMillis();
			log.info("reloadProfile: Profile reload and indexes built completed in " + (endTime-startTime) + " ms");
		}
	}
    
    
	private void buildIndexes (ProfileIndex prfIndex, String appCode) throws DASException {
		if(log.isDebugEnabled())
    		log.debug("Inside buildIndexes method");
		
		log.info("buildingIndex for application : " + appCode);
		
		//Application Validator
		List<String> validatorList = propertiesManager.getApplicationValiator(appCode);
		if(validatorList != null && !validatorList.isEmpty()){
			for(String appValidator : validatorList){
				if(appValidator != null && !appValidator.equalsIgnoreCase("")){
					try {										
						Validator validator = new ValidatorImpl ();
						validator.init(appValidator);		    		
			    	}
			    	catch (ConfigurationException e) {
						log.error("Error while initializing " + appCode + " application validator: "+ appValidator +".");
					}
				}
			}
		}
		
    	Application app = prfIndex.getApplication(appCode);    	
    	List<LookupProperties> lookupList = ProfileCommandQuery.getLookupPropertiesOfApplication(app.getId());
		if(lookupList==null || lookupList.isEmpty()){
			log.warn(String.format("Criteria Category \"%1$s\" doesn't have properties defined. Corresponding index won't be built", app.getApplicationCode()));
			return;
		}
		Collections.sort(lookupList,lookupCmp);
		LookupProperties [] lpList = new LookupProperties[lookupList.size()];
		lookupList.toArray(lpList);
		Map<Long,Property> lPropertyMap = new HashMap<Long, Property>();
		
		String lookupCode = ProfileCommandQuery.getPropertyById(lpList[0].getPropertyId()).getPropertyCode();
		LookupIndex lookupIndex = new LookupIndex();
		lookupIndex.setLookupPropertyCode(lookupCode);
		prfIndex.addLookupIndex(app.getApplicationCode(), lookupIndex);
		
		List<PropertyGroup> listPropertyGroups = ProfileCommandQuery.getPropertyGroupsOfApplication(app.getId());
		if(listPropertyGroups != null && !listPropertyGroups.isEmpty()){ 
			for (PropertyGroup group : listPropertyGroups) {
			List<PropertyGroupMapping> listPropertyGroupMappings = 
				ProfileCommandQuery.getPropertyGroupMappingOfPropertyGroup(group.getId());
			if(listPropertyGroupMappings != null && !listPropertyGroupMappings.isEmpty())
				for (PropertyGroupMapping mappings : listPropertyGroupMappings) {
					Property pro = ProfileCommandQuery.getPropertyById(mappings.getPropertyId());
					if(pro!=null){
						prfIndex.addProperty(pro.getPropertyCode(), pro);
						prfIndex.addPropertyType(pro.getPropertyCode(), pro.getDataType());
					}else {
						throw new DASException("Property Not Found in Cache "+mappings.getPropertyId());
					}
				}
			}
		}
		
		
		DataConverter dataConverter = propertiesManager.getApplicationDataConverter(appCode);
		IHierarchyLoader hierarchyLoader = propertiesManager.getApplicationHierarchyLoader(appCode);
		if(hierarchyLoader!=null){
			hierarchyLoader.init();
		}
		
		for (LookupProperties lookup : lookupList) {
			Property pro = ProfileCommandQuery.getPropertyById(lookup.getPropertyId());
			prfIndex.addProperty(pro.getPropertyCode(), pro);
			prfIndex.addPropertyType(pro.getPropertyCode(), pro.getDataType());
			lPropertyMap.put(pro.getId(), pro);
		}
		
		List<Rule> listRules = ProfileCommandQuery.getRulesOfApplication(app.getId());
		if(listRules != null && !listRules.isEmpty())for (Rule rule : listRules) {
			Application application = ProfileCommandQuery.getApplicationById(rule.getApplicationId());
			if (!application.getApplicationCode().equalsIgnoreCase(appCode))
				continue;
			LookupIndex critIndex = lookupIndex;
			prfIndex.addRule(rule.getId(), rule);
			rule.getTargetRuleProperty().clear();
			List<RuleProperty> listRuleProperty = ProfileCommandQuery.getRulePropertyByRuleId(rule.getId());
			
			if(listRuleProperty != null && !listRuleProperty.isEmpty())
				for (RuleProperty ruleProp : listRuleProperty) {				
					rule.addTargetProperty(ruleProp, dataConverter);
			}
			
			int lastOrd = -1;
			
			if (!rule.getActiveFlag())
				continue;
			
			for (int i = 0; i < lpList.length; i++) {
				if (rule.getTargetRuleProperty().containsKey(lPropertyMap.get(lpList[i].getPropertyId()).getPropertyCode()))
					lastOrd = i;				
			}			
			
			if(critIndex == null){
				log.warn(String.format("Rule \"%1$s\" doesn't have Index to be put into. The rule ignored", rule.getId()));
				continue;
			}
			
			for (int i = 0; i < lpList.length; ++i) {
				if(i > lastOrd) break;
				Property prop = lPropertyMap.get(lpList[i].getPropertyId());
				String propCode = prop.getPropertyCode();
				Map<Object, LookupIndex> subIndexMap = critIndex.getSubIndexMap();
				Object propVal = LookupIndex.NULL_KEY;
				List<String> values = rule.retrieveDisplayStrings(propCode, prop.getDataType(), dataConverter);
				if (values.size() != 0) {
					StringBuilder builder = new StringBuilder ();
					for (Object key : values)
					{
						if (builder.length() != 0)
							builder.append(",");
						builder.append(key);
					}	
					propVal = builder.toString();
				}
				
				LookupIndex nextLookup = null;
				String subPropCode;
				if(i + 1 < lookupList.size()){
					Property subProp = lPropertyMap.get(lpList[i+1].getPropertyId());
					subPropCode = subProp.getPropertyCode();
				}
				else subPropCode = null;
				if(subIndexMap.containsKey(propVal))
					nextLookup = subIndexMap.get(propVal);
				else 
					nextLookup = critIndex.addSubIndex(subPropCode, propVal);
				
				critIndex = nextLookup;
			}
			critIndex.setRule(rule);
		}
    }
    
    /*
     * Build Profile Rule indexes based on Lookup criteria for each rule
     */    
	private void buildIndexes (ProfileIndex prfIndex, Application app) throws DASException {
		if(log.isDebugEnabled())
    		log.debug("Inside buildIndexes method");
		
		String appCode = app.getApplicationCode();
		log.info("buildingIndex for application : " + appCode);
		
		//Application Validator
		List<String> validatorList = propertiesManager.getApplicationValiator(appCode);
		if(validatorList!=null && !validatorList.isEmpty()){
			for(String appValidator : validatorList){
				if(appValidator != null && !appValidator.equalsIgnoreCase("")){
					try {										
						Validator validator = new ValidatorImpl ();
						validator.init(appValidator);		    		
			    	}
			    	catch (ConfigurationException e) {
						log.error("Error while initializing " + appCode + " application validator: "+ appValidator +".");
					}
				}
			}
		}
    	List<LookupProperties> lookupList = ProfileCommandQuery.getLookupPropertiesOfApplication(app.getId());
		if(lookupList==null || lookupList.isEmpty()){
			log.warn(String.format("Criteria Category \"%1$s\" doesn't have properties defined. Corresponding index won't be built", app.getApplicationCode()));
			return;
		}
		
		Collections.sort(lookupList,lookupCmp);
		LookupProperties [] lpList = new LookupProperties[lookupList.size()];
		lookupList.toArray(lpList);
		
		Map<Long,Property> lPropertyMap = new HashMap<Long, Property>();
		String lookupCode = ProfileCommandQuery.getPropertyById(lpList[0].getPropertyId()).getPropertyCode();
		LookupIndex lookupIndex = new LookupIndex();
		lookupIndex.setLookupPropertyCode(lookupCode);
		
		List<PropertyGroup> listPropertyGroups = ProfileCommandQuery.getPropertyGroupsOfApplication(app.getId());
		if(listPropertyGroups != null && !listPropertyGroups.isEmpty()){ 
			for (PropertyGroup group : listPropertyGroups) {
			List<PropertyGroupMapping> listPropertyGroupMappings = 
				ProfileCommandQuery.getPropertyGroupMappingOfPropertyGroup(group.getId());
			if(listPropertyGroupMappings != null && !listPropertyGroupMappings.isEmpty())
				for (PropertyGroupMapping mappings : listPropertyGroupMappings) {
					Property pro = ProfileCommandQuery.getPropertyById(mappings.getPropertyId());
					if(pro!=null){
						prfIndex.addProperty(pro.getPropertyCode(), pro);
						prfIndex.addPropertyType(pro.getPropertyCode(), pro.getDataType());
					}else {
						throw new DASException("Property Not Found in Cache"+mappings.getPropertyId());
					}
				}
			}
		}
		DataConverter dataConverter = propertiesManager.getApplicationDataConverter(appCode);
		IHierarchyLoader hierarchyLoader = propertiesManager.getApplicationHierarchyLoader(appCode);
		if(hierarchyLoader!=null){
			hierarchyLoader.init();
		}
		for (LookupProperties lookup : lookupList) {
			Property pro = ProfileCommandQuery.getPropertyById(lookup.getPropertyId());
			prfIndex.addProperty(pro.getPropertyCode(), pro);
			prfIndex.addPropertyType(pro.getPropertyCode(), pro.getDataType());
			lPropertyMap.put(pro.getId(), pro);
		}
		
		List<Rule> listRules = ProfileCommandQuery.getRulesOfApplication(app.getId());
		if(listRules != null && !listRules.isEmpty()){
			for (Rule rule : listRules) {
				Application application = ProfileCommandQuery.getApplicationById(rule.getApplicationId());
				if (!application.getApplicationCode().equalsIgnoreCase(appCode))
					continue;
				LookupIndex critIndex = lookupIndex;
				rule.clearTargetRuleProperty();
				List<RuleProperty> listRuleProperty = ProfileCommandQuery.getRulePropertyByRuleId(rule.getId());
				if(listRuleProperty != null && !listRuleProperty.isEmpty())
					for (RuleProperty ruleProp : listRuleProperty) {				
						rule.addTargetProperty(ruleProp, dataConverter);
				}
				prfIndex.addRule(rule.getId(), rule);
				int lastOrd = -1;
				if (!rule.getActiveFlag())
					continue;
				for (int i = 0; i < lpList.length; i++) {
					if (rule.getTargetRuleProperty().containsKey(lPropertyMap.get(lpList[i].getPropertyId()).getPropertyCode()))
						lastOrd = i;				
				}			
				if(critIndex == null){
					log.warn(String.format("Rule \"%1$s\" doesn't have Index to be put into. The rule ignored", rule.getId()));
					continue;
				}
				for (int i = 0; i < lpList.length; ++i) {
					if(i > lastOrd) break;
					Property prop = lPropertyMap.get(lpList[i].getPropertyId());
					String propCode = prop.getPropertyCode();
					Map<Object, LookupIndex> subIndexMap = critIndex.getSubIndexMap();
					Object propVal = LookupIndex.NULL_KEY;
					List<String> values = rule.retrieveDisplayStrings(propCode, prop.getDataType(), dataConverter);
					if (values.size() != 0) {
						StringBuilder builder = new StringBuilder ();
						for (Object key : values)
						{
							if (builder.length() != 0)
								builder.append(",");
							builder.append(key);
						}	
						propVal = builder.toString();
					}
					
					LookupIndex nextLookup = null;
					String subPropCode;
					if(i + 1 < lookupList.size()){
						Property subProp = lPropertyMap.get(lpList[i+1].getPropertyId());
						subPropCode = subProp.getPropertyCode();
					} else 
						subPropCode = null;
					
					if(subIndexMap.containsKey(propVal))
						nextLookup = subIndexMap.get(propVal);
					else 
						nextLookup = critIndex.addSubIndex(subPropCode, propVal);
					
					critIndex = nextLookup;
				}
				critIndex.setRule(rule);
			}
		}
		// Add Look Up Index at the end
		prfIndex.addLookupIndex(app.getApplicationCode(), lookupIndex);
    }
	
	private void buildRule(ProfileIndex prfIndex, Application app, Long ruleId) throws DASException {
		if(log.isDebugEnabled())
    		log.debug("Inside buildIndexes method");
		String appCode = app.getApplicationCode();
		log.info("buildingIndex for application : " + appCode);
		DataConverter dataConverter = propertiesManager.getApplicationDataConverter(appCode);
		Rule rule = ProfileCommandQuery.getRuleById(ruleId);
		if (rule != null && rule.getApplicationId().equals(app.getId())) {
			rule.clearTargetRuleProperty();
			List<RuleProperty> listRuleProperty = ProfileCommandQuery.getRulePropertyByRuleId(rule.getId());
			if(listRuleProperty != null && !listRuleProperty.isEmpty())for (RuleProperty ruleProp : listRuleProperty) {				
				rule.addTargetProperty(ruleProp, dataConverter);
			}
			prfIndex.addRule(rule.getId(), rule);
		}
    }
}