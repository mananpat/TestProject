package com.ml.elt.s1.profile.impl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ml.elt.s1.platform.container.exception.ConfigurationException;
import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.platform.container.service.cache.CacheDas;
import com.ml.elt.s1.platform.plugins.das.Das;
import com.ml.elt.s1.platform.plugins.das.RamDas;
import com.ml.elt.s1.profile.core.das.cache.ProfileCommandQuery;
import com.ml.elt.s1.profile.core.das.iface.ContactDao;
import com.ml.elt.s1.profile.core.das.iface.RuleDao;
import com.ml.elt.s1.profile.core.das.util.DBDataLoader;
import com.ml.elt.s1.profile.core.enums.Action;
import com.ml.elt.s1.profile.core.sdo.Application;
import com.ml.elt.s1.profile.core.sdo.Contact;
import com.ml.elt.s1.profile.core.sdo.LookupProperties;
import com.ml.elt.s1.profile.core.sdo.Property;
import com.ml.elt.s1.profile.core.sdo.Rule;
import com.ml.elt.s1.profile.core.sdo.RuleProperty;
import com.ml.elt.s1.profile.core.sdo.util.ObjectConverter;
import com.ml.elt.s1.profile.exception.ProfileException;
import com.ml.elt.s1.profile.intface.DataConverter;
import com.ml.elt.s1.profile.intface.IHierarchyLoader;
import com.ml.elt.s1.profile.intface.ILookupGenerator;
import com.ml.elt.s1.profile.intface.ProfileLifeCycle;
import com.ml.elt.s1.profile.plugins.cache.ProfileDataReloader;
import com.ml.elt.s1.profile.transfer.gui.AppBean;
import com.ml.elt.s1.profile.transfer.gui.ContactBean;
import com.ml.elt.s1.profile.transfer.gui.ErrorBean;
import com.ml.elt.s1.profile.transfer.gui.ProfileAmendReportBean;
import com.ml.elt.s1.profile.transfer.gui.ProfileDataList;
import com.ml.elt.s1.profile.transfer.gui.PropertyBean;
import com.ml.elt.s1.profile.transfer.gui.RuleBean;
import com.ml.elt.s1.profile.util.ProfileOperation;
import com.ml.elt.s1.rules.Validator;
import com.ml.elt.s1.rules.impl.ValidatorImpl;

public class ProfileLifeCycleImpl implements ProfileLifeCycle {
	
	private static Log log = LogFactory.getLog(ProfileLifeCycleImpl.class);

	private static RuleDao ruleDao = null;	
	private static ContactDao contactDao = null;
	
	private ProfilePropertiesMananger propertiesManager;
	
	private CacheDas cacheDas = null;	
	
	static {
		try 
    	{
			Das das = new RamDas();
			ruleDao = (RuleDao)das.getDao(Rule.class);			
			contactDao = (ContactDao)das.getDao(Contact.class);
    	}
    	catch(Throwable t){
    		log.error("Error while loading bean from configuration", t);
    	} 
	}
	
	
	public ProfileLifeCycleImpl (CacheDas das){
		try {
			cacheDas = das.newInstance(null, null);
			cacheDas.connect(null);
		} catch (DASException e) {
		}
	}
	
	@SuppressWarnings("unchecked")
	public List<AppBean> getAllApplications() throws ProfileException {
		List<AppBean> ret = new ArrayList<AppBean>();
		try {
			List<Application> list = ProfileCommandQuery.getApplications();
			if(list != null && !list.isEmpty()){ 
				for(Application app:list) {
					AppBean appBean = new AppBean();
					appBean.setApplicationCode(app.getApplicationCode());
					appBean.setDescription(app.getDescription());
					ret.add(appBean);
				}
			}
		} catch (DASException e) {
			throw new ProfileException(e);
		}
		return ret;
	}
	

	public List<RuleBean> getRules(String applicationCode) throws ProfileException {		
		try 
		{		
			Application app  = ProfileCommandQuery.getApplicationByCode(applicationCode);		
			if(app == null){
				String errorMessage = String.format("Application Code \"%1$s\" doesn't exist.", applicationCode);
				log.error(errorMessage);
				return null;
			}
		
			List<RuleBean> retValue = new ArrayList<RuleBean> ();			
			if(app != null) {
				List<Rule> listRules = ProfileCommandQuery.getRulesOfApplication(app.getId());
				if(listRules!= null && !listRules.isEmpty()) {
					for (Rule rule : listRules) 
						retValue.add(getLookupsForRule(rule, app));
				}
			}
			return retValue;
		}
		catch(DASException ds) {
			throw new ProfileException(ds);
		}
		catch(Throwable t) {
			throw new ProfileException(t);
		}
	}

	private RuleBean getLookupsForRule (Rule rule, Application app) throws DASException {			
		List<PropertyBean> retProps = new ArrayList<PropertyBean> ();		
		List<LookupProperties> listLookupProperties = ProfileCommandQuery.getLookupPropertiesOfApplication(app.getId());
		if(listLookupProperties != null && !listLookupProperties.isEmpty()){
			for (LookupProperties lookup : listLookupProperties) {
				if(lookup == null)
					continue;
				Property property = ProfileCommandQuery.getPropertyById(lookup.getPropertyId());
				if(property == null)
					continue;
				List<String> retValues = rule.retrieveDisplayStrings(property.getPropertyCode(), property.getDataType(), propertiesManager.getApplicationDataConverter(app.getApplicationCode()));
				if (retValues.size() > 0) {
					String propList = retValues.get(0);
					PropertyBean bean = new PropertyBean ();
					bean.setPropertyCode(property.getPropertyCode());
					bean.setValue(propList);
					bean.setRuleId(rule.getId());
					bean.setProperty(property.getDescription());
					retProps.add(bean);				
				}
			}
		}
		
		RuleBean ruleTO = new RuleBean (retProps);
		ruleTO.setActive(rule.getActiveFlag());
		ruleTO.setDescription(rule.getDescription());
		ruleTO.setRuleId(rule.getId());
		ruleTO.setUpdateTime(rule.getUpdateDateTime());
		ruleTO.setUpdateUser(rule.getUpdateUser());
		return ruleTO;
	}	
	
	public RuleBean getProfileById(String appCode, Long ruleId) throws ProfileException 
	{
		ProfileIndex prfIndex = ProfileLoader.getInstance ().getProfileIndex();
		Rule rule = prfIndex.getRule(ruleId);
		if (rule == null) {
			log.warn(String.format("Rule \"%1$s\" doesn't exist in ProfileIndex.", ruleId));
			return null;
		}
		
		Application application = prfIndex.getApplication(appCode);
		if (application == null) {
			log.warn(String.format("Application \"%1$s\" doesn't exist in ProfileIndex.", appCode));
			return null;
		}
		
		RuleBean retValue = new RuleBean ();
		retValue.setRuleId(ruleId);
		retValue.setActive(rule.getActiveFlag());
		retValue.setUpdateUser(rule.getUpdateUser());
		retValue.setUpdateTime(rule.getUpdateDateTime());
		retValue.setDescription(rule.getDescription());
		
		DataConverter converter = propertiesManager.getApplicationDataConverter(appCode);
		
		for (String propertyCode : rule.getTargetRuleProperty().keySet()) {
			Property prop = prfIndex.getPropertyMap().get(propertyCode);
			if (prop == null) {
				log.warn(String.format("Property \"%1$s\" doesn't exist.", propertyCode));
				return null;
			}
			
			PropertyBean bean = new PropertyBean ();			
			bean.setGroup(ProfileCommandQuery.getPropertyGroupCodeByPropertyId(application.getId(), prop.getId()));			
			bean.setPropertyCode(prop.getPropertyCode());
					
			String value = "";
			List<String> rpValues = rule.retrieveDisplayStrings(bean.getPropertyCode(), prop.getDataType(), converter);
			for (String val : rpValues) {
				if (value.length() != 0)
					value += ",";
				value += val;
			}			
			bean.setValue(value);
			
			bean.setRuleId(ruleId);
			bean.setProperty(prop.getDescription());
			retValue.addProfileProperty(bean);
		}		
		return retValue;
	}
	
	public RuleBean getProperties(String appCode, RuleBean incomingRule) throws ProfileException 
	{		
		if (incomingRule.getProfileProperty() == null || incomingRule.getProfileProperty().size() == 0) {
			log.debug(String.format("No lookup properties exists."));
			return null;
		}
		
		Map<String, Object> lookups = new HashMap<String, Object> ();
		for (PropertyBean pbean : incomingRule.getProfileProperty()) {
			if (pbean.getValue() != null && pbean.getValue().length() != 0)
				lookups.put (pbean.getPropertyCode(), pbean.getValue());
		}
		
		ILookupGenerator lookupGen = propertiesManager.getApplicationLookupGenerators(appCode);
		if (lookupGen != null)
			lookupGen.generateLookups(lookups, incomingRule.getUpdateUser());
		
		RuleBean retValue = new RuleBean ();
		retValue.setRuleId(incomingRule.getRuleId());
		for (String key : lookups.keySet()) {
			PropertyBean pbean = new PropertyBean ();
			pbean.setPropertyCode(key);
			pbean.setValue(lookups.get(key).toString());
			pbean.setRuleId(incomingRule.getRuleId());
			retValue.getProfileProperty().add(pbean);
		}	
		
		Application application = ProfileLoader.getInstance ().getProfileIndex().getApplication(appCode);
		if (application == null) {
			log.warn(String.format("Application \"%1$s\" doesn't exist in ProfileIndex.", appCode));
			return null;
		}
		
		LookupIndex lookupIndex = ProfileLoader.getInstance ().getProfileIndex().getLookupIndex(appCode);
		
		if (lookupIndex != null ) {
			LookupResultSet ctx = new LookupResultSet();
			ctx.lookupValues = lookups;
			IHierarchyLoader hierarchy = propertiesManager.getApplicationHierarchyLoader(appCode);
			Long startTime = System.currentTimeMillis();
			if(hierarchy != null){
				hierarchy.helpSearch(lookupIndex,ctx);
			} else { 
				lookupIndex.search(ctx,true);
			}
			log.info("Profile Search Done in:"+(System.currentTimeMillis() - startTime));

			for (String key : ctx.propertyValues.keySet()) {
				Property prop = ProfileLoader.getInstance ().getProfileIndex().getPropertyMap().get(key);
				if (prop == null) {
					log.debug(String.format("Property doesn't exist for Property Code \"%1$s\".", key));
					continue;
				}
				PropertyBean pbean = new PropertyBean ();
				pbean.setPropertyCode(prop.getPropertyCode());
				pbean.setGroup(ProfileCommandQuery.getPropertyGroupCodeByPropertyId(application.getId(), prop.getId()));
				pbean.setRuleId(ctx.rulesMap.get(key));
				pbean.setProperty(prop.getDescription());
				Rule rule = ProfileLoader.getInstance ().getProfileIndex().getRule(pbean.getRuleId());
				
				String value = "";
				List<String> rpValues = rule.retrieveDisplayStrings(key, prop.getDataType(), propertiesManager.getApplicationDataConverter(appCode));
				for (String val : rpValues) {
					if (value.length() != 0)
						value += ",";
					value += val;
				}	
				pbean.setValue(value);
				
				incomingRule.getProfileProperty().add(pbean);
			}
			
			List<String> validationErrors = null;		
			List<String> validatorList = propertiesManager.getApplicationValiator(appCode);					
			if(validatorList != null && !validatorList.isEmpty()){
				for(String appValidator : validatorList){
					if(appValidator != null && !appValidator.equalsIgnoreCase("")){
						if(appValidator.endsWith(appCode+".Preview")){
							try {										
								Validator validator = new ValidatorImpl ();
								validationErrors = validator.validate(ctx.propertyValues, appValidator);	    		
					    	}
					    	catch (ConfigurationException e) {
								log.error("Error while validating " + appCode + " application validator: "+ appValidator +".");
							}
						}
					}
				}
			}	
			
			if ( validationErrors !=null && validationErrors.size() > 0) {
				for (String errorMsg : validationErrors) {
					ErrorBean errorBean = new ErrorBean ();
					errorBean.setRuleId(incomingRule.getRuleId());
					errorBean.setErrorMsg(errorMsg);
					incomingRule.addError(errorBean);					
				}
			}				
		}
		
		return retValue;		 
	}
	
	/*
	 * Insert or Update Rule and Rule Properties
	 * 
	 * (non-Javadoc)
	 * @see com.ml.elt.s1.profile.intface.ProfileLifeCycle#saveOrUpdateProfiles(com.ml.elt.s1.profile.transfer.gui.ProfileDataList, java.lang.String)
	 */
	public ProfileDataList saveProfile(String applicationCode, ProfileDataList incomingProfDataList) throws ProfileException {
		log.info("Inside saveProfile method.");
		try
		{
			Application application = ProfileCommandQuery.getApplicationByCode(applicationCode);
			if (application == null) {
				String message = String.format("Invalid Profile Save Request. Application \"%1$s\" doesn't exist.", applicationCode);
				throw new ProfileException(message);
			}
					
			if(incomingProfDataList == null || incomingProfDataList.getRules() == null || incomingProfDataList.getRules().isEmpty())
				throw new ProfileException("Invalid Profile Save Request. ProfileData is either invalid or empty.");
			
			String userId = incomingProfDataList.getUserId();
			
			for(RuleBean incomingRuleBean : incomingProfDataList.getRules()){
				try
				{	
					RuleBean propertyErrorBean = validateRuleProperty(application, incomingRuleBean);
					if (propertyErrorBean != null && propertyErrorBean.getErrors().size() > 0){
						incomingRuleBean.addAllError(propertyErrorBean.getErrors());
						continue;
					}
					
					RuleBean errorBean = validateRule(application, incomingRuleBean);
					if (errorBean != null && errorBean.getErrors().size() > 0){
						incomingRuleBean.addAllError(errorBean.getErrors());
						continue;
					}
					
					List<RuleProperty> deleteRulePropertyList = null;
					List<RuleProperty> newRulePropertyList = null;
					
					//check for Rule Properties									
					List<PropertyBean> incomingPropertyBeanList = incomingRuleBean.getProfileProperty();					
					if(incomingPropertyBeanList == null || incomingPropertyBeanList.isEmpty()){
						String message = String.format("Rule Properties do not exist in the save reuqest for Rule Id \"%1$s\" ..", incomingRuleBean.getRuleId());
						log.info(message);
					}
					else
					{					
						DataConverter converter = propertiesManager.getApplicationDataConverter(applicationCode);
						
						deleteRulePropertyList = new ArrayList<RuleProperty>();
						newRulePropertyList = new ArrayList<RuleProperty>();
							
						//PropertyId to Rule property Map
						Map<Long,List<RuleProperty>> existingRulePropertyMap = ProfileCommandQuery.getRulePropertyMapByRuleId(incomingRuleBean.getRuleId());
							
						for(PropertyBean incomingPropBean : incomingPropertyBeanList){							
							Property property = ProfileCommandQuery.getPropertyByPropCode(incomingPropBean.getPropertyCode());
							if(property == null){
								String message = String.format("Invalid Profile Save Request. Property Code \"%1$s\" doesn't exist in cache..", incomingPropBean.getPropertyCode());
								log.error(message);
								continue;
							}
							
							List<RuleProperty> existingRulePropertyList = null;
							if(existingRulePropertyMap != null)
								existingRulePropertyList = existingRulePropertyMap.get(property.getId());
														
							//check for those rule properties which can have mutliple values i.e. calendars
							String propVal = incomingPropBean.getValue().trim();
							String seperator = converter.isAList(property.getPropertyCode()) ? "," : null;
							String[] splitValues;
							if(seperator != null)
								splitValues  = propVal.split(seperator);
							else {
								splitValues = new String[1];
								splitValues[0] = propVal;
							}
								
							Set<String> newValueSet = new HashSet<String>();
							for(String value : splitValues){
								if(!"".equals(value.trim()))
									newValueSet.add(value.trim());
							}
							
							//New Rule Properties
							if(existingRulePropertyList == null)
							{
								if(newValueSet.size() != 0){
									for(String newValue : newValueSet){
										RuleProperty newRuleProperty = new RuleProperty();
										newRuleProperty.setAction(Action.ADD);
										newRuleProperty.setCreateUser(userId);
										newRuleProperty.setUpdateUser(userId);							
										newRuleProperty.setRuleId( incomingPropBean.getRuleId());
										newRuleProperty.setValue(newValue);
										newRuleProperty.setPropertyId(property.getId());							
										newRulePropertyList.add(newRuleProperty);
									}
								}								
							}
							else
							{	
								//existing Rule Property updates - by adding more to an existing one
								if(newValueSet.size() > 1){
									//delete existing new Rule Properties
									for(RuleProperty existingRuleProperty : existingRulePropertyList){
										if(newValueSet.contains(existingRuleProperty.getValue().trim())){										
											newValueSet.remove(existingRuleProperty.getValue().trim());
										}
										else{											
											RuleProperty deleteRuleProperty = new RuleProperty();												
											deleteRuleProperty.setAction(Action.DELETE);
											deleteRuleProperty.setRuleId(existingRuleProperty.getRuleId());									
											deleteRuleProperty.setId(existingRuleProperty.getId());
											deleteRuleProperty.setPropertyId(existingRuleProperty.getPropertyId());
											deleteRulePropertyList.add(deleteRuleProperty);
										}									
									}
									
									for(String newValue : newValueSet){
										RuleProperty newRuleProperty = new RuleProperty();
										newRuleProperty.setAction(Action.ADD);
										newRuleProperty.setCreateUser(userId);
										newRuleProperty.setUpdateUser(userId);							
										newRuleProperty.setRuleId( incomingPropBean.getRuleId());
										newRuleProperty.setValue(newValue);
										newRuleProperty.setPropertyId(property.getId());							
										newRulePropertyList.add(newRuleProperty);
									}
								}
								else if(newValueSet.size() == 0 && existingRulePropertyList.size() > 0){
									//existing Rule Property updates - Deleting an existing ones
									for(RuleProperty existingRuleProperty : existingRulePropertyList){
										RuleProperty deleteRuleProperty = new RuleProperty();												
										deleteRuleProperty.setAction(Action.DELETE);	
										deleteRuleProperty.setRuleId(existingRuleProperty.getRuleId());	
										deleteRuleProperty.setId(existingRuleProperty.getId());
										deleteRuleProperty.setPropertyId(existingRuleProperty.getPropertyId());
										deleteRulePropertyList.add(deleteRuleProperty);
									}
								}
								else
								{								
									if(existingRulePropertyList.size() > 1){
										for(RuleProperty existingRuleProperty : existingRulePropertyList){
											if(newValueSet.contains(existingRuleProperty.getValue().trim()))												
												newValueSet.remove(existingRuleProperty.getValue().trim());											
											else {										
												RuleProperty deleteRuleProperty = new RuleProperty();												
												deleteRuleProperty.setAction(Action.DELETE);
												deleteRuleProperty.setRuleId(existingRuleProperty.getRuleId());		
												deleteRuleProperty.setId(existingRuleProperty.getId());
												deleteRuleProperty.setPropertyId(existingRuleProperty.getPropertyId());
												deleteRulePropertyList.add(deleteRuleProperty);
											}									
										}										
										for(String newValue : newValueSet){
											RuleProperty newRuleProperty = new RuleProperty();
											newRuleProperty.setAction(Action.ADD);
											newRuleProperty.setRuleId(incomingPropBean.getRuleId());
											newRuleProperty.setPropertyId(property.getId());
											newRuleProperty.setValue(newValue);
											newRuleProperty.setCreateUser(userId);
											newRuleProperty.setUpdateUser(userId);							
											newRulePropertyList.add(newRuleProperty);										}
									}
									else
									{
										RuleProperty existingRuleProperty = existingRulePropertyList.get(0);
										RuleProperty newRuleProperty = new RuleProperty();									
										newRuleProperty.setAction(Action.UPDATE);			
										newRuleProperty.setId(existingRuleProperty.getId());
										newRuleProperty.setRuleId(incomingPropBean.getRuleId());
										newRuleProperty.setPropertyId(property.getId());
										newRuleProperty.setValue(splitValues[0]);										
										newRuleProperty.setUpdateUser(userId);
										newRulePropertyList.add(newRuleProperty);
									}
								}								
							}
						}						
					} //end of if-else incomingPropertyBeanList		
															
					List<RuleProperty> mergedRuleProperties = new ArrayList<RuleProperty>();
					if(deleteRulePropertyList != null && !deleteRulePropertyList.isEmpty())					
						mergedRuleProperties.addAll(deleteRulePropertyList);					
					if(newRulePropertyList != null && !newRulePropertyList.isEmpty())						
						mergedRuleProperties.addAll(newRulePropertyList);					
					
					Rule existingRule = ProfileCommandQuery.getRuleById(incomingRuleBean.getRuleId());
					Rule updatedRule = null;		
					
					if(existingRule == null){						
						updatedRule = ObjectConverter.getRule(incomingRuleBean, application.getId());								
						updatedRule.setCreateUser(userId);
						updatedRule.setUpdateUser(userId);									
						updatedRule.setAction(Action.ADD);					
					}
					else
					{					
						if(mergedRuleProperties == null || mergedRuleProperties.isEmpty()){
							if(!existingRule.equals(incomingRuleBean)){
								//Rule Description or Active Flag is changed
								updatedRule = ObjectConverter.getRule(incomingRuleBean, application.getId());								
								updatedRule.setCreateDateTime(existingRule.getCreateDateTime());
								updatedRule.setCreateUser(existingRule.getCreateUser());
								updatedRule.setUpdateUser(userId);												
								updatedRule.setAction(Action.UPDATE);
							}
							else
							{	
								String message = String.format("Neither Rule nor Rule Properties are updated in the Profile Save Request. Rule Id: \"%1$s\".", incomingRuleBean.getRuleId());
								log.info(message);							
								ErrorBean error = new ErrorBean ();
								error.setRuleId(incomingRuleBean.getRuleId());
								error.setErrorMsg("Neither Rule nor Properties are changed");								
								incomingRuleBean.addError(error);
								continue;								
							}
						}
						else
						{
							//Update of Rule 
							updatedRule = ObjectConverter.getRule(incomingRuleBean, application.getId());
							updatedRule.setCreateDateTime(existingRule.getCreateDateTime());
							updatedRule.setCreateUser(existingRule.getCreateUser());
							updatedRule.setUpdateUser(userId);									
							updatedRule.setAction(Action.UPDATE);
						}
					}
					
					if(updatedRule != null){
						boolean result = false;
						StringBuffer errorMsg = new StringBuffer(); 
						try
						{
							result = ruleDao.saveRule(updatedRule, mergedRuleProperties);
						}
						catch(DASException de){							
							errorMsg.append(String.format("Exception while saving rules. Rule Id: \"%1$s\".", incomingRuleBean.getRuleId()));
							log.warn(errorMsg, de);
							result = false;
						}
						
						String message = String.format("Rule Id: \"%1$s\" update status: \"%2$s\"", incomingRuleBean.getRuleId(), result);
						log.info(message);
						if(result){
							if(existingRule == null)
								cacheDas.write(updatedRule);
							else
							{
								Rule cachedRule = ProfileCommandQuery.getRuleById(existingRule.getId());
								Boolean uiActiveFlag =  updatedRule.getActiveFlag();
								Boolean cacheActiveFlag =  cachedRule.getActiveFlag();

//								if((uiActiveFlag!=null  && cacheActiveFlag!=null && !uiActiveFlag.equals(cacheActiveFlag)) ||
//									(uiActiveFlag==null  && cacheActiveFlag!=null) || 
//									(uiActiveFlag!=null  && cacheActiveFlag==null)){

								if(!((uiActiveFlag!=null  && cacheActiveFlag!=null && uiActiveFlag.equals(cacheActiveFlag)) ||
											  (uiActiveFlag==null  && cacheActiveFlag==null))) {									
									incomingRuleBean.setCommand(ProfileOperation.PRF_REFRESH);
								}
								
								existingRule.setActiveFlag(updatedRule.getActiveFlag());
								existingRule.setActiveValue(updatedRule.getActiveValue());
								existingRule.setDescription(updatedRule.getDescription());
								existingRule.setUpdateUser(updatedRule.getUpdateUser());
								existingRule.setUpdateDateTime(updatedRule.getUpdateDateTime());
								cacheDas.write(existingRule);								
							}
							if(deleteRulePropertyList != null && !deleteRulePropertyList.isEmpty())
								cacheDas.remove(deleteRulePropertyList);
							if(newRulePropertyList != null && !newRulePropertyList.isEmpty())
								cacheDas.write(newRulePropertyList);
							log.info(String.format("Cache Updated successfully for Rule Id: \"%1$s\".", incomingRuleBean.getRuleId()));
						}					
						else
						{	
							if(!result && errorMsg.length() != 0)
								errorMsg.append(String.format("One or more error(s) occurred while saving rule and/or properties in the database. Rule Id: \"%1$s\".", incomingRuleBean.getRuleId()));
							log.warn(errorMsg);
							ErrorBean error = new ErrorBean();
							error.setRuleId(incomingRuleBean.getRuleId());
							error.setErrorMsg("One or more error(s) occurred while saving rule and/or properties in the database.");
							incomingRuleBean.addError(error);
						}
					}
				} catch(Throwable t) {					
					ErrorBean error = new ErrorBean();
					error.setRuleId(incomingRuleBean.getRuleId());
					error.setErrorMsg("One or more error(s) occurred while saving profile data");
					incomingRuleBean.addError(error);					
				}			
			}			
			return createSaveProfileResponse(application, incomingProfDataList.getRules());	
		}
		catch(DASException de){
			String message = "Exception occurred while saving profile data.";
			log.error(message, de);
			throw new ProfileException(message, de);
		}	
	}
	
	private ProfileDataList createSaveProfileResponse(Application application, List<RuleBean> incomingRuleBeansList) throws ProfileException {
		ProfileDataList responseProfileDataList = new ProfileDataList();
		try
		{	
			List<LookupProperties> listLookupProperties = ProfileCommandQuery.getLookupPropertiesOfApplication(application.getId());
			
			for(RuleBean incomingRuleBean : incomingRuleBeansList){
				responseProfileDataList.addRuleBean(incomingRuleBean);				
				if(incomingRuleBean.getErrors() != null && !incomingRuleBean.getErrors().isEmpty())	{
					responseProfileDataList.setErrors(incomingRuleBean.getErrors());
					continue;
				}
				
				//if any of the properties updated is lookup properties then reload;
				List<PropertyBean> incomingPropertyBeanList = incomingRuleBean.getProfileProperty();
				Set<Long> updatedPropIdSet = new HashSet<Long>();
				for(PropertyBean propBean : incomingPropertyBeanList){
					Property property = ProfileCommandQuery.getPropertyByPropCode(propBean.getPropertyCode());						
					updatedPropIdSet.add(property.getId());
				}			
				
				if(!ProfileOperation.PRF_REFRESH.equals(incomingRuleBean.getCommand())){
					boolean isRefreshByAppRequired = false;
					for(LookupProperties lookProperties : listLookupProperties){
						if(updatedPropIdSet.contains(lookProperties.getPropertyId())){										
							isRefreshByAppRequired = true;
							break;
						}
					}
										
					if(isRefreshByAppRequired)								
						incomingRuleBean.setCommand(ProfileOperation.PRF_REFRESH);
				}
			}	
		}
		catch(Throwable t){
			String message = "One or more error(s) occurred in while preparing view data in profile response.";
			log.error(message, t);
			throw new ProfileException(message, t);
		}
		log.info("End of buildProfileDataView and saveProfile method.");
		return responseProfileDataList;
	}
		
	/*
	private ProfileDataList buildProfileDataView(Application application, List<RuleBean> incomingRuleBeansList) throws ProfileException {
		ProfileDataList responseProfileDataList = new ProfileDataList();
		try
		{
			List<RuleBean> retRuleBeanList = new ArrayList<RuleBean>();			
			for(RuleBean incomingRuleBean : incomingRuleBeansList){
				if(incomingRuleBean.getErrors() != null && !incomingRuleBean.getErrors().isEmpty()){	
					responseProfileDataList.addRuleBean(incomingRuleBean); //add errors to each rule as well;
					responseProfileDataList.setErrors(incomingRuleBean.getErrors());
					continue;
				}
										
				Rule rule = ProfileCommandQuery.getRuleById(incomingRuleBean.getRuleId());
				List<LookupProperties> listLookupProperties = ProfileCommandQuery.getLookupPropertiesOfApplication(application.getId());
				List<RuleProperty> ruleProperties = ProfileCommandQuery.getRulePropertyByRuleId(incomingRuleBean.getRuleId());
				
				//if any of the properties updated is lookup properties then reload;
				List<PropertyBean> incomingPropertyBeanList = incomingRuleBean.getProfileProperty();
				Set<Long> updatedPropIdSet = new HashSet<Long>();
				for(PropertyBean propBean : incomingPropertyBeanList){
					Property property = ProfileCommandQuery.getPropertyByPropCode(propBean.getPropertyCode());						
					updatedPropIdSet.add(property.getId());
				}			
				
				RuleBean retRuleBean = ObjectConverter.getRuleBean(rule);
				
				if(ProfileOperation.PRF_REFRESH.equals(incomingRuleBean.getCommand())){
					retRuleBean.setCommand(ProfileOperation.PRF_REFRESH);
				}
				else
				{
					boolean isReloadForRule = true;
					for(LookupProperties lookProperties : listLookupProperties){
						if(updatedPropIdSet.contains(lookProperties.getPropertyId())){
							rebuildProfileIndex(application.getApplicationCode());					
							isReloadForRule = false;
							break;
						}				
					}
					
					if(isReloadForRule)
						rebuildProfileIndex(application.getApplicationCode(), incomingRuleBean.getRuleId());
					else				
						retRuleBean.setCommand(ProfileOperation.PRF_REFRESH);
				}
				Set<Long> lookupPropIds = new HashSet<Long>();
				
				for (LookupProperties lookup : listLookupProperties) {
					lookupPropIds.add(lookup.getPropertyId());
				}
					
				for(RuleProperty ruleProperty : ruleProperties){
					if(ruleProperty.getPropertyId()!=null &&  lookupPropIds.contains(ruleProperty.getPropertyId())	){
							Property property = ProfileCommandQuery.getPropertyById(ruleProperty.getPropertyId());								
							if(property != null && ruleProperty != null){
								PropertyBean pbean = new PropertyBean(retRuleBean.getRuleId(), property.getPropertyCode(), ruleProperty.getValue(), property.getDescription(), null);
								retRuleBean.addProfileProperty(pbean);
								retRuleBeanList.add(retRuleBean);
							}
						}						
					responseProfileDataList.setRules(retRuleBeanList);
				}	
			}
		}
		catch(Throwable t){
			String message = "One or more error(s) occurred in while preparing view data in profile response.";
			log.error(message, t);
			throw new ProfileException(message, t);
		}
		log.info("End of buildProfileDataView and saveProfile method.");
		return responseProfileDataList;
	}
	*/
	@SuppressWarnings("unchecked")
	public List<ContactBean> getAllContacts() throws ProfileException {
		List<ContactBean> retValue = new ArrayList<ContactBean>();
		try {
			List<Contact> list = ProfileCommandQuery.getContacts();
			if(list != null && !list.isEmpty()) {
				for (Contact contact : list) {
					ContactBean newBean = ObjectConverter.toContactBean(contact);
					retValue.add(newBean);
				}				
			}
		} catch (DASException e) {
			throw new ProfileException(e);
		}
		return retValue;
	}
	
	
	public ProfileDataList saveContacts(ProfileDataList incomingProfDataList) throws ProfileException {
		log.info("Inside saveContacts method.");
		if(incomingProfDataList == null || incomingProfDataList.getContacts() == null || incomingProfDataList.getContacts().isEmpty())
			throw new ProfileException("Invalid Profile Request. ProfileData is either invalid or null.");
		
		String userId = incomingProfDataList.getUserId();
		ProfileDataList dataList = new ProfileDataList();
		
		for(ContactBean contactBean : incomingProfDataList.getContacts()){
			try
			{	
				Contact cachedContct = ProfileCommandQuery.getContactById(contactBean.getId());
				Contact newContact = ObjectConverter.toContact(contactBean);				
				if(cachedContct == null){					
					newContact.setAction(Action.ADD);
					newContact.setCreateUser(userId);
					newContact.setUpdateUser(userId);
					newContact.setId(null);
				}
				else {					
					newContact.setAction(Action.UPDATE);
					//Some of the old contact did not have create users to have to as work around
					if(newContact.getCreateUser() == null || "".equals(newContact.getCreateUser()))
						newContact.setCreateUser(userId);
					newContact.setUpdateUser(userId);
				}
				
				boolean result = false;
				StringBuffer errorMsg = new StringBuffer(); 
				try
				{
					result = contactDao.saveContact(newContact);
					contactBean.setId(newContact.getId());
				}
				catch(DASException de){							
					errorMsg.append(String.format("Exception while saving contact. Contact Id: \"%1$s\".", contactBean.getId()));
					log.warn(errorMsg, de);
					result = false;
				}
				
				String message = String.format("Contact Id: \"%1$s\" update status: \"%2$s\"", contactBean.getId(), result);
				log.info(message);
				if(result){
					cacheDas.write(newContact);					
					log.info(String.format("Cache Updated successfully for Contact Id: \"%1$s\".", contactBean.getId()));
					dataList.addContacts(contactBean);
				}					
				else
				{	
					if(!result && errorMsg.length() != 0)
						errorMsg.append(String.format("One or more error(s) occurred while saving contact in the database. Rule Id: \"%1$s\".", contactBean.getId()));
					log.warn(errorMsg);
					ErrorBean error = new ErrorBean();
					error.setRuleId(contactBean.getId());
					error.setErrorMsg("One or more error(s) occurred while saving contact in the database.");
					contactBean.addErrors(error);
					dataList.addError(error);					
				}
			}
			catch(Throwable t){
				String message = "One or more errors occurred while saving Contact.";					
				ErrorBean error = new ErrorBean();
				error.setRuleId(contactBean.getId());
				error.setErrorMsg(message);
				contactBean.addErrors(error);
				dataList.addError(error);
			}			
		}

		log.info("End of saveContacts method.");
		return dataList;
	}
	
	
	public void saveContactsToCache(ProfileDataList incomingProfDataList) throws ProfileException {
		log.info("Start of saveContactsToCache.");
		if(incomingProfDataList == null || incomingProfDataList.getContacts() == null || incomingProfDataList.getContacts().isEmpty())
			throw new ProfileException("Invalid Profile Request. ProfileData is either invalid or null.");
		for(ContactBean contactBean : incomingProfDataList.getContacts()){
			Contact newContact = ObjectConverter.toContact(contactBean);				
			if(newContact != null){					
				Long contactId = newContact.getId();
				if(contactId!=null && contactId > 0){
					try {
						cacheDas.write(newContact);
					} catch (DASException dasEx) {
						log.error("Unable to write contact details to cache :" + contactBean, dasEx);
					}
				} else {
					log.warn("Unable to write contact details to cache:" + contactBean);
				}
			}
		}
		log.info("End of saveContactsToCache");
	}
	
	public List<ProfileAmendReportBean> getAmendmentTrailReport(List<Long> ruleIds, Date startTime, Date endTime) throws ProfileException {
		try 
		{			
			if(startTime == null)
				startTime = new Date();
			if(endTime == null)
				endTime = new Date();
			
			if(!startTime.equals(endTime) && !startTime.before(endTime)){				
				final DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
				String startDateString = dateFormat.format(startTime);
				String endDateString = dateFormat.format(endTime);
				String error = String.format("Invalid Date Range. Start Date \"%1$s\" must be equal or before End Date \"%2$s\" for Profile Amendment Report.", startDateString, endDateString);			
				throw new ProfileException(error);
			}
			
			return DBDataLoader.getProfileAmendReport(ruleIds, startTime, endTime);
		}
		catch(Throwable t) {
			throw new ProfileException(t);
		}
	}

	public long getNextRuleId() throws ProfileException {
		Long nextRuleId = null;
		try {
			nextRuleId = ruleDao.getNextRuleId();
		} catch (DASException dasEx) {
			throw new ProfileException("Unable to get New Rule Id",dasEx);
		}
		
		return nextRuleId;
	}
	
	private RuleBean validateRuleProperty (Application application, RuleBean incomingRuleBean) {
		if (application == null || incomingRuleBean == null)
			return null;
		 
		ProfilePropertyDataTypeValidator validator = new ProfilePropertyDataTypeValidator ();
		List<String> errors = validator.validate(application.getApplicationCode(), incomingRuleBean.getProfileProperty());						
		
		RuleBean errorRule = null;
		if ( errors != null && errors.size() > 0) {
			errorRule = new RuleBean ();
			for (String error : errors) {
				ErrorBean errorBean = new ErrorBean ();
				errorBean.setRuleId(incomingRuleBean.getRuleId());
				errorBean.setErrorMsg(error);
				errorRule.addError(errorBean);					
			}					
		}
		
		return errorRule;
	}
		
	private RuleBean validateRule (Application application, RuleBean incomingRuleBean) {
		if (application == null || incomingRuleBean == null)
			return null;
		
		try
		{			
			String validatorConfig = null;
			List<String> validatorList = propertiesManager.getApplicationValiator(application.getApplicationCode());					
			if(validatorList != null && !validatorList.isEmpty()){
				for(String appValidator : validatorList){
					if(appValidator != null && !appValidator.equalsIgnoreCase("")){
						if(appValidator.endsWith(application.getApplicationCode())){
							validatorConfig = appValidator;
							break;
						}
					}
				}
			}	
			
			if( validatorConfig == null || "".equals(validatorConfig))
				return null;
			
			Map<String, List<Object>> existingRulePropMap = new HashMap<String, List<Object>> ();
			Map<String, Object> lookups = new HashMap<String, Object> ();			
			Rule existingRule = ProfileCommandQuery.getRuleById(incomingRuleBean.getRuleId());
			List<LookupProperties> listLookupPropertyList = ProfileCommandQuery.getLookupPropertiesOfApplication(application.getId());
			
			if(existingRule != null){
				existingRulePropMap.putAll(existingRule.getTargetRuleProperty());
				if(listLookupPropertyList != null && !listLookupPropertyList.isEmpty()){
					for (LookupProperties lookupProperty : listLookupPropertyList) {
						Property property = ProfileCommandQuery.getPropertyById(lookupProperty.getPropertyId());					
						List<Object> values = existingRule.getTargetRuleProperty().get(property.getPropertyCode());
						if (values != null && values.size() > 0)
							lookups.put(property.getPropertyCode(), values.get(0));
					}
				}
			}			
			
			if(incomingRuleBean.getProfileProperty() != null && !incomingRuleBean.getProfileProperty().isEmpty()){
				for (PropertyBean incomingPropBean : incomingRuleBean.getProfileProperty()) {
					if (incomingPropBean.getValue() != null && incomingPropBean.getValue().length() != 0) {
						List<Object> list = new ArrayList<Object> ();
						list.add (incomingPropBean.getValue());
						existingRulePropMap.put(incomingPropBean.getPropertyCode(), list);					
					}
					else 
						existingRulePropMap.remove(incomingPropBean.getPropertyCode());
					
					if(listLookupPropertyList != null && !listLookupPropertyList.isEmpty()){
						for (LookupProperties lookupProperty : listLookupPropertyList) {
							Property property = ProfileCommandQuery.getPropertyById(lookupProperty.getPropertyId());	
							if (property.getPropertyCode().equals(incomingPropBean.getPropertyCode())) {
								if (incomingPropBean.getValue() != null && incomingPropBean.getValue().length() != 0)
									lookups.put(incomingPropBean.getPropertyCode(), incomingPropBean.getValue());
								else 
									lookups.remove(incomingPropBean.getPropertyCode());
								break;
							}
						}
					}
				}
			}
			
			List<String> errors = null;
			try {
				Validator validator = new ValidatorImpl ();
				errors = validator.validate(existingRulePropMap, validatorConfig);						
			}
			catch (ConfigurationException e) {
				log.warn("ConfigurationException while validating profile data in the request.", e);
				if(errors == null)
					errors = new ArrayList<String>();
				errors.add("One or more error(s) occurred while validating profile rule and/or properties in the profile save request.");
			}
			
			DataConverter converter = propertiesManager.getApplicationDataConverter(application.getApplicationCode());
			
			LookupIndex critNdx = ProfileLoader.getInstance().getProfileIndex().getLookupIndex(application.getApplicationCode());
			if (critNdx != null) {
				LookupResultSet context = new LookupResultSet();

				IHierarchyLoader hierarchy = propertiesManager.getApplicationHierarchyLoader(application.getApplicationCode());
				
				context.lookupValues = lookups;
				context.propertyTypesMap = ProfileLoader.getInstance().getProfileIndex().getPropertyTypeMaps();

				if(hierarchy != null){
					hierarchy.helpSearch(critNdx,context);
				} else { 
					critNdx.search(context,true);
				}
				
				Long sameRuleId = null;
				for (Long id : context.rulesList) {
					if (existingRule != null && existingRule.getId().equals(id)) {
						sameRuleId = null;
						continue;
					}
					Rule checkRule = ProfileLoader.getInstance ().getProfileIndex().getRuleMap().get(id);
					sameRuleId = id;
					for (String lookupKey : lookups.keySet()) {
						List<String> values = checkRule.retrieveDisplayStrings(lookupKey, ProfileLoader.getInstance ().getProfileIndex().getPropertyMap().get(lookupKey).getDataType(), converter);
						if (values.size() == 0 || !values.get(0).equalsIgnoreCase(lookups.get (lookupKey).toString()))
							sameRuleId = null;
					}
					if (sameRuleId != null)
						break;					
				}
				if (sameRuleId != null && context.rulesList.size() > 0) {
					if (errors == null)
						errors = new ArrayList<String> ();
					errors.add("Profile with the same criteria properties already exists (" + sameRuleId + ")");				
				}					
			}
						
			RuleBean errorRule = new RuleBean ();
			if ( errors != null && errors.size() > 0) {
				for (String error : errors) {
					ErrorBean errorBean = new ErrorBean ();
					errorBean.setRuleId(incomingRuleBean.getRuleId());
					errorBean.setErrorMsg(error);
					errorRule.addError(errorBean);					
				}					
			}	
			return errorRule;
		}
		catch(Throwable t){
			String message = "One or more error(s) occurred while validating profile rule and/or properties in the profile save request."; 
			log.warn(message);
			RuleBean errorRule = new RuleBean ();
			ErrorBean errorBean = new ErrorBean ();
			errorBean.setRuleId(incomingRuleBean.getRuleId());
			errorBean.setErrorMsg(message);
			errorRule.addError(errorBean);
			return errorRule;		
		}
	}

	/*
	 * Refresh Profiles for all configured applications.
	 * (non-Javadoc)
	 * @see com.ml.elt.s1.profile.intface.ProfileLifeCycle#reloadProfile()
	 */
	public void rebuildProfileIndex() throws ProfileException {
		log.info("Rebuilding Profile Index!!!");
		ProfileLoader profileLoad = ProfileLoader.getInstance();
		profileLoad.reloadProfile();
		log.info("Done Rebuilding Profile Index");
	}
	
	/*
	 * Refresh by Application
	 */
	public void rebuildProfileIndex(String applicationCode) throws ProfileException {		
		if(applicationCode != null){
			log.info("Rebuilding Profile Index for Application : " + applicationCode);		
			ProfileLoader profileLoad = ProfileLoader.getInstance();
			profileLoad.reloadProfile(applicationCode);
			log.info("Done Rebuilding Profile Index for Application : " + applicationCode);
		}
		else
			rebuildProfileIndex();
	}
	
	/*
	 * Refresh by Application and RuleId. 
	 */
	public void rebuildProfileIndex(String applicationCode, Long ruleId) throws ProfileException {
		log.info("Rebuilding Profile Index for Application : " + applicationCode +", RuleId: "+ ruleId);
		ProfileLoader profileLoad = ProfileLoader.getInstance();
		profileLoad.reloadProfile(applicationCode,ruleId);
		log.info("Done Rebuilding Profile Index for Application : " + applicationCode +", RuleId: "+ ruleId);
	}
	

	
	public Rule reloadProfileRuleData(Long ruleId) throws ProfileException {
		Rule cacheRule = null;
		if(ruleId !=null){
			try {
				cacheRule = ProfileCommandQuery.getRuleById(ruleId);
				Rule ruleDb = DBDataLoader.loadRule(ruleId);
				if(ruleDb!=null){
					if(cacheRule!=null){
						ObjectConverter.updateRule(ruleDb, cacheRule);
					} else {
						cacheRule = ruleDb;
					}
					cacheDas.write(cacheRule);
				}
				List<RuleProperty> dbRulePropList = DBDataLoader.loadRuleProperties(ruleId);
				List<RuleProperty> cacheRulePropList = ProfileCommandQuery.getRulePropertyByRuleId(ruleId);
				if(cacheRulePropList!=null && !cacheRulePropList.isEmpty()){
					cacheDas.remove(cacheRulePropList);
				}
				if(dbRulePropList!=null && !dbRulePropList.isEmpty()){
					cacheDas.write(dbRulePropList);
				}
			} catch (DASException dasEx) {
				log.warn("Unable to Reload Rule Data"+ruleId,dasEx);
			}
		}
		return cacheRule;
	}

	/*
	 * Reload Profile and Pickers Data From Database 
	 * (non-Javadoc)
	 * @see com.ml.elt.s1.profile.intface.ProfileLifeCycle#reloadProfileData()
	 */
	public void reloadProfileData() throws ProfileException {
		log.info("loading Profile data from database in ProfileLifeCycleImpl");
		ProfileDataReloader profileDataReloader = new ProfileDataReloader();
		profileDataReloader.reloadData(cacheDas);
		log.info("done loading Profile data from database in ProfileLifeCycleImpl");
	}
	
	/*
	 * Reload Pickers Data From Database 
	 * (non-Javadoc)
	 * @see com.ml.elt.s1.profile.intface.ProfileLifeCycle#reloadPickersData()
	 */
	public void reloadPickersData() throws ProfileException {
		log.info("loading Pickers data from database in ProfileLifeCycleImpl.");		
		try {
			DBDataLoader.loadAllPickers();
		} catch (DASException e) {
			log.error("Exception in 'loadAllPickers' while loading Pickers data from database in ProfileLifeCycleImpl.", e);
			throw new ProfileException(e);			
		}
		
		ProfileLoader profileLoader = ProfileLoader.getInstance();
		profileLoader.reloadProfile();
		log.info("done loading Pickers data from database in ProfileLifeCycleImpl.");
	}

	public ProfilePropertiesMananger getPropertiesManager() {
		return propertiesManager;
	}

	public void setPropertiesManager(ProfilePropertiesMananger propertiesManager) {
		this.propertiesManager = propertiesManager;
	}		
}
