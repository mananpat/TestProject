package com.ml.elt.s1.profile.core.sdo;

import com.ml.elt.s1.platform.plugins.cache.PrimaryKey;
import com.ml.elt.s1.profile.core.enums.Action;
import com.ml.elt.s1.profile.transfer.gui.PropertyBean;

/**
 * RuleProperty
 */
public class RuleProperty extends ProfileDomainObject {

	private static final long serialVersionUID = 1L;

	private Long id;		
	private Long propertyId;
	private Long ruleId;	
	private String value;
	private Action action;
	
	public RuleProperty() {
	}

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getPropertyId() {
		return propertyId;
	}

	public void setPropertyId(Long propertyId) {
		this.propertyId = propertyId;
	}

	public Long getRuleId() {
		return ruleId;
	}

	public void setRuleId(Long ruleId) {
		this.ruleId = ruleId;
	}

	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
	public Action getAction() {
		return action;
	}

	public void setAction(Action action) {
		this.action = action;
	}

	/* (non-Javadoc)
	 * @see com.ml.elt.s1.platform.plugins.cache.CacheObject#getCacheKey()
	 */
	@Override
	public String getCacheKey(){
		if (primaryKey == null && this.id != null){
			Object[] key = new Object[]{this.id};
			primaryKey = new PrimaryKey(key, this.getClass(), true, true);
		}
		return primaryKey.getStringKey();
	}
	
	public static String getCacheKey(Long id){
		Object[] key = new Object[]{id};
		PrimaryKey primaryKey = new PrimaryKey(key, RuleProperty.class, true, true);
		return primaryKey.getStringKey();
	}
	
	public boolean equals(PropertyBean propertyBean) {
		if(propertyBean == null || !(propertyBean instanceof PropertyBean))
			return false;

		if(this.ruleId.equals(propertyBean.getRuleId()) &&
		  ((this.value == null && propertyBean.getValue() == null) ||
		  ( this.value != null && propertyBean.getValue() != null && this.value.equals(propertyBean.getValue()))))	
			return true;
		else
			return false;
	}
	
	public String getPath(){
		return getClass().getPackage().getName().replace('.', '_')
		+ "/" + getClass().getSimpleName()
		+ "/" + getRuleId();
	}
}
