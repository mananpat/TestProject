/**
 * 
 */
package com.ml.elt.s1.profile.plugins.jmx;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ml.elt.s1.platform.container.jmx.AbstractDynamicMBean;
import com.ml.elt.s1.platform.container.service.cache.CacheDas;
import com.ml.elt.s1.platform.plugins.boot.DefaultConfiguration;
import com.ml.elt.s1.profile.plugins.cache.ProfileDataReloader;

/**
 * @author mpatel12
 *
 */
public class LoadProfileData extends AbstractDynamicMBean {

	private static Log log = LogFactory.getLog(LoadProfileData.class);
	protected CacheDas cacheDas;
	
	public LoadProfileData() {
		CacheDas localcacheDas = (CacheDas)DefaultConfiguration.getBean("cacheDas");
		try {
			cacheDas = localcacheDas.newInstance(null, null);
			cacheDas.connect(null);
		} catch (Exception e) {
			log.warn("LoadProfileData : Unable to connect to cache");
		}
	}
	
	public String loadAllProfileDataFromDB() {
		try 
		{
			ProfileDataReloader profileDataReloader = new ProfileDataReloader();
			profileDataReloader.reloadData(cacheDas);

			return "Profile and Pickers data load from database is successful.";
		} catch (Exception ex) {
			log.error("Exception while loading Profile and Pickers data load from database.",ex);
			return "Profile and Pickers data load failed.";
		}
	}
	
	public String rebuildProfileIndexByAppCode(String appCode) {
		String returnMsg = "";
		try 
		{
			appCode = (appCode==null)?"":appCode.trim();
			if( !"".equals(appCode)){
				ProfileDataReloader profileDataReloader = new ProfileDataReloader();
				profileDataReloader.rebuildProfileIndex(appCode);
				returnMsg = "Profile Rules load by AppCode "+ appCode + " from database is successful.";
			}else{
				returnMsg = "Invalid AppCode :"+ appCode;
			}
		} catch (Exception ex) {
			log.error("Exception in rebuildProfileIndexByAppCode in LoadProfileData.",ex);
			returnMsg = "Profile and Pickers data load failed.";
		}
		return returnMsg;
	}

	public String rebuildProfileIndexByAppCodeRuleID(String appCode, String strRuleId) {
		String returnMsg = "";
		try 
		{
			Long ruleId = null;
			try{
				strRuleId = (strRuleId==null)?"":strRuleId.trim();
				ruleId = Long.parseLong(strRuleId);
			}catch(Exception ex){
				returnMsg = "Unable to parse ruleId :" + strRuleId;
			}
			appCode = (appCode==null)?"":appCode.trim();
			if(ruleId!=null && !"".equals(appCode)){
				ProfileDataReloader profileDataReloader = new ProfileDataReloader();
				profileDataReloader.rebuildProfileIndex(appCode, ruleId);
				returnMsg = "Profile Rule " + ruleId + " load by AppCode "+ appCode + " and Rule Id from database is successful.";
			} else {
				returnMsg = "Invalid AppCode :"+ appCode + " or ruleId :" +strRuleId; 
			}
		} catch (Exception ex) {
			log.error("Exception in rebuildProfileIndexByAppCodeRuleID in LoadProfileData.",ex);
			returnMsg = "Profile and Pickers data load failed.";
		}
		return returnMsg;
	}

}
