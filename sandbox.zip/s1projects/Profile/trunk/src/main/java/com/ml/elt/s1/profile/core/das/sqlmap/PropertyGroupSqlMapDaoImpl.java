/**
 * 
 */
package com.ml.elt.s1.profile.core.das.sqlmap;

import java.util.List;

import org.springframework.orm.ibatis.SqlMapClientTemplate;

import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.profile.core.das.iface.PropertyGroupDao;
import com.ml.elt.s1.profile.core.sdo.PropertyGroup;

/**
 * @author mpatel12
 *
 */
public class PropertyGroupSqlMapDaoImpl extends SqlMapClientTemplate implements PropertyGroupDao {
	
	/* (non-Javadoc)
	 * @see com.ml.elt.s1.core.das.iface.PropertyGroupDao#getAllPropertyGroup()
	 */
	@SuppressWarnings("unchecked")
	public List<PropertyGroup> getAllPropertyGroups() throws DASException {	
		try {
			return (List<PropertyGroup>) queryForList("getAllPropertyGroups");			
		} catch (org.springframework.dao.DataAccessException ex) {
			throw new DASException(ex);
		}
	}

	/* (non-Javadoc)
	 * @see com.ml.elt.s1.core.das.iface.PropertyGroupDao#getPropertyByAppId()
	 */
	@SuppressWarnings("unchecked")
	public List<PropertyGroup> getPropertyGroupsByAppId(long appId) throws DASException {
		try {
			return (List<PropertyGroup>) queryForList("getPropertyGroupByAppId", appId);			
		} catch (org.springframework.dao.DataAccessException ex) {
			throw new DASException(ex);
		}
	}

	/* (non-Javadoc)
	 * @see com.ml.elt.s1.core.das.iface.PropertyGroupDao#getPropertyByPropGroupCode()
	 */
	@SuppressWarnings("unchecked")
	public List<PropertyGroup> getPropertyGroupsByPropGroupCode(String propertyGroupCode) throws DASException {
		try {
			return (List<PropertyGroup>) queryForList("getPropertyGroupByPropGroupCode",propertyGroupCode);			 
		} catch (org.springframework.dao.DataAccessException ex) {
			throw new DASException(ex);
		}
	}

}
