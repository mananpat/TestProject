package com.ml.elt.s1.profile.plugins.cache;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.platform.container.exception.ExceptionHandler;
import com.ml.elt.s1.platform.container.service.cache.CachableObject;
import com.ml.elt.s1.platform.container.service.cache.CacheDas;
import com.ml.elt.s1.platform.plugins.das.Das;

/**
 * @author mpatel12
 *
 */
abstract public class Worker implements Runnable {
	private Throwable throwable;
	protected Das daoManagerDb;
	protected CacheDas cacheDas;
	protected boolean writeToCache = true;
	private List<List<? extends CachableObject>>  groups = null;
	private Long counter = null;
	
	protected Logger log = Logger.getLogger(this.getClass());


	public Worker(Das daoManagerDb, CacheDas cacheDas) {
		this.cacheDas = cacheDas;
		this.daoManagerDb = daoManagerDb;
	}
	
	@SuppressWarnings("unchecked")
	protected void write(List<? extends CachableObject> list) throws DASException{
		if (list != null && !list.isEmpty()){
			if(writeToCache) {
				CacheDas localCacheDas = cacheDas.newInstance(null, null);
				localCacheDas.connect(null);
				localCacheDas.write(list);
				localCacheDas.close();
			}
			if(groups != null) 
				groups.add(list);
		}
	}
	
	protected void write(CachableObject obj) throws DASException{
		if (obj != null){
			if(writeToCache) {
				CacheDas localCacheDas = cacheDas.newInstance(null, null);
				localCacheDas.connect(null);
				localCacheDas.write(obj);
				localCacheDas.close();
			}
			if(groups != null) {
				List<CachableObject> list = new ArrayList<CachableObject>();
				list.add(obj);
				groups.add(list);
			}
		}
	}
	
	public void run() {
		try {
			doWork();
		} catch (Throwable t) {
			throwable = t;
			ExceptionHandler.getInstance().handleSystemException(
					t.getMessage(), t, this.getClass());
		}
		finally{
			countDown();
		}
	}

	public void setCounter(Long counter) {
		this.counter = counter;
		if(counter != null) synchronized (counter) {
			this.counter++;			
		}
	}

	private void countDown() {
		if(counter != null) synchronized (counter) {
			this.counter--;			
		}
	}

	abstract public void doWork() throws Exception;

	public Throwable getThrowable() {
		return throwable;
	}

	public void setWriteToCache(boolean writeToCache) {
		this.writeToCache = writeToCache;
	}

	public List<List<? extends CachableObject>> getGroups() {
		return groups;
	}

	public void setGroups(List<List<? extends CachableObject>> groups) {
		this.groups = groups;
	}
}
