package com.ml.elt.s1.profile.core.das.iface;

import java.sql.SQLException;
import java.util.List;

import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.platform.container.service.das.Dao;
import com.ml.elt.s1.profile.core.sdo.ClientEmailAudit;

public interface ClientEmailAuditDao extends Dao {
	List<ClientEmailAudit> getClientEmailAuditBySwpTrdId(List<Long> swpTrdId) throws DASException;
	List<ClientEmailAudit> getLatestClientEmailAuditBySwpTrdId(List<Long> swpTrdId) throws DASException;	
	void insertEmailAudit(ClientEmailAudit audit) throws DASException;
	void insertEmailAudit(List<ClientEmailAudit> audits) throws DASException, SQLException; 
}
