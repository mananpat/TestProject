package com.ml.elt.s1.profile.transfer.gui;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class RuleBean implements Serializable {
	private static final long serialVersionUID = 2L;

	private Long ruleId;

	private Boolean active;
	
	private String description;
	
	private String updateUser;
	
	private Date updateTime;
	
	private String command;
	
	private List<PropertyBean> profileProperty = new ArrayList<PropertyBean> ();
	
	private List<ErrorBean> errors = new ArrayList<ErrorBean> ();

	public void setRuleId(Long ruleId) {
		this.ruleId = ruleId;
	}

	public Long getRuleId() {
		return ruleId;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public Boolean getActive() {
		return active;
	}

	public RuleBean(List<PropertyBean> properties) {

		this.setProfileProperty(properties);
	}

	public RuleBean() {

	}

	public List<ErrorBean> getErrors() {
		return errors;
	}

	public void setErrors(List<ErrorBean> errors) {
		this.errors = errors;
	}
	
	public void addError(ErrorBean o) {
		this.errors.add(o);
	}

	public void addAllError(List<ErrorBean> list) {
		this.errors.addAll(list);
	}


	public void setDescription(String desc) {
		this.description = desc;
	}

	public String getDescription() {
		return description;
	}

	public void setProfileProperty(List<PropertyBean> profileProperty) {
		this.profileProperty = profileProperty;
	}

	public List<PropertyBean> getProfileProperty() {
		return profileProperty;		
	}

	public void setUpdateUser(String user) {
		this.updateUser = user;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateTime(Date time) {
		this.updateTime = time;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setCommand(String command) {
		this.command = command;
	}

	public String getCommand() {
		return command;
	}
	
	public void addProfileProperty(PropertyBean propertyBean){
		if(propertyBean != null){
			this.profileProperty.add(propertyBean);
		}
	}
}