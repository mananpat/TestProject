package com.ml.elt.s1.profile.intface;

import java.util.List;
import java.util.Map;

import com.ml.elt.s1.platform.container.service.ComponentInterface;
import com.ml.elt.s1.profile.exception.ProfileException;
import com.ml.elt.s1.profile.impl.LookupResultSet;

/**
 * @author schuz
 */
public interface ProfileProcessor extends ComponentInterface{
	
	/**
	 * Loads profile data from persistent data store and builds indexes.
	 * After this method executes, profile service will operate on new set of data.
	 * This method should be also called before the first usage of other profile processor methods.
	 */
	public void reloadProfile(boolean initializing) throws ProfileException;
		
	/**
	 * Allow to discover criteria properties for given criteria category.
	 * @param criteriaCategoryCode the Criteria Category Code to discover.
	 * @return list of Criteria Property Codes for the Criteria Category.
	 * @throws ProfileException.
	 */
	public List<String> getCriteriaProperties(String criteriaCategoryCode)
	throws ProfileException;
	
	/**
	 * Allow to discover target properties for given criteria category.
	 * @param criteriaCategoryCode the Criteria Category Code to discover.
	 * @return map of Target Property Codes (key) to Required Flag (value) for the Criteria Category.
	 * @throws ProfileException
	 */
	public Map<String,Boolean> getTargetProperties(String criteriaCategoryCode)
	throws ProfileException;
	
	/**
	 * Retrieves the property code and values for a profile
	 * @param criteriaCategoryCode Application Name
	 * @param criteriaValues Map of lookup properties and values
	 * @return Map of property codes and List of object.
	 * @throws ProfileException
	 */
	public LookupResultSet getTargetValues(String criteriaCategoryCode,
		Map<String, Object> criteriaValues) throws ProfileException;

	/**
	 * Retrieves the property code and values for a profile
	 * @param criteriaCategoryCode Application Name
	 * @param criteriaValues Map of lookup properties and values
	 * @return Map of property codes and List of Object converted in real type.
	 * @throws ProfileException
	 */
	public LookupResultSet getTargetConvertedValues(String criteriaCategoryCode,
		Map<String, Object> criteriaValues) throws ProfileException;

	/**
	 * Set object attributes (state full call)  
	 * @param anObject The object which attributes needs to be enriched 
	 * @param errStrings List of error strings in setting the attributes
	 * @throws ProfileException
	 */
	public void setObjectAttributes(Object anObject, 
										List<String> errStrings) throws ProfileException;
	
	/**
	 * Set object attributes (Stateless call)
	 * @param anObject The object which attributes needs to be enriched
	 * @param critPropValues The map of criteria property values for looking up the profile 
	 * @param errStrings the list of error strings in setting the attributes
	 * @throws ProfileException
	 */
	public void setObjectAttributes(Object anObject,String appCode, 
										Map<String, Object> critPropValues, 
										List<String> errStrings) throws ProfileException;


	/**
	 * Exposes profile properties and their data types;
	 * @return Profile Properties Definitions;
	 * @throws ProfileException 
	 */
	public Map<String,String> getPropertyDataTypeMap() throws ProfileException;
	

}
