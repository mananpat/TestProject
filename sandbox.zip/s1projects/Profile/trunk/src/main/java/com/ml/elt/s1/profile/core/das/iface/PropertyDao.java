/**
 * 
 */
package com.ml.elt.s1.profile.core.das.iface;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.platform.container.service.das.Dao;
import com.ml.elt.s1.profile.core.sdo.Property;

/**
 * @author mpatel12
 *
 */
public interface PropertyDao extends Dao {

	/**
	 * returns Property List
	 * @return Property
	 * @throws DataAccessException
	 */
	public List<Property> getAllProperties() throws DASException;

	/**
	 * returns Property
	 * @return Property
	 * @throws DataAccessException
	 */
	public Property getPropertyById(long propertyId) throws DASException; 
}
