package com.ml.elt.s1.profile.plugins.cache.loaders;

import java.util.List;

import org.apache.log4j.Logger;

import com.ml.elt.s1.platform.container.service.cache.CacheDas;
import com.ml.elt.s1.platform.plugins.das.Das;
import com.ml.elt.s1.profile.core.das.iface.ClientEmailAuditPropertyDao;
import com.ml.elt.s1.profile.core.sdo.ClientEmailAuditProperty;
import com.ml.elt.s1.profile.plugins.cache.Worker;

public class ClientEmailAuditPropertyLoader extends Worker {
	private static Logger log = Logger.getLogger(ClientEmailAuditPropertyLoader.class);
	
	public ClientEmailAuditPropertyLoader(Das daoManagerDb, CacheDas cacheDas) {	
		super(daoManagerDb, cacheDas);		
	}
	
	public void doWork() throws Exception {
		log.info("loading Client Email Properties...");
		ClientEmailAuditPropertyDao cliEmailPropertyDao = (ClientEmailAuditPropertyDao)daoManagerDb.getDao(ClientEmailAuditProperty.class);
		List<ClientEmailAuditProperty> properties = cliEmailPropertyDao.getAllClientEmailProperty();
		if(properties != null && !properties.isEmpty()){
			write(properties);
		}
		log.info("done - loading Client Email Properties and writing to cache. (" + properties.size() + " properties loaded)");
	}
}
