package com.ml.elt.s1.profile.plugins.amendmentreport;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ml.elt.s1.platform.container.ServiceContext;
import com.ml.elt.s1.platform.container.exception.MessageException;
import com.ml.elt.s1.platform.container.service.MetaData;
import com.ml.elt.s1.platform.container.service.Request;
import com.ml.elt.s1.platform.container.service.Response;
import com.ml.elt.s1.platform.container.service.cache.CacheDas;
import com.ml.elt.s1.platform.container.service.processor.MessageProcessor;
import com.ml.elt.s1.platform.container.service.processor.ProcessorInitialization;
import com.ml.elt.s1.platform.plugins.connector.ems.OutputData;
import com.ml.elt.s1.profile.exception.ProfileException;
import com.ml.elt.s1.profile.intface.ProfileLifeCycle;
import com.ml.elt.s1.profile.transfer.gui.ProfileAmendReportBean;

/**
 * @author mpatel12
 *
 * Profile Amendment Report Processor.
 * 
 */
public class AmendmentReportProcessor implements MessageProcessor, ProcessorInitialization {

	private static Log log = LogFactory.getLog(AmendmentReportProcessor.class);
	
	private ServiceContext context;
	private CacheDas cacheDas;
	private Response finalResponse;
	
	private List<AmendmentReportResponse> amendmentReportResponse;	
	private ProfileLifeCycle profileLifeCycle;
	
	public CacheDas getCacheDas() {
		return cacheDas;
	}

	public void setCacheDas(CacheDas cacheDas) {
		this.cacheDas = cacheDas;
	}
	
	public ProfileLifeCycle getProfileLifeCycle() {
		return profileLifeCycle;
	}

	public void setProfileLifeCycle(ProfileLifeCycle profileLifeCycle) {
		this.profileLifeCycle = profileLifeCycle;
	}
	
	public void init(ServiceContext context){
		
	}	
	
	public Response process(Request request) {
		finalResponse = new Response();
		Object[] array = request.getData();
		if (array == null)
			return finalResponse;
		
		try 
		{			
			context = request.getServiceContext();
			
			if (array != null) 
			{				
				for (Object object : array) 
				{
					AmendmentReportRequest amendmentReportRequest = null;
					if(object instanceof AmendmentReportRequest)
						amendmentReportRequest = (AmendmentReportRequest)object;
					else if(object instanceof OutputData){
						Object objectTemp = ((OutputData)object).getData();
						MetaData metaData = ((OutputData)object).getMetaData();
						if(metaData != null && metaData.getMap() != null)
							context.getMetaData().getMap().putAll(metaData.getMap());
						if(object instanceof AmendmentReportRequest)
							amendmentReportRequest = (AmendmentReportRequest)objectTemp;
						else {
							log.error("Unknown message format:" + object.toString());
							continue;
						}
					}
					else {
						log.error("Unknown message format:" + object.toString());
						continue;
					}
					
					this.amendmentReportResponse = new ArrayList<AmendmentReportResponse>();
					
					if("profile".equals(amendmentReportRequest.getCommand()))
					{
						log.info("Profile Amendment request received " + amendmentReportRequest.getCommand() + ". Processing the request !!!");
						try {
							processProfileRequest(amendmentReportRequest);
						}
						catch(ProfileException pe){							
							handleDefaultException(pe, null);						
						}
					}
					else
					{
						String message = "Profile Amendment Request is Invalid. Command is not specified in the request.";
						handleDefaultException(null, message);	
					}
					
					if(this.amendmentReportResponse.size() > 0)										
						dispatch();						
					
					log.info("Profile Amendment request completed. Total results found " + this.amendmentReportResponse.size() + ".");
					finalResponse.addOutput(publishEof());
				}
			}
		}
		catch (Throwable t) {
			String message = "One or more error(s) occurred while executing profile amendment request."; 
			log.error(message, t);
			handleDefaultException(t, message);		
		}	
		return finalResponse;
	}
	
	private String getErrorMessage(String error){
		StringBuilder errString =  new StringBuilder("<?xml version=\"1.0\" encoding=\"ISO-8859-1\" standalone=\"yes\"?><batch count=\"1\"><error>").append(error).append("</error></batch>");
		return errString.toString();
	}
	
	private void handleDefaultException(Throwable t, String exceptionMessages) {		
		String exceptions;
		if (exceptionMessages == null || "".equals(exceptionMessages)) 
			exceptions = formatExceptionMessage(t);		
		else
			exceptions = exceptionMessages;
		
		context.getMetaData().setData("type", "xml-exception");
		log.error(exceptions, t);
		finalResponse.addException(new MessageException(getErrorMessage(exceptions),	t, exceptions));
		finalResponse.addOutput(publishEof());
	}
	
	protected String formatExceptionMessage(Throwable t) {
		if(t == null)
			return null;	
		
		String exceptions = t.getMessage();
		Throwable temp = t;
		while ((temp = temp.getCause()) != null) {
			if (temp.getMessage() != null)exceptions += temp.getMessage() + ". ";
		}
		if (exceptions == null || exceptions.equals("")) {
			StackTraceElement[] elements = t.getStackTrace();
			for (StackTraceElement ele : elements) {
					exceptions =  ele.getClassName() + "." + ele.getMethodName() + "()" + ele.getFileName() + ":" + ele.getLineNumber() + ")";
			}
		}
		return exceptions;
	}
	
	private void processProfileRequest(AmendmentReportRequest amendmentReportRequest) throws ProfileException {
		List<ProfileAmendReportBean> profileAmendReportBeanList = profileLifeCycle.getAmendmentTrailReport(amendmentReportRequest.getRuleId(), amendmentReportRequest.getDateTimeFrom(), amendmentReportRequest.getDateTimeTo());
		
		if(profileAmendReportBeanList != null && !profileAmendReportBeanList.isEmpty()){
			for(ProfileAmendReportBean profileAmendReportBean : profileAmendReportBeanList)
			{
				AmendmentReportResponse response = new AmendmentReportResponse();
				response.setRuleId(profileAmendReportBean.getRuleId());
				response.setField(profileAmendReportBean.getPropDescription());
				response.setNewValue(profileAmendReportBean.getValue());
				response.setOldValue(profileAmendReportBean.getOldValue());
				response.setActiveFlag(profileAmendReportBean.getActiveFlag());			
				response.setOperationType(profileAmendReportBean.getOperationType());			
				response.setRuleOperationType(profileAmendReportBean.getRuleOperationType());
				response.setUpdateUser(profileAmendReportBean.getUpdateUser());
				response.setUpdateDateTime(profileAmendReportBean.getUpdateTime());		
				this.amendmentReportResponse.add(response);
			}
		}
	}
	
	@SuppressWarnings({ "unchecked", "unused" })
	private OutputData publishEof(){
		OutputData eofData =  new OutputData();
		String eofString =  "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" standalone=\"yes\"?><batch count=\"0\"/>";
		eofData.setData(eofString);
		MetaData metadata = new MetaData();
		Map map = new HashMap(context.getMetaData().getMap());
		map.put("type", "eof");
		metadata.setMap(map);
		eofData.setMetaData(metadata);
		return eofData;
	}	
		
	@SuppressWarnings({ "unused", "unchecked" })
	private void dispatch(){
    	if(this.amendmentReportResponse != null && !this.amendmentReportResponse.isEmpty()){
    		Response resp = new Response();
			OutputData result = new OutputData();
			MetaData resultMetadata = new MetaData();
			resultMetadata.setMap(context.getMetaData().getMap());
			result.setMetaData(resultMetadata);
			AmendmentReportResponseList response = new AmendmentReportResponseList();
			response.setAmendmentReportResponseList(this.amendmentReportResponse);
			result.setData(response);
			resp.addOutput(result);			
			try{
				context.dispatch(resp);				
			} catch (Exception e){
				log.warn(e.getMessage());
			}
    	}
    }
}