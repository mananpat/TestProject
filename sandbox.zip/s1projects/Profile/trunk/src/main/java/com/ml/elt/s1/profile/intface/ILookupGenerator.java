package com.ml.elt.s1.profile.intface;

import java.util.Map;

public interface ILookupGenerator {
	void generateLookups (Map<String, Object> lookups, String userId);
}
