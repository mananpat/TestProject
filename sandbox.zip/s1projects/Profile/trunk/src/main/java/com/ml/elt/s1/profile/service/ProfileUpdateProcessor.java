/**
 * 
 */
package com.ml.elt.s1.profile.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ml.elt.s1.platform.container.ServiceContext;
import com.ml.elt.s1.platform.container.service.Request;
import com.ml.elt.s1.platform.container.service.Response;
import com.ml.elt.s1.platform.container.service.processor.MessageProcessor;
import com.ml.elt.s1.profile.core.das.cache.ProfileCommandQuery;
import com.ml.elt.s1.profile.core.sdo.Application;
import com.ml.elt.s1.profile.core.sdo.LookupProperties;
import com.ml.elt.s1.profile.core.sdo.Property;
import com.ml.elt.s1.profile.core.sdo.Rule;
import com.ml.elt.s1.profile.core.sdo.RuleProperty;
import com.ml.elt.s1.profile.core.sdo.util.ObjectConverter;
import com.ml.elt.s1.profile.exception.ProfileException;
import com.ml.elt.s1.profile.intface.ProfileLifeCycle;
import com.ml.elt.s1.profile.transfer.gui.ErrorBean;
import com.ml.elt.s1.profile.transfer.gui.ProfileDataList;
import com.ml.elt.s1.profile.transfer.gui.PropertyBean;
import com.ml.elt.s1.profile.transfer.gui.RuleBean;
import com.ml.elt.s1.profile.util.ProfileApplicationConstant;
import com.ml.elt.s1.profile.util.ProfileOperation;

/**
 * @author mpatel12
 *
 * Processor to check for any Profile data update and rebuild index or refresh application data accordingly.
 * NOTE: This process is executed after the update message is broad cast to booking service nodes. 
 */
public class ProfileUpdateProcessor implements MessageProcessor {
	
	private static Log log = LogFactory.getLog(ProfileUpdateProcessor.class);
	
	private ProfileLifeCycle prfLifeCycle = null;
	private Response finalResponse = null;
	
	public ProfileLifeCycle getPrfLifeCycle() {
		return prfLifeCycle;
	}

	public void setPrfLifeCycle(ProfileLifeCycle prfLifeCycle) {
		this.prfLifeCycle = prfLifeCycle;
	}
	
	public Response process(Request request) {
		if (request == null)
			return new Response();
		
		Object[] objs = request.getData();
		if(objs == null)
			return new Response();
		
		try
		{
			finalResponse = new Response();
			ServiceContext context = request.getServiceContext();	
			context.getMetaData().remove(ProfileApplicationConstant.CONTEXT_BROADCAST_COMMAND);
			String command = (String)context.getMetaData().getData(ProfileApplicationConstant.CONTEXT_COMMAND);	
			String appCode = (String)context.getMetaData().getData(ProfileApplicationConstant.CONTEXT_APP_CODE);	
			String userId = (String)context.getMetaData().getData(ProfileApplicationConstant.CONTEXT_USERID);
			
			if (command.equalsIgnoreCase(ProfileOperation.PRF_RELOAD)){				
				log.info("ProfileUpdateProcessor: Profile Request "+ command + " by userId "+userId +".");
				String reqid = (String)context.getMetaData().getData("reqid");
				context.getMetaData().setData("errorReqId", reqid);
				context.getMetaData().setData("reqid", appCode);
				prfLifeCycle.reloadProfileData();
			}
			else if(command.equalsIgnoreCase(ProfileOperation.PRF_CREATE_OR_UPDATE)||
			   command.equalsIgnoreCase(ProfileOperation.PRF_SAVE_CONTACT)){	
				log.info("ProfileUpdateProcessor: Profile Request "+ command + " by userId "+userId +".");				
				buildProfileDataView(objs, context, appCode);				
			}
		}
		catch (Throwable  e) {
			log.error("One or more error(s) occurred in Profile Update Processor. Due to: ", e);
			handleDefaultException(objs, e);
		}
		
		return finalResponse;
	}
	
	private void handleDefaultException(Object[] array, Throwable e) {
		ProfileDataList prfResponse = new ProfileDataList ();
		List<ErrorBean> errors = new ArrayList<ErrorBean> ();
		ErrorBean bean = new ErrorBean ();
		bean.setErrorMsg(e.getMessage());
		errors.add(bean);		
		prfResponse.setErrors(errors);		
		finalResponse.addOutput(prfResponse);
	}
	
	
	/*
	 * Check if any Profile Data Update requires Profile Refresh by Application
	 */
	private boolean isRefreshByApplicationRequired(Object[] objs){
		boolean isRefreshByApp = false;		
		for(Object obj : objs){	
			ProfileDataList  inProfileList = null;					
			if(obj instanceof ProfileDataList){
				inProfileList = (ProfileDataList)obj;
				if(inProfileList.getRules() != null && !inProfileList.getRules().isEmpty()){
					for(RuleBean ruleBean : inProfileList.getRules()){
						if((ruleBean.getErrors() == null || ruleBean.getErrors().isEmpty()) && ProfileOperation.PRF_REFRESH.equals(ruleBean.getCommand())){
							isRefreshByApp = true;
							break;
						}
					}
				}		
			}
		}
		
		return isRefreshByApp;
	}
		
	
	private void buildProfileDataView(Object[] objs, ServiceContext context,String appCode) throws ProfileException {		
		ProfileDataList responseProfileDataList = new ProfileDataList();
		try
		{	
			Application application = ProfileCommandQuery.getApplicationByCode(appCode);
			if(application == null)
				log.warn("Unable to get Application by appCode: "+appCode);	
				
			List<LookupProperties> listLookupProperties = ProfileCommandQuery.getLookupPropertiesOfApplication(application.getId());
			if(listLookupProperties == null){
				if(log.isDebugEnabled())
					log.debug("Lookup Properties does not exit for application: "+appCode);
			}
			
			boolean isRefreshByApplication = isRefreshByApplicationRequired(objs);
			
			if(isRefreshByApplication)			
				this.prfLifeCycle.rebuildProfileIndex(application.getApplicationCode());			
			
			for(Object obj : objs){	
				ProfileDataList  inProfileList = null;					
				if(obj instanceof ProfileDataList)
					inProfileList = (ProfileDataList) obj;
				
				List<RuleBean> incomingRuleBeansList = inProfileList.getRules();
				
				if(incomingRuleBeansList != null && !incomingRuleBeansList.isEmpty()){				
					List<RuleBean> retRuleBeanList = new ArrayList<RuleBean>();
					for(RuleBean incomingRuleBean : incomingRuleBeansList){
						if(incomingRuleBean.getErrors() != null && !incomingRuleBean.getErrors().isEmpty())
							continue;			
						Rule rule = ProfileCommandQuery.getRuleById(incomingRuleBean.getRuleId());					
						List<RuleProperty> ruleProperties = ProfileCommandQuery.getRulePropertyByRuleId(incomingRuleBean.getRuleId());
						List<PropertyBean> incomingPropertyBeanList = incomingRuleBean.getProfileProperty();
						
						Set<Long> updatedPropIdSet = new HashSet<Long>();
						
						for(PropertyBean propBean : incomingPropertyBeanList){
							Property property = ProfileCommandQuery.getPropertyByPropCode(propBean.getPropertyCode());						
							updatedPropIdSet.add(property.getId());
						}			
						
						RuleBean retRuleBean = ObjectConverter.getRuleBean(rule);
						
						if(!isRefreshByApplication)
							this.prfLifeCycle.rebuildProfileIndex(application.getApplicationCode(), incomingRuleBean.getRuleId());
						
						Set<Long> lookupPropIds = new HashSet<Long>();		
						if(listLookupProperties != null && !listLookupProperties.isEmpty()){
							for (LookupProperties lookup : listLookupProperties) {
								lookupPropIds.add(lookup.getPropertyId());
							}
						}
							
						if(ruleProperties != null && !ruleProperties.isEmpty()){
							for(RuleProperty ruleProperty : ruleProperties){
								if(ruleProperty.getPropertyId()!=null &&  lookupPropIds.contains(ruleProperty.getPropertyId())	){
									Property property = ProfileCommandQuery.getPropertyById(ruleProperty.getPropertyId());								
									if(property != null && ruleProperty != null){
										PropertyBean pbean = new PropertyBean(retRuleBean.getRuleId(), property.getPropertyCode(), ruleProperty.getValue(), property.getDescription(), null);
										retRuleBean.addProfileProperty(pbean);
									}
								}
							}	
						}
						retRuleBeanList.add(retRuleBean);
					}
					responseProfileDataList.setRules(retRuleBeanList);
				}
			}
			
			if(responseProfileDataList.getRules() != null && !responseProfileDataList.getRules().isEmpty()){
				String reqid = (String)context.getMetaData().getData("reqid");
				context.getMetaData().setData("errorReqId", reqid);
				context.getMetaData().setData("reqid", appCode);
				finalResponse.addOutput(responseProfileDataList);
			}
		}
		catch(Throwable t){
			String message = "One or more error(s) occurred in while preparing view data in profile update processor.";
			log.error(message, t);
			throw new ProfileException(message, t);
		}	
	}
}
