/**
 * 
 */
package com.ml.elt.s1.profile.core.das.iface;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.platform.container.service.das.Dao;
import com.ml.elt.s1.profile.core.sdo.PropertyGroupMapping;

/**
 * @author mpatel12
 *
 */
public interface PropertyGroupMappingDao extends Dao{

	/**
	 * returns PropertyGroupMapping List
	 * @return PropertyGroupMapping
	 * @throws DataAccessException
	 */
	public List<PropertyGroupMapping>  getAllPropertyGroupMappings() throws DASException;
	
	/**
	 * returns PropertyGroupMapping List
	 * @return PropertyGroupMapping
	 * @throws DataAccessException
	 */
	public List<PropertyGroupMapping>  getPropertyGroupMappingsByPropertyGroupId(long propertyGroupId) throws DASException;  
}
