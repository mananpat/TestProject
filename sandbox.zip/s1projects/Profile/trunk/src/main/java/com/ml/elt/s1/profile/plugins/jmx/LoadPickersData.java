/**
 * 
 */
package com.ml.elt.s1.profile.plugins.jmx;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ml.elt.s1.platform.container.jmx.AbstractDynamicMBean;
import com.ml.elt.s1.profile.core.das.util.DBDataLoader;
import com.ml.elt.s1.profile.impl.ProfileLoader;

/**
 * @author mpatel12
 *
 */
public class LoadPickersData extends AbstractDynamicMBean {

	private static Log log = LogFactory.getLog(LoadPickersData.class);
	
	public LoadPickersData() {		
	}
	
	public String loadAllPickerDataFromDB() {
		try 
		{
			log.info("loading Pickers data from database in LoadProfileData");
			DBDataLoader.loadAllPickers();
			ProfileLoader profileLoad = ProfileLoader.getInstance();
			profileLoad.reloadProfile();
			log.info("done loading Pickers data from database in LoadProfileData");
			return "Pickers data load from database is successful.";
		} catch (Exception ex) {
			log.error("Exception while loading Pickers data load from database.",ex);
			return "Pickers data load failed.";
		}
	}
}
