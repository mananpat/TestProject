/**
 * 
 */
package com.ml.elt.s1.profile.core.enums;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;

/**
 * @author mpatel12
 *
 */
@XmlEnum(String.class)
public enum Action {
	@XmlEnumValue("ADD")
	ADD,
	@XmlEnumValue("UPDATE")
	UPDATE,
	@XmlEnumValue("DELETE")
	DELETE;	
}