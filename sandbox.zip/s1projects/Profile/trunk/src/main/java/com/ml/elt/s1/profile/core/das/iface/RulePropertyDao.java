package com.ml.elt.s1.profile.core.das.iface;

import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.platform.container.service.das.Dao;
import com.ml.elt.s1.profile.core.sdo.RuleProperty;

/**
 * @author
 */
public interface RulePropertyDao extends Dao {
	
	/**
	 * returns RuleProperty List
	 * @return RuleProperty
	 * @throws DataAccessException
	 */
	public List<RuleProperty> getAllRuleProperties() throws DASException;
	
	/**
	 * returns RuleProperty List
	 * @return RuleProperty
	 * @throws DataAccessException
	 */
	 public List<RuleProperty> getAllRulePropertiesByApp(List<Long> appIds) throws DASException;
	
	/**
	 * returns RuleProperty Object
	 * @param rulePropertyId
	 * @return RuleProperty
	 * @throws DataAccessException
	 */
	public RuleProperty getRuleProperty(Long rulePropertyId) throws DASException;

	/**
	 * returns List of RuleProperty Object
	 * @param rulePropertyIds
	 * @return List<RuleProperty>
	 * @throws DataAccessException
	 */

	public List<RuleProperty> getRulePropertyList(List<Long> rulePropertyIds) throws DASException;

	/**
	 * returns Map of RuleProperty Object with Key as ID
	 * @param rulePropertyIds
	 * @return List<RuleProperty>
	 * @throws DataAccessException
	 */

	public Map<Long, RuleProperty> getRulePropertyMap(List<Long> rulePropertyIds) throws DASException;

	/**
	 * returns List of RuleProperty Object
	 * @param ruleId
	 * @return List<RuleProperty>
	 * @throws DataAccessException
	 */
	public List<RuleProperty> getRulePropertyListForRuleId(Long ruleId) throws DASException;

	/**
	 * returns List of RuleProperty Object
	 * @param ruleId
	 * @return List<RuleProperty>
	 * @throws DataAccessException
	 */
	public Map<Long, RuleProperty> getRulePropertyMapForRuleId(Long ruleId) throws DASException;

	/**
	 * returns List of RuleProperty Object
	 * @param ruleIds
	 * @return List<RuleProperty>
	 * @throws DataAccessException
	 */
	public List<RuleProperty> getRulePropertyListForRuleIds(List<Long> ruleIds) throws DASException;

	/**
	 * returns List of RuleProperty Object
	 * @param ruleIds
	 * @return List<RuleProperty>
	 * @throws DataAccessException
	 */
	public Map<Long, RuleProperty> getRulePropertyMapForRuleIds(List<Long> ruleIds) throws DASException;
	
	/**
	 * Update RuleProperty 
	 * @param RuleProperty
	 * @return boolean
	 * @throws DataAccessException
	 */

	public boolean updateRuleProperty(RuleProperty ruleProperty) throws DASException;

	/**
	 * Delete RuleProperty 
	 * @param RuleProperty
	 * @return boolean
	 * @throws DataAccessException
	 */

	public boolean deleteRuleProperty(RuleProperty ruleProperty) throws DASException;

	/**
	 * Delete RuleProperty 
	 * @param RuleProperty
	 * @return boolean
	 * @throws DataAccessException
	 */
	public RuleProperty insertRuleProperty(RuleProperty ruleProperty) throws DASException;
}
