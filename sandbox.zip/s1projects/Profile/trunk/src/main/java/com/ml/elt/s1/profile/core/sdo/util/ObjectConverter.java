/**
 * 
 */
package com.ml.elt.s1.profile.core.sdo.util;

import java.util.ArrayList;
import java.util.List;

import com.ml.elt.s1.profile.core.sdo.Contact;
import com.ml.elt.s1.profile.core.sdo.Rule;
import com.ml.elt.s1.profile.core.sdo.RuleProperty;
import com.ml.elt.s1.profile.transfer.gui.ContactBean;
import com.ml.elt.s1.profile.transfer.gui.PropertyBean;
import com.ml.elt.s1.profile.transfer.gui.RuleBean;

/**
 * @author mpatel12
 *
 */
public class ObjectConverter {

	public static Rule getRule(RuleBean ruleBean){
		Rule newRule = new Rule();
		newRule.setId(ruleBean.getRuleId());
		newRule.setActiveFlag(ruleBean.getActive());
		newRule.setDescription(ruleBean.getDescription());
		newRule.setUpdateUser(ruleBean.getUpdateUser());
		return newRule;
	}

	
	public static boolean updateRule(Rule source, Rule target){
		boolean bret = false;
		if(source!=null && target!=null){
			target.setId(source.getId());
			target.setActiveFlag(source.getActiveFlag());
			target.setApplicationId(source.getApplicationId());
			target.setCreateDateTime(source.getCreateDateTime());
			target.setCreateUser(source.getCreateUser());
			target.setDescription(source.getDescription());
			target.setUpdateDateTime(source.getUpdateDateTime());
			target.setUpdateUser(source.getUpdateUser());
			bret = true;
		}
		return bret;
	}

	
	public static Rule getRule(RuleBean ruleBean, Long applicationId){
		Rule newRule = getRule(ruleBean);
		newRule.setApplicationId(applicationId);	
		return newRule;
	}
	
	public static RuleBean getRuleBean(Rule rule){
		RuleBean newRuleBean = new RuleBean();
		newRuleBean.setRuleId(rule.getId());		
		newRuleBean.setActive(rule.getActiveFlag());
		newRuleBean.setDescription(rule.getDescription());
		newRuleBean.setUpdateUser(rule.getUpdateUser());
		newRuleBean.setUpdateTime(rule.getUpdateDateTime());
		return newRuleBean;
	}
	
	public static List<RuleProperty> getRuleProperty(List<PropertyBean> propertyBeanList){
		List<RuleProperty> rulePropertyList = new ArrayList<RuleProperty>();
		if(propertyBeanList != null && !propertyBeanList.isEmpty()){
			for(PropertyBean pbean : propertyBeanList){
				rulePropertyList.add(getRuleProperty(pbean));
			}
		}
		return rulePropertyList;
	}
	
	public static List<PropertyBean> getPropertyBean(List<RuleProperty> rulePropertyList){
		List<PropertyBean> propertyBeanList = new ArrayList<PropertyBean>();
		if(rulePropertyList != null && !rulePropertyList.isEmpty()){
			for(RuleProperty ruleProperty : rulePropertyList){
				propertyBeanList.add(getPropertyBean(ruleProperty));
			}
		}
		return propertyBeanList;
	}
		
	public static RuleProperty getRuleProperty(PropertyBean pbean){
		RuleProperty newRuleProp = new RuleProperty();
		newRuleProp.setRuleId(pbean.getRuleId());
		newRuleProp.setValue(pbean.getValue());			
		return newRuleProp;
	}
	
	public static RuleProperty getRuleProperty(PropertyBean pbean, Long rulePropertyId, Long propertyId){
		RuleProperty newRuleProp = getRuleProperty(pbean);		
		newRuleProp.setId(rulePropertyId);		
		newRuleProp.setPropertyId(propertyId);		
		return newRuleProp;
	}
	
	
	public static PropertyBean getPropertyBean(RuleProperty rp){
		PropertyBean newPBean = new PropertyBean();
		newPBean.setRuleId(rp.getRuleId());
		newPBean.setValue(rp.getValue());
		return newPBean;
	}
	
	public static Contact toContact(ContactBean contactBean){
		Contact newContact = new Contact();
		newContact.setId(contactBean.getId());
		newContact.setFirstName(contactBean.getFirstName());
		newContact.setMiddleName(contactBean.getMiddleName());
		newContact.setLastName(contactBean.getLastName());
		newContact.setCompany(contactBean.getCompany());
		newContact.setEmail(contactBean.getEmail());
		newContact.setRecipientType(contactBean.getRecipientType());
		newContact.setRole(contactBean.getRole());	
		return newContact;
	}
	
	public static ContactBean toContactBean(Contact contact){
		ContactBean contactBean = new ContactBean();
		contactBean.setId(contact.getId());
		contactBean.setFirstName(contact.getFirstName());
		contactBean.setMiddleName(contact.getMiddleName());
		contactBean.setLastName(contact.getLastName());
		contactBean.setCompany(contact.getCompany());
		contactBean.setEmail(contact.getEmail());
		contactBean.setRecipientType(contact.getRecipientType());
		contactBean.setRole(contact.getRole());	
		contactBean.setUpdateUser(contact.getUpdateUser());
		return contactBean;
	}
}

