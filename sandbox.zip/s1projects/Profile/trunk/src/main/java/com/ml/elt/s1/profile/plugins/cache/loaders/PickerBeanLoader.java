/**
 * 
 */
package com.ml.elt.s1.profile.plugins.cache.loaders;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.ml.elt.s1.platform.container.service.cache.CacheDas;
import com.ml.elt.s1.platform.plugins.boot.DefaultConfiguration;
import com.ml.elt.s1.platform.plugins.das.Das;
import com.ml.elt.s1.profile.core.das.cache.ProfileCommandQuery;
import com.ml.elt.s1.profile.core.das.iface.PickerListDao;
import com.ml.elt.s1.profile.core.sdo.PickerBean;
import com.ml.elt.s1.profile.core.sdo.Pickerlist;
import com.ml.elt.s1.profile.core.sdo.StaticData;
import com.ml.elt.s1.profile.plugins.cache.Worker;


/**
 * @author mpatel12
 *
 */
public class PickerBeanLoader extends Worker {

	private static Logger log = Logger.getLogger(PickerBeanLoader.class);
	
	private static boolean loadPickBean = false;
	
	public PickerBeanLoader(Das daoManagerDb, CacheDas cacheDas) {	
		super(daoManagerDb, cacheDas);
	}
	
	static {
		loadPickBean = Boolean.parseBoolean(DefaultConfiguration.getInstanceProperties().getProperty("instance.profile.load.pickerbean", "false"));
	}
	
	public void doWork() throws Exception {
		log.info("loading PickerBean...");
		PickerListDao dbDao = (PickerListDao) daoManagerDb.getDao(Pickerlist.class);
		List<Pickerlist> pickerList = dbDao.getAllPickerlist();
		List<PickerBean> listBean = new ArrayList<PickerBean>();
		
		if(loadPickBean && pickerList != null && !pickerList.isEmpty()) {
			write(pickerList);
		
			for(Pickerlist picker: pickerList){
				String pickerName = picker.getName();
				List<StaticData> staticData =  ProfileCommandQuery.getStaticDataOfPickerlist(picker.getId());
				Long pickerParentId = picker.getParentId();
				Pickerlist parentPicker = null;
				if(pickerParentId != null){
					parentPicker = ProfileCommandQuery.getPickerlistById(pickerParentId);
				}
				if(staticData==null){
					log.warn(String.format("Static Data for Picker List Id \"%1$s\" doesn't exist.", picker.getId()));					
				}
				if(staticData!=null && !staticData.isEmpty()){
					for(StaticData sd : staticData){
						PickerBean bean = new PickerBean();
						String pickerVal =  sd.getValue();
						String descr = sd.getDescription();
						Long parentId = sd.getParentId();
						if(parentId != null && parentId!=0 && parentPicker != null){
							StaticData staData = ProfileCommandQuery.getStaticDataById(parentId);
							if(staData!=null){
								bean.setParentType(staData.getValue());
							}else {
								log.error("Unable to Find Static Data for:"+parentId);
							}
						}
						if (parentPicker != null) 
							bean.setParentPickerType(parentPicker.getName());
						bean.setPickerName(pickerName);
						bean.setPickerValue(pickerVal);
						bean.setDescription(descr);
						bean.setId(sd.getId());
						listBean.add(bean);
					}
				}
			}
			if(listBean != null && !listBean.isEmpty())
				write(listBean);
		}
		
		log.info("done - loading PickerBean and writing to cache.");	
	}
}
