package com.ml.elt.s1.profile.core.das.iface;

import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.platform.container.service.das.Dao;
import com.ml.elt.s1.profile.core.sdo.Rule;
import com.ml.elt.s1.profile.core.sdo.RuleProperty;

/**
 * @author
 */
public interface RuleDao extends Dao {
	
	/**
	 * returns Rule List
	 * @return Rule
	 * @throws DataAccessException
	 */
	public List<Rule> getAllRules() throws DASException;
	
	/**
	 * returns Rule List
	 * @return Rule
	 * @throws DataAccessException
	 */
	public List<Rule> getAllRulesByApp(List<Long> appIds) throws DASException;
	
	/**
	 * returns Rule Object
	 * @param ruleId
	 * @return Rule
	 * @throws DataAccessException
	 */
	public Rule getRule(Long ruleId) throws DASException;

	/**
	 * returns List of Rule Object
	 * @param ruleIds
	 * @return List<Rule>
	 * @throws DataAccessException
	 */

	public List<Rule> getRuleList(List<Long> ruleIds) throws DASException;

	/**
	 * returns Map of Rule Object with Key as ID
	 * @param ruleIds
	 * @return List<Rule>
	 * @throws DataAccessException
	 */

	public Map<Long, Rule> getRuleMap(List<Long> ruleIds) throws DASException;

	
	/**
	 * returns List of Rule Object
	 * @param applicationId
	 * @return List<Rule>
	 * @throws DataAccessException
	 */

	public List<Rule> getRuleListForApplication(Long applicationId) throws DASException;
	
	
	/**
	 * returns Map of Rule Object with Key as ID
	 * @param applicationId
	 * @return Map<Long, Rule>
	 * @throws DataAccessException
	 */

	public Map<Long, Rule> getRuleMapForApplication(Long applicationId) throws DASException;

	
	/**
	 * Returns next Rule Id 
	 * @return Long
	 * @throws DataAccessException
	 */
	public Long getNextRuleId() throws DASException;

	/**
	 * Delete Rule Object
	 * @param ruleId
	 * @return Rule
	 * @throws DataAccessException
	 */
	public boolean deleteRule(Rule rule) throws DASException;

	/**
	 * Update Rule Object
	 * @param ruleId
	 * @return Rule
	 * @throws DataAccessException
	 */
	public boolean insertRule(Rule rule, List<RuleProperty> deleteList, List<RuleProperty> updateList, List<RuleProperty> insertList) throws DASException;

	/**
	 * Update Rule Object
	 * @param ruleId
	 * @return Rule
	 * @throws DataAccessException
	 */
	public boolean updateRule(Rule rule, List<RuleProperty> deleteList, List<RuleProperty> updateList, List<RuleProperty> insertList) throws DASException;


	/**
	 * Save Rule and Rule Property List
	 * @param rule 
	 * @param rulePropList
	 * @return boolean
	 * @throws DataAccessException
	 */
	public boolean saveRule(Rule rule, List<RuleProperty> rulePropList) throws DASException;

	/**
	 * Save Rule List and Rule Property List
	 * @param ruleList 
	 * @param rulePropList
	 * @return boolean
	 * @throws DataAccessException
	 */

	public boolean saveRule(List<Rule> ruleList, List<RuleProperty> rulePropList) throws DASException;
}


