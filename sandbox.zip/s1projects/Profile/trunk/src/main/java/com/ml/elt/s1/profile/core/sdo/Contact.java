package com.ml.elt.s1.profile.core.sdo;

import javax.xml.bind.annotation.XmlRootElement;

import com.ml.elt.s1.platform.plugins.cache.PrimaryKey;
import com.ml.elt.s1.profile.core.enums.Action;
import com.ml.elt.s1.profile.transfer.gui.ContactBean;

@XmlRootElement(name = "contact")
public class Contact extends ProfileDomainObject {
	
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private String firstName;	
	private String lastName;	
	private String middleName;	
	private String email;	
	private String company;	
	private String role;	
	private String recipientType;	
	
	private Action action;
	
	public Contact(){	
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getRecipientType() {
		return recipientType;
	}

	public void setRecipientType(String recipientType) {
		this.recipientType = recipientType;
	}
	
	public Action getAction() {
		return action;
	}

	public void setAction(Action action) {
		this.action = action;
	}
	
	/* (non-Javadoc)
	 * @see com.ml.elt.s1.platform.plugins.cache.CacheObject#getCacheKey()
	 */
	@Override
	public String getCacheKey(){
		if (primaryKey == null){
			Object[] key = new Object[]{getId()};
			primaryKey = new PrimaryKey(key, this.getClass(), true, true);
		}
		return primaryKey.getStringKey();
	}
	
	public static String getCacheKey(Long id){
		Object[] key = new Object[]{id};
		PrimaryKey primaryKey = new PrimaryKey(key, Contact.class, true, true);
		return primaryKey.getStringKey();
	}
	
	public boolean equals(ContactBean contactBean) {
		if(contactBean == null || !(contactBean instanceof ContactBean))
			return false;

		if(this.id == contactBean.getId() 
	        && this.firstName.equals(contactBean.getFirstName())
	        && this.middleName.equals(contactBean.getMiddleName())
	        && this.lastName.equals(contactBean.getLastName())
	        && this.email.equals(contactBean.getEmail())
	        && this.company.equals(contactBean.getCompany())
	        && this.role.equals(contactBean.getRole())
	        && this.recipientType.equals(contactBean.getRecipientType()))
			return false;
		else
			return true;
	}
}
