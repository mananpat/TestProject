package com.ml.elt.s1.profile.core.sdo;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

import com.ml.elt.s1.platform.container.service.cache.CachableObject;
@XmlRootElement(name = "priceTolerances")

public class PriceTolerances implements Serializable, CachableObject, Cloneable {
	private static final long serialVersionUID = 1L;

	private String description;
	private String model;
	private String insttype;
	private String currency;
	private String exchange;
	private String instrument;
	private Double tolerance;
	

	private Long id;
	
	public PriceTolerances() {
		
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public Object getCacheKey() {
		return id;
	}
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	
	public String getModel() {
		return model;
	}
	public void setMoldel(String model) {
		this.model = model;
	}
	
	public String getInsttype() {
		return insttype;
	}
	public void setInsttype(String insttype) {
		this.insttype = insttype;
	}
	
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	
	public String getExchange() {
		return exchange;
	}
	public void setExchange(String exchange) {
		this.exchange = exchange;
	}
	
	public String getInstrument() {
		return instrument;
	}
	public void setInstrument(String instrument) {
		this.instrument = instrument;
	}
	
	public Double getTolerance() {
		return tolerance;
	}
	public void setTolerance(Double tolerance) {
		this.tolerance = tolerance;
	}
	
	public Object clone() throws CloneNotSupportedException {
		//get initial bit-by-bit copy, which handles all immutable fields
		PriceTolerances code = (PriceTolerances)super.clone();

		//mutable fields need to be made independent of this object, for reasons
		//similar to those for defensive copies - to prevent unwanted access to
		//this object's internal state
		Double tolerance = new Double(this.getTolerance());
		code.setTolerance(tolerance);
		return code;
	}
}
