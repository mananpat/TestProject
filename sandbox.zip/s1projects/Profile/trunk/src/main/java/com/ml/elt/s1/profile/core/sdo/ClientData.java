package com.ml.elt.s1.profile.core.sdo;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ClientData{
	
	private String shortName;
	private Set<String> parentSet;
	
	private List<ClientData> parentList;
	

	public ClientData(){	
	}

	public ClientData(String shortName){
		this.shortName = shortName;
	}

	public String getShortName() {
		return shortName;
	}

	public void setShortName(String shortName) {
		this.shortName = shortName;
	}

	public Set<String> getParentSet() {
		return parentSet;
	}

	public void setParentSet(Set<String> parentSet) {
		this.parentSet = parentSet;
	}

	public List<ClientData> getParentList() {
		return parentList;
	}

	public void setParentList(List<ClientData> parentList) {
		this.parentList = parentList;
	}

	public void addParentString(String parent){
		if(this.parentSet ==null)this.parentSet = new HashSet<String>(2);
		this.parentSet.add(parent);
	}
	
	public void addParent(ClientData parent){
		if(this.parentList ==null)this.parentList = new ArrayList<ClientData>(2);
		if(parent!=null)
			this.parentList.add(parent);
	}
	
	public void flushParentList(){
		if(this.parentList!=null)
			this.parentList.clear();
		this.parentList = null;
	}

	public String toString(){
		StringBuilder sb = new StringBuilder();
		sb.append("Child["+shortName+"]");
		sb.append("Parent["+parentSet+"]\n");
		return sb.toString();
	}
}
