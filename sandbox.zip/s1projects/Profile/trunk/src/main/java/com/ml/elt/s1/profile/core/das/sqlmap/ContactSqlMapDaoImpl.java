/**
 * 
 */
package com.ml.elt.s1.profile.core.das.sqlmap;

import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.orm.ibatis.SqlMapClientTemplate;

import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.profile.core.das.iface.ContactDao;
import com.ml.elt.s1.profile.core.enums.Action;
import com.ml.elt.s1.profile.core.sdo.Contact;

/**
 * @author mpatel12
 *
 */
public class ContactSqlMapDaoImpl extends SqlMapClientTemplate implements ContactDao {

	/* (non-Javadoc)
	 * @see com.ml.elt.s1.core.das.iface.ContactDao#getAllContacts()
	 */
	@SuppressWarnings("unchecked")
	public List<Contact> getAllContacts() throws DASException {
		try {
			return (List<Contact>) queryForList("getAllContacts");		
		} catch (org.springframework.dao.DataAccessException ex) {
			throw new DASException(ex);
		}
	}

	/* (non-Javadoc)
	 * @see com.ml.elt.s1.core.das.iface.ContactDao#getContactById(java.lang.String)
	 */	
	public Contact getContactById(Long id) throws DASException {
		try {
			return (Contact) queryForObject("getContactById", id);			
		} catch (org.springframework.dao.DataAccessException ex) {
			throw new DASException(ex);
		}
	}
		
	
	/**
	 * save Contact
	 * @return Contact
	 * @throws DataAccessException
	 */
	public boolean saveContact(Contact contact) throws DASException {
		try {
			if(contact.getAction().equals(Action.ADD))
				return insertContact(contact);
			else			
				return updateContact(contact);				
		} catch (org.springframework.dao.DataAccessException ex) {
			throw new DASException(ex);
		}
	}
	
	/**
	 * insert Contact
	 * @return Contact
	 * @throws DataAccessException
	 */
	private boolean insertContact(Contact contact) throws DASException{
		try {		
			insert("insertContact", contact);
			return true;
		} catch (org.springframework.dao.DataAccessException ex) {
			throw new DASException(ex);
		}
	}
	
	/**
	 * update Contact
	 * @return Contact
	 * @throws DataAccessException
	 */
	private boolean updateContact(Contact contact) throws DASException{
		try {		
			update("updateContact", contact);
			return true;
		} catch (org.springframework.dao.DataAccessException ex) {
			throw new DASException(ex);
		}
	}

}
