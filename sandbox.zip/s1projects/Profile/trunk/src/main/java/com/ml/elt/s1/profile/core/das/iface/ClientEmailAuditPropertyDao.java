package com.ml.elt.s1.profile.core.das.iface;

import java.util.List;

import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.platform.container.service.das.Dao;
import com.ml.elt.s1.profile.core.sdo.ClientEmailAuditProperty;

public interface ClientEmailAuditPropertyDao extends Dao {
    List<ClientEmailAuditProperty> getAllClientEmailProperty() throws DASException;
    
    List<ClientEmailAuditProperty> getAllActiveClientEmailProperty() throws DASException;
}