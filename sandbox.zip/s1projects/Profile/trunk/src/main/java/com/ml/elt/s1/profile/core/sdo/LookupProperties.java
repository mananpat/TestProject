package com.ml.elt.s1.profile.core.sdo;

import com.ml.elt.s1.platform.plugins.cache.PrimaryKey;

/**
 * LookupProperties 
 */
public class LookupProperties extends ProfileDomainObject  {

	private static final long serialVersionUID = 1L;

	private Long id;
	private Long applicationId;
	private Long propertyId;
	private Short lookupRank;
	private Short viewWidth;
	
	public LookupProperties() {
	}

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Short getLookupRank() {
		return this.lookupRank;
	}

	public void setLookupRank(Short lookupRank) {
		this.lookupRank = lookupRank;
	}

	public Short getViewWidth() {
		return this.viewWidth;
	}

	public void setViewWidth(Short viewWidth) {
		this.viewWidth = viewWidth;
	}
	
	public Long getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}

	public Long getPropertyId() {
		return propertyId;
	}

	public void setPropertyId(Long propertyId) {
		this.propertyId = propertyId;
	}
			
	/* (non-Javadoc)
	 * @see com.ml.elt.s1.platform.plugins.cache.CacheObject#getCacheKey()
	 */
	@Override
	public String getCacheKey(){
		if (primaryKey == null){
			Object[] key = new Object[]{getId()};
			primaryKey = new PrimaryKey(key, this.getClass(), true, true);
		}
		return primaryKey.getStringKey();
	}
	
	
	public static String getCacheKey(Long id){
		Object[] key = new Object[]{id};
		PrimaryKey primaryKey = new PrimaryKey(key, LookupProperties.class, true, true);
		return primaryKey.getStringKey();
	}
	
	
	public String getPath(){
		return getClass().getPackage().getName().replace('.', '_')
		+ "/" + getClass().getSimpleName()
		+ "/" + getApplicationId();
	}

}
