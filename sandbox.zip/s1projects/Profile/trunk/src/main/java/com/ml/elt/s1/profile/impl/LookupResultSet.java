package com.ml.elt.s1.profile.impl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LookupResultSet implements Serializable{
	private static final long serialVersionUID = 1L;
	
	public Map<String, Object> lookupValues;
	public Map<String, List<Object>> propertyValues = new HashMap<String, List<Object>>();
	public Map<String,Long> rulesMap = new HashMap<String,Long>();
	public Map<String,String> propertyTypesMap = new HashMap<String,String>();
	public List<Long> rulesList = new ArrayList<Long> ();
	
	public void clear () {
		if(lookupValues != null)
			lookupValues.clear();
		if(propertyValues != null)
			propertyValues.clear();
		if(rulesList != null)
			rulesList.clear();
		if(rulesMap != null)
			rulesMap.clear();		
	}
	
}
