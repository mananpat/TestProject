/**
 * 
 */
package com.ml.elt.s1.profile.core.sdo.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ml.elt.s1.profile.core.das.cache.ProfileCommandQuery;
import com.ml.elt.s1.profile.core.sdo.Application;
import com.ml.elt.s1.profile.core.sdo.PropertyGroup;
import com.ml.elt.s1.profile.core.sdo.PropertyGroupMapping;



/**
 *
 *	ApplicationId-> PropertyId -> PropertyGroupCode
 * 
 * @author mpatel12
 *
 */
public class PropertyGroupCodeUtil {
	
	private static Log log = LogFactory.getLog(PropertyGroupCodeUtil.class);
		
	private static Map<Long, Map<Long,String>> appPropertyGroupCodeMap = new HashMap<Long, Map<Long,String>>();

	
	@SuppressWarnings("unchecked")
	public static void initPropertyGroupCodeMap(){
		try {
			appPropertyGroupCodeMap.clear();
			
			List<Application> list = ProfileCommandQuery.getApplications();
			if(list != null && !list.isEmpty()){ 
				for(Application app : list) {
					Long appId = app.getId();
					List<PropertyGroup> propertyGroupList = ProfileCommandQuery.getPropertyGroupsOfApplication(appId);
					if(propertyGroupList != null && !propertyGroupList.isEmpty()){
						Map<Long,String> propertyGroupCodeMap = new HashMap<Long, String>(5);
						
						for(PropertyGroup pg : propertyGroupList){
							String propertyGroupCode = pg.getPropertyGroupCode();
							List<PropertyGroupMapping> pgmList = ProfileCommandQuery.getPropertyGroupMappingOfPropertyGroup(pg.getId());

							if(pgmList != null && !pgmList.isEmpty()){
								for(PropertyGroupMapping pgm : pgmList){
									propertyGroupCodeMap.put(pgm.getPropertyId(), propertyGroupCode);							
								}
							}
						}
						
						appPropertyGroupCodeMap.put(appId, propertyGroupCodeMap);
					}
				}
			}
		} catch (Exception dasEx) {
			log.error("Unable to Create Property Group and Property Map", dasEx);
		}
	}

	
	public static String getPropertyGroupCodeByPropertyId(Long applicationId, Long propertyId){
		if(appPropertyGroupCodeMap == null || appPropertyGroupCodeMap.isEmpty())
			return null;
		
		if(appPropertyGroupCodeMap.containsKey(applicationId)){
			Map<Long,String> propertyGrpCodeMap = appPropertyGroupCodeMap.get(applicationId);
			if(propertyGrpCodeMap != null)
				return propertyGrpCodeMap.get(propertyId);
		}
		return null;
	}
		
}
