/**
 * 
 */
package com.ml.elt.s1.profile.plugins.cache.loaders;

import java.util.List;

import org.apache.log4j.Logger;

import com.ml.elt.s1.platform.container.service.cache.CacheDas;
import com.ml.elt.s1.platform.plugins.das.Das;
import com.ml.elt.s1.profile.core.das.iface.PropertyDao;
import com.ml.elt.s1.profile.core.sdo.Property;
import com.ml.elt.s1.profile.plugins.cache.Worker;


/**
 * @author mpatel12
 *
 */
public class PropertyLoader extends Worker {

	private static Logger log = Logger.getLogger(PropertyLoader.class);
	
	public PropertyLoader(Das daoManagerDb, CacheDas cacheDas) {	
		super(daoManagerDb, cacheDas);
	}
	
	public void doWork() throws Exception {
		log.info("loading Property...");
		PropertyDao dbDao = (PropertyDao) daoManagerDb.getDao(Property.class);
		List<Property> list = dbDao.getAllProperties();
		if(list != null && !list.isEmpty()){
			write(list);
		}
		log.info("done - loading Property and writing to cache.");		
	}
}
