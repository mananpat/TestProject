package com.ml.elt.s1.profile.core.das.sqlmap;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.orm.ibatis.SqlMapClientTemplate;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.ibatis.sqlmap.client.SqlMapClient;
import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.profile.core.das.iface.RuleDao;
import com.ml.elt.s1.profile.core.enums.Action;
import com.ml.elt.s1.profile.core.sdo.Rule;
import com.ml.elt.s1.profile.core.sdo.RuleProperty;

public class RuleSqlMapDaoImpl extends SqlMapClientTemplate implements RuleDao {
	
	private static Log log = LogFactory.getLog(RuleSqlMapDaoImpl.class);  

	private final String INSERT_RULE_PROP = "INSERT INTO RULE_PROPERTY (ID, RULE_ID,PROPERTY_ID, VALUE, CREATE_USER, CREATE_TS, UPDATE_USER ,UPDATE_TS) "
		+ " VALUES(? , ?, ?, ?, ?, ?, ?, ?) ";
	
	private final String INSERT_RULE = "INSERT INTO RULE (ID, APPLICATION_ID, ACTIVE_FLAG, DESCRIPTION, CREATE_USER, CREATE_TS, UPDATE_USER, UPDATE_TS) "
		+ " VALUES(?, ?, ?, ?, ?, ?, ?, ?) ";


	private final String UPDATE_RULE = "UPDATE RULE SET ACTIVE_FLAG= ? , UPDATE_USER =? , DESCRIPTION =? , UPDATE_TS=? WHERE ID = ?";

	private final String UPDATE_RULE_PROP = "UPDATE RULE_PROPERTY SET VALUE=?, UPDATE_USER=?, UPDATE_TS=?   WHERE ID= ? AND RULE_ID= ? AND PROPERTY_ID = ? ";

	private final String DELETE_RULE_PROP = "DELETE  RULE_PROPERTY WHERE ID= ? AND RULE_ID= ? AND PROPERTY_ID = ? ";

	private DataSourceTransactionManager dsTxManager = null;
	
	public DataSourceTransactionManager getDsTxManager() {
		return dsTxManager;
	}

	public void setDsTxManager(DataSourceTransactionManager dsTxManager) {
		this.dsTxManager = dsTxManager;
	}

	@SuppressWarnings("unchecked")
	public List<Rule> getAllRules() throws DASException {
		try {
			return (List<Rule>) queryForList("getAllRules");
		} catch (DataAccessException daEx) {
			throw new DASException(daEx);
		}
	}
	
	@SuppressWarnings("unchecked")
	public List<Rule> getAllRulesByApp(List<Long> appIds) throws DASException {
		List<Rule> ruleList = null;
		try {
			if(appIds !=null && !appIds.isEmpty()){
				ruleList = (List<Rule>)queryForList("getAllRulesByApp",appIds);
			}
		}catch(DataAccessException daEx){
			throw new DASException(daEx);
		}
		return ruleList;		
	}

	public Rule getRule(Long ruleId) throws DASException {
		try {
			return (Rule) queryForObject("getRule", ruleId);
		} catch (DataAccessException daEx) {
			throw new DASException(daEx);
		}
	}

	@SuppressWarnings("unchecked")
	public List<Rule> getRuleList(List<Long> ruleIds) throws DASException {
		List<Rule> ruleList = null;
		try {
			if (ruleIds != null && !ruleIds.isEmpty()) {
				ruleList = (List<Rule>) queryForList("getRuleList", ruleIds);
			}
		} catch (DataAccessException daEx) {
			throw new DASException(daEx);
		}
		return ruleList;
	}

	@SuppressWarnings("unchecked")
	public List<Rule> getRuleListForApplication(Long applicationId)
			throws DASException {
		List<Rule> ruleList = null;
		try {
			if (applicationId != null) {
				ruleList = (List<Rule>) queryForList(
						"getRuleListForApplication", applicationId);
			}
		} catch (DataAccessException daEx) {
			throw new DASException(daEx);
		}
		return ruleList;
	}

	@SuppressWarnings("unchecked")
	public Map<Long, Rule> getRuleMap(List<Long> ruleIds) throws DASException {
		Map<Long, Rule> ruleMap = null;
		try {
			if (ruleIds != null && !ruleIds.isEmpty()) {
				ruleMap = (Map<Long, Rule>) queryForMap("getRuleList", ruleIds,
						"id");
			}
		} catch (DataAccessException daEx) {
			throw new DASException(daEx);
		}
		return ruleMap;
	}

	@SuppressWarnings("unchecked")
	public Map<Long, Rule> getRuleMapForApplication(Long applicationId)
			throws DASException {
		Map<Long, Rule> ruleMap = null;
		try {
			if (applicationId != null) {
				ruleMap = (Map<Long, Rule>) queryForMap(
						"getRuleListForApplication", applicationId, "id");
			}
		} catch (DataAccessException daEx) {
			throw new DASException(daEx);
		}
		return ruleMap;
	}

	
	public Long  getNextRulePropertyId() throws DASException{
		try {
		return (Long) queryForObject("getNextRulePropertyId");
		} catch (DataAccessException daEx) {
			throw new DASException(daEx);
		}
	}

	
	@SuppressWarnings("unchecked")
	public Long  getNextRuleId() throws DASException {
		try {
			return (Long) queryForObject("getNextRuleId");
		} catch (DataAccessException daEx) {
			throw new DASException(daEx);
		}
	}
	
	

	/*
	 * (non-Javadoc)
	 * @see com.ml.elt.s1.profile.core.das.iface.RuleDao#insertRule(com.ml.elt.s1.profile.core.sdo.Rule, java.util.List)
	 */
//	public boolean saveRule(Rule rule, List<RuleProperty> rulePropList)
//			throws DASException {
//		boolean bret = false;
//		synchronized (writeLock) {
//			try {
//				DefaultTransactionDefinition def = new DefaultTransactionDefinition();
//				def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
//				TransactionStatus status = dsTxManager.getTransaction(def);
//				try {
//					addRule(rule);		
//					addRuleProperty(rulePropList);
//					
//					dsTxManager.commit(status);
//					bret = true;
//				} catch (Exception ex) {
//					try{
//						dsTxManager.rollback(status);
//					}catch(Exception inEx){
//						log.error("Unable to Rollback transaction",inEx);
//					}
//					throw new DASException(ex);
//				}
//			} catch (DataAccessException daEx) {
//				throw new DASException(daEx);
//			}
//		}
//		return bret;
//	}
	

	public boolean saveRule(Rule rule, List<RuleProperty> rulePropList)
	throws DASException {
		boolean bret = false;
		try {
			Connection conn = getSqlMapClient().getDataSource().getConnection();
			conn.clearWarnings();
			conn.setAutoCommit(false);
			try{
				addRule(rule,conn);		
				addRuleProperty(rulePropList, conn);
				conn.commit();
				bret = true;
			}catch(Throwable t){
				try{
					conn.rollback();
					log.info("Transaction Rolled Back");
				}catch(Throwable t2){
					log.error("Transaction RollBack Failed",t2);
				}
			}
			finally{
				conn.setAutoCommit(true);
				try{
					conn.close();
				}catch(Throwable t){
					log.error("Unable to Return connection to the Pool",t);
				}
			}
		} catch (Throwable ext) {
				throw new DASException(ext);
		}
		return bret;
	}

	public boolean saveRule(List<Rule> ruleList, List<RuleProperty> rulePropList)
	throws DASException {
		boolean bret = false;
		try {
			DefaultTransactionDefinition def = new DefaultTransactionDefinition();
			def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
			TransactionStatus status = dsTxManager.getTransaction(def);
			try {
				addRule(ruleList);		
				addRuleProperty(rulePropList);
				
				dsTxManager.commit(status);
				bret = true;
			} catch (Exception ex) {
				try{
					dsTxManager.rollback(status);
				}catch(Exception inEx){
					log.error("Unable to Rollback transaction",inEx);
				}
				throw new DASException(ex);
			}
		} catch (DataAccessException daEx) {
			throw new DASException(daEx);
		}
		return bret;
	}


	
	private boolean addRule(Rule rule) throws DASException {
		if(Action.ADD.equals(rule.getAction()))
			return insertRule(rule);
		else
			return updateRule(rule);
	}
	
	private boolean addRule(Rule rule,Connection conn) throws SQLException {
		if(Action.ADD.equals(rule.getAction()))
			return insertRule(rule,conn);
		else
			return updateRule(rule,conn);
	}

	
	
	private boolean addRule(List<Rule> ruleList) throws SQLException {
		boolean bret = false;
		if (ruleList != null && !ruleList.isEmpty()) {
			SqlMapClient sqlMapClient = getSqlMapClient();
			sqlMapClient.startTransaction();
			sqlMapClient.startBatch();
			for (Rule rule : ruleList) {
				if (Action.ADD.equals(rule.getAction()))
					insert("insertRule", rule);
				else if (Action.UPDATE.equals(rule.getAction()))
					update("updateRule", rule);
				else
					update("updateRule", rule);
			}
			sqlMapClient.executeBatch();
			sqlMapClient.commitTransaction();

			bret = true;
		}
		return bret;
	}
	
	private boolean insertRule(Rule rule) throws DASException {
		boolean bret = false;
		try {
			insert("insertRule", rule);
			bret = true;
		} catch (DataAccessException daEx) {
			throw new DASException(daEx);
		}
		return bret;
	}

	private boolean updateRule(Rule rule) throws DASException {
		boolean bret = false;
		try {
			update("updateRule", rule);
			bret = true;
		} catch (DataAccessException daEx) {
			throw new DASException(daEx);
		}
		return bret;
	}
	
	
	private boolean addRuleProperty(List<RuleProperty> rulePropertyList,Connection conn) throws SQLException, DASException {
		boolean bret = false;
		if (rulePropertyList != null && !rulePropertyList.isEmpty()) {
			List<RuleProperty> deleteList = new ArrayList<RuleProperty>();
			List<RuleProperty> insertList = new ArrayList<RuleProperty>();
			List<RuleProperty> updateList = new ArrayList<RuleProperty>();
			for (RuleProperty ruleProp : rulePropertyList) {
				if (Action.ADD.equals(ruleProp.getAction())){
					Long rulePropId = getNextRulePropertyId();
					ruleProp.setId(rulePropId);
					insertList.add(ruleProp);
				} else if (Action.UPDATE.equals(ruleProp.getAction())){
					updateList.add(ruleProp);
				} else if (Action.DELETE.equals(ruleProp.getAction())){
					deleteList.add(ruleProp);
				} else {					
					log.warn("Incorrect Action of the Rule Property: " + ruleProp);
				}
			}
			
			if(!deleteList.isEmpty()){
				deleteRuleProperty(deleteList, conn);
			} 
			if(!insertList.isEmpty()){
				insertRuleProperty(insertList, conn);
			}		
			if(!updateList.isEmpty()){
				updateRuleProperty(updateList, conn);
			}
			bret = true;
		}
		return bret;
	}
	
	
	

	
	private boolean addRuleProperty(List<RuleProperty> rulePropertyList) throws SQLException {
		boolean bret = false;
		if (rulePropertyList != null && !rulePropertyList.isEmpty()) {
			SqlMapClient sqlMapClient = getSqlMapClient();
			sqlMapClient.startTransaction();
			sqlMapClient.startBatch();
			for (RuleProperty ruleProp : rulePropertyList) {
				if (Action.ADD.equals(ruleProp.getAction()))
					insert("insertRuleProperty", ruleProp);
				else if (Action.UPDATE.equals(ruleProp.getAction()))
					update("updateRuleProperty", ruleProp);
				else if (Action.DELETE.equals(ruleProp.getAction()))
					delete("deleteRuleProperty", ruleProp);
				else
					insert("insertRuleProperty", ruleProp);
			}
			sqlMapClient.executeBatch();
			sqlMapClient.commitTransaction();

			bret = true;
		}
		return bret;
	}
	
	
	public boolean updateRule(Rule rule, List<RuleProperty> deleteList,
			List<RuleProperty> updateList, List<RuleProperty> insertList)
			throws DASException {
		boolean bret = false;
		try {
			SqlMapClient sqlMap = getSqlMapClient();
			Connection con = sqlMap.getDataSource().getConnection();
			con.setAutoCommit(false);
			try {
				updateRule(rule, con);
				deleteRuleProperty(deleteList, con);
				updateRuleProperty(updateList, con);
				insertRuleProperty(insertList, con);
				con.commit();
			} catch (Exception ex) {
				throw new DASException(ex);
			} finally {
				con.setAutoCommit(true);
				sqlMap.endTransaction();
			}
		} catch (SQLException sqlEx) {
			throw new DASException(sqlEx);
		}
		return bret;
	}

	public boolean insertRule(Rule rule, List<RuleProperty> deleteList,
			List<RuleProperty> updateList, List<RuleProperty> insertList)
			throws DASException {
		boolean bret = false;
		try {
			SqlMapClient sqlMap = getSqlMapClient();
			Connection con = sqlMap.getDataSource().getConnection();
			con.setAutoCommit(false);
			try {
				insertRule(rule, con);
				deleteRuleProperty(deleteList, con);
				updateRuleProperty(updateList, con);
				insertRuleProperty(insertList, con);
				con.commit();
			} catch (Exception ex) {
				throw new DASException(ex);
			} finally {
				con.setAutoCommit(true);
				sqlMap.endTransaction();
			}
		} catch (SQLException sqlEx) {
			throw new DASException(sqlEx);
		}
		return bret;
	}
	
	public boolean deleteRule(Rule rule) 
		throws DASException{
			throw new DASException("Rule Deletion is not Allowed");
	}

	
	//INSERT RULE_PROPERTY (ID, RULE_ID,PROPERTY_ID, VALUE, CREATE_USER, CREATE_TS, UPDATE_USER ,UPDATE_TS)
	
	public boolean insertRuleProperty(List<RuleProperty> rulePropertyList,
			Connection con) throws SQLException {
		boolean bret = false;
		if (con != null && rulePropertyList != null
				&& !rulePropertyList.isEmpty()) {
			PreparedStatement psmt = con.prepareStatement(INSERT_RULE_PROP);
			Timestamp updateDate = new Timestamp(System.currentTimeMillis());
			for (RuleProperty ruleProp : rulePropertyList) {
				if(ruleProp.getUpdateDateTime()!=null){
					updateDate = new Timestamp(ruleProp.getUpdateDateTime().getTime());
				} else {
					updateDate = new Timestamp(System.currentTimeMillis());
				}
				psmt.setLong(1, ruleProp.getId());
				psmt.setLong(2, ruleProp.getRuleId());
				psmt.setLong(3, ruleProp.getPropertyId());
				psmt.setString(4, ruleProp.getValue());
				psmt.setString(5, ruleProp.getCreateUser());
				psmt.setTimestamp(6, updateDate);
				psmt.setString(7, ruleProp.getCreateUser());
				psmt.setTimestamp(8, updateDate);
				psmt.addBatch();
			}
			int[] rIntAr = psmt.executeBatch();
			if (rIntAr != null) {
				bret = true;
				for (int rInt : rIntAr) {
					if (rInt == Statement.EXECUTE_FAILED) {
						bret = false;
						break;
					}
				}
			}
		}
		return bret;
	}

	
	// DELETE  RULE_PROPERTY WHERE ID= ? RULE_ID= ? AND PROPERTY_ID = ? 
	public boolean deleteRuleProperty(List<RuleProperty> rulePropertyList,
			Connection con) throws SQLException {
		boolean bret = false;
		if (con != null && rulePropertyList != null
				&& !rulePropertyList.isEmpty()) {
			PreparedStatement psmt = con.prepareStatement(DELETE_RULE_PROP);
			for (RuleProperty ruleProp : rulePropertyList) {
				psmt.setLong(1, ruleProp.getId());
				psmt.setLong(2, ruleProp.getRuleId());
				psmt.setLong(3, ruleProp.getPropertyId());
				psmt.addBatch();
			}
			int[] rIntAr = psmt.executeBatch();
			if (rIntAr != null) {
				bret = true;
				for (int rInt : rIntAr) {
					if (rInt == Statement.EXECUTE_FAILED) {
						bret = false;
						break;
					}
				}
			}
		}
		return bret;
	}

//	UPDATE RULE_PROPERTY SET VALUE=?, UPDATE_USER=?, UPDATE_TS=?   WHERE ID= ? AND RULE_ID= ? AND PROPERTY_ID = ? ";
	
	public boolean updateRuleProperty(List<RuleProperty> rulePropertyList,
			Connection con) throws SQLException {
		boolean bret = false;
		if (con != null && rulePropertyList != null
				&& !rulePropertyList.isEmpty()) {
			PreparedStatement psmt = con.prepareStatement(UPDATE_RULE_PROP);
			Timestamp time = null;

			for (RuleProperty ruleProp : rulePropertyList) {
				if(ruleProp.getUpdateDateTime()!=null){
					time = new Timestamp(ruleProp.getUpdateDateTime().getTime()); 
				} else {
					time = new Timestamp(System.currentTimeMillis());
				}

				psmt.setString(1, ruleProp.getValue());
				psmt.setString(2, ruleProp.getUpdateUser());
				psmt.setTimestamp(3, time);
				psmt.setLong(4, ruleProp.getId());
				psmt.setLong(5, ruleProp.getRuleId());
				psmt.setLong(6, ruleProp.getPropertyId());
				psmt.addBatch();
			}
			int[] rIntAr = psmt.executeBatch();
			if (rIntAr != null) {
				bret = true;
				for (int rInt : rIntAr) {
					if (rInt == Statement.EXECUTE_FAILED) {
						bret = false;
						break;
					}
				}
			}
		}
		return bret;
	}

	// UPDATE RULE SET ACTIVE_FLAG= ? , UPDATE_USER =? , DESCRIPTION =? , UPDATE_TS=? WHERE ID = ?"
	
	public boolean updateRule(Rule rule, Connection con) throws SQLException {
		boolean bret = false;
		if (con != null && rule != null) {
			PreparedStatement psmt = con.prepareStatement(UPDATE_RULE);
			int activeNum = (rule.getActiveFlag()!=null)?(rule.getActiveFlag()?1:0):1;
			
			Timestamp updateDate = null;
			if(rule.getUpdateDateTime()!=null){
				updateDate = new Timestamp(rule.getUpdateDateTime().getTime()); 
			} else {
				updateDate = new Timestamp(System.currentTimeMillis());
			}
			psmt.setInt(1, activeNum);
			psmt.setString(2, rule.getUpdateUser());
			psmt.setString(3, rule.getDescription());
			psmt.setTimestamp(4,updateDate);
			psmt.setLong(5,rule.getId());
			
			int rInt = psmt.executeUpdate();
			if (rInt >= 0)
				bret = true;
		}
		return bret;
	}


//	INSERT RULE (ID, APPLICATION_ID, ACTIVE_FLAG, DESCRIPTION, CREATE_USER, CREATE_TS, UPDATE_USER, UPDATE_TS) 
//	  VALUES(?, ?, ?, ?, ?, ?, ?, ?) 
	
	public boolean insertRule(Rule rule, Connection con) throws SQLException {
		boolean bret = false;
		if (con != null && rule != null) {
			PreparedStatement psmt = con.prepareStatement(INSERT_RULE);
			int activeNum = (rule.getActiveFlag()!=null)?(rule.getActiveFlag()?1:0):1;
			Timestamp updateDate = null;
			if(rule.getCreateDateTime()!=null){
				updateDate = new Timestamp(rule.getCreateDateTime().getTime()); 
			} else {
				updateDate = new Timestamp(System.currentTimeMillis());
			}
			psmt.setLong(1, rule.getId());
			psmt.setLong(2, rule.getApplicationId());
			psmt.setInt(3, activeNum);
			psmt.setString(4, rule.getDescription());
			psmt.setString(5, rule.getCreateUser());
			psmt.setTimestamp(6, updateDate);
			psmt.setString(7, rule.getCreateUser());
			psmt.setTimestamp(8, updateDate);

			int rInt = psmt.executeUpdate();
			if (rInt >= 0)
				bret = true;
		}
		return bret;
	}

}
