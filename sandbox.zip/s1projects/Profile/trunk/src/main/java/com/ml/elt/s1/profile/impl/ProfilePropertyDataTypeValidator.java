/**
 * 
 */
package com.ml.elt.s1.profile.impl;

import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.platform.plugins.boot.DefaultConfiguration;
import com.ml.elt.s1.profile.core.das.cache.ProfileCommandQuery;
import com.ml.elt.s1.profile.core.sdo.Property;
import com.ml.elt.s1.profile.exception.ProfileException;
import com.ml.elt.s1.profile.intface.DataConverter;
import com.ml.elt.s1.profile.transfer.gui.PropertyBean;
import com.ml.elt.s1.profile.util.ProfileApplicationConstant;

/**
 * @author mpatel12
 *
 */
public class ProfilePropertyDataTypeValidator {

	private static Log log = LogFactory.getLog(ProfilePropertyDataTypeValidator.class);
	
	public static final String TYPE_STRING = "STRING";
    public static final String TYPE_DOUBLE = "DOUBLE";
    public static final String TYPE_CONTACT = "CONTACT";
    public static final String TYPE_BOOLEAN = "BOOLEAN";
    public static final String TYPE_INTEGER = "INTEGER";
    public static final String TYPE_LONG = "LONG";
    public static final String TYPE_FLOAT = "FLOAT";
    public static final String TYPE_DATETIME = "DATE";
    public static final String TYPE_SHORT = "SHORT";	
    public static final String TYPE_MARKET = ProfileApplicationConstant.MARKET_CHARGES;
    public static final String ENUM_PACKAGE_PREFIX = "com.ml.elt.s1.core.sdo.enums.";
    public static final String ENUM_CONVERT_METHOD = "fromId";
	public static final String TYPE_ENUM = "ENUM";
	
	
	private static final String DATETIMEFORMAT = "MM/dd/yyyy";
	private static DateFormat dateFormat = new SimpleDateFormat(DATETIMEFORMAT);
    
	private static ProfilePropertiesMananger propertiesManager = null;
	
	static {
    	try 
    	{
    		Object obj = DefaultConfiguration.getBean("profilePropertiesMananger");
	    	if(propertiesManager == null){
		    	if(obj != null)
		    		propertiesManager = (ProfilePropertiesMananger) obj;    	
		    	else
		    		log.error("Profile Properties Manager Configuration is missing");	    	
	    	}
    	} catch(Throwable t) {
    		log.error("Error while loading bean from configuration", t);
    	}  
	}
	
	public List<String> validate(String applicationCode, List<PropertyBean> incomingPropertyBeanList) {
		List<String> errors = null;
		try 
		{		
			if(incomingPropertyBeanList != null && !incomingPropertyBeanList.isEmpty()){
				errors = new ArrayList<String>();
				for(PropertyBean propBean :  incomingPropertyBeanList){
					Property property = null;
					
					String validationError = null;
					try{
						property = ProfileCommandQuery.getPropertyByPropCode(propBean.getPropertyCode());
					}
					catch(DASException de){
						log.warn("Exception while retrieving property from cache for poperty code: " + propBean.getPropertyCode());
						validationError = "Error while retrieving property from cache for poperty code: " + propBean.getPropertyCode();
						errors.add(validationError);
						continue;
					}				
					
					
					validationError = validateProperty(applicationCode, property.getDataType(), propBean.getValue(), property.getDescription());
					
					if(validationError != null && !"".equals(validationError))
						errors.add(validationError);
				}
			}
		}
		catch(Throwable t){
			log.warn("Exception in validate method in PropertyDataTypeValidator", t);
			String error = "One or more error(s) while validating Rule Property.";
			if(errors != null)
				errors = new ArrayList<String>();
			errors.add(error);
		}
		return errors;
		
	}
	
	/*
	 * Parse Incoming Property Value in case multiple values are allowed.
	 */
	private Set<String> parsePropertyValue(String applicationCode, Object propValue, String propertyCode){
		Set<String> newValueSet = null;		
		String propString = propValue.toString();
		if (propString == null || propString.length() == 0)
			return null;		
		else
		{
			String propVal = propString.trim();
			DataConverter converter = propertiesManager.getApplicationDataConverter(applicationCode);
			String seperator = converter.isAList(propertyCode) ? "," : null;
			String[] splitValues;
			if(seperator != null){
				splitValues  = propVal.split(seperator);
			}
			else {
				splitValues = new String[1];
				splitValues[0] = propVal;
			}
				
			newValueSet = new HashSet<String>();
			for(String value : splitValues){
				if(!"".equals(value.trim()))
					newValueSet.add(value.trim());
			}
		}
		return newValueSet;
	}
	
	@SuppressWarnings("unchecked")
	public String validateProperty(String applicationCode, String propertyDataType, Object propValue, String propertyCode) throws ProfileException {
		String errorMsg = "Invalid Value \"%1$s\" for Property \"%2$s\". Value MUST be of \"%3$s\" data type.";
		if (propValue == null || propertyDataType == null || propertyCode == null)
			return null;
		
		if (propertyDataType.equalsIgnoreCase(TYPE_STRING))
			return null;
		else if (propertyDataType.equalsIgnoreCase(TYPE_DOUBLE)) {
			try
			{
				/*String propString = propValue.toString();
				if (propString == null || propString.length() == 0)
					return null;
				Double value = Double.parseDouble(propString);*/
				
				Set<String> propValueSet = parsePropertyValue(applicationCode, propValue, propertyCode);
				if(propValueSet != null && propValueSet.size() != 0){
					for(String newValue : propValueSet){
						try
						{	
							Double value = Double.parseDouble(newValue);
						}
						catch(NumberFormatException ne){
							log.warn(String.format("Cannot convert %1$s to type %2$s. Due to: ", propValue, propertyDataType), ne);					
							return String.format(errorMsg, propValue, propertyCode, propertyDataType);
						}
					}
				}
				return null;
			}
			catch(Throwable t){
				log.warn(String.format("Failed to parse or convert %1$s to type %2$s. Due to: ", propValue, propertyDataType), t);				
				return String.format(errorMsg, propValue, propertyCode, propertyDataType);
			}
		}
		else if (propertyDataType.equalsIgnoreCase(TYPE_BOOLEAN)) {
			try
			{	
				/*String propString = propValue.toString();
				if (propString == null || propString.length() == 0)
					return null;
				Boolean value = Boolean.parseBoolean(propString);*/
				
				Set<String> propValueSet = parsePropertyValue(applicationCode, propValue, propertyCode);
				if(propValueSet != null && propValueSet.size() != 0){
					for(String newValue : propValueSet){
						try
						{	
							Boolean value = Boolean.parseBoolean(newValue);
						}
						catch(Throwable t){
							log.warn(String.format("Cannot convert %1$s to type %2$s. Due to: ", propValue, propertyDataType), t);					
							return String.format(errorMsg, propValue, propertyCode, propertyDataType);
						}
					}
				}	
				return null;
			}
			catch(Throwable t){
				log.warn(String.format("Failed to parse or convert %1$s to type %2$s. Due to: ", propValue, propertyDataType), t);					
				return String.format(errorMsg, propValue, propertyCode, propertyDataType);
			}			
		}
		else if (propertyDataType.equalsIgnoreCase(TYPE_INTEGER)) {
			try {
				/*String propString = propValue.toString();
				if (propString == null || propString.length() == 0)
					return null;				
				Integer value  = Integer.parseInt(propString);*/
				
				Set<String> propValueSet = parsePropertyValue(applicationCode, propValue, propertyCode);
				if(propValueSet != null && propValueSet.size() != 0){
					for(String newValue : propValueSet){
						try
						{	
							Integer value  = Integer.parseInt(newValue);
						}
						catch(NumberFormatException ne){
							log.warn(String.format("Cannot convert %1$s to type %2$s. Due to: ", propValue, propertyDataType), ne);					
							return String.format(errorMsg, propValue, propertyCode, propertyDataType);
						}
					}
				}	
				
				return null;
			}
			catch(Throwable t){
				log.warn(String.format("Failed to parse or convert %1$s to type %2$s. Due to: ", propValue, propertyDataType), t);					
				return String.format(errorMsg, propValue, propertyCode, propertyDataType);
			}	
		}
		else if (propertyDataType.equalsIgnoreCase(TYPE_SHORT)) {
			try {
				/*String propString = propValue.toString();
				if (propString == null || propString.length() == 0)
					return null;
				Short value  = Short.parseShort(propString);*/
				
				Set<String> propValueSet = parsePropertyValue(applicationCode, propValue, propertyCode);
				if(propValueSet != null && propValueSet.size() != 0){
					for(String newValue : propValueSet){
						try
						{	
							Short value  = Short.parseShort(newValue);
						}
						catch(NumberFormatException ne){
							log.warn(String.format("Cannot convert %1$s to type %2$s. Due to: ", propValue, propertyDataType), ne);					
							return String.format(errorMsg, propValue, propertyCode, propertyDataType);
						}
					}
				}	
				
				return null;
			}
			catch(Throwable t){
				log.warn(String.format("Failed to parse or convert %1$s to type %2$s. Due to: ", propValue, propertyDataType), t);					
				return String.format(errorMsg, propValue, propertyCode, propertyDataType);
			}
		}
		else if (propertyDataType.equalsIgnoreCase(TYPE_LONG)) {
			try {
				/*String propString = propValue.toString();
				if (propString == null || propString.length() == 0)
					return null;
				Long value  = Long.parseLong(propString);*/
				Set<String> propValueSet = parsePropertyValue(applicationCode, propValue, propertyCode);
				if(propValueSet != null && propValueSet.size() != 0){
					for(String newValue : propValueSet){
						try
						{	
							Long value  = Long.parseLong(newValue);
						}
						catch(NumberFormatException ne){
							log.warn(String.format("Cannot convert %1$s to type %2$s. Due to: ", propValue, propertyDataType), ne);					
							return String.format(errorMsg, propValue, propertyCode, propertyDataType);
						}
					}
				}	
				return null;
			}
			catch(Throwable t){
				log.warn(String.format("Failed to parse or convert %1$s to type %2$s. Due to: ", propValue, propertyDataType), t);					
				return String.format(errorMsg, propValue, propertyCode, propertyDataType);
			}			
		}
		else if (propertyDataType.equalsIgnoreCase(TYPE_FLOAT)) {
			try
			{
				/*String propString = propValue.toString();
				if (propString == null || propString.length() == 0)
					return null;
				Float value  = Float.parseFloat(propString);*/
				Set<String> propValueSet = parsePropertyValue(applicationCode, propValue, propertyCode);
				if(propValueSet != null && propValueSet.size() != 0){
					for(String newValue : propValueSet){
						try
						{	
							Float value  = Float.parseFloat(newValue);
						}
						catch(NumberFormatException ne){
							log.warn(String.format("Cannot convert %1$s to type %2$s. Due to: ", propValue, propertyDataType), ne);					
							return String.format(errorMsg, propValue, propertyCode, propertyDataType);
						}
					}
				}	
				return null;
			}
			catch(Throwable t){
				log.warn(String.format("Failed to parse or convert %1$s to type %2$s. Due to: ", propValue, propertyDataType), t);				
				return String.format(errorMsg, propValue, propertyCode, propertyDataType);
			}
		}	
		else if (propertyDataType.equalsIgnoreCase(TYPE_DATETIME)) {
			try {
				/*String propString = propValue.toString();
				if (propString == null || propString.length() == 0)
					return null;*/
				Set<String> propValueSet = parsePropertyValue(applicationCode, propValue, propertyCode);
				if(propValueSet != null && propValueSet.size() != 0){
					for(String newValue : propValueSet){
						try
						{
							propValue = dateFormat.parse(newValue);
						}
						catch(ParseException pe){
							log.warn(String.format("Cannot convert %1$s to type %2$s. Due to: ", propValue, propertyDataType), pe);				
							return String.format(errorMsg, propValue, propertyCode, propertyDataType);
						}
					}
				}
				return null;
			}
			catch(Throwable t){
				log.warn(String.format("Failed to parse or convert %1$s to type %2$s. Due to: ", propValue, propertyDataType), t);				
				return String.format(errorMsg, propValue, propertyCode, propertyDataType);
			}
		}
		else if (propertyDataType.equalsIgnoreCase(TYPE_CONTACT)) {
			try {
				/*String propString = propValue.toString();
				if (propString == null || propString.length() == 0)
					return null;*/
				Set<String> propValueSet = parsePropertyValue(applicationCode, propValue, propertyCode);
				if(propValueSet != null && propValueSet.size() != 0){
					for(String newValue : propValueSet){
						try
						{	
							Long contactId = Long.parseLong(newValue);
						}
						catch(NumberFormatException ne){
							log.warn(String.format("Cannot convert %1$s to type %2$s. Due to: ", propValue, propertyDataType), ne);					
							return String.format(errorMsg, propValue, propertyCode, propertyDataType);
						}
					}
				}					
				return null;
			} catch (Throwable t) {
				log.warn(String.format("Failed to parse or convert %1$s to type %2$s. Due to: ", propValue, propertyDataType), t);	
				return String.format(errorMsg, propValue, propertyCode, propertyDataType);
			}
		}
		else if (propertyDataType.equalsIgnoreCase(TYPE_MARKET)) {
			try {
				/*String propString = propValue.toString();
				if (propString == null || propString.length() == 0)
					return null;
				Long marketId = Long.parseLong(propString);	*/
				Set<String> propValueSet = parsePropertyValue(applicationCode, propValue, propertyCode);
				if(propValueSet != null && propValueSet.size() != 0){
					for(String newValue : propValueSet){
						try
						{	
							Long marketId = Long.parseLong(newValue);
						}
						catch(NumberFormatException ne){
							log.warn(String.format("Cannot convert %1$s to type %2$s. Due to: ", propValue, propertyDataType), ne);					
							return String.format(errorMsg, propValue, propertyCode, propertyDataType);
						}						
					}
				}	
				return null;
			} catch (Throwable t) {
				log.warn(String.format("Failed to parse or convert %1$s to type %2$s. Due to: ", propValue, propertyDataType), t);	
				return String.format(errorMsg, propValue, propertyCode, propertyDataType);
			}
		}
		else if (propertyDataType.startsWith(TYPE_ENUM)) {					
			try {
				String propString = propValue.toString();
				if (propString == null || propString.length() == 0)
					return null;
				
				propertyDataType = propertyDataType.replaceAll(TYPE_ENUM, "");
				propertyDataType = propertyDataType.replace('(', ' ');
				propertyDataType = propertyDataType.replace(')', ' ');	
				String clazzName = new StringBuilder(ENUM_PACKAGE_PREFIX).append(propertyDataType.trim()).toString();
				Class clazz = Class.forName(clazzName);
				Method method = clazz.getMethod(ENUM_CONVERT_METHOD,
						new Class[] { String.class });
				propValue = method.invoke(null, propString);
				return null;
			} catch (Throwable t) {
				log.warn(String.format("Cannot convert %1$s to type %2$s. Due to: ", propValue, propertyDataType), t);				
				return String.format(errorMsg, propValue, propertyCode, propertyDataType);				
			} 
		}
		else
		{
			log.info(String.format("Validation is not configured for Property Code %1$s", propertyDataType));
			return null;
		}
	}	
}
