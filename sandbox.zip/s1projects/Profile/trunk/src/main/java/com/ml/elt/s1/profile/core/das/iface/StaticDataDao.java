/**
 * 
 */
package com.ml.elt.s1.profile.core.das.iface;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.platform.container.service.das.Dao;
import com.ml.elt.s1.profile.core.sdo.StaticData;

/**
 * @author mpatel12
 *
 */
public interface StaticDataDao extends Dao {
	
	/**
	 * returns StaticData List
	 * @return StaticData
	 * @throws DataAccessException
	 */
	public List<StaticData> getAllStaticData() throws DASException;
	
	/**
	 * returns StaticData List
	 * @return StaticData
	 * @throws DataAccessException
	 */
	public List<StaticData> getStaticDataByPickerList(int pickerListId) throws DASException; 
}
