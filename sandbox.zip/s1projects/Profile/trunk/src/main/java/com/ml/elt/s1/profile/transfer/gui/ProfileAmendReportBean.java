package com.ml.elt.s1.profile.transfer.gui;

import java.io.Serializable;
import java.util.Date;

public class ProfileAmendReportBean implements Serializable {
	private static final long serialVersionUID = 2L;
	
	private String id;
	
	private String propertyCode;
	
	private String propDescription;
	
	private Long ruleId;
	
	private String value;
	
	private String oldValue;
	
	private String operationType;
	
	private String ruleOperationType;
	
	private Date updateTime;
	
	private String updateUser;
	
	private Boolean activeFlag;
	
	private String description;

	public Boolean getActiveFlag() {
		return activeFlag;
	}

	public void setActiveFlag(Boolean activeFlag) {
		this.activeFlag = activeFlag;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPropertyCode() {
		return propertyCode;
	}

	public void setPropertyCode(String propertyCode) {
		this.propertyCode = propertyCode;
	}

	public Long getRuleId() {
		return ruleId;
	}

	public void setRuleId(Long ruleId) {
		this.ruleId = ruleId;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getOperationType() {
		return operationType;
	}

	public void setOperationType(String operationType) {
		this.operationType = operationType;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public String toString () {
		StringBuilder builder = new StringBuilder ();
		if (propertyCode != null) {
			builder.append ("Property Code: ");
			builder.append (propertyCode);
			builder.append ("\n");
		}
		if (updateUser != null) {
			builder.append ("Update User: ");
			builder.append (updateUser);
			builder.append ("\n");
		}
		if (updateTime != null) {
			builder.append ("Update Time: ");
			builder.append (updateTime);
			builder.append ("\n");
		}
		if (operationType != null) {
			builder.append ("Operation Type: ");
			builder.append (operationType);
			builder.append ("\n");
		}
		if (value != null) {
			builder.append ("Value: ");
			builder.append (value);
			builder.append ("\n");
		}
		if (ruleId != null) {
			builder.append ("Rule Id: ");
			builder.append (ruleId);		
		}
		
		return builder.toString();
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getOldValue() {
		return oldValue;
	}

	public void setOldValue(String oldValue) {
		this.oldValue = oldValue;
	}

	public String getPropDescription() {
		return propDescription;
	}

	public void setPropDescription(String propDescription) {
		this.propDescription = propDescription;
	}

	public String getRuleOperationType() {
		return ruleOperationType;
	}

	public void setRuleOperationType(String ruleOperationType) {
		this.ruleOperationType = ruleOperationType;
	}
}
