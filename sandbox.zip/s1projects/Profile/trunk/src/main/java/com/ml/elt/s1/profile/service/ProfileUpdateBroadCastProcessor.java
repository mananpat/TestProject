package com.ml.elt.s1.profile.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ml.elt.s1.platform.container.ServiceContext;
import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.platform.container.service.MetaData;
import com.ml.elt.s1.platform.container.service.Request;
import com.ml.elt.s1.platform.container.service.Response;
import com.ml.elt.s1.platform.container.service.processor.MessageProcessor;
import com.ml.elt.s1.platform.plugins.connector.ems.OutputData;
import com.ml.elt.s1.profile.core.das.cache.ProfileCommandQuery;
import com.ml.elt.s1.profile.core.sdo.Application;
import com.ml.elt.s1.profile.intface.ProfileLifeCycle;
import com.ml.elt.s1.profile.transfer.gui.AppBean;
import com.ml.elt.s1.profile.transfer.gui.ContactBean;
import com.ml.elt.s1.profile.transfer.gui.ErrorBean;
import com.ml.elt.s1.profile.transfer.gui.ProfileDataList;
import com.ml.elt.s1.profile.transfer.gui.RuleBean;
import com.ml.elt.s1.profile.util.ProfileApplicationConstant;
import com.ml.elt.s1.profile.util.ProfileOperation;

/**
 * @author mpatel12
 *
 * Processor to check if any Profile Data updates are performed by Profile Hander Service 
 * and appropriately send broad cast message to Booking Nodes.
 * 
 */
public class ProfileUpdateBroadCastProcessor implements MessageProcessor {

	private static Log log = LogFactory.getLog(ProfileUpdateBroadCastProcessor.class);
	
	private ProfileLifeCycle prfLifeCycle;	
	
	public ProfileLifeCycle getPrfLifeCycle() {
		return prfLifeCycle;
	}

	public void setPrfLifeCycle(ProfileLifeCycle prfLifeCycle) {
		this.prfLifeCycle = prfLifeCycle;
	}
	
	public Response process(Request request) {
		if (request == null)
		return new Response();
	
		Object[] objs = request.getData();
		if(objs == null)
			return new Response();
		
		try 
		{
			ServiceContext context = request.getServiceContext();		
			String command = (String)context.getMetaData().getData(ProfileApplicationConstant.CONTEXT_COMMAND);	
			String appCode = (String)context.getMetaData().getData(ProfileApplicationConstant.CONTEXT_APP_CODE);	
			String userId = (String)context.getMetaData().getData(ProfileApplicationConstant.CONTEXT_USERID);
			
			if(command.equalsIgnoreCase(ProfileOperation.PRF_CREATE_OR_UPDATE)||
			   command.equalsIgnoreCase(ProfileOperation.PRF_SAVE_CONTACT) ||
			   command.equalsIgnoreCase(ProfileOperation.PRF_RELOAD)){
			   log.info("ProfileUpdateBroadCastFilter: Profile update message for "+ appCode + ", Request Type: " + command + ", UserId: "+userId);
				
			   if(command.equalsIgnoreCase(ProfileOperation.PRF_RELOAD))					
					dispatch(objs, context, appCode, ProfileOperation.PRF_RELOAD);				
			   else
			   {
					if(isRefreshByApplicationRequired(objs))
						dispatch(objs, context, appCode, ProfileOperation.PRF_REFRESH);
					else 			
						dispatch(objs, context, appCode, command);					
				}
			  }			
		}
		catch (Throwable  e) {
			log.error("One or more error(s) occurred in ProfileUpdateBroadCastFilter. Due to: ", e);
			return handleDefaultException(objs, e);
		}	
	
		return new Response();
	}
	
	private Response handleDefaultException(Object[] array, Throwable e) {
		String message = "One or more error(s) occurred in ProfileUpdateBroadCastFilter";
		
		Response finalResponse = new Response();				
		ProfileDataList prfResponse = new ProfileDataList ();
		List<ErrorBean> errors = new ArrayList<ErrorBean> ();
		ErrorBean bean = new ErrorBean ();
		bean.setRuleId(0);
		bean.setErrorMsg(message);
		errors.add(bean);		
		prfResponse.setErrors(errors);
		finalResponse.addOutput(prfResponse);
		return finalResponse;
	}
	
	/*
	 * Check if any Profile Data Update requires Profile Refresh by Application
	 */
	private boolean isRefreshByApplicationRequired(Object[] objs){
		boolean isRefreshByApp = false;		
		for(Object obj : objs){	
			ProfileDataList  inProfileList = null;					
			if(obj instanceof ProfileDataList){
				inProfileList = (ProfileDataList)obj;
				if(inProfileList.getRules() != null && !inProfileList.getRules().isEmpty()){
					for(RuleBean ruleBean : inProfileList.getRules()){
						if((ruleBean.getErrors() == null || ruleBean.getErrors().isEmpty()) && ProfileOperation.PRF_REFRESH.equals(ruleBean.getCommand())){
							isRefreshByApp = true;
							break;
						}
					}
				}		
			}
		}
		
		return isRefreshByApp;
	}
		
	/*
	 * Dispatch update event to Profile Client Nodes
	 */
	private void dispatch(Object[] objs, ServiceContext context, String appCode, String command){
		
		if(appCode == null || objs == null)
			return;
		
		Application application  = null;
		try {
			application = ProfileCommandQuery.getApplicationByCode(appCode);
			if(application == null)
				log.warn("Unable to get Application by appCode: "+appCode);	
				
		} catch (DASException dasEx) {
			log.warn("Unable to get Application by appCode: "+appCode,dasEx);
		}
		
		for(Object obj : objs){	
			ProfileDataList  inProfileList = null;					
			if(obj instanceof ProfileDataList)
				inProfileList = (ProfileDataList) obj;
				
			if(command.equals(ProfileOperation.PRF_CREATE_OR_UPDATE) || command.equals(ProfileOperation.PRF_SAVE_CONTACT)){
				List<RuleBean> outRuleBean = getValidRuleBeansForReponse(inProfileList);
				List<ContactBean> outContactBean = getValidContactBeansForReponse(inProfileList);
				if(outRuleBean == null && outContactBean == null)
					return;
				
		    	Response resp = new Response();	    	
				AppBean appBean = new AppBean ();
				appBean.setApplicationCode(appCode);
				appBean.setDescription(application.getDescription());
				
				List<AppBean> appList = new ArrayList<AppBean>();
				appList.add(appBean);
				
				ProfileDataList outProfileList = new ProfileDataList();			
				outProfileList.setApps(appList);
				
				//add valid contact and rules to response to broadcast
				if(outRuleBean != null)
					outProfileList.setRules(outRuleBean);
				if(outContactBean != null)
					outProfileList.setContacts(outContactBean);
				
				OutputData result = new OutputData();
				MetaData resultMetadata = new MetaData();
				resultMetadata.setMap(context.getMetaData().getMap());
	
				result.setMetaData(resultMetadata);				
				result.setData(outProfileList);
				
				resp.addOutput(result);
				
				context.getMetaData().setData(ProfileApplicationConstant.CONTEXT_BROADCAST_COMMAND, command );
				context.dispatch(resp);
	    	}
			else if(command.equals(ProfileOperation.PRF_REFRESH)){			
				
				List<RuleBean> outRuleBean = getValidRuleBeansForReponse(inProfileList);			
				if(outRuleBean == null)
					return;
							
				Response resp = new Response();	    	
				AppBean appBean = new AppBean ();
				appBean.setApplicationCode(appCode);
				appBean.setDescription(application.getDescription());
				
				ProfileDataList outProfileList = new ProfileDataList();
				List<AppBean> appList = new ArrayList<AppBean>();
				appList.add(appBean);
				outProfileList.setApps(appList);
						
				//add valid contact and rules to response to broadcast
				if(outRuleBean != null)
					outProfileList.setRules(outRuleBean);			
				
				OutputData result = new OutputData();
				MetaData resultMetadata = new MetaData();
				resultMetadata.setMap(context.getMetaData().getMap());			
				result.setMetaData(resultMetadata);				
				result.setData(outProfileList);			
				resp.addOutput(result);
				context.getMetaData().setData(ProfileApplicationConstant.CONTEXT_BROADCAST_COMMAND, ProfileOperation.PRF_REFRESH );
				context.dispatch(resp);
			}				
			else if(command.equals(ProfileOperation.PRF_RELOAD))
			{			
				Response resp = new Response();	    	
				AppBean appBean = new AppBean ();
				appBean.setApplicationCode(appCode);
				appBean.setDescription(application.getDescription());
							
				ProfileDataList outProfileList = new ProfileDataList();
				List<AppBean> appList = new ArrayList<AppBean>();
				appList.add(appBean);
				outProfileList.setApps(appList);
				
				OutputData result = new OutputData();
				MetaData resultMetadata = new MetaData();
				resultMetadata.setMap(context.getMetaData().getMap());			
				result.setMetaData(resultMetadata);				
				result.setData(outProfileList);			
				resp.addOutput(result);
				
				context.getMetaData().setData(ProfileApplicationConstant.CONTEXT_BROADCAST_COMMAND,ProfileOperation.PRF_RELOAD );
				context.dispatch(resp);
			}		
		}
    }
	
	private List<RuleBean> getValidRuleBeansForReponse(ProfileDataList inProfileList){
		List<RuleBean> returnList = null;
		if(inProfileList != null && inProfileList.getRules() != null && !inProfileList.getRules().isEmpty()){
			returnList = new ArrayList<RuleBean>();
			for(RuleBean rule : inProfileList.getRules()){
				if(rule.getErrors() == null || rule.getErrors().isEmpty())
					returnList.add(rule);				
			}
			
			if(returnList.isEmpty())
				returnList = null;
		}	
		
		return returnList;
	}	
	
	private List<ContactBean> getValidContactBeansForReponse(ProfileDataList inProfileList){
		List<ContactBean> returnList = null;
		if(inProfileList != null && inProfileList.getContacts() != null && !inProfileList.getContacts().isEmpty()){
			returnList = new ArrayList<ContactBean>();
			for(ContactBean contact : inProfileList.getContacts()){
				if(contact.getErrors() == null || contact.getErrors().isEmpty())
					returnList.add(contact);				
			}
			
			if(returnList.isEmpty())
				returnList = null;
		}		
		return returnList;
	}	
}