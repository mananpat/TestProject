/**
 * 
 */
package com.ml.elt.s1.profile.core.sdo;

import java.util.Date;

import com.ml.elt.s1.platform.plugins.cache.CacheObject;

abstract public class ProfileDomainObject extends CacheObject {
	
	private static final long serialVersionUID = 1L;
	
	private String createUser;
	private String updateUser;
	private Date createDateTime;
	private Date updateDateTime;
	
	public ProfileDomainObject() {
		super();
		Date date =new Date();
		setCreateDateTime(date);
		setUpdateDateTime(date);
	}
	
	public String getCreateUser() {
		return createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public String getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}

	public Date getCreateDateTime() {
		return createDateTime;
	}

	public void setCreateDateTime(Date createDateTime) {
		this.createDateTime = createDateTime;
	}

	public Date getUpdateDateTime() {
		return updateDateTime;
	}

	public void setUpdateDateTime(Date updateDateTime) {
		this.updateDateTime = updateDateTime;
	}	
}
