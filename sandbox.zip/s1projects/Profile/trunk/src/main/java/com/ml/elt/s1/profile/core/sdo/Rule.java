package com.ml.elt.s1.profile.core.sdo;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.ml.elt.s1.platform.container.exception.DASException;
import com.ml.elt.s1.platform.plugins.cache.PrimaryKey;
import com.ml.elt.s1.profile.core.das.cache.ProfileCommandQuery;
import com.ml.elt.s1.profile.core.enums.Action;
import com.ml.elt.s1.profile.exception.ProfileException;
import com.ml.elt.s1.profile.intface.DataConverter;
import com.ml.elt.s1.profile.transfer.gui.RuleBean;


/**
 * Rule 
 */
public class Rule  extends ProfileDomainObject  {
	
	private static Log log = LogFactory.getLog(Rule.class);

	private static final long serialVersionUID = 1L;

	private Long id;
	private Long applicationId;
	private Boolean activeFlag;
	private String description;
	private Action action;
	private Integer activeValue;

	private Map<String, List<Object>> targetRuleProperty;
	
	public Rule() {
		targetRuleProperty = new HashMap<String, List<Object>>();
	}

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}
	
	public Boolean getActiveFlag() {
		return this.activeFlag;
	}

	public void setActiveFlag(Boolean activeFlag) {
		this.activeFlag = activeFlag;
		if(activeFlag!=null && activeFlag){
			setActiveValue(1);
		}else
			setActiveValue(0);
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	public Action getAction() {
		return action;
	}

	public void setAction(Action action) {
		this.action = action;
	}
	
	
	public Integer getActiveValue() {
		return activeValue;
	}

	public void setActiveValue(Integer activeValue) {
		this.activeValue = activeValue;
	}

	/* (non-Javadoc)
	 * @see com.ml.elt.s1.platform.plugins.cache.CacheObject#getCacheKey()
	 */
	@Override
	public String getCacheKey(){
		if (primaryKey == null && this.id != null){
			Object[] key = new Object[]{this.id};
			primaryKey = new PrimaryKey(key, this.getClass(), true, true);
		}
		return primaryKey.getStringKey();
	}
	
	public static String getCacheKey(Long id){
		Object[] key = new Object[]{id};
		PrimaryKey primaryKey = new PrimaryKey(key, Rule.class, true, true);
		return primaryKey.getStringKey();
	}
	
	@SuppressWarnings("unchecked")
	public void addTargetProperty (RuleProperty ruleProperty, DataConverter converter) throws DASException {
		Long propertyId = ruleProperty.getPropertyId();
		Property property = ProfileCommandQuery.getPropertyById(propertyId);
		if(property != null){
			String rulePropertyCode =property.getPropertyCode();
			String dataType = property.getDataType();			
			
			if(rulePropertyCode!=null && dataType!=null ){
				if (!this.targetRuleProperty.containsKey(rulePropertyCode)) {
					Object value = ruleProperty.getValue();
					try {
						value = converter.convert(value, dataType);
					} catch (ProfileException e) {
						log.error(e.getMessage());
					}
					if (value != null) {
						List<Object> valList = new ArrayList<Object> ();
						valList.add(value);
						this.targetRuleProperty.put(rulePropertyCode, valList);
					}
				}
				else {
					Object value = this.targetRuleProperty.get(rulePropertyCode);
					List<Object> valList = (List<Object>)value;
					Object tmp = ruleProperty.getValue();
					try {
						tmp = converter.convert(tmp, dataType);
					} catch (ProfileException e) {
						log.error(e.getMessage());
					}
					if (tmp != null)
						valList.add(tmp);
				}
			}
		} else {
			throw new DASException("Unable to find property with Id:"+propertyId);
		}
	}
	
	public List<String> retrieveDisplayStrings (String propCode, String dataType, DataConverter converter) {
		List<String> retValues = new ArrayList<String> ();
		List<Object> propValues = this.targetRuleProperty.get(propCode);
		if (propValues == null)
			return retValues;
		for (Object val : propValues)				
			retValues.add(converter.getDisplayString(val, dataType));		
		return retValues;
	}

	public Map<String, List<Object>> getTargetRuleProperty() {
		return targetRuleProperty;
	}
	
	public void clearTargetRuleProperty() {
		if(targetRuleProperty != null)
			targetRuleProperty.clear();
	}

	
	public boolean equals(RuleBean ruleBean) {
		if(ruleBean == null || !(ruleBean instanceof RuleBean))
			return false;

		if(this.id.equals(ruleBean.getRuleId()) && 
           this.activeFlag.equals(ruleBean.getActive()) && 	        
	       ((this.description == null && ruleBean.getDescription() == null) ||
	        ( this.description != null && ruleBean.getDescription() != null && this.description.equals(ruleBean.getDescription()))))
			return true;
		else
			return false;
	}
	
	public String getPath(){
		return getClass().getPackage().getName().replace('.', '_')
		+ "/" + getClass().getSimpleName()
		+ "/" + getApplicationId();
	}

}
