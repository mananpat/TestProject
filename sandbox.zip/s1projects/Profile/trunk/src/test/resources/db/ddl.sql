create table PRF_PICKER (
	PICKER_TYPE VARCHAR(32) not null,
	PICKER_DB VARCHAR(16) not null,
	PICKER_SQL VARCHAR(1024) not null, constraint PRF_PICKER_PK primary key (PICKER_TYPE) ); 

create table PRF_COLLECTION_ITEM (
	COLLECTION_ID INTEGER not null,
	ITEM_KEY VARCHAR(32) not null,
	ITEM_VALUE VARCHAR(1024) not null, constraint PRF_COLLECTION_ITEM_PK primary key (COLLECTION_ID, ITEM_KEY) ); 

create table PRF_PROPERTY (
	PROPERTY_CODE VARCHAR(32) not null,
	DESCRIPTION VARCHAR(256) null,
	DATA_TYPE VARCHAR(64) not null, constraint PRF_PROPERTY_PK primary key (PROPERTY_CODE) ); 

create table PRF_CRITERIA_CATEGORY (
	CRITERIA_CATEGORY_CODE VARCHAR(32) not null,
	DESCRIPTION VARCHAR(256) null,
	VIEW_ORDER INTEGER null, constraint PRF_CRITERIA_CATEGORY_PK primary key (CRITERIA_CATEGORY_CODE) ); 

create table PRF_TARGET_CATEGORY (
	TARGET_CATEGORY_CODE VARCHAR(32) not null,
	DESCRIPTION VARCHAR(256) null,
	CRITERIA_CATEGORY_CODE VARCHAR(32) not null, constraint PRF_TARGET_CATEGORY_PK primary key (TARGET_CATEGORY_CODE) ); 

create table PRF_ENUM (
	ENUM_ID INTEGER not null,
	ENUM_TYPE VARCHAR(64) not null,
	DESCRIPTION VARCHAR(256) null, constraint PRF_ENUM_PK primary key (ENUM_ID) ); 

create table PRF_ENUM_ITEM (
	ENUM_ID INTEGER not null,
	ENUM_ITEM_ID VARCHAR(32) not null,
	RAM_ITEM_ID VARCHAR(32) null,
	DESCRIPTION VARCHAR(256) null, constraint PRF_ENUM_ITEM_PK primary key (ENUM_ITEM_ID, ENUM_ID) ); 

create table PRF_CRITERIA_PROPERTY (
	CRITERIA_CATEGORY_CODE VARCHAR(32) not null,
	PROPERTY_CODE VARCHAR(32) not null,
	PROPERTY_ORDER INTEGER not null,
	VIEW_WIDTH INTEGER null, constraint PRF_CRITERIA_PROPERTY_PK primary key (CRITERIA_CATEGORY_CODE, PROPERTY_CODE) ); 

create table PRF_TARGET_PROPERTY (
	TARGET_CATEGORY_CODE VARCHAR(16) not null,
	PROPERTY_CODE VARCHAR(32) not null,
	REQUIRED_FLAG CHAR(1) default 'N' not null, constraint PRF_TARG_PROP_REQ_FLAG_CHK check (REQUIRED_FLAG in ('N','Y')) , constraint PRF_TARGET_PROPERTY_PK primary key (TARGET_CATEGORY_CODE, PROPERTY_CODE) ); 

create table PRF_RULE (
	RULE_ID INTEGER not null,
	DESCRIPTION VARCHAR(256) null,
	CRITERIA_CATEGORY_CODE VARCHAR(32) null,
	ACTIVE_FLAG CHAR(1) not null, constraint PRF_RULEACTIVE_FLAG_CHK check (ACTIVE_FLAG in ('N','Y')) , constraint PRF_RULE_PK primary key (RULE_ID) ); 

create table PRF_RULE_PROPERTY (
	RULE_ID INTEGER not null,
	PROPERTY_CODE VARCHAR(32) not null,
	"VALUE" VARCHAR(1024) not null, constraint PRF_RULE_PROPERTY_PK primary key (RULE_ID, PROPERTY_CODE) ); 

create unique index PRF_ENUM_U1 on PRF_ENUM (
	ENUM_TYPE); 


alter table PRF_TARGET_CATEGORY
	add constraint PRF_CRIT_CAT_TARG_CAT_FK1 foreign key (
		CRITERIA_CATEGORY_CODE)
	 references PRF_CRITERIA_CATEGORY (
		CRITERIA_CATEGORY_CODE); 

alter table PRF_ENUM_ITEM
	add constraint PRF_ENUM_ENUM_ITEM_FK1 foreign key (
		ENUM_ID)
	 references PRF_ENUM (
		ENUM_ID); 

alter table PRF_CRITERIA_PROPERTY
	add constraint PRF_CRIT_CAT_CRIT_PROP_FK1 foreign key (
		CRITERIA_CATEGORY_CODE)
	 references PRF_CRITERIA_CATEGORY (
		CRITERIA_CATEGORY_CODE); 

alter table PRF_CRITERIA_PROPERTY
	add constraint PRF_PROP_CRIT_PROP_FK1 foreign key (
		PROPERTY_CODE)
	 references PRF_PROPERTY (
		PROPERTY_CODE); 

alter table PRF_TARGET_PROPERTY
	add constraint PRF_TARG_CAT_TARG_PROP_FK1 foreign key (
		TARGET_CATEGORY_CODE)
	 references PRF_TARGET_CATEGORY (
		TARGET_CATEGORY_CODE); 

alter table PRF_TARGET_PROPERTY
	add constraint PRF_PROP_TARG_PROP_FK1 foreign key (
		PROPERTY_CODE)
	 references PRF_PROPERTY (
		PROPERTY_CODE); 

alter table PRF_RULE
	add constraint PRF_CRIT_CAT_RULE_FK1 foreign key (
		CRITERIA_CATEGORY_CODE)
	 references PRF_CRITERIA_CATEGORY (
		CRITERIA_CATEGORY_CODE); 

alter table PRF_RULE_PROPERTY
	add constraint PRF_RULE_RULE_CRIT_PROP_FK1 foreign key (
		RULE_ID)
	 references PRF_RULE (
		RULE_ID); 

alter table PRF_RULE_PROPERTY
	add constraint PRF_PRO_RULE_PROP_FK1 foreign key (
		PROPERTY_CODE)
	 references PRF_PROPERTY (
		PROPERTY_CODE); 
