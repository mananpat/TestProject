/**
 * 
 */
package com.ml.elt.s1.profile;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;

import com.ml.elt.s1.profile.exception.ProfileException;
import com.ml.elt.s1.profile.impl.ProfileProcessorImpl;
import com.ml.elt.s1.profile.intface.ProfileProcessor;

/**
 * @author schuz
 *
 */
public class ProfileProcessorTest {
	static final Logger log = Logger.getLogger(ProfileProcessorTest.class);
	private ProfileProcessor proc;


	@Before
	public void setUp() throws Exception {
		proc = new ProfileProcessorImpl();
		proc.reloadProfile(true);
	}

	@Test
	public void testMetaDataDiscovery() throws ProfileException {
		log.info("******** testMetaDataDiscovery() *********");
		List<String> critProps = proc.getCriteriaProperties("CC1");
		assertTrue(critProps.containsAll(Arrays.asList(new String[]{ "CP1", "CP2", "CP3" })));
		assertFalse(critProps.contains("CP4"));
		// Should change to List<String> in 1.1 release
		Map<String, Boolean> targProps = proc.getTargetProperties("CC1");
		assertTrue(targProps.keySet().containsAll(Arrays.asList(new String[]{ "TP1", "TP2", "TP3", "TP4", "TP5" })));
		assertFalse(targProps.keySet().contains("TP6"));
	}

	@Test
	public void testSimpleRule() throws ProfileException {
		log.info("******** testSimpleRule() *********");
		Map<String, Object> crit = new HashMap<String, Object>();
		crit.put("CP1", "CP1V1");
		Map<String, List<Object>> targ = proc.getTargetValues("CC1", crit).propertyValues;
		assertTrue(targ.containsKey("TP1"));
		assertEquals(targ.get("TP1").get(0), "TP1V1");
	}

	@Test
	public void testDefaultLogic() throws ProfileException {
		log.info("******** testDefaultLogic() *********");
		Map<String, Object> crit = new HashMap<String, Object>();
		crit.put("CP1", "CP1V1");
		crit.put("CP2", "CP2V2");
		Map<String, List<Object>> targ = proc.getTargetValues("CC1", crit).propertyValues;
		assertTrue(targ.keySet().containsAll(Arrays.asList(new String[]{ "TP1", "TP2", "TP3" })));
		assertFalse(targ.keySet().contains("TP4"));
		assertEquals(targ.get("TP1").get(0), "TP1V1");
		assertEquals(targ.get("TP2").get(0), "TP2V2");
		assertEquals(targ.get("TP3").get(0), "TP3V2");
	}

	@Test
	public void testComplexCriteriaLogic() throws ProfileException {
		log.info("******** testComplexCriteriaLogic() *********");
		Map<String, Object> crit = new HashMap<String, Object>();
		crit.put("CP1", "CP1V3");
		crit.put("CP2", "CP2V2");
		Map<String, List<Object>> targ = proc.getTargetValues("CC1", crit).propertyValues;
		assertTrue(targ.keySet().containsAll(Arrays.asList(new String[]{ "TP1", "TP2", "TP3", "TP4", "TP5" })));
		assertFalse(targ.keySet().contains("TP6"));
		assertEquals(targ.get("TP1").get(0), "TP1V4");
		assertEquals(targ.get("TP2").get(0), "TP2V4");
		assertEquals(targ.get("TP3").get(0), "TP3V2");
		assertEquals(targ.get("TP4").get(0), "TP4V3");
		assertEquals(targ.get("TP5").get(0), "TP5V4");
	}

	@Test
	public void testTargetCollection() throws ProfileException {
		log.info("******** testTargetCollection() *********");
		Map<String, Object> crit = new HashMap<String, Object>();
		crit.put("CP1", "CP1V10");
		crit.put("CP2", "CP2V10");
		Map<String, List<Object>> targ = proc.getTargetValues("CC1", crit).propertyValues;
		assertTrue(targ.keySet().contains("TP10"));
		
	}
}
