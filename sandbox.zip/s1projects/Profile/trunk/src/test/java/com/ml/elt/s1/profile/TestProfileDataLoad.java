/**
 * 
 */
package com.ml.elt.s1.profile;

import java.util.Date;

import junit.framework.TestCase;

import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ml.elt.s1.profile.core.das.iface.ApplicationDao;
import com.ml.elt.s1.profile.core.das.iface.ContactDao;
import com.ml.elt.s1.profile.core.das.iface.LookupPropertiesDao;
import com.ml.elt.s1.profile.core.das.iface.PickerListDao;
import com.ml.elt.s1.profile.core.das.iface.PropertyDao;
import com.ml.elt.s1.profile.core.das.iface.PropertyGroupDao;
import com.ml.elt.s1.profile.core.das.iface.PropertyGroupMappingDao;
import com.ml.elt.s1.profile.core.das.iface.RuleDao;
import com.ml.elt.s1.profile.core.das.iface.RulePropertyDao;
import com.ml.elt.s1.profile.core.sdo.Contact;

/**
 * @author mpatel12
 *
 */
public class TestProfileDataLoad extends TestCase {

	private static final Logger log = Logger.getLogger(TestProfileDataLoad.class);
	
	private static ClassPathXmlApplicationContext context = null;

	public void setUp() throws Exception {
		log.info("Inside setUp.");
		
		if(context == null){
			context = new ClassPathXmlApplicationContext(new String[] { "env_ram_db.xml" });				
			ApplicationDao appDao = (ApplicationDao) context.getBean("ramApplicationDao");		
			assertNotNull(appDao);
			
			LookupPropertiesDao lookupPropertiesDao = (LookupPropertiesDao)  context.getBean("ramLookupPropertyDao");
			assertNotNull(lookupPropertiesDao);
			
			RuleDao ruleDao = (RuleDao) context.getBean("ramRuleDao");
			assertNotNull(ruleDao);
			
			RulePropertyDao rulePropertyDao = (RulePropertyDao) context.getBean("ramRulePropertyDao");
			assertNotNull(rulePropertyDao);
			
			PropertyGroupDao propertyGroupDao = (PropertyGroupDao)  context.getBean("ramPropertyGroupDao");
			assertNotNull(propertyGroupDao);
					
			PropertyGroupMappingDao propertyGroupMappingDao = (PropertyGroupMappingDao) context.getBean("ramPropertyGroupMappingDao");
			assertNotNull(propertyGroupMappingDao);
					
			PropertyDao ramPropertyDao = (PropertyDao)  context.getBean("ramPropertyDao");
			assertNotNull(ramPropertyDao);
			
			PickerListDao pickerListDao = (PickerListDao)  context.getBean("ramPickerListDao");
			assertNotNull(pickerListDao);
			
			ContactDao contactDao = (ContactDao) context.getBean("ramContactDao");	
			assertNotNull(contactDao);
			
			/*ProfileAmendReportDao  profileAmendDao = (ProfileAmendReportDao) context.getBean("ramContactDao");	
			assertNotNull(profileAmendDao);
			List<ProfileAmendReportBean> profileBeanList = profileAmendDao.getAllProfileAmendReport();
			System.out.println(profileBeanList); */
		}
				
		log.info("End of setUp.Dao");
	}
	
	public void tearDown() throws Exception 
	{
		log.info("Inside TearDown.Dao");
	}
	
	
	
	/*
	public void testApplicationData() throws Exception 
	{
		try
		{			
			ApplicationDao appDao = (ApplicationDao) context.getBean("ramApplicationDao");		
			assertNotNull(appDao);
			List<Application> list = appDao.getAllApplications();
			log.info("Application List size : " + list.size());
			log.info("Result Data \n:" + list);
						
			log.info("Application By Id list");
			List<String> appCodeList =  new ArrayList<String>();
			appCodeList.add("SWAP_TRADE");
			list = appDao.getApplicationsByAppCode(appCodeList);
			log.info("Application List size : " + list.size());
		}
		catch(Throwable t){
			System.out.println(t);
		}
	}
	*/
	/*
	public void testRuleData() throws Exception 
	{
		try
		{
			RuleDao ruleDao = (RuleDao) context.getBean("ramRuleDao");
			assertNotNull(ruleDao);
			
			List<Rule> list = ruleDao.getAllRules();
			log.info("Rule List size : " + list.size());
			log.info("Result Data \n:" + list);
		}
		catch(Throwable t){
			System.out.println(t);
		}
	}*/	
	
	/*
	public void testRulePropertyData() throws Exception 
	{
		try
		{
			RulePropertyDao rulePropertyDao = (RulePropertyDao) context.getBean("ramRulePropertyDao");
			assertNotNull(rulePropertyDao);			
			List<RuleProperty> list = rulePropertyDao.getAllRuleProperties();
			log.info("Rule Property List size : " + list.size());		
		}
		catch(Throwable t){
			System.out.println(t);
		}
	}
	*/
	
	/*
	public void testLookupPropertiesData() throws Exception 
	{
		try
		{
			LookupPropertiesDao lookupPropertiesDao = (LookupPropertiesDao)  context.getBean("ramLookupPropertyDao");
			assertNotNull(lookupPropertiesDao);			
			List<LookupProperties> list = lookupPropertiesDao.getAllLookupProperties();
			log.info("LookupProperties List size : " + list.size());		
		}
		catch(Throwable t){
			System.out.println(t);
		}
	}
	/*
	
	/*
	public void testPropertyGroupData() throws Exception 
	{
		try
		{
			PropertyGroupDao propertyGroupDao = (PropertyGroupDao)  context.getBean("ramPropertyGroupDao");
			assertNotNull(propertyGroupDao);			
			List<PropertyGroup> list = propertyGroupDao.getAllPropertyGroups();
			log.info("PropertyGroup List size : " + list.size());		
		}
		catch(Throwable t){
			System.out.println(t);
		}
	}
	
	/*
	public void testPropertyGroupMappingData() throws Exception 
	{
		try
		{
			PropertyGroupMappingDao propertyGroupMappingDao = (PropertyGroupMappingDao) context.getBean("ramPropertyGroupMappingDao");
			assertNotNull(propertyGroupMappingDao);			
			List<PropertyGroupMapping> list = propertyGroupMappingDao.getAllPropertyGroupMappings();
			log.info("PropertyGroupMapping List size : " + list.size());		
		}
		catch(Throwable t){
			log.error(t);
		}
	}
	*/
	/*
	public void testPropertyData() throws Exception 
	{
		try
		{
			PropertyDao propertyDao = (PropertyDao) context.getBean("ramPropertyDao");
			assertNotNull(propertyDao);			
			List<Property> list = propertyDao.getAllProperties();
			log.info("Property List size : " + list.size());		
		}
		catch(Throwable t){
			System.out.println(t);
		}
	}*/
	
	public void testSaveContact() throws Exception 
	{
		log.info("Inside testSaveContact" );	
		try
		{
			
//			ContactDao dao = (ContactDao) context.getBean("ramContactDao");	
//			assertNotNull(dao);
//			
//			Contact c = new Contact();
//			c.setFirstName("Manan");
//			c.setMiddleName("S");
//			c.setLastName("Patel");
//			c.setRole("DEV");
//			c.setCompany("ML");
//			c.setEmail("manan_patel@ml.com");
//			c.setRecipientType("TO");
//			c.setCreateUser("mpatle12");	
//			c.setCreateDateTime(new Date());	
//			c.setUpdateUser("mpatle12");	
//			c.setUpdateDateTime(new Date());			
//			Long contactId = dao.saveContact(c);
//			log.info("New Contact Created with Id: " + contactId);
//						
//			Contact loadedContact = dao.getContactById(contactId);
//			assertNotNull(loadedContact.getId());			
//			assertEquals(loadedContact.getFirstName(), c.getFirstName());
//			assertEquals(loadedContact.getMiddleName(), c.getMiddleName());
//			assertEquals(loadedContact.getLastName(), c.getLastName());
//			assertEquals(loadedContact.getCreateUser(), c.getCreateUser());
//			
//			log.info("Saving the Contact");
//			String updatedName = "Test 1";
//			loadedContact.setFirstName(updatedName);
//			dao.updateContact(loadedContact);
//			loadedContact = dao.getContactById(contactId);
//			assertEquals(loadedContact.getId().longValue(), contactId.longValue());
//			assertEquals(loadedContact.getFirstName(), updatedName);
			
			log.info("Test Successful");		
		}
		catch(Throwable t){
			log.error("Error is savecontact testcase" , t);
		}
		
		log.info("End of testSaveContact" );
	}
	
	/*
	public void testPickerListData() throws Exception 
	{
		try
		{
			PickerListDao pickerListDao = (PickerListDao)  context.getBean("ramPickerListDao");
			assertNotNull(pickerListDao);		
			List<Pickerlist> list = pickerListDao.getAllPickerlist();
			log.info("Pickerlist size : " + list.size());		
		}
		catch(Throwable t){
			System.out.println(t);
		}
	}
	
	
	public void testStaticDataData() throws Exception 
	{
		try
		{
			StaticDataDao staticDataDao = (StaticDataDao)  context.getBean("ramStaticDataDao");
			assertNotNull(staticDataDao);		
			List<StaticData> list = staticDataDao.getAllStaticData();
			log.info("StaticData size : " + list.size());		
		}
		catch(Throwable t){
			System.out.println(t);
		}
	} */

	
}
