/**
 * 
 */
package com.ml.elt.s1.profile;

import junit.framework.TestCase;

import org.apache.log4j.Logger;

import com.ml.elt.s1.platform.plugins.boot.DefaultConfiguration;
import com.ml.elt.s1.platform.plugins.convertor.xml2object.Converter;
import com.ml.elt.s1.profile.core.sdo.Rule;
import com.ml.elt.s1.profile.impl.ProfileIndex;
import com.ml.elt.s1.profile.impl.ProfileLoader;
import com.ml.elt.s1.profile.intface.ProfileLifeCycle;

/**
 * @author mpatel12
 *
 */
public class TestRuleReload extends TestCase {

	private static final Logger log = Logger.getLogger(TestRuleReload.class);
	
	private ProfileLifeCycle profileLifeCycleImpl = null;
	private Converter converter = null;	
	private static final String applicationCode = "SWAP_TRADE";
	
	public void setUp() throws Exception {
		log.info("Inside setUp.");		
		DefaultConfiguration.loadBeanDefinitionsFromClasspath("profile_configuration_test.xml");		
		profileLifeCycleImpl = (ProfileLifeCycle) DefaultConfiguration.getBean("ProfileLifeCycle");
		converter = (Converter) DefaultConfiguration.getBean("XMLConverter");
		
		assertNotNull(profileLifeCycleImpl);
		assertNotNull(converter);
		
		log.info("End of setUp.");
	}
	
	public void tearDown() throws Exception 
	{
		log.info("Inside TearDown.");
	}
	
	private void loadProfile() throws Exception {		
		log.info("starting profile reload.");		
		long startTime = System.currentTimeMillis();		
		profileLifeCycleImpl.rebuildProfileIndex();
		log.info("Done Profile Loading. Time taken is: " + (System.currentTimeMillis()-startTime) + " ms");		
	}
	
	public void testProfileIndex()throws Exception {
		
		loadProfile();
		
		Long ruleId = new Long(2038);
		String propertyCode = "PC_TYPE";
		
		//1
		log.info("Rule from ProfileIndex before any update");
		checkRuleInProfileIndex(ruleId, propertyCode);
		
		//2. update using profileservice
		
		log.info("Rule from ProfileIndex after any update");
		checkRuleInProfileIndex(ruleId, propertyCode);
		
		log.info("Reloading Rule");
		long startTime = System.currentTimeMillis(); 
		profileLifeCycleImpl.rebuildProfileIndex(applicationCode, ruleId);
		//profileLifeCycleImpl.reloadProfile(false, applicationCode, true);	
		long endTime = System.currentTimeMillis();
		System.out.println("total time taken for getProfileRulesByRuleId: " + (endTime-startTime) + " ms");
		
		log.info("Rule from ProfileIndex after reload");
		checkRuleInProfileIndex(ruleId, propertyCode);
		
		
		log.info("End of testProfileIndex");
	}
	
	/*
	 * Check rule in Profile Index
	 */
	public void checkRuleInProfileIndex(Long ruleId, String propertyCode){
		log.info("Inside checkRuleInProfileIndex");		
		ProfileIndex profileIndex = ProfileLoader.getInstance().getProfileIndex();		
		Rule ruleFromIndex = profileIndex.getRuleMap().get(ruleId);
		log.info("Rule Id "+ ruleId + " from Profile Index hashcode: " + ruleFromIndex.hashCode());		
//		Set<RuleProperty> rulePropertySet = ruleFromIndex.getRuleProperties();		
//		for (Iterator<RuleProperty> iterator = rulePropertySet.iterator(); iterator.hasNext();) {
//			RuleProperty ruleProperty = (RuleProperty) iterator.next();
//			Property property = ruleProperty.getProperty();
//			if(property.getPropertyCode().equals(propertyCode)){
//				log.info("Rule Update By: " + ruleProperty.getUpdateUser() + " UpdateTime: " + ruleProperty.getUpdateDateTime() + " Property Code: " + property.getPropertyCode() + " Property Value: " + ruleProperty.getValue());
//				break;
//			}
//		}		
		log.info("End of checkRuleInProfileIndex");
	}
}
