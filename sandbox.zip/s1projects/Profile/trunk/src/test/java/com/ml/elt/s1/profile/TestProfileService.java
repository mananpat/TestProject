/**
 * 
 */
package com.ml.elt.s1.profile;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

import org.apache.log4j.Logger;
import org.junit.Test;

import com.ml.elt.s1.platform.plugins.boot.DefaultConfiguration;
import com.ml.elt.s1.platform.plugins.convertor.xml2object.Converter;
import com.ml.elt.s1.profile.core.sdo.Property;
import com.ml.elt.s1.profile.core.sdo.Rule;
import com.ml.elt.s1.profile.exception.ProfileException;
import com.ml.elt.s1.profile.impl.LookupResultSet;
import com.ml.elt.s1.profile.impl.ProfileIndex;
import com.ml.elt.s1.profile.impl.ProfileLoader;
import com.ml.elt.s1.profile.impl.ProfileProcessorImpl;
import com.ml.elt.s1.profile.intface.ProfileLifeCycle;
import com.ml.elt.s1.profile.transfer.gui.ProfileDataList;
import com.ml.elt.s1.profile.transfer.gui.PropertyBean;
import com.ml.elt.s1.profile.transfer.gui.RuleBean;

/**
 * @author mpatel12
 *
 */
public class TestProfileService extends TestCase {

	private static final Logger log = Logger.getLogger(TestProfileService.class);
	
	private ProfileLifeCycle profileLifeCycleImpl = null;
	private Converter converter = null;
	private static boolean isProfileLoaded = false;
	private static final String applicationCode = "SWAP_TRADE";
	
	public void setUp() throws Exception {
		log.info("Inside setUp.");		
		DefaultConfiguration.loadBeanDefinitionsFromClasspath("profile_configuration_test.xml");		
		profileLifeCycleImpl = (ProfileLifeCycle) DefaultConfiguration.getBean("ProfileLifeCycle");
		converter = (Converter) DefaultConfiguration.getBean("XMLConverter");		
		assertNotNull(profileLifeCycleImpl);
		assertNotNull(converter);
		
		log.info("End of setUp.");
	}
	
	public void tearDown() throws Exception 
	{
		log.info("Inside TearDown.");
	}			
	
	private void loadProfile() throws Exception {		
		log.info("starting profile reload.");		
		long startTime = System.currentTimeMillis();		
		profileLifeCycleImpl.rebuildProfileIndex();
		log.info("Profile reload done. Time taken is: " + (System.currentTimeMillis()-startTime) + " ms");		
	}
	
	/*
	 * Test case to update update Rule first. Check ProfileIndex, reload rule and update ProfileIndex.
	 */
	public void testRuleUpdate() {
		log.info("Test testLoadRuleById");
		try
		{	
			loadProfile();
			
			Long ruleId = new Long(2038);
			String propertyCode = "PC_TYPE";
			
			log.info("Before Update checking ProfileIndex Rule");
			checkRuleInProfileIndex(ruleId, propertyCode);
			
			log.info("Update Rule");			
			saveOrUpdateProfiles();			
		
			log.info("After object update. checking ProfileIndex Rule ");
			checkRuleInProfileIndex(ruleId, propertyCode);
			
			log.info("Rule loading from database after update:");			
//			Session session = ProfileSessionFactory.getInstance().getCurrentSession();	
//			Rule existingRule = (Rule) session.get(Rule.class, ruleId);			
//			session.evict(existingRule);
//			log.info("Rule evicted Id "+ existingRule.getId() + " hashcode: " + existingRule.hashCode());
//						
//			log.info("After eviction. checking ProfileIndex Rule ");
//			checkRuleInProfileIndex(ruleId, propertyCode);
//			
//			long startTime = System.currentTimeMillis();
//			Rule loadedRule = (Rule) session.get(Rule.class, ruleId);
//			session.refresh(loadedRule);
//			ProfileSessionFactory.getInstance().closeCurrentSession();			
//			log.info("Rule loaded Id "+ loadedRule.getId() + " hashcode: " + loadedRule.hashCode());
//			
//			Set<RuleProperty> ruleLoadedPropertySet = loadedRule.getRuleProperties();			
//			for (Iterator<RuleProperty> iterator = ruleLoadedPropertySet.iterator(); iterator.hasNext();) {
//				RuleProperty ruleProperty = (RuleProperty) iterator.next();
//				Property property = ruleProperty.getProperty();
//				if(property.getPropertyCode().equals(propertyCode)){
//					log.info("Loaded Rule Update By: " + ruleProperty.getUpdateUser() + " UpdateTime: " + ruleProperty.getUpdateDateTime() + " Property Code: " + property.getPropertyCode() + " Property Value: " + ruleProperty.getValue());
//					break;
//				}
//			}
				
			
			log.info("Before reloading profile");
			checkRuleInProfileIndex(ruleId, propertyCode);
			/*
			log.info("Reloading profile !!!");
			reloadProfileRule(ruleId, propertyCode);
			
			log.info("After reloading profile");
			checkRuleInProfileIndex(ruleId, propertyCode);
			*/
			/*			
			Map<String, Object> criteriaValues = new HashMap<String, Object>();
			criteriaValues.put("clientShortName", "ING_CAP_MKTS");
			criteriaValues.put("underlyingInstId", "IBM   .1");
			criteriaValues.put("TRADE_SETL_CCY", "USD");
			criteriaValues.put("underCcy", "USD");
			criteriaValues.put("UNDERMARKET", "US");
			criteriaValues.put("UNDERREGION", "North America");
			
			ProfileProcessorImpl profile = new ProfileProcessorImpl();
			LookupResultSet lookupResultSet = profile.getTargetValues(applicationCode, criteriaValues);
			for (Iterator<String> iterator = lookupResultSet.propertyValues.keySet().iterator(); iterator.hasNext();) {
				String property = (String) iterator.next();
				if(property.equals(propertyCode)){
					List<Object> objList = lookupResultSet.propertyValues.get(property);
					log.info("lookupResultSet Property: " + property + " objList: " + objList.toString());
					break;
				}
			}*/
		}
		catch (Exception ex) {
			log.error("Error in testLoadRuleById "+ ex.getMessage());
		}
		log.info("End of testLoadRuleById.");
	}
	
	/*
	 * Test case to update update Rule first. Check ProfileIndex, reload rule and update ProfileIndex.
	 */
	public void _testRuleUpdateAndBuildProfileIndex() {
		log.info("Test testRuleUpdateAndBuildProfileIndex");
		try
		{	
			Long ruleId = new Long(2038);
			String propertyCode = "PC_TYPE";
			//String propertyCode = "LONG_COMMISSION";
			
			log.info("Rule from ProfileIndex before any update");
			checkRuleInProfileIndex(ruleId, propertyCode);
			
			log.info("Update Rule");			
			saveOrUpdateProfiles();			
			
			log.info("TestProfileServic. starting profile reload.");	
			
			long startTime = System.currentTimeMillis();		
			profileLifeCycleImpl.rebuildProfileIndex(applicationCode, ruleId);
			log.info("TestProfileService -> Profile reload done. Time taken is: " + (System.currentTimeMillis()-startTime) + " ms");
			
			log.info("Rule from ProfileIndex After Rule update");
			checkRuleInProfileIndex(ruleId, propertyCode);
						
			log.info("Look values for Swap Trade Profile");
			
			Map<String, Object> criteriaValues = new HashMap<String, Object>();
			criteriaValues.put("clientShortName", "ING_CAP_MKTS");
			criteriaValues.put("underlyingInstId", "IBM   .1");
			criteriaValues.put("TRADE_SETL_CCY", "USD");
			/*
			criteriaValues.put("underCcy", "USD");
			criteriaValues.put("UNDERMARKET", "US");*/
			
			/*
			 * <incomingTrade><clientShortName></clientShortName><underlyingInstId></underlyingInstId><settleCurrency>USD</settleCurrency>
			 * <quantity>1000</quantity><price>100</price><tradeDate>2008-11-06</tradeDate><transactionType>TR</transactionType></incomingTrade>
			 * 
			 */
			
			
			//criteriaValues.put(propertyCode.UNDERL_EXCH_ID, trade.getUnderlyingExchangeId());
			ProfileProcessorImpl profile = new ProfileProcessorImpl();
			LookupResultSet lookupResultSet = profile.getTargetValues(applicationCode, criteriaValues);
			for (Iterator<String> iterator = lookupResultSet.propertyValues.keySet().iterator(); iterator.hasNext();) {
				String property = (String) iterator.next();
				List<Object> objList = lookupResultSet.propertyValues.get(property);
				log.info("lookupResultSet Property: " + property + " objList: " + objList.toString());
			}
			
			/*
			log.info("Rule loaded Id "+ loadedRule.getId() + " hashcode: " + loadedRule.hashCode());			
			Set<RuleProperty> ruleLoadedPropertySet = loadedRule.getRuleProperties();			
			for (Iterator<RuleProperty> iterator = ruleLoadedPropertySet.iterator(); iterator.hasNext();) {
				RuleProperty ruleProperty = (RuleProperty) iterator.next();
				Property property = ruleProperty.getProperty();
				if(property.getPropertyCode().equals(propertyCode)){
					log.info("Loaded Rule Update By: " + ruleProperty.getUpdateUser() + " UpdateTime: " + ruleProperty.getUpdateTs() + " Property Code: " + property.getPropertyCode() + " Property Value: " + ruleProperty.getValue());
					break;
				}
			}
			
			log.info("Updated ProfileIndex with loaded Rule");
			updateProfileIndex(ruleId, loadedRule);
			
			log.info("Rule from ProfileIndex before any updating ProfileIndex");
			checkRuleInProfileIndex(ruleId, propertyCode);
			*/
			
			
		}
		catch (Exception ex) {
			log.error("Error in testLoadRuleById "+ ex.getMessage());
		}
		log.info("End of testLoadRuleById.");
	}
	
	
	/*
	 * Check rule in Profile Index
	 */
	public void checkRuleInProfileIndex(Long ruleId, String propertyCode){
		log.info("Inside checkRuleInProfileIndex");		
		ProfileIndex profileIndex = ProfileLoader.getInstance().getProfileIndex();		
		Rule ruleFromIndex = profileIndex.getRuleMap().get(ruleId);
		log.info("Rule Id "+ ruleId + " from Profile Index hashcode: " + ruleFromIndex.hashCode());		
//		Set<RuleProperty> rulePropertySet = ruleFromIndex.getRuleProperties();		
//		for (Iterator<RuleProperty> iterator = rulePropertySet.iterator(); iterator.hasNext();) {
//			RuleProperty ruleProperty = (RuleProperty) iterator.next();
//			Property property = ruleProperty.getProperty();
//			if(property.getPropertyCode().equals(propertyCode)){
//				log.info("Rule Update By: " + ruleProperty.getUpdateUser() + " UpdateTime: " + ruleProperty.getUpdateDateTime() + " Property Code: " + property.getPropertyCode() + " Property Value: " + ruleProperty.getValue());
//				break;
//			}
//		}		
		log.info("End of checkRuleInProfileIndex");
	}
	
	
	/*
	 * Update ProfileIndex Map after the update to individual Rule/Rule Property is made.
	 */
	public void updateProfileIndex(Long ruleId, Rule loadedRule){
		log.info("Inside updateProfileIndex");
		if(loadedRule instanceof Rule){		
			ProfileIndex profileIndex = ProfileLoader.getInstance().getProfileIndex();
			Map<Long, Rule> rulesMap = profileIndex.getRuleMap();		
			if(rulesMap.get(ruleId) != null)
				rulesMap.remove(ruleId);
					
			rulesMap.put(ruleId, loadedRule);
		}
		
		log.info("End of updateProfileIndex");
	}
	
	public void _testProfileIndexUpdate() {
//		log.info("Test testProfileIndexUpdate");
//		try
//		{
//			SessionFactory sessionFactory = (SessionFactory)DefaultConfiguration.getBean("profileSessionFactory");
//			Session session = sessionFactory.openSession();		
//			Transaction tx = session.beginTransaction();
//			
//			long startTime = System.currentTimeMillis();
//			Rule rule = (Rule) session.get(Rule.class, new Long(2030));
//			log.info("Profile Rule loaded in " + (System.currentTimeMillis()-startTime) + " ms");
//			
//			log.info("Loaded Rule Id: " + rule.getId());
////			Set<RuleProperty> rulePropertySet = rule.getRuleProperties();
////			log.info("Size of RuleProperty: " + rulePropertySet.size());
//			
//		}
//		catch (Exception ex) {
//			log.error("Error in testProfileIndexUpdate "+ ex.getMessage());
//		}
//		log.info("End of testProfileIndexUpdate.");
	}
	
	public void _testProfileReload() {
		log.info("Test testProfileReload");
		try
		{
			log.info("starting profile reload.");		
			long startTime = System.currentTimeMillis();

			profileLifeCycleImpl.rebuildProfileIndex(applicationCode);
			log.info("Profile Reload Completed for  "+ applicationCode + " in " + (System.currentTimeMillis()-startTime) + " ms");
		}
		catch (Exception ex) {
			log.error("Error in testProfileReload "+ ex.getMessage());
		}
		log.info("End of testProfileReload.");
	}
	
	
	@SuppressWarnings("unchecked")
	public void _testSessionFactoryCreation() throws ProfileException 
	{
		/*log.info("Inside testSessionFactoryCreation.");		
		long startTime = System.currentTimeMillis();		
		profileLifeCycleImpl.reloadProfile(false,"SWAP_TRADE", true);
		log.info("Profile loaded.. Time taken is: " + (System.currentTimeMillis()-startTime) + " ms");*/
		
				
		//profileLifeCycle.reloadProfile(false,"SWAP_TRADE", true);
		
		//List<RuleBean> rulesList = prfFromGui.getRules();		
		//ArrayList<PropertyBean> propsBean = new ArrayList<PropertyBean> ();
		//for (RuleBean rule : rulesList) {
		
		//RuleBean rule =  profileLifeCycle.getProfileById("SWAP_TRADE", new Long(2030));
		
		/*RuleProperty ruleProperty = rule.getProfileProperty()
		ArrayList<PropertyBean> propertyBeanList = new ArrayList<PropertyBean> ();*/
		//if (rule != null) {
				//propsBean.addAll(rule.getProfileProperty ());
				//log.info("Printing Rules \n");				
				//ruletoString(rule);				
				//propertyBeanList.addAll(rule.getProfileProperty ());
				//propertyBeanToString(propertyBeanList);
		//}
		
		Rule rule = ProfileLoader.getInstance().getProfileIndex().getRuleMap().get(new Long(2030));
		log.info("size of TargetProperty: " + rule.getTargetRuleProperty().size());
		printTargetRuleProperty(rule.getTargetRuleProperty());
		
		for (String propertyCode : rule.getTargetRuleProperty().keySet()) {
			Property prop = ProfileLoader.getInstance().getProfileIndex().getPropertyMap().get(propertyCode);
			propertyToString(prop);
		}
		
		/*for (RuleProperty ruleProperties : rule.getRuleProperties()) {
			//Property prop = ProfileLoader.getInstance().getProfileIndex().getPropertyMap().get(propertyCode);
			log.info("RuleProperty: ID : " + ruleProperties.getId() + " Description: " + ruleProperties.getProperty().getDescription());
		}*/
		
		
		log.info("End of testSessionFactoryCreation.");
	}
	
	@Test
	@SuppressWarnings("unchecked")
	public void _testGetProfileRulesByRuleId() {
		log.info("Inside testGetProfileRulesByRuleId.");
		try 
		{	
			/*log.info("Inside testSessionFactoryCreation.");		
			long startTime = System.currentTimeMillis();		
			profileLifeCycleImpl.reloadProfile(true);
			log.info("Profile loaded.. Time taken is: " + (System.currentTimeMillis()-startTime) + " ms");*/
			
			/*RuleBean requestBean = new RuleBean();
			requestBean.setRuleId(new Long(2038));
			*/
			
			
			/*Map<String, Object> criteriaValues = new HashMap<String, Object> ();
			criteriaValues.put("clientShortName", "ING_CAP_MKTS");
			criteriaValues.put("underCcy", "USD");
			criteriaValues.put("settleOffset", 3);
			criteriaValues.put("underlyingInstId", "ABC   .1");
			criteriaValues.put("underModel", "STK");*/
			
			long startTime = System.currentTimeMillis(); 
			RuleBean ruleBean = profileLifeCycleImpl.getProfileById(applicationCode, new Long(2038));
			long endTime = System.currentTimeMillis();
			System.out.println("total time taken for getProfileRulesByRuleId: " + (endTime-startTime) + " ms");
			
			assertNotNull(ruleBean);
			
			/*List<PropertyBean> propertyBeanList = ruleBean.getProfileProperty();
			if(propertyBeanList != null && !propertyBeanList.isEmpty()){
				for (PropertyBean propertyBean : propertyBeanList) {
					log.info(propertyBean.toString());
				}
			}*/
			
			for(int i =0 ; i<10; i++){
				log.info("Making Second Call ");
				ruleBean = null;
				startTime = System.currentTimeMillis();				
				ruleBean = profileLifeCycleImpl.getProfileById(applicationCode, new Long(2038));
				endTime = System.currentTimeMillis();				
				System.out.println("Total time taken for getProfileRulesByRuleId: " + (endTime-startTime) + " ms");
				log.info("Rule property size: " + ruleBean.getProfileProperty().size());
			}
		}
		catch (Exception ex) {
			log.error("Error in testGetProfileRulesByRuleId "+ ex.getMessage());
		}
		
		log.info("End of testGetProfileRulesByRuleId.");
	}
	
	
	@Test
	@SuppressWarnings("unchecked")
	public void saveOrUpdateProfiles() {
		log.info("Inside saveOrUpdateProfiles.");
		try 
		{	
			
			Long ruleId = new Long(2038);
			/*String propertyCode = "underlyingInstId";
			String propertyDesc = "Und. Security";
			String newValue = "MSFT .1";
			String groupCode = null;*/
			
			String propertyCode = "PC_TYPE";
			String propertyDesc = "PC Type";
			String groupCode = "CHARGES_DEFLT";
			String newValue = "SOFT";
			
			ProfileDataList requestDataList = new ProfileDataList();
			requestDataList.setHostName("ENYCWBEQDBFY8Z");
			requestDataList.setUserId("mpatel12");
			requestDataList.setCreatedTime(new Date());
			List<RuleBean> ruleBeanList = new ArrayList<RuleBean>();
			RuleBean ruleBean = new RuleBean();
			ruleBean.setRuleId(ruleId);
			ruleBean.setActive(true);		
			 
			PropertyBean pbean = new PropertyBean(ruleId, propertyCode , newValue, groupCode ,propertyDesc);
			List<PropertyBean> profilePropertyList = new ArrayList<PropertyBean>();
			profilePropertyList.add(pbean);
			ruleBean.setProfileProperty(profilePropertyList);
			ruleBeanList.add(ruleBean);
			requestDataList.setRules(ruleBeanList);
						
			long startTime = System.currentTimeMillis(); 
			ProfileDataList returnDataList = profileLifeCycleImpl.saveProfile(applicationCode, requestDataList);
			long endTime = System.currentTimeMillis();
			log.info("Total time taken for saveOrUpdateProfiles: " + (endTime-startTime) + " ms");
			
		}	
		catch (Exception ex) {
			log.error("Error in saveOrUpdateProfiles "+ ex.getMessage());
		}
		
		log.info("End of saveOrUpdateProfiles.");
	}
	
	private void reloadProfileRule(Long ruleId, String propertyCode){
		log.info("Before ProfileIndexBuilt");
		checkRuleInProfileIndex(ruleId, propertyCode);
		
		try{
			profileLifeCycleImpl.rebuildProfileIndex(applicationCode, ruleId);
			//prfLifeCycle.reloadProfile(false, appCode, true);	
		}
		catch(Throwable t){
			log.error("exception in reload ", t);
		}								
	
		log.info("After ProfileIndexBuilt");
		checkRuleInProfileIndex(ruleId, propertyCode);
	}
	private String getPropertyValueForProfile(String applicationCode, Long ruleId, String propertyCode){
		try
		{
			long startTime = System.currentTimeMillis(); 
			RuleBean ruleBean = profileLifeCycleImpl.getProfileById(applicationCode, ruleId);
			long endTime = System.currentTimeMillis();
			System.out.println("total time taken for getProfileRulesByRuleId: " + (endTime-startTime) + " ms");
			assertNotNull(ruleBean);
			
			List<PropertyBean> propertyBeanList = ruleBean.getProfileProperty();
			if(propertyBeanList != null && !propertyBeanList.isEmpty()){
				for (PropertyBean propertyBean : propertyBeanList) {
					if(propertyBean.getPropertyCode().equals(propertyCode))
						return propertyBean.getValue();
				}
			}
		}
		catch(ProfileException pe){
			log.error("Error in getPropertyValueForProfile "+ pe.getMessage());
		}
		
		return null;
	}
	
	
	private void ruleToString(RuleBean rule){
		StringBuffer sf = new StringBuffer();
		sf.append("[Rule Id: " + rule.getRuleId() + " Description: " + rule.getDescription() + " Active Flag: " + rule.getActive() + " Update user: " + rule.getUpdateUser() + " update time: "+ rule.getUpdateTime());
		log.info(sf.toString());
	}
	
	private void propertyToString(Property property){
		StringBuffer sf = new StringBuffer();
		sf.append("[Property Id: " + property.getId() + " propertyCode: " + property.getPropertyCode() + "]");
		log.info(sf.toString());
	}	
	
	private void printTargetRuleProperty(Map<String, List<Object>> targetRuleProperty)
	{
		for (Iterator<String> iterator = targetRuleProperty.keySet().iterator(); iterator.hasNext();) {
			String propertyName = (String) iterator.next();
			List<Object> list = targetRuleProperty.get(propertyName);
			log.info("TargetProperty: PropertyName : " + propertyName + " Value List: " + list );
		}
	}
	
	
	@SuppressWarnings("unchecked")
	public synchronized void reloadProfile() throws ProfileException {
//		log.info("Reloading Profile and building indexes");
//		
//		SessionFactory sessionFactory = (SessionFactory)DefaultConfiguration.getBean("profileSessionFactory");
//		Session session = sessionFactory.openSession();		
//		//Transaction tx = session.beginTransaction();
//		
//		Criteria criteria = session.createCriteria(Application.class);
//		criteria.addOrder(Order.asc("viewOrder"));
//		//criteria.add(Restrictions.in("applicationCode", ProfileServiceUtil.getApplicationsToLoad()));
//		//log.info("Application to be loaded "  + ProfileServiceUtil.getApplicationsToLoad());
//		
//		List<Application> appList = criteria.list();
//		ProfileIndex profileIndex = new ProfileIndex();
//		
//		for (Application app : appList) {
//			profileIndex.getApplicationMap().put(app.getApplicationCode(), app);	
//		}
//			
//		log.info("Done reloading Profile and building indexes");
	}
}
