/**
 * 
 */
package com.ml.elt.s1.profile;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.Map;

import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;

import com.ml.elt.s1.profile.core.sdo.Application;
import com.ml.elt.s1.profile.core.sdo.Rule;
import com.ml.elt.s1.profile.exception.ProfileException;
import com.ml.elt.s1.profile.impl.ProfileLoader;


/**
 * @author schuz
 *
 */
public class DataLoadTest {
	private static final Logger log = Logger.getLogger(DataLoadTest.class);
	private ProfileLoader profileLoader;

	@Before
	public void setUp() throws Exception {
		long startTime = System.currentTimeMillis();
		System.out.println("Profile loading started---------------");
		profileLoader = ProfileLoader.getInstance();
		profileLoader.reloadProfile();
		System.out.println("Profile loaded.. Time taken is: " + (System.currentTimeMillis()-startTime)/1000 + " Seconds");
	}

	@Test
	@SuppressWarnings("unchecked")
	public final void testDataLoad() throws ProfileException {
		
		Map<String, Application> critCategMap = profileLoader.getProfileIndex().getApplicationMap();
		assertNotNull(critCategMap);
		assertTrue(critCategMap.containsKey("CC1"));
		Application critCateg = critCategMap.get("CC1");
//		assertNotNull(critCateg.getLookupPropertieses());
//		assertTrue(critCateg.getLookupPropertieses().size() == 3);
		int count = 0;
//		for(LookupProperties critProp: critCateg.getLookupPropertieses() ){
//			if(count ==0){
//				assertTrue(critProp.getProperty().getPropertyCode().equals("CP1"));
//				assertTrue(critProp.getLookupRank() == 1);
//			}
//			if(count ==1){
//				assertTrue(critProp.getProperty().getPropertyCode().equals("CP2"));
//				assertTrue(critProp.getLookupRank() == 2);
//			}
//			count ++;
//		}
		Map<Long, Rule> ruleMap = profileLoader.getProfileIndex().getRuleMap();
		assertNotNull(ruleMap);
		assertTrue(ruleMap.containsKey(662L));
		Rule rule = ruleMap.get(662L);
//		for(RuleProperty ruleProp:rule.getRuleProperties() ){
//			if(ruleProp.getProperty().getPropertyCode().equalsIgnoreCase("CP2"))
//				assertTrue(ruleProp.getValue().equals("CP2V10"));
//			if(ruleProp.getProperty().getPropertyCode().equalsIgnoreCase("TP10")){
//				assertNotNull(ruleProp.getValue());
//				assertTrue(ruleProp.getValue().equals("2") || ruleProp.getValue().equals("3"));
//			}
//		}
		log.info("testDataLoad - success");
	}
	

}
